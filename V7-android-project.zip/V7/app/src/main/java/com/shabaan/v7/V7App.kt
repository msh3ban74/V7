package com.shabaan.v7

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import coil.disk.DiskCache
import coil.memory.MemoryCache
import coil.request.CachePolicy
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.asCoroutineDispatcher
import java.util.concurrent.Executors

@HiltAndroidApp
class V7App : Application(), ImageLoaderFactory {

    override fun onCreate() {
        super.onCreate()
        createMusicChannel()
    }

    private fun createMusicChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                getString(R.string.music_channel_id),
                getString(R.string.music_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                setShowBadge(false)
                setSound(null, null)
            }
            mgr.createNotificationChannel(channel)
        }
    }

    /**
     * A single, app-wide ImageLoader tuned for buttery thumbnail scrolling:
     *
     *  - Large in-memory cache (30% of app heap) so re-scrolling is instant.
     *  - 250 MB persistent disk cache → thumbnails survive app restarts, so the
     *    grid is never "reloaded" again after the first time.
     *  - Both caches enabled READ+WRITE explicitly.
     *  - A dedicated thread pool sized to the CPU so video-frame decoding never
     *    blocks the UI and many tiles decode in parallel.
     *  - crossfade kept short (180 ms) so images settle fast, not lazily.
     *
     * Per-request sizing (downsampling to the tile size) is done at the call
     * site via the `thumb()` helper in ThumbnailRequest.kt — that is what stops
     * full-resolution photos from being decoded into tiny cells.
     */
    override fun newImageLoader(): ImageLoader {
        val cores = Runtime.getRuntime().availableProcessors().coerceIn(2, 8)
        val decodeExecutor = Executors.newFixedThreadPool(cores)

        return ImageLoader.Builder(this)
            .components {
                add(VideoFrameDecoder.Factory())
                add(com.shabaan.v7.util.MediaStoreThumbnailFetcher.Factory(this@V7App))
                add(com.shabaan.v7.util.VaultThumbnailFetcher.Factory(this@V7App))
            }
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.40)
                    .strongReferencesEnabled(true)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("v7_image_cache"))
                    .maxSizeBytes(250L * 1024 * 1024)
                    .build()
            }
            .memoryCachePolicy(CachePolicy.ENABLED)
            .diskCachePolicy(CachePolicy.ENABLED)
            .networkCachePolicy(CachePolicy.DISABLED) // all media is local
            .respectCacheHeaders(false)
            .crossfade(180)
            .dispatcher(
                decodeExecutor.asCoroutineDispatcher()
            )
            .build()
    }
}

package com.shabaan.v7.util

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Reads WhatsApp statuses that WhatsApp has cached on local storage, and lets the
 * user save a copy to their gallery. WhatsApp stores viewed statuses (temporarily)
 * under the app's media folder:
 *
 *   Android/media/com.whatsapp/WhatsApp/Media/.Statuses
 *
 * Since Android 11 the `Android/media/...` tree is still reachable by an app that
 * holds All-files access (MANAGE_EXTERNAL_STORAGE) — which V7 already requests —
 * unlike `Android/data/...` which is fully sandboxed. The user must have opened
 * the status in WhatsApp first (that's when WhatsApp writes the file locally).
 */
data class StatusFile(
    val path: String,
    val name: String,
    val isVideo: Boolean,
    val lastModified: Long
)

object WhatsAppStatus {

    /** Candidate status directories across WhatsApp variants + old/new layouts. */
    private fun candidateDirs(): List<File> {
        val ext = Environment.getExternalStorageDirectory()
        return listOf(
            // Newer layout (Android 11+)
            File(ext, "Android/media/com.whatsapp/WhatsApp/Media/.Statuses"),
            File(ext, "Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses"),
            // Older layout (pre-Android 11)
            File(ext, "WhatsApp/Media/.Statuses"),
            File(ext, "WhatsApp Business/Media/.Statuses")
        )
    }

    /** True if status files are reachable via direct file access. */
    fun isAccessible(): Boolean = candidateDirs().any { it.exists() && it.canRead() }

    /** Lists current statuses (images + videos), newest first. */
    suspend fun list(context: Context): List<StatusFile> = withContext(Dispatchers.IO) {
        // Strategy 1: direct file access (works when All-files access is granted).
        val direct = listDirect()
        if (direct.isNotEmpty()) return@withContext direct
        // Strategy 2: MediaStore query (works on devices where the .Statuses
        // folder is indexed but direct File access is blocked).
        listViaMediaStore(context)
    }

    /** Direct file-system read of the .Statuses folders. */
    private fun listDirect(): List<StatusFile> {
        val out = ArrayList<StatusFile>()
        for (dir in candidateDirs()) {
            if (!dir.exists() || !dir.isDirectory) continue
            val files = dir.listFiles() ?: continue
            for (f in files) {
                if (!f.isFile) continue
                val lower = f.name.lowercase()
                val isVideo = lower.endsWith(".mp4")
                val isImage = lower.endsWith(".jpg") || lower.endsWith(".jpeg") ||
                    lower.endsWith(".png") || lower.endsWith(".webp")
                if (!isVideo && !isImage) continue
                out.add(
                    StatusFile(
                        path = f.absolutePath,
                        name = f.name,
                        isVideo = isVideo,
                        lastModified = f.lastModified()
                    )
                )
            }
        }
        return out.sortedByDescending { it.lastModified }
    }

    /**
     * Fallback: query MediaStore for files whose path contains ".Statuses".
     * Some OEM builds index the WhatsApp media folder even when a raw File
     * listing is denied, so this catches those devices.
     */
    private fun listViaMediaStore(context: Context): List<StatusFile> {
        val out = ArrayList<StatusFile>()
        try {
            val collection = MediaStore.Files.getContentUri("external")
            val projection = arrayOf(
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DISPLAY_NAME,
                MediaStore.Files.FileColumns.DATA,
                MediaStore.Files.FileColumns.MIME_TYPE,
                MediaStore.Files.FileColumns.DATE_MODIFIED
            )
            val selection = "${MediaStore.Files.FileColumns.DATA} LIKE ?"
            val args = arrayOf("%.Statuses%")
            val sort = "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
            context.contentResolver.query(collection, projection, selection, args, sort)?.use { c ->
                val dataIdx = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA)
                val nameIdx = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val mimeIdx = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE)
                val dateIdx = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED)
                while (c.moveToNext()) {
                    val path = c.getString(dataIdx) ?: continue
                    val name = c.getString(nameIdx) ?: path.substringAfterLast('/')
                    val mime = c.getString(mimeIdx) ?: ""
                    val lower = name.lowercase()
                    val isVideo = mime.startsWith("video") || lower.endsWith(".mp4")
                    val isImage = mime.startsWith("image") || lower.endsWith(".jpg") ||
                        lower.endsWith(".jpeg") || lower.endsWith(".png") || lower.endsWith(".webp")
                    if (!isVideo && !isImage) continue
                    if (lower == ".nomedia") continue
                    out.add(
                        StatusFile(
                            path = path,
                            name = name,
                            isVideo = isVideo,
                            lastModified = c.getLong(dateIdx) * 1000L
                        )
                    )
                }
            }
        } catch (_: Exception) { /* ignore — return whatever we have */ }
        return out
    }

    /** Saves a status to the public gallery (Pictures/V7 Status or Movies/V7 Status). */
    suspend fun saveToGallery(context: Context, status: StatusFile): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, status.name)
                    if (status.isVideo) {
                        put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            put(
                                MediaStore.MediaColumns.RELATIVE_PATH,
                                Environment.DIRECTORY_MOVIES + "/V7 Status"
                            )
                        }
                    } else {
                        put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            put(
                                MediaStore.MediaColumns.RELATIVE_PATH,
                                Environment.DIRECTORY_PICTURES + "/V7 Status"
                            )
                        }
                    }
                }
                val collection = if (status.isVideo) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                        MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                        MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                }
                val item = resolver.insert(collection, values) ?: return@withContext false
                resolver.openOutputStream(item)?.use { os ->
                    // Try direct file read first; if blocked, resolve via MediaStore.
                    val src = File(status.path)
                    if (src.exists() && src.canRead()) {
                        src.inputStream().use { it.copyTo(os) }
                    } else {
                        val srcUri = findContentUri(context, status) ?: return@withContext false
                        resolver.openInputStream(srcUri)?.use { it.copyTo(os) }
                            ?: return@withContext false
                    }
                } ?: return@withContext false
                true
            } catch (e: Exception) {
                false
            }
        }

    /** Resolves a MediaStore content URI for a status file by its path. */
    private fun findContentUri(context: Context, status: StatusFile): android.net.Uri? {
        return try {
            val collection = MediaStore.Files.getContentUri("external")
            val projection = arrayOf(MediaStore.Files.FileColumns._ID)
            val selection = "${MediaStore.Files.FileColumns.DATA} = ?"
            context.contentResolver.query(
                collection, projection, selection, arrayOf(status.path), null
            )?.use { c ->
                if (c.moveToFirst()) {
                    val id = c.getLong(c.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID))
                    android.content.ContentUris.withAppendedId(collection, id)
                } else null
            }
        } catch (_: Exception) { null }
    }
}

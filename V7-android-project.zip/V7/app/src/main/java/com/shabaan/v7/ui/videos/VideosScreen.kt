package com.shabaan.v7.ui.videos

import android.content.Intent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material.icons.outlined.Slideshow
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.shabaan.v7.data.model.MediaItem
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.shabaan.v7.ui.components.*
import com.shabaan.v7.util.SettingsStore
import com.shabaan.v7.util.SortBy
import com.shabaan.v7.util.SortOrder

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class)
@Composable
fun VideosScreen(
    onOpenPlayer: (Int) -> Unit,
    onOpenReels: (Int) -> Unit,
    vm: VideosViewModel = hiltViewModel()
) {
    val perms = rememberMediaPermissions()
    val state by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val settings = remember { SettingsStore(ctx) }
    var sortBy by remember { mutableStateOf(settings.sortBy) }
    var sortOrder by remember { mutableStateOf(settings.sortOrder) }

    // System delete-request launcher (Android 11+ scoped storage)
    val deleteLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.StartIntentSenderForResult()
    ) { vm.refreshAfterDelete() }

    fun requestDelete(uris: List<android.net.Uri>) {
        if (uris.isEmpty()) { vm.refreshAfterDelete(); return }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            val pi = android.provider.MediaStore.createDeleteRequest(ctx.contentResolver, uris)
            deleteLauncher.launch(
                androidx.activity.result.IntentSenderRequest.Builder(pi.intentSender).build()
            )
        } else {
            // Pre-11: best effort direct delete
            uris.forEach { runCatching { ctx.contentResolver.delete(it, null, null) } }
            vm.refreshAfterDelete()
        }
    }

    LaunchedEffect(perms.allPermissionsGranted) {
        if (perms.allPermissionsGranted) vm.ensureLoaded()
    }

    Column(Modifier.fillMaxSize()) {
        if (state.selectionMode) {
            SelectionTopBar(
                count = state.selection.size,
                totalAvailable = state.items.size,
                onClose = vm::clearSelection,
                onSelectAll = vm::selectAll,
                onShare = {
                    val items = vm.selectedItems()
                    if (items.isNotEmpty()) {
                        val send = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                            type = "video/*"
                            putParcelableArrayListExtra(
                                Intent.EXTRA_STREAM,
                                ArrayList(items.map { it.uri })
                            )
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        ctx.startActivity(Intent.createChooser(send, "Share videos"))
                    }
                    vm.clearSelection()
                },
                onVault = {
                    vm.moveSelectedToVault { uris -> requestDelete(uris) }
                },
                onDelete = {
                    vm.moveSelectedToTrash { uris -> requestDelete(uris) }
                }
            )
        } else {
            V7TopBar(
                title = "Videos",
                actions = {
                    IconButton(onClick = vm::toggleFavoritesOnly) {
                        Icon(
                            imageVector = if (state.showFavoritesOnly)
                                Icons.Outlined.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = "Favorites"
                        )
                    }
                    IconButton(onClick = {
                        if (state.items.isNotEmpty()) {
                            VideoSession.list = state.items
                            onOpenReels(0)
                        }
                    }) {
                        Icon(
                            Icons.Outlined.Slideshow,
                            contentDescription = "Reels"
                        )
                    }
                }
            )
            SearchSortBar(
                query = state.query,
                onQueryChange = vm::setQuery,
                sortBy = sortBy,
                sortOrder = sortOrder,
                onSortBy = { sb ->
                    sortBy = sb
                    settings.sortBy = sb
                    vm.load()
                },
                onToggleOrder = {
                    sortOrder = if (sortOrder == SortOrder.DESCENDING) SortOrder.ASCENDING else SortOrder.DESCENDING
                    settings.sortOrder = sortOrder
                    vm.load()
                }
            )
        }

        PermissionGate(perms) {
            when {
                state.loading -> ShimmerGrid(columns = 3)
                state.items.isEmpty() -> EmptyState(
                    text = if (state.query.isNotBlank()) "No matches"
                    else "No videos yet",
                    icon = Icons.Outlined.VideoLibrary,
                    subtitle = if (state.query.isNotBlank()) "Try a different search"
                    else "Videos on your device will appear here"
                )
                else -> {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(settings.gridSize),
                        contentPadding = PaddingValues(2.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        if (state.continueWatching.isNotEmpty() &&
                            !state.selectionMode && state.query.isBlank() && !state.showFavoritesOnly
                        ) {
                            item(span = { GridItemSpan(maxLineSpan) }) {
                                ContinueWatchingRow(
                                    cwList = state.continueWatching,
                                    onResume = { cw ->
                                        // Build a session list starting at the resumed video
                                        val full = state.items
                                        val idx = full.indexOfFirst { it.id == cw.item.id }
                                        if (idx >= 0) {
                                            VideoSession.list = full
                                            onOpenPlayer(idx)
                                        } else {
                                            VideoSession.list = listOf(cw.item)
                                            onOpenPlayer(0)
                                        }
                                    }
                                )
                            }
                        }
                        itemsIndexed(
                            state.items,
                            key = { _, it -> it.id },
                            contentType = { _, _ -> "video_cell" }
                        ) { index, item ->
                            VideoCell(
                                item = item,
                                index = index,
                                isFavorite = item.id in state.favorites,
                                selected = item.id in state.selection,
                                inSelectionMode = state.selectionMode,
                                onClick = {
                                    if (state.selectionMode) vm.toggleSelection(item.id)
                                    else {
                                        val idx = state.items.indexOf(item).coerceAtLeast(0)
                                        VideoSession.list = state.items
                                        onOpenPlayer(idx)
                                    }
                                },
                                onLongClick = { vm.startSelection(item.id) },
                                onFav = { vm.toggleFavorite(item.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalPermissionsApi::class)
@Composable
private fun VideoCell(
    item: MediaItem,
    index: Int,
    isFavorite: Boolean,
    selected: Boolean,
    inSelectionMode: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onFav: () -> Unit
) {
    Box(
        Modifier
            .padding(2.dp)
            .entrance(index)
            .aspectRatio(1f)
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        AsyncImage(
            model = rememberThumbRequest(data = item.uri, mediaId = item.id, sizePx = 400),
            contentDescription = item.name,
            modifier = Modifier.fillMaxSize(),
            contentScale = androidx.compose.ui.layout.ContentScale.Crop
        )
        DurationBadge(
            durationMs = item.duration,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(6.dp)
        )
        if (!inSelectionMode) {
            IconButton(
                onClick = onFav,
                modifier = Modifier.align(Alignment.TopEnd).size(34.dp)
            ) {
                Icon(
                    imageVector = if (isFavorite) Icons.Outlined.Favorite else Icons.Outlined.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (isFavorite) Color.White else Color.White.copy(alpha = 0.85f)
                )
            }
        }
        SelectionOverlay(selected = selected)
    }
}

/** Lightweight handoff for player without serializing the entire list across nav args. */
object VideoSession {
    @Volatile var list: List<MediaItem> = emptyList()
}

@Composable
private fun ContinueWatchingRow(
    cwList: List<ContinueWatching>,
    onResume: (ContinueWatching) -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp)) {
        Text(
            "Continue watching",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(start = 4.dp, bottom = 6.dp)
        )
        androidx.compose.foundation.lazy.LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            cwList.forEach { cw ->
                item(key = cw.item.id) {
                    ContinueWatchingCard(cw = cw, onClick = { onResume(cw) })
                }
            }
        }
    }
}

@Composable
private fun ContinueWatchingCard(cw: ContinueWatching, onClick: () -> Unit) {
    Column(
        Modifier
            .width(160.dp)
            .clip(RoundedCornerShape(10.dp))
            .premiumClick(onClick = onClick)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            AsyncImage(
                model = rememberThumbRequest(data = cw.item.uri, mediaId = cw.item.id, sizePx = 400),
                contentDescription = cw.item.name,
                modifier = Modifier.fillMaxSize(),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop
            )
            Icon(
                Icons.Rounded.PlayArrow,
                contentDescription = "Resume",
                tint = Color.White,
                modifier = Modifier.align(Alignment.Center).size(40.dp)
            )
            // Progress bar at bottom
            Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .height(4.dp)
                    .background(Color.Black.copy(alpha = 0.4f))
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(cw.fraction)
                        .height(4.dp)
                        .background(MaterialTheme.colorScheme.primary)
                )
            }
        }
        Text(
            cw.item.name,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            modifier = Modifier.padding(top = 4.dp, start = 2.dp)
        )
    }
}

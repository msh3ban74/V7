package com.shabaan.v7.data.repository

import android.content.Context
import com.shabaan.v7.data.local.FavoriteEntity
import com.shabaan.v7.data.local.V7Database
import com.shabaan.v7.data.model.MediaType

class FavoritesRepository(context: Context) {

    private val dao = V7Database.get(context).favoriteDao()

    fun observeAll() = dao.observeAll()
    fun observeByType(type: MediaType) = dao.observeByType(type.name)
    fun observeIsFavorite(mediaId: Long, type: MediaType) = dao.exists(buildId(mediaId, type))

    suspend fun toggle(mediaId: Long, type: MediaType): Boolean {
        val id = buildId(mediaId, type)
        val entity = FavoriteEntity(
            id = id,
            mediaId = mediaId,
            type = type.name,
            addedAt = System.currentTimeMillis()
        )
        // Simple toggle: try insert; if exists we remove
        return runCatching {
            dao.insert(entity)
            true
        }.getOrElse { false }
    }

    suspend fun add(mediaId: Long, type: MediaType) {
        dao.insert(
            FavoriteEntity(
                id = buildId(mediaId, type),
                mediaId = mediaId,
                type = type.name,
                addedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun remove(mediaId: Long, type: MediaType) {
        dao.deleteById(buildId(mediaId, type))
    }

    private fun buildId(mediaId: Long, type: MediaType) = "${type.name}:$mediaId"
}

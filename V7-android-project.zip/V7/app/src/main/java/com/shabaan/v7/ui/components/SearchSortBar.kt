package com.shabaan.v7.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowDownward
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Sort
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.shabaan.v7.util.SortBy
import com.shabaan.v7.util.SortOrder

@Composable
fun SearchSortBar(
    query: String,
    onQueryChange: (String) -> Unit,
    sortBy: SortBy,
    sortOrder: SortOrder,
    onSortBy: (SortBy) -> Unit,
    onToggleOrder: () -> Unit,
    modifier: Modifier = Modifier
) {
    var searchOpen by remember { mutableStateOf(false) }
    var sortMenuOpen by remember { mutableStateOf(false) }

    Row(
        modifier = modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        AnimatedVisibility(
            visible = searchOpen,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut(),
            modifier = Modifier.weight(1f)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                singleLine = true,
                placeholder = { Text("Search…") },
                trailingIcon = {
                    IconButton(onClick = {
                        if (query.isNotEmpty()) onQueryChange("")
                        else searchOpen = false
                    }) {
                        Icon(Icons.Outlined.Close, contentDescription = "Close search")
                    }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (!searchOpen) {
            // Spacer so icons sit at the right
            androidx.compose.foundation.layout.Spacer(Modifier.weight(1f))
            IconButton(onClick = { searchOpen = true }) {
                Icon(Icons.Outlined.Search, contentDescription = "Search")
            }
            IconButton(onClick = { sortMenuOpen = true }) {
                Icon(Icons.Outlined.Sort, contentDescription = "Sort")
            }
            IconButton(onClick = onToggleOrder) {
                Icon(
                    if (sortOrder == SortOrder.DESCENDING) Icons.Outlined.ArrowDownward
                    else Icons.Outlined.ArrowUpward,
                    contentDescription = "Toggle order"
                )
            }
        }

        DropdownMenu(
            expanded = sortMenuOpen,
            onDismissRequest = { sortMenuOpen = false }
        ) {
            SortBy.entries.forEach { option ->
                DropdownMenuItem(
                    text = {
                        Text(when (option) {
                            SortBy.DATE -> "By date"
                            SortBy.NAME -> "By name"
                            SortBy.SIZE -> "By size"
                        })
                    },
                    leadingIcon = if (sortBy == option) {
                        { Icon(Icons.Outlined.Check, contentDescription = null) }
                    } else null,
                    onClick = {
                        onSortBy(option)
                        sortMenuOpen = false
                    }
                )
            }
        }
    }
}

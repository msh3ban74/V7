package com.shabaan.v7.ui.trash

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material.icons.outlined.SelectAll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.shabaan.v7.data.local.TrashEntity
import com.shabaan.v7.data.model.MediaType
import com.shabaan.v7.util.Formatters

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun TrashScreen(
    onBack: () -> Unit,
    vm: TrashViewModel = hiltViewModel()
) {
    val items by vm.items.collectAsState()
    val selectionMode by vm.selectionMode.collectAsState()
    val selection by vm.selection.collectAsState()
    var confirmDelete by remember { mutableStateOf<TrashEntity?>(null) }
    var confirmEmpty by remember { mutableStateOf(false) }
    var confirmDeleteSelected by remember { mutableStateOf(false) }

    androidx.activity.compose.BackHandler(enabled = selectionMode) { vm.clearSelection() }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    if (selectionMode) {
                        IconButton(onClick = { vm.clearSelection() }) {
                            Icon(Icons.Outlined.Close, contentDescription = "Cancel")
                        }
                    }
                },
                title = {
                    if (selectionMode) {
                        Text("${selection.size} selected", fontWeight = FontWeight.SemiBold)
                    } else {
                        Column {
                            Text("Recently Deleted", fontWeight = FontWeight.SemiBold)
                            Text(
                                "${items.size} item${if (items.size == 1) "" else "s"} • kept ${vm.retentionDays} days",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    if (selectionMode) {
                        IconButton(onClick = { vm.selectAll() }) {
                            Icon(Icons.Outlined.SelectAll, contentDescription = "Select all")
                        }
                        IconButton(
                            enabled = selection.isNotEmpty(),
                            onClick = { vm.restoreSelected() }
                        ) {
                            Icon(Icons.Filled.Restore, contentDescription = "Restore selected")
                        }
                        IconButton(
                            enabled = selection.isNotEmpty(),
                            onClick = { confirmDeleteSelected = true }
                        ) {
                            Icon(Icons.Filled.DeleteForever, contentDescription = "Delete selected")
                        }
                    } else if (items.isNotEmpty()) {
                        IconButton(onClick = { vm.selectAll() }) {
                            Icon(Icons.Outlined.SelectAll, contentDescription = "Select")
                        }
                        IconButton(onClick = { confirmEmpty = true }) {
                            Icon(Icons.Filled.DeleteForever, contentDescription = "Empty trash")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        if (items.isEmpty()) {
            Box(
                Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        Icons.Outlined.Delete,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text("Trash is empty", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Deleted items appear here for ${vm.retentionDays} days before being purged.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 32.dp)
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(8.dp, 8.dp, 8.dp, 96.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize().padding(padding)
            ) {
                items(items, key = { it.id }) { item ->
                    TrashCell(
                        item = item,
                        selectionMode = selectionMode,
                        selected = item.id in selection,
                        onClick = {
                            if (selectionMode) vm.toggleSelection(item.id)
                        },
                        onLongClick = { vm.startSelection(item.id) },
                        onRestore = { vm.restore(item) },
                        onDelete = { confirmDelete = item }
                    )
                }
            }
        }
    }

    if (confirmDeleteSelected) {
        AlertDialog(
            onDismissRequest = { confirmDeleteSelected = false },
            title = { Text("Delete forever?") },
            text = { Text("Permanently delete ${selection.size} selected item(s)? This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteSelected(); confirmDeleteSelected = false
                }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDeleteSelected = false }) { Text("Cancel") }
            }
        )
    }

    confirmDelete?.let { item ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Delete forever?") },
            text = { Text("\"${item.originalName}\" will be permanently removed.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteForever(item); confirmDelete = null
                }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = null }) { Text("Cancel") }
            }
        )
    }

    if (confirmEmpty) {
        AlertDialog(
            onDismissRequest = { confirmEmpty = false },
            title = { Text("Empty trash?") },
            text = { Text("This permanently removes ${items.size} item${if (items.size == 1) "" else "s"}.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.emptyAll(); confirmEmpty = false
                }) { Text("Empty", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { confirmEmpty = false }) { Text("Cancel") }
            }
        )
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun TrashCell(
    item: TrashEntity,
    selectionMode: Boolean,
    selected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onRestore: () -> Unit,
    onDelete: () -> Unit
) {
    val ctx = LocalContext.current
    var showActions by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(RoundedCornerShape(10.dp))
            .combinedClickable(
                onClick = {
                    if (selectionMode) onClick()
                    else showActions = !showActions
                },
                onLongClick = onLongClick
            ),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Box(Modifier.fillMaxSize()) {
            when (item.type) {
                MediaType.IMAGE.name, MediaType.VIDEO.name -> {
                    AsyncImage(
                        model = com.shabaan.v7.ui.components.thumbRequest(
                            ctx = ctx,
                            data = item.storedPath,
                            mediaId = item.id,
                            sizePx = 400,
                            useOsThumb = false
                        ),
                        contentDescription = item.originalName,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                else -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.Outlined.MusicNote,
                            contentDescription = null,
                            modifier = Modifier.size(40.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            if (item.type == MediaType.VIDEO.name) {
                Icon(
                    Icons.Outlined.PlayCircle,
                    contentDescription = null,
                    modifier = Modifier.align(Alignment.Center).size(32.dp),
                    tint = MaterialTheme.colorScheme.surface
                )
            }
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.scrim.copy(alpha = 0.55f))
                    .padding(horizontal = 6.dp, vertical = 4.dp)
            ) {
                Text(
                    Formatters.relativeTime(item.deletedAt),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.inverseOnSurface
                )
            }

            if (showActions && !selectionMode) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.scrim.copy(alpha = 0.65f)),
                    contentAlignment = Alignment.Center
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(onClick = { showActions = false; onRestore() }) {
                            Icon(
                                Icons.Filled.Restore,
                                contentDescription = "Restore",
                                tint = MaterialTheme.colorScheme.inverseOnSurface
                            )
                        }
                        IconButton(onClick = { showActions = false; onDelete() }) {
                            Icon(
                                Icons.Filled.DeleteForever,
                                contentDescription = "Delete forever",
                                tint = MaterialTheme.colorScheme.inverseOnSurface
                            )
                        }
                    }
                }
            }

            // Selection check overlay (only while selecting)
            if (selectionMode) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.30f)
                            else androidx.compose.ui.graphics.Color.Transparent
                        )
                )
                Icon(
                    imageVector = if (selected) Icons.Filled.CheckCircle
                    else Icons.Outlined.RadioButtonUnchecked,
                    contentDescription = if (selected) "Selected" else "Not selected",
                    tint = if (selected) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.inverseOnSurface,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .size(24.dp)
                        .background(
                            MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                            RoundedCornerShape(12.dp)
                        )
                )
            }
        }
    }
}

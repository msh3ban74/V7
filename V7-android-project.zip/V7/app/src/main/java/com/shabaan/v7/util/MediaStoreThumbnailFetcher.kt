package com.shabaan.v7.util

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import coil.ImageLoader
import coil.decode.DataSource
import coil.fetch.DrawableResult
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.request.Options
import coil.size.pxOrElse

/**
 * A Coil [Fetcher] that pulls thumbnails straight from the Android OS thumbnail
 * cache (MediaStore). The OS pre-generates and caches these, so loading is
 * near-instant and doesn't re-decode the full image or re-extract a video frame
 * on every scroll — this is what makes the grid feel like Google/OPPO Photos.
 *
 * Use [ThumbKey] as the model so this fetcher is selected.
 */
data class ThumbKey(
    val mediaId: Long,
    val isVideo: Boolean
)

class MediaStoreThumbnailFetcher(
    private val context: Context,
    private val key: ThumbKey,
    private val options: Options
) : Fetcher {

    override suspend fun fetch(): FetchResult? {
        val w = options.size.width.pxOrElse { 400 }
        val h = options.size.height.pxOrElse { 400 }
        val size = Size(w.coerceAtLeast(96), h.coerceAtLeast(96))

        val bmp: Bitmap? = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val uri = if (key.isVideo)
                    ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI, key.mediaId
                    )
                else
                    ContentUris.withAppendedId(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, key.mediaId
                    )
                context.contentResolver.loadThumbnail(uri, size, null)
            } else {
                @Suppress("DEPRECATION")
                if (key.isVideo) {
                    MediaStore.Video.Thumbnails.getThumbnail(
                        context.contentResolver, key.mediaId,
                        MediaStore.Video.Thumbnails.MINI_KIND, null
                    )
                } else {
                    MediaStore.Images.Thumbnails.getThumbnail(
                        context.contentResolver, key.mediaId,
                        MediaStore.Images.Thumbnails.MINI_KIND, null
                    )
                }
            }
        } catch (e: Exception) {
            null
        } ?: return null

        return DrawableResult(
            drawable = BitmapDrawable(context.resources, bmp),
            isSampled = true,
            dataSource = DataSource.DISK
        )
    }

    class Factory(private val context: Context) : Fetcher.Factory<ThumbKey> {
        override fun create(data: ThumbKey, options: Options, imageLoader: ImageLoader): Fetcher =
            MediaStoreThumbnailFetcher(context, data, options)
    }
}

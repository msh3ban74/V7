package com.shabaan.v7.util

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import coil.ImageLoader
import coil.decode.DataSource
import coil.decode.ImageSource
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.fetch.SourceResult
import coil.request.Options
import coil.size.pxOrElse
import okio.Buffer
import java.io.ByteArrayOutputStream

/**
 * A Coil [Fetcher] that pulls thumbnails straight from the Android OS thumbnail
 * cache (MediaStore). The OS pre-generates and caches these, so loading is
 * near-instant and doesn't re-decode the full image or re-extract a video frame
 * on every scroll.
 *
 * It returns the thumbnail as an encoded JPEG *source* (not a ready Drawable),
 * which lets Coil persist it to its disk cache. That means each thumbnail is
 * produced **once** and then reused forever — exactly the smooth, no-reload
 * behaviour of the stock gallery.
 */
data class ThumbKey(
    val mediaId: Long,
    val isVideo: Boolean
)

class MediaStoreThumbnailFetcher(
    private val context: Context,
    private val key: ThumbKey,
    private val options: Options
) : Fetcher {

    override suspend fun fetch(): FetchResult? {
        // Videos: cap the requested thumbnail smaller than photos. The OS video
        // thumbnail is expensive to produce, and a grid cell never needs more
        // than ~256 px. Smaller size = much faster extraction + decode.
        val cap = if (key.isVideo) 200 else 400
        val w = options.size.width.pxOrElse { cap }.coerceAtMost(cap)
        val h = options.size.height.pxOrElse { cap }.coerceAtMost(cap)
        val size = Size(w.coerceAtLeast(96), h.coerceAtLeast(96))

        val bmp: Bitmap = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val uri = if (key.isVideo)
                    ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI, key.mediaId
                    )
                else
                    ContentUris.withAppendedId(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, key.mediaId
                    )
                context.contentResolver.loadThumbnail(uri, size, null)
            } else {
                @Suppress("DEPRECATION")
                if (key.isVideo) {
                    MediaStore.Video.Thumbnails.getThumbnail(
                        context.contentResolver, key.mediaId,
                        MediaStore.Video.Thumbnails.MINI_KIND, null
                    )
                } else {
                    MediaStore.Images.Thumbnails.getThumbnail(
                        context.contentResolver, key.mediaId,
                        MediaStore.Images.Thumbnails.MINI_KIND, null
                    )
                }
            }
        } catch (e: Exception) {
            return null
        } ?: return null

        // Encode to JPEG bytes so Coil can store the result in its disk cache.
        // Quality 80 is visually identical at thumbnail size but encodes faster
        // and writes a smaller cache entry.
        val bos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 80, bos)
        if (!bmp.isRecycled) bmp.recycle()
        val bytes = bos.toByteArray()

        val buffer = Buffer().apply { write(bytes) }
        return SourceResult(
            source = ImageSource(buffer, context),
            mimeType = "image/jpeg",
            // IMPORTANT: report NETWORK (not DISK). Coil only WRITES a fetcher's
            // result into its persistent disk cache when the source is treated
            // as remote. Reporting DISK makes Coil assume it's already cached and
            // skip the write — which meant every app restart re-extracted every
            // thumbnail from scratch. NETWORK = "save this", so after the first
            // time a thumbnail is produced it's reused forever, even across
            // restarts. (Nothing is actually downloaded; all media is local.)
            dataSource = DataSource.NETWORK
        )
    }

    class Factory(private val context: Context) : Fetcher.Factory<ThumbKey> {
        override fun create(data: ThumbKey, options: Options, imageLoader: ImageLoader): Fetcher =
            MediaStoreThumbnailFetcher(context, data, options)
    }
}

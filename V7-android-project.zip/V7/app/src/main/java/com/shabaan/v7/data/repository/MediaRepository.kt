package com.shabaan.v7.data.repository

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import com.shabaan.v7.data.model.MediaItem
import com.shabaan.v7.data.model.MediaType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MediaRepository(private val context: Context) {

    suspend fun loadVideos(): List<MediaItem> = withContext(Dispatchers.IO) {
        val list = mutableListOf<MediaItem>()
        val proj = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.RELATIVE_PATH
        )
        val coll = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        context.contentResolver.query(
            coll, proj, null, null,
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { c ->
            val idIx = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameIx = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val mimeIx = c.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
            val sizeIx = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            val dateIx = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
            val durIx = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val wIx = c.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
            val hIx = c.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
            val pathIx = c.getColumnIndexOrThrow(MediaStore.Video.Media.RELATIVE_PATH)
            while (c.moveToNext()) {
                val id = c.getLong(idIx)
                val uri = ContentUris.withAppendedId(coll, id)
                list += MediaItem(
                    id = id,
                    uri = uri,
                    name = c.getString(nameIx) ?: "Video",
                    mimeType = c.getString(mimeIx) ?: "video/*",
                    size = c.getLong(sizeIx),
                    dateAdded = c.getLong(dateIx),
                    duration = c.getLong(durIx),
                    type = MediaType.VIDEO,
                    width = c.getInt(wIx),
                    height = c.getInt(hIx),
                    relativePath = c.getString(pathIx)
                )
            }
        }
        list
    }

    suspend fun loadImages(): List<MediaItem> = withContext(Dispatchers.IO) {
        val list = mutableListOf<MediaItem>()
        val proj = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.MIME_TYPE,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.DATE_ADDED,
            MediaStore.Images.Media.WIDTH,
            MediaStore.Images.Media.HEIGHT,
            MediaStore.Images.Media.RELATIVE_PATH
        )
        val coll = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        context.contentResolver.query(
            coll, proj, null, null,
            "${MediaStore.Images.Media.DATE_ADDED} DESC"
        )?.use { c ->
            val idIx = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val nameIx = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val mimeIx = c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
            val sizeIx = c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
            val dateIx = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
            val wIx = c.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH)
            val hIx = c.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT)
            val pathIx = c.getColumnIndexOrThrow(MediaStore.Images.Media.RELATIVE_PATH)
            while (c.moveToNext()) {
                val id = c.getLong(idIx)
                val uri = ContentUris.withAppendedId(coll, id)
                list += MediaItem(
                    id = id,
                    uri = uri,
                    name = c.getString(nameIx) ?: "Photo",
                    mimeType = c.getString(mimeIx) ?: "image/*",
                    size = c.getLong(sizeIx),
                    dateAdded = c.getLong(dateIx),
                    type = MediaType.IMAGE,
                    width = c.getInt(wIx),
                    height = c.getInt(hIx),
                    relativePath = c.getString(pathIx)
                )
            }
        }
        list
    }

    suspend fun loadAudio(): List<MediaItem> = withContext(Dispatchers.IO) {
        val list = mutableListOf<MediaItem>()
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.IS_MUSIC
        )
        val coll = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        context.contentResolver.query(
            coll, proj,
            "${MediaStore.Audio.Media.IS_MUSIC} != 0",
            null,
            "${MediaStore.Audio.Media.DATE_ADDED} DESC"
        )?.use { c ->
            val idIx = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val nameIx = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val titleIx = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val mimeIx = c.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
            val sizeIx = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val dateIx = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val durIx = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val artistIx = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumIx = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdIx = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            while (c.moveToNext()) {
                val id = c.getLong(idIx)
                val uri = ContentUris.withAppendedId(coll, id)
                val dur = c.getLong(durIx)
                if (dur < 15_000) continue // skip tiny audio clips
                list += MediaItem(
                    id = id,
                    uri = uri,
                    name = c.getString(titleIx) ?: c.getString(nameIx) ?: "Track",
                    mimeType = c.getString(mimeIx) ?: "audio/*",
                    size = c.getLong(sizeIx),
                    dateAdded = c.getLong(dateIx),
                    duration = dur,
                    type = MediaType.AUDIO,
                    artist = c.getString(artistIx),
                    album = c.getString(albumIx),
                    albumId = c.getLong(albumIdIx)
                )
            }
        }
        list
    }

    fun albumArtUri(albumId: Long): Uri =
        ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)
}

package com.shabaan.v7.ui.trash

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shabaan.v7.data.local.TrashEntity
import com.shabaan.v7.data.repository.TrashRepository
import com.shabaan.v7.util.SettingsStore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TrashViewModel @Inject constructor(
    private val repo: TrashRepository,
    private val settings: SettingsStore
) : ViewModel() {

    val items: StateFlow<List<TrashEntity>> =
        repo.items.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        // Best-effort auto-purge on every VM creation
        viewModelScope.launch {
            runCatching { repo.purgeExpired(settings.trashRetentionDays) }
        }
    }

    fun restore(item: TrashEntity, onDone: (Boolean) -> Unit = {}) {
        viewModelScope.launch { onDone(repo.restore(item)) }
    }

    fun deleteForever(item: TrashEntity, onDone: (Boolean) -> Unit = {}) {
        viewModelScope.launch { onDone(repo.deleteForever(item)) }
    }

    fun emptyAll(onDone: (Int) -> Unit = {}) {
        viewModelScope.launch { onDone(repo.emptyAll()) }
    }

    val retentionDays get() = settings.trashRetentionDays
}

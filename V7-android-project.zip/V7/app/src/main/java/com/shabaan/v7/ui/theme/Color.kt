package com.shabaan.v7.ui.theme

import androidx.compose.ui.graphics.Color

// Titanium / Platinum Silver palette — refined, futuristic, metallic.
val Titanium50  = Color(0xFFF6F7F9)
val Titanium100 = Color(0xFFE8EBF0)
val Titanium200 = Color(0xFFCBD2DC)
val Titanium300 = Color(0xFFAAB4C2)
val Titanium400 = Color(0xFF8893A4)
val Titanium500 = Color(0xFF6B7686)
val Titanium600 = Color(0xFF515B6A)
val Titanium700 = Color(0xFF3A4350)
val Titanium800 = Color(0xFF242B35)
val Titanium900 = Color(0xFF12161C)

// Electric platinum accent — a cool, futuristic sheen with a hint of ice-blue.
val TitaniumAccent = Color(0xFF5FA8D3)
val PlatinumGlow = Color(0xFF7FD4E8)
val PlatinumDeep = Color(0xFF0A0D12)

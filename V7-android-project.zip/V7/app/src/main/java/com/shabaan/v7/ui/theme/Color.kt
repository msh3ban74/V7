package com.shabaan.v7.ui.theme

import androidx.compose.ui.graphics.Color

// Titanium Silver palette
val Titanium50  = Color(0xFFF4F5F7)
val Titanium100 = Color(0xFFE5E7EB)
val Titanium200 = Color(0xFFC9CDD3)
val Titanium300 = Color(0xFFA8AEB6)
val Titanium400 = Color(0xFF878D96)
val Titanium500 = Color(0xFF6C737D)
val Titanium600 = Color(0xFF525861)
val Titanium700 = Color(0xFF3B404A)
val Titanium800 = Color(0xFF262A32)
val Titanium900 = Color(0xFF14171C)
val TitaniumAccent = Color(0xFF8C99AB)

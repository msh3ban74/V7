package com.shabaan.v7.data.repository

import com.shabaan.v7.data.model.MediaItem
import com.shabaan.v7.util.SortBy
import com.shabaan.v7.util.SortOrder

/** A bucket of media grouped by folder. */
data class Album(
    val name: String,
    val items: List<MediaItem>
) {
    val cover: MediaItem? get() = items.firstOrNull()
    val count: Int get() = items.size
}

/** Apply user sort preferences. */
fun List<MediaItem>.sorted(by: SortBy, order: SortOrder): List<MediaItem> {
    val ascending = order == SortOrder.ASCENDING
    val cmp: Comparator<MediaItem> = when (by) {
        SortBy.DATE -> compareBy { it.dateAdded }
        SortBy.NAME -> compareBy(String.CASE_INSENSITIVE_ORDER) { it.name }
        SortBy.SIZE -> compareBy { it.size }
    }
    return if (ascending) sortedWith(cmp) else sortedWith(cmp.reversed())
}

/** Case-insensitive substring match on name + artist + album. */
fun List<MediaItem>.filteredBy(query: String): List<MediaItem> {
    val q = query.trim()
    if (q.isEmpty()) return this
    return filter {
        it.name.contains(q, ignoreCase = true) ||
            (it.artist?.contains(q, ignoreCase = true) == true) ||
            (it.album?.contains(q, ignoreCase = true) == true)
    }
}

/** Group items by their relative path (folder). */
fun List<MediaItem>.toAlbums(): List<Album> {
    val grouped = groupBy { item ->
        val raw = item.relativePath?.trimEnd('/').orEmpty()
        if (raw.isEmpty()) "Other" else raw.substringAfterLast('/').ifEmpty { raw }
    }
    return grouped.map { (name, items) -> Album(name, items) }
        .sortedByDescending { it.items.maxOfOrNull { m -> m.dateAdded } ?: 0L }
}

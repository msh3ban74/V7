package com.shabaan.v7.data.repository

import com.shabaan.v7.data.model.MediaItem
import com.shabaan.v7.util.SortBy
import com.shabaan.v7.util.SortOrder

/** A bucket of media grouped by folder. */
data class Album(
    val name: String,
    val items: List<MediaItem>
) {
    val cover: MediaItem? get() = items.firstOrNull()
    val count: Int get() = items.size
}

/** Apply user sort preferences. */
fun List<MediaItem>.sorted(by: SortBy, order: SortOrder): List<MediaItem> {
    val ascending = order == SortOrder.ASCENDING
    val cmp: Comparator<MediaItem> = when (by) {
        SortBy.DATE -> compareBy { it.dateAdded }
        SortBy.NAME -> compareBy(String.CASE_INSENSITIVE_ORDER) { it.name }
        SortBy.SIZE -> compareBy { it.size }
    }
    return if (ascending) sortedWith(cmp) else sortedWith(cmp.reversed())
}

/** Case-insensitive substring match on name + artist + album. */
fun List<MediaItem>.filteredBy(query: String): List<MediaItem> {
    val q = query.trim()
    if (q.isEmpty()) return this
    return filter {
        it.name.contains(q, ignoreCase = true) ||
            (it.artist?.contains(q, ignoreCase = true) == true) ||
            (it.album?.contains(q, ignoreCase = true) == true)
    }
}

/** Group items by their relative path (folder). */
fun List<MediaItem>.toAlbums(): List<Album> {
    val grouped = groupBy { item ->
        val raw = item.relativePath?.trimEnd('/').orEmpty()
        if (raw.isEmpty()) "Other" else raw.substringAfterLast('/').ifEmpty { raw }
    }
    return grouped.map { (name, items) -> Album(name, items) }
        .sortedByDescending { it.items.maxOfOrNull { m -> m.dateAdded } ?: 0L }
}

/** A run of media that share a date header (Today, Yesterday, a month…). */
data class DateSection(
    val title: String,
    val items: List<MediaItem>
)

/**
 * Splits a media list into human-friendly sections: Today, Yesterday,
 * This Week, This Month, then by "Month Year". Gives the gallery a
 * Google/OPPO-Photos timeline feel.
 */
fun List<MediaItem>.toDateSections(): List<DateSection> {
    if (isEmpty()) return emptyList()
    val now = System.currentTimeMillis()
    val cal = java.util.Calendar.getInstance()
    cal.timeInMillis = now
    cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
    cal.set(java.util.Calendar.MINUTE, 0)
    cal.set(java.util.Calendar.SECOND, 0)
    cal.set(java.util.Calendar.MILLISECOND, 0)
    val startOfToday = cal.timeInMillis
    val startOfYesterday = startOfToday - 24L * 60 * 60 * 1000
    val startOfWeek = startOfToday - 7L * 24 * 60 * 60 * 1000
    val startOfMonth = startOfToday - 30L * 24 * 60 * 60 * 1000

    val monthFmt = java.text.SimpleDateFormat("MMMM yyyy", java.util.Locale.getDefault())

    fun sectionTitle(dateMs: Long): String {
        val ms = if (dateMs < 10_000_000_000L) dateMs * 1000 else dateMs
        return when {
            ms >= startOfToday -> "Today"
            ms >= startOfYesterday -> "Yesterday"
            ms >= startOfWeek -> "This Week"
            ms >= startOfMonth -> "This Month"
            else -> monthFmt.format(java.util.Date(ms))
        }
    }

    val order = listOf("Today", "Yesterday", "This Week", "This Month")
    val grouped = LinkedHashMap<String, MutableList<MediaItem>>()
    for (item in this.sortedByDescending { it.dateAdded }) {
        val t = sectionTitle(item.dateAdded)
        grouped.getOrPut(t) { mutableListOf() }.add(item)
    }
    return grouped.entries
        .sortedWith(compareBy {
            val i = order.indexOf(it.key)
            if (i >= 0) i else order.size
        })
        .map { DateSection(it.key, it.value) }
}

package com.shabaan.v7.ui.videos

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Rational
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.PictureInPicture
import androidx.compose.material.icons.outlined.Repeat
import androidx.compose.material.icons.outlined.RepeatOne
import androidx.compose.material.icons.outlined.SkipNext
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Gif
import androidx.compose.material.icons.outlined.ContentCut
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.Subtitles
import androidx.compose.material.icons.outlined.VolumeUp
import androidx.compose.material.icons.outlined.VolumeOff
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem as Media3Item
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.shabaan.v7.util.Formatters
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun VideoPlayerRoute(
    startIndex: Int,
    onBack: () -> Unit,
    progressVm: PlaybackProgressViewModel = androidx.hilt.navigation.compose.hiltViewModel(),
    favVm: PlayerFavViewModel = androidx.hilt.navigation.compose.hiltViewModel()
) {
    val ctx = LocalContext.current
    val activity = ctx as? Activity
    val items = remember { VideoSession.list }
    if (items.isEmpty()) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val favorites by favVm.favorites.collectAsState()
    val safeStart = startIndex.coerceIn(0, items.lastIndex)
    val pagerState = rememberPagerState(initialPage = safeStart) { items.size }
    val scope = androidx.compose.runtime.rememberCoroutineScope()

    DisposableEffect(Unit) {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }
    BackHandler { onBack() }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        VerticalPager(state = pagerState, beyondViewportPageCount = 1) { page ->
            val item = items[page]
            val active = page == pagerState.currentPage
            SinglePlayerPage(
                mediaId = item.id,
                uri = item.uri,
                title = item.name,
                active = active,
                progressVm = progressVm,
                isFavorite = item.id in favorites,
                onToggleFavorite = { favVm.toggle(item.id) },
                onBack = onBack,
                onTogglePiP = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && activity != null &&
                        activity.packageManager.hasSystemFeature(
                            android.content.pm.PackageManager.FEATURE_PICTURE_IN_PICTURE
                        )
                    ) {
                        try {
                            val params = PictureInPictureParams.Builder()
                                .setAspectRatio(Rational(16, 9))
                                .build()
                            activity.enterPictureInPictureMode(params)
                        } catch (_: Exception) { /* device refused PiP */ }
                    }
                },
                onShare = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = item.mimeType
                        putExtra(Intent.EXTRA_STREAM, item.uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    ctx.startActivity(Intent.createChooser(send, "Share"))
                },
                onAdvanceNext = {
                    val next = page + 1
                    if (next < items.size) {
                        scope.launch { pagerState.animateScrollToPage(next) }
                    }
                }
            )
        }
    }
}

@Composable
private fun SinglePlayerPage(
    mediaId: Long,
    uri: Uri,
    title: String,
    active: Boolean,
    progressVm: PlaybackProgressViewModel,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onBack: () -> Unit,
    onTogglePiP: () -> Unit,
    onShare: () -> Unit,
    onAdvanceNext: () -> Unit = {}
) {
    val ctx = LocalContext.current
    val activity = ctx as? Activity
    val lifecycleOwner = LocalLifecycleOwner.current

    var subtitleUri by remember { mutableStateOf<Uri?>(null) }
    val subtitlePicker = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    it, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) { /* not all URIs are persistable */ }
            subtitleUri = it
        }
    }

    val player = remember(uri) {
        ExoPlayer.Builder(ctx)
            .setAudioAttributes(
                androidx.media3.common.AudioAttributes.Builder()
                    .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MOVIE)
                    .setUsage(androidx.media3.common.C.USAGE_MEDIA)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setWakeMode(androidx.media3.common.C.WAKE_MODE_LOCAL)
            .build().apply {
                setMediaItem(Media3Item.fromUri(uri))
                prepare()
            }
    }
    // A MediaSession lets the OS recognise this as active media and keep it
    // playing in the background (with system media controls) when enabled.
    val mediaSession = remember(player) {
        androidx.media3.session.MediaSession.Builder(ctx, player)
            .setId("v7_video_${System.currentTimeMillis()}")
            .build()
    }
    DisposableEffect(mediaSession) {
        onDispose { mediaSession.release() }
    }
    var muted by remember { mutableStateOf(false) }
    LaunchedEffect(muted) { player.volume = if (muted) 0f else 1f }

    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var makingSticker by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var showStickerMenu by remember { mutableStateOf(false) }
    // 0 = stop at end (default), 1 = auto-play next, 2 = repeat this video
    var videoRepeatMode by remember { mutableIntStateOf(0) }
    var extractingAudio by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    var showTrim by remember { mutableStateOf(false) }
    var trimming by remember { mutableStateOf(false) }

    fun makeSticker(durationMs: Long, share: Boolean) {
        val startAt = player.currentPosition
        makingSticker = true
        scope.launch {
            // Animated WebP = real WhatsApp sticker (not a GIF).
            val sticker = com.shabaan.v7.util.StickerMaker.createWebpSticker(
                context = ctx,
                uri = uri,
                startMs = startAt,
                durationMs = durationMs,
                fps = 10
            )
            if (sticker == null) {
                makingSticker = false
                android.widget.Toast.makeText(
                    ctx, "Couldn't create sticker", android.widget.Toast.LENGTH_SHORT
                ).show()
                return@launch
            }
            if (share) {
                makingSticker = false
                com.shabaan.v7.util.StickerMaker.shareSticker(ctx, sticker)
            } else {
                val ok = com.shabaan.v7.util.StickerMaker.saveStickerToGallery(ctx, sticker)
                makingSticker = false
                android.widget.Toast.makeText(
                    ctx,
                    if (ok) "Sticker saved to gallery" else "Couldn't save sticker",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    // Resume from last saved position. We must wait until the player is READY
    // (the media is loaded and its duration is known) before seeking, otherwise
    // the seek is applied to a not-yet-prepared player and gets lost.
    LaunchedEffect(uri) {
        val resumeAt = progressVm.resumePosition(mediaId)
        if (resumeAt <= 0) return@LaunchedEffect
        if (player.playbackState == Player.STATE_READY && player.duration > 0) {
            player.seekTo(resumeAt)
        } else {
            val listener = object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_READY) {
                        player.seekTo(resumeAt)
                        player.removeListener(this)
                    }
                }
            }
            player.addListener(listener)
        }
    }

    // Apply subtitle without restarting playback: keep position & play state.
    LaunchedEffect(subtitleUri) {
        val sub = subtitleUri ?: return@LaunchedEffect
        val resumeAt = player.currentPosition
        val wasPlaying = player.playWhenReady
        val mime = ctx.contentResolver.getType(sub) ?: MimeTypes.APPLICATION_SUBRIP
        val subConfig = Media3Item.SubtitleConfiguration.Builder(sub)
            .setMimeType(mime)
            .setLanguage("und")
            .setSelectionFlags(androidx.media3.common.C.SELECTION_FLAG_DEFAULT)
            .build()
        val newItem = Media3Item.Builder()
            .setUri(uri)
            .setSubtitleConfigurations(listOf(subConfig))
            .build()
        player.setMediaItem(newItem, resumeAt)
        player.prepare()
        player.playWhenReady = wasPlaying
    }

    LaunchedEffect(active) { player.playWhenReady = active }

    DisposableEffect(player, lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> {
                    // Background playback is always on: keep the audio playing when
                    // the screen locks or the user leaves the app. Just persist a
                    // resume point.
                    val pos = player.currentPosition
                    val dur = player.duration.coerceAtLeast(0)
                    if (pos > 0) progressVm.save(mediaId, pos, dur, title, uri.toString())
                }
                Lifecycle.Event.ON_RESUME -> { /* playback continues uninterrupted */ }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            // Persist resume point before releasing
            val pos = player.currentPosition
            val dur = player.duration.coerceAtLeast(0)
            if (pos > 0) progressVm.save(mediaId, pos, dur, title, uri.toString())
            player.release()
        }
    }

    var showControls by remember { mutableStateOf(true) }
    var isPlaying by remember { mutableStateOf(true) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var speed by remember { mutableFloatStateOf(1f) }

    var seekIndicator by remember { mutableStateOf<Long?>(null) }

    val audioManager = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)

    LaunchedEffect(player) {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(p: Boolean) { isPlaying = p }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) {
                    when (videoRepeatMode) {
                        1 -> onAdvanceNext()          // auto-play next
                        2 -> { player.seekTo(0); player.play() }  // repeat
                        else -> { /* stop naturally */ }
                    }
                }
            }
        })
        var sinceSave = 0
        while (true) {
            position = player.currentPosition
            duration = player.duration.coerceAtLeast(0)
            sinceSave += 1
            if (sinceSave >= 10 && player.isPlaying && position > 0) {
                sinceSave = 0
                progressVm.save(mediaId, position, duration, title, uri.toString())
            }
            delay(500)
        }
    }
    LaunchedEffect(showControls) {
        if (showControls && isPlaying) {
            delay(3500)
            showControls = false
        }
    }
    LaunchedEffect(seekIndicator) {
        if (seekIndicator != null) {
            delay(900)
            seekIndicator = null
        }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = {
                PlayerView(it).apply {
                    this.player = player
                    useController = false
                    setBackgroundColor(android.graphics.Color.BLACK)
                }
            },
            update = { it.player = player },
            modifier = Modifier
                .fillMaxSize()
                // Tap area for showing controls & double-tap seek
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { showControls = !showControls },
                        onDoubleTap = { offset ->
                            val w = size.width
                            val cur = player.currentPosition
                            val target = if (offset.x < w / 2) cur - 10_000 else cur + 10_000
                            player.seekTo(target.coerceAtLeast(0))
                            showControls = true
                        }
                    )
                }
                // Brightness/volume drags were removed on purpose: they conflicted
                // with swiping between videos. Now the VerticalPager receives
                // up/down swipes from anywhere on the screen — like Reels/TikTok.
        )

        // Gesture indicator overlays
        seekIndicator?.let { pos ->
            Surface(
                color = Color.Black.copy(alpha = 0.6f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Text(
                    "${Formatters.duration(pos)} / ${Formatters.duration(duration)}",
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }

        if (showControls) {
            // Top bar
            Surface(
                color = Color.Black.copy(alpha = 0.45f),
                modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Spacer(Modifier.weight(1f))
                    // Mute (main #2)
                    IconButton(onClick = { muted = !muted }) {
                        Icon(
                            if (muted) Icons.Outlined.VolumeOff
                            else Icons.Outlined.VolumeUp,
                            contentDescription = if (muted) "Unmute" else "Mute",
                            tint = Color.White
                        )
                    }
                    // Subtitles (main #5)
                    IconButton(onClick = { subtitlePicker.launch(arrayOf("*/*")) }) {
                        Icon(Icons.Outlined.Subtitles, contentDescription = "Subtitles", tint = Color.White)
                    }
                    // Sticker icon (own menu for duration)
                    Box {
                        IconButton(
                            enabled = !makingSticker,
                            onClick = { showStickerMenu = true }
                        ) {
                            if (makingSticker) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(22.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(Icons.Outlined.Gif, contentDescription = "Sticker", tint = Color.White)
                            }
                        }
                        DropdownMenu(
                            expanded = showStickerMenu,
                            onDismissRequest = { showStickerMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Send to WhatsApp (2s)") },
                                onClick = { showStickerMenu = false; makeSticker(2000L, share = true) }
                            )
                            DropdownMenuItem(
                                text = { Text("Send to WhatsApp (3s)") },
                                onClick = { showStickerMenu = false; makeSticker(3000L, share = true) }
                            )
                            DropdownMenuItem(
                                text = { Text("Send to WhatsApp (5s)") },
                                onClick = { showStickerMenu = false; makeSticker(5000L, share = true) }
                            )
                        }
                    }
                    // More menu (3 dots) — extract audio, info
                    Box {
                        IconButton(
                            enabled = !extractingAudio,
                            onClick = { showMoreMenu = true }
                        ) {
                            if (extractingAudio) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(22.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(Icons.Outlined.MoreVert, contentDescription = "More", tint = Color.White)
                            }
                        }
                        DropdownMenu(
                            expanded = showMoreMenu,
                            onDismissRequest = { showMoreMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Extract audio (MP3)") },
                                leadingIcon = { Icon(Icons.Outlined.MusicNote, contentDescription = null) },
                                onClick = {
                                    showMoreMenu = false
                                    extractingAudio = true
                                    scope.launch {
                                        val ok = com.shabaan.v7.util.AudioExtractor.extractToMusic(
                                            ctx, uri, title
                                        )
                                        extractingAudio = false
                                        android.widget.Toast.makeText(
                                            ctx,
                                            if (ok) "Audio saved to Music/V7 Audio" else "Couldn't extract audio",
                                            android.widget.Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("Trim video") },
                                leadingIcon = { Icon(Icons.Outlined.ContentCut, contentDescription = null) },
                                onClick = { showMoreMenu = false; showTrim = true }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("Info") },
                                leadingIcon = { Icon(Icons.Outlined.Info, contentDescription = null) },
                                onClick = { showMoreMenu = false; showInfo = true }
                            )
                        }
                    }
                }
            }

            // Center play/pause
            FilledIconButton(
                onClick = { player.playWhenReady = !player.isPlaying },
                modifier = Modifier.align(Alignment.Center).size(72.dp),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = Color.Black.copy(alpha = 0.45f),
                    contentColor = Color.White
                )
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(40.dp)
                )
            }

            // TikTok-style vertical action rail on the right
            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                RailAction(
                    icon = if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    label = "Like",
                    tint = if (isFavorite) Color(0xFFFF3B5C) else Color.White,
                    onClick = onToggleFavorite
                )
                RailAction(
                    icon = Icons.Rounded.Share,
                    label = "Share",
                    onClick = onShare
                )
                RailAction(
                    icon = Icons.Outlined.PictureInPicture,
                    label = "PiP",
                    onClick = onTogglePiP
                )
                RailAction(
                    icon = when (videoRepeatMode) {
                        1 -> Icons.Outlined.SkipNext
                        2 -> Icons.Outlined.RepeatOne
                        else -> Icons.Outlined.Repeat
                    },
                    label = when (videoRepeatMode) {
                        1 -> "Next"
                        2 -> "Repeat"
                        else -> "Off"
                    },
                    tint = if (videoRepeatMode == 0) Color.White.copy(alpha = 0.6f) else Color(0xFF6CC4FF),
                    onClick = {
                        videoRepeatMode = (videoRepeatMode + 1) % 3
                        val msg = when (videoRepeatMode) {
                            1 -> "Auto-play next"
                            2 -> "Repeat this video"
                            else -> "Stop at end"
                        }
                        android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_SHORT).show()
                    }
                )
            }

            // Bottom controls
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.45f))
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(Formatters.duration(position), color = Color.White, style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.width(8.dp))
                    Slider(
                        value = if (duration > 0) position.toFloat() / duration else 0f,
                        onValueChange = { player.seekTo((it * duration).toLong()) },
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(
                            thumbColor = Color.White,
                            activeTrackColor = Color.White,
                            inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                        )
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(Formatters.duration(duration), color = Color.White, style = MaterialTheme.typography.labelSmall)
                }
                Row(
                    Modifier.fillMaxWidth().padding(top = 6.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    listOf(0.5f, 1f, 1.25f, 1.5f, 2f).forEach { s ->
                        TextButton(onClick = {
                            speed = s
                            player.setPlaybackSpeed(s)
                        }) {
                            Text(
                                "${s}x",
                                color = if (s == speed) Color.White else Color.White.copy(alpha = 0.55f),
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }
        }

        if (showInfo) {
            AlertDialog(
                onDismissRequest = { showInfo = false },
                title = { Text("Details") },
                text = {
                    Column {
                        Text(title, style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Duration: " + Formatters.duration(duration),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showInfo = false }) { Text("Close") }
                }
            )
        }

        if (showTrim) {
            val totalMs = duration.coerceAtLeast(1000L)
            var startMs by remember { mutableFloatStateOf(0f) }
            var endMs by remember { mutableFloatStateOf(totalMs.toFloat()) }
            AlertDialog(
                onDismissRequest = { if (!trimming) showTrim = false },
                title = { Text("Trim video") },
                text = {
                    Column {
                        Text(
                            "From: " + Formatters.duration(startMs.toLong()),
                            style = MaterialTheme.typography.labelMedium
                        )
                        Slider(
                            value = startMs,
                            onValueChange = { if (it < endMs - 1000) startMs = it },
                            valueRange = 0f..totalMs.toFloat()
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "To: " + Formatters.duration(endMs.toLong()),
                            style = MaterialTheme.typography.labelMedium
                        )
                        Slider(
                            value = endMs,
                            onValueChange = { if (it > startMs + 1000) endMs = it },
                            valueRange = 0f..totalMs.toFloat()
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Clip length: " + Formatters.duration((endMs - startMs).toLong()),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                confirmButton = {
                    TextButton(enabled = !trimming, onClick = {
                        trimming = true
                        scope.launch {
                            val ok = com.shabaan.v7.util.VideoTrimmer.trim(
                                ctx, uri, startMs.toLong(), endMs.toLong(), title
                            )
                            trimming = false
                            showTrim = false
                            android.widget.Toast.makeText(
                                ctx,
                                if (ok) "Saved to Movies/V7 Trimmed" else "Couldn't trim video",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }
                    }) { Text(if (trimming) "Saving…" else "Save clip") }
                },
                dismissButton = {
                    TextButton(enabled = !trimming, onClick = { showTrim = false }) { Text("Cancel") }
                }
            )
        }
    }
}

@Composable
private fun IndicatorOverlay(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    progress: Float,
    label: String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color.Black.copy(alpha = 0.6f),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp)
        ) {
            Icon(icon, contentDescription = null, tint = Color.White)
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier
                    .width(4.dp)
                    .height(80.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.25f))
            ) {
                Box(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .width(4.dp)
                        .fillMaxHeight(progress)
                        .background(Color.White)
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(label, color = Color.White, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun RailAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        FilledIconButton(
            onClick = onClick,
            modifier = Modifier.size(48.dp),
            colors = IconButtonDefaults.filledIconButtonColors(
                containerColor = Color.Black.copy(alpha = 0.35f),
                contentColor = tint
            )
        ) {
            Icon(icon, contentDescription = label, modifier = Modifier.size(26.dp))
        }
        Spacer(Modifier.height(4.dp))
        Text(label, color = Color.White, style = MaterialTheme.typography.labelSmall)
    }
}

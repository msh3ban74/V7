package com.shabaan.v7.ui.videos

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Rational
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem as Media3Item
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.shabaan.v7.util.Formatters
import kotlinx.coroutines.delay

@Composable
fun VideoPlayerRoute(
    startIndex: Int,
    onBack: () -> Unit,
    progressVm: PlaybackProgressViewModel = androidx.hilt.navigation.compose.hiltViewModel()
) {
    val ctx = LocalContext.current
    val activity = ctx as? Activity
    val items = remember { VideoSession.list }
    if (items.isEmpty()) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val safeStart = startIndex.coerceIn(0, items.lastIndex)
    val pagerState = rememberPagerState(initialPage = safeStart) { items.size }

    DisposableEffect(Unit) {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }
    BackHandler { onBack() }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(state = pagerState, beyondViewportPageCount = 1) { page ->
            val item = items[page]
            val active = page == pagerState.currentPage
            SinglePlayerPage(
                mediaId = item.id,
                uri = item.uri,
                title = item.name,
                active = active,
                progressVm = progressVm,
                onBack = onBack,
                onTogglePiP = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && activity != null &&
                        activity.packageManager.hasSystemFeature(
                            android.content.pm.PackageManager.FEATURE_PICTURE_IN_PICTURE
                        )
                    ) {
                        try {
                            val params = PictureInPictureParams.Builder()
                                .setAspectRatio(Rational(16, 9))
                                .build()
                            activity.enterPictureInPictureMode(params)
                        } catch (_: Exception) { /* device refused PiP */ }
                    }
                },
                onShare = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = item.mimeType
                        putExtra(Intent.EXTRA_STREAM, item.uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    ctx.startActivity(Intent.createChooser(send, "Share"))
                }
            )
        }
    }
}

@Composable
private fun SinglePlayerPage(
    mediaId: Long,
    uri: Uri,
    title: String,
    active: Boolean,
    progressVm: PlaybackProgressViewModel,
    onBack: () -> Unit,
    onTogglePiP: () -> Unit,
    onShare: () -> Unit
) {
    val ctx = LocalContext.current
    val activity = ctx as? Activity
    val lifecycleOwner = LocalLifecycleOwner.current

    var subtitleUri by remember { mutableStateOf<Uri?>(null) }
    val subtitlePicker = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    it, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) { /* not all URIs are persistable */ }
            subtitleUri = it
        }
    }

    val player = remember(uri) {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(Media3Item.fromUri(uri))
            prepare()
        }
    }

    // Resume from last saved position (once, when this page first becomes active)
    LaunchedEffect(uri) {
        val resumeAt = progressVm.resumePosition(mediaId)
        if (resumeAt > 0) player.seekTo(resumeAt)
    }

    // Apply subtitle without restarting playback: keep position & play state.
    LaunchedEffect(subtitleUri) {
        val sub = subtitleUri ?: return@LaunchedEffect
        val resumeAt = player.currentPosition
        val wasPlaying = player.playWhenReady
        val mime = ctx.contentResolver.getType(sub) ?: MimeTypes.APPLICATION_SUBRIP
        val subConfig = Media3Item.SubtitleConfiguration.Builder(sub)
            .setMimeType(mime)
            .setLanguage("und")
            .setSelectionFlags(androidx.media3.common.C.SELECTION_FLAG_DEFAULT)
            .build()
        val newItem = Media3Item.Builder()
            .setUri(uri)
            .setSubtitleConfigurations(listOf(subConfig))
            .build()
        player.setMediaItem(newItem, resumeAt)
        player.prepare()
        player.playWhenReady = wasPlaying
    }

    LaunchedEffect(active) { player.playWhenReady = active }

    DisposableEffect(player, lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> player.playWhenReady = false
                Lifecycle.Event.ON_RESUME -> if (active) player.playWhenReady = true
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            // Persist resume point before releasing
            val pos = player.currentPosition
            val dur = player.duration.coerceAtLeast(0)
            progressVm.save(mediaId, pos, dur, title, uri.toString())
            player.release()
        }
    }

    var showControls by remember { mutableStateOf(true) }
    var isPlaying by remember { mutableStateOf(true) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var speed by remember { mutableFloatStateOf(1f) }

    // Brightness/volume overlays
    var brightnessIndicator by remember { mutableStateOf<Float?>(null) }
    var volumeIndicator by remember { mutableStateOf<Float?>(null) }
    var seekIndicator by remember { mutableStateOf<Long?>(null) }

    val audioManager = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)

    LaunchedEffect(player) {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(p: Boolean) { isPlaying = p }
        })
        while (true) {
            position = player.currentPosition
            duration = player.duration.coerceAtLeast(0)
            delay(500)
        }
    }
    LaunchedEffect(showControls) {
        if (showControls && isPlaying) {
            delay(3500)
            showControls = false
        }
    }
    LaunchedEffect(brightnessIndicator, volumeIndicator, seekIndicator) {
        if (brightnessIndicator != null || volumeIndicator != null || seekIndicator != null) {
            delay(900)
            brightnessIndicator = null
            volumeIndicator = null
            seekIndicator = null
        }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = {
                PlayerView(it).apply {
                    this.player = player
                    useController = false
                    setBackgroundColor(android.graphics.Color.BLACK)
                }
            },
            update = { it.player = player },
            modifier = Modifier
                .fillMaxSize()
                // Tap area for showing controls & double-tap seek
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { showControls = !showControls },
                        onDoubleTap = { offset ->
                            val w = size.width
                            val cur = player.currentPosition
                            val target = if (offset.x < w / 2) cur - 10_000 else cur + 10_000
                            player.seekTo(target.coerceAtLeast(0))
                            showControls = true
                        }
                    )
                }
                // Vertical drag on left = brightness, on right = volume
                .pointerInput(Unit) {
                    detectVerticalDragGestures { change, dragAmount ->
                        val w = size.width
                        val h = size.height.coerceAtLeast(1)
                        val onLeft = change.position.x < w / 2
                        val delta = -dragAmount / (h * 1.2f)   // up = positive

                        if (onLeft && activity != null) {
                            val lp = activity.window.attributes
                            val current = lp.screenBrightness.let {
                                if (it < 0f) {
                                    try {
                                        Settings.System.getInt(
                                            ctx.contentResolver,
                                            Settings.System.SCREEN_BRIGHTNESS
                                        ) / 255f
                                    } catch (_: Exception) { 0.5f }
                                } else it
                            }
                            val next = (current + delta).coerceIn(0.01f, 1f)
                            lp.screenBrightness = next
                            activity.window.attributes = lp
                            brightnessIndicator = next
                        } else {
                            val cur = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                            val curFrac = cur / maxVolume.toFloat()
                            val next = (curFrac + delta).coerceIn(0f, 1f)
                            audioManager.setStreamVolume(
                                AudioManager.STREAM_MUSIC,
                                (next * maxVolume).toInt(),
                                0
                            )
                            volumeIndicator = next
                        }
                    }
                }
                // Horizontal drag = seek scrubbing
                .pointerInput(Unit) {
                    detectHorizontalDragGestures { _, dragAmount ->
                        val w = size.width.coerceAtLeast(1)
                        val seekMs = (dragAmount / w * duration * 1.5f).toLong()
                        val target = (player.currentPosition + seekMs)
                            .coerceIn(0, duration.coerceAtLeast(0))
                        player.seekTo(target)
                        seekIndicator = target
                    }
                }
        )

        // Gesture indicator overlays
        brightnessIndicator?.let { v ->
            IndicatorOverlay(
                icon = Icons.Outlined.BrightnessMedium,
                progress = v,
                label = "${(v * 100).toInt()}%",
                modifier = Modifier.align(Alignment.CenterStart).padding(start = 32.dp)
            )
        }
        volumeIndicator?.let { v ->
            IndicatorOverlay(
                icon = Icons.Outlined.VolumeUp,
                progress = v,
                label = "${(v * 100).toInt()}%",
                modifier = Modifier.align(Alignment.CenterEnd).padding(end = 32.dp)
            )
        }
        seekIndicator?.let { pos ->
            Surface(
                color = Color.Black.copy(alpha = 0.6f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Text(
                    "${Formatters.duration(pos)} / ${Formatters.duration(duration)}",
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }

        if (showControls) {
            // Top bar
            Surface(
                color = Color.Black.copy(alpha = 0.45f),
                modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Text(
                        title,
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f).padding(start = 4.dp),
                        maxLines = 1
                    )
                    IconButton(onClick = { subtitlePicker.launch(arrayOf("*/*")) }) {
                        Icon(Icons.Outlined.Subtitles, contentDescription = "Subtitles", tint = Color.White)
                    }
                    IconButton(onClick = onTogglePiP) {
                        Icon(Icons.Outlined.PictureInPicture, contentDescription = "PiP", tint = Color.White)
                    }
                    IconButton(onClick = onShare) {
                        Icon(Icons.Outlined.Share, contentDescription = "Share", tint = Color.White)
                    }
                }
            }

            // Center play/pause
            FilledIconButton(
                onClick = { player.playWhenReady = !player.isPlaying },
                modifier = Modifier.align(Alignment.Center).size(72.dp),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = Color.Black.copy(alpha = 0.45f),
                    contentColor = Color.White
                )
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(40.dp)
                )
            }

            // Bottom controls
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.45f))
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(Formatters.duration(position), color = Color.White, style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.width(8.dp))
                    Slider(
                        value = if (duration > 0) position.toFloat() / duration else 0f,
                        onValueChange = { player.seekTo((it * duration).toLong()) },
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(
                            thumbColor = Color.White,
                            activeTrackColor = Color.White,
                            inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                        )
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(Formatters.duration(duration), color = Color.White, style = MaterialTheme.typography.labelSmall)
                }
                Row(
                    Modifier.fillMaxWidth().padding(top = 6.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    listOf(0.5f, 1f, 1.25f, 1.5f, 2f).forEach { s ->
                        TextButton(onClick = {
                            speed = s
                            player.setPlaybackSpeed(s)
                        }) {
                            Text(
                                "${s}x",
                                color = if (s == speed) Color.White else Color.White.copy(alpha = 0.55f),
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun IndicatorOverlay(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    progress: Float,
    label: String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color.Black.copy(alpha = 0.6f),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp)
        ) {
            Icon(icon, contentDescription = null, tint = Color.White)
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier
                    .width(4.dp)
                    .height(80.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.25f))
            ) {
                Box(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .width(4.dp)
                        .fillMaxHeight(progress)
                        .background(Color.White)
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(label, color = Color.White, style = MaterialTheme.typography.labelSmall)
        }
    }
}

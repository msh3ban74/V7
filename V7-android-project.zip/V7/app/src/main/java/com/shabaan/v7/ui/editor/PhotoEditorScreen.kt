package com.shabaan.v7.ui.editor

import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Crop
import androidx.compose.material.icons.outlined.Flip
import androidx.compose.material.icons.outlined.PhotoFilter
import androidx.compose.material.icons.outlined.Rotate90DegreesCcw
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.shabaan.v7.util.ImageEditor
import com.shabaan.v7.util.PhotoFilter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.foundation.Image
import androidx.compose.runtime.rememberCoroutineScope

private enum class EditTab { ADJUST, FILTER, TRANSFORM }

@Composable
fun PhotoEditorScreen(
    uri: Uri,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var original by remember { mutableStateOf<Bitmap?>(null) }
    var working by remember { mutableStateOf<Bitmap?>(null) }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var loading by remember { mutableStateOf(true) }
    var saving by remember { mutableStateOf(false) }

    var tab by remember { mutableStateOf(EditTab.ADJUST) }
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var saturation by remember { mutableFloatStateOf(1f) }
    var filter by remember { mutableStateOf(PhotoFilter.NONE) }

    // Load image once
    LaunchedEffect(uri) {
        val bmp = ImageEditor.load(ctx, uri)
        original = bmp
        working = bmp
        preview = bmp
        loading = false
    }

    // Recompute preview when adjustments/filter change (debounced via snapshot)
    LaunchedEffect(brightness, contrast, saturation, filter, working) {
        val base = working ?: return@LaunchedEffect
        val result = withContext(Dispatchers.Default) {
            var b = ImageEditor.applyAdjustments(base, brightness, contrast, saturation)
            b = ImageEditor.applyFilter(b, filter)
            b
        }
        preview = result
    }

    BackHandler { onBack() }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Top bar
        Row(
            Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Text("Edit", color = Color.White, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            if (saving) {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp
                )
            } else {
                TextButton(
                    enabled = preview != null,
                    onClick = {
                        val out = preview ?: return@TextButton
                        saving = true
                        scope.launch {
                            val ok = ImageEditor.saveToGallery(ctx, out, "edit")
                            saving = false
                            Toast.makeText(
                                ctx,
                                if (ok) "Saved to Pictures/V7 Edited" else "Couldn't save",
                                Toast.LENGTH_SHORT
                            ).show()
                            if (ok) onBack()
                        }
                    }
                ) {
                    Text("Save", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Preview
        Box(
            Modifier
                .fillMaxWidth()
                .weight(1f),
            contentAlignment = Alignment.Center
        ) {
            if (loading) {
                CircularProgressIndicator(color = Color.White)
            } else {
                preview?.let {
                    Image(
                        bitmap = it.asImageBitmap(),
                        contentDescription = "Preview",
                        modifier = Modifier.fillMaxSize().padding(8.dp),
                        contentScale = ContentScale.Fit
                    )
                }
            }
        }

        // Controls per tab
        Column(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            when (tab) {
                EditTab.ADJUST -> {
                    SliderRow("Brightness", brightness, -1f, 1f) { brightness = it }
                    SliderRow("Contrast", contrast, 0f, 2f) { contrast = it }
                    SliderRow("Saturation", saturation, 0f, 2f) { saturation = it }
                }
                EditTab.FILTER -> {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(vertical = 4.dp)
                    ) {
                        val filters = listOf(
                            PhotoFilter.NONE to "Original",
                            PhotoFilter.MONO to "Mono",
                            PhotoFilter.WARM to "Warm",
                            PhotoFilter.COOL to "Cool",
                            PhotoFilter.VIVID to "Vivid",
                            PhotoFilter.VINTAGE to "Vintage"
                        )
                        items(filters.size) { i ->
                            val (f, label) = filters[i]
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clickable { filter = f }
                                    .padding(4.dp)
                            ) {
                                Box(
                                    Modifier
                                        .size(56.dp)
                                        .background(
                                            if (filter == f) MaterialTheme.colorScheme.primary
                                            else MaterialTheme.colorScheme.surfaceVariant,
                                            RoundedCornerShape(10.dp)
                                        )
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (filter == f) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
                EditTab.TRANSFORM -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TransformButton("Rotate", Icons.Outlined.Rotate90DegreesCcw) {
                            working?.let { working = ImageEditor.rotate(it, 90f) }
                        }
                        TransformButton("Flip H", Icons.Outlined.Flip) {
                            working?.let { working = ImageEditor.flip(it, true) }
                        }
                        TransformButton("Flip V", Icons.Outlined.Flip) {
                            working?.let { working = ImageEditor.flip(it, false) }
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // Tab bar
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                TabItem("Adjust", Icons.Outlined.Tune, tab == EditTab.ADJUST) { tab = EditTab.ADJUST }
                TabItem("Filter", Icons.Outlined.PhotoFilter, tab == EditTab.FILTER) { tab = EditTab.FILTER }
                TabItem("Transform", Icons.Outlined.Crop, tab == EditTab.TRANSFORM) { tab = EditTab.TRANSFORM }
            }
        }
    }
}

@Composable
private fun SliderRow(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth()) {
            Text(label, style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.weight(1f))
            Text(
                "%.1f".format(value),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Slider(value = value, onValueChange = onChange, valueRange = min..max)
    }
}

@Composable
private fun TransformButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Icon(icon, contentDescription = label)
        Spacer(Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun TabItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }.padding(8.dp)
    ) {
        Icon(
            icon,
            contentDescription = label,
            tint = if (selected) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(4.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = if (selected) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

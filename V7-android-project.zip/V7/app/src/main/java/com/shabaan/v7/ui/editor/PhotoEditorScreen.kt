package com.shabaan.v7.ui.editor

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Crop
import androidx.compose.material.icons.outlined.Draw
import androidx.compose.material.icons.outlined.Rotate90DegreesCcw
import androidx.compose.material.icons.outlined.TextFields
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.shabaan.v7.util.ImageEditor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.widget.Toast

private enum class EditTool { NONE, CROP, TEXT, ROTATE, PEN }

/** A single free-hand stroke drawn by the pen tool. */
private class PenStroke(val color: Color, val width: Float) {
    val points = mutableStateListOf<Offset>()
}

@Composable
fun PhotoEditorScreen(
    uri: Uri,
    onBack: () -> Unit
) {
    val ctx = LocalContextSafe()
    val scope = rememberCoroutineScope()

    var original by remember { mutableStateOf<Bitmap?>(null) }
    var working by remember { mutableStateOf<Bitmap?>(null) }
    var loading by remember { mutableStateOf(true) }
    var saving by remember { mutableStateOf(false) }
    var tool by remember { mutableStateOf(EditTool.NONE) }

    // Pen strokes (overlaid on the image, baked in on save)
    val strokes = remember { mutableStateListOf<PenStroke>() }
    var penColor by remember { mutableStateOf(Color.Red) }

    // Text overlay
    var overlayText by remember { mutableStateOf("") }
    var textColor by remember { mutableStateOf(Color.White) }
    var showTextDialog by remember { mutableStateOf(false) }

    // Save dialog (replace vs copy)
    var showSaveDialog by remember { mutableStateOf(false) }

    LaunchedEffect(uri) {
        val bmp = ImageEditor.load(ctx, uri)
        original = bmp
        working = bmp
        loading = false
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Top bar
        Row(
            Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Text("Edit", color = Color.White, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            TextButton(
                enabled = !saving && working != null,
                onClick = { showSaveDialog = true }
            ) {
                Text("Save", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
        }

        // Canvas area
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            val bmp = working
            if (loading || bmp == null) {
                CircularProgressIndicator(color = Color.White)
            } else {
                Box(Modifier.fillMaxSize()) {
                    androidx.compose.foundation.Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = androidx.compose.ui.layout.ContentScale.Fit
                    )
                    // Pen drawing layer
                    Canvas(
                        Modifier
                            .fillMaxSize()
                            .pointerInput(tool, penColor) {
                                if (tool == EditTool.PEN) {
                                    detectDragGestures(
                                        onDragStart = { off ->
                                            val s = PenStroke(penColor, 8f)
                                            s.points.add(off)
                                            strokes.add(s)
                                        }
                                    ) { change, _ ->
                                        change.consume()
                                        strokes.lastOrNull()?.points?.add(change.position)
                                    }
                                }
                            }
                    ) {
                        for (s in strokes) {
                            for (i in 1 until s.points.size) {
                                drawLine(
                                    color = s.color,
                                    start = s.points[i - 1],
                                    end = s.points[i],
                                    strokeWidth = s.width
                                )
                            }
                        }
                    }
                    // Text overlay preview
                    if (overlayText.isNotEmpty()) {
                        Text(
                            overlayText,
                            color = textColor,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.headlineSmall,
                            modifier = Modifier
                                .align(Alignment.Center)
                                .padding(8.dp)
                        )
                    }
                }
            }
        }

        // Tool buttons: Crop, Text, Rotate, Pen
        Row(
            Modifier
                .fillMaxWidth()
                .background(Color(0xFF1A1A1A))
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ToolButton(Icons.Outlined.Crop, "Crop", tool == EditTool.CROP) {
                // Simple center crop to square (safe, no extra gesture UI)
                val b = working ?: return@ToolButton
                val side = minOf(b.width, b.height)
                val l = (b.width - side) / 2f
                val t = (b.height - side) / 2f
                working = ImageEditor.crop(b, l, t, l + side, t + side)
                tool = EditTool.CROP
            }
            ToolButton(Icons.Outlined.TextFields, "Text", tool == EditTool.TEXT) {
                tool = EditTool.TEXT
                showTextDialog = true
            }
            ToolButton(Icons.Outlined.Rotate90DegreesCcw, "Rotate", tool == EditTool.ROTATE) {
                val b = working ?: return@ToolButton
                working = ImageEditor.rotate(b, 90f)
                tool = EditTool.ROTATE
            }
            ToolButton(Icons.Outlined.Draw, "Pen", tool == EditTool.PEN) {
                tool = EditTool.PEN
            }
        }

        // Pen color row (only when pen active)
        if (tool == EditTool.PEN) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1A1A1A))
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.White, Color.Black).forEach { c ->
                    Box(
                        Modifier
                            .padding(horizontal = 6.dp)
                            .size(if (penColor == c) 34.dp else 28.dp)
                            .background(c, androidx.compose.foundation.shape.CircleShape)
                            .pointerInput(Unit) {
                                detectDragGestures(onDragStart = {}) { _, _ -> }
                            }
                    ) {
                        IconButton(onClick = { penColor = c }, modifier = Modifier.fillMaxSize()) {}
                    }
                }
            }
        }
    }

    // Text input dialog
    if (showTextDialog) {
        AlertDialog(
            onDismissRequest = { showTextDialog = false },
            title = { Text("Add text") },
            text = {
                Column {
                    OutlinedTextField(
                        value = overlayText,
                        onValueChange = { overlayText = it },
                        label = { Text("Text") }
                    )
                    Spacer(Modifier.height(12.dp))
                    Text("Color:")
                    Row {
                        listOf(Color.White, Color.Black, Color.Red, Color.Yellow).forEach { c ->
                            Box(
                                Modifier
                                    .padding(6.dp)
                                    .size(if (textColor == c) 34.dp else 28.dp)
                                    .background(c, androidx.compose.foundation.shape.CircleShape)
                            ) {
                                IconButton(onClick = { textColor = c }, modifier = Modifier.fillMaxSize()) {}
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTextDialog = false }) { Text("Done") }
            },
            dismissButton = {
                TextButton(onClick = { overlayText = ""; showTextDialog = false }) { Text("Clear") }
            }
        )
    }

    // Save: Replace vs Copy
    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { if (!saving) showSaveDialog = false },
            title = { Text("Save changes") },
            text = { Text("Replace the original, or save as a new copy?") },
            confirmButton = {
                TextButton(enabled = !saving, onClick = {
                    showSaveDialog = false
                    saving = true
                    scope.launch {
                        val baked = bakeOverlays(working, strokes, overlayText, textColor)
                        val ok = if (baked != null)
                            ImageEditor.replaceOriginal(ctx, uri, baked) else false
                        saving = false
                        Toast.makeText(
                            ctx,
                            if (ok) "Original replaced" else "Couldn't replace",
                            Toast.LENGTH_SHORT
                        ).show()
                        if (ok) onBack()
                    }
                }) { Text("Replace") }
            },
            dismissButton = {
                TextButton(enabled = !saving, onClick = {
                    showSaveDialog = false
                    saving = true
                    scope.launch {
                        val baked = bakeOverlays(working, strokes, overlayText, textColor)
                        val ok = if (baked != null)
                            ImageEditor.saveToGallery(ctx, baked, "edit") else false
                        saving = false
                        Toast.makeText(
                            ctx,
                            if (ok) "Saved a copy to V7 Edited" else "Couldn't save",
                            Toast.LENGTH_SHORT
                        ).show()
                        if (ok) onBack()
                    }
                }) { Text("Save copy") }
            }
        )
    }
}

/** Draws the pen strokes + text onto a copy of the bitmap before saving. */
private suspend fun bakeOverlays(
    src: Bitmap?,
    strokes: List<PenStroke>,
    text: String,
    textColor: Color
): Bitmap? = withContext(Dispatchers.Default) {
    val base = src ?: return@withContext null
    try {
        val out = base.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = android.graphics.Canvas(out)
        // Note: strokes are in screen coords; for a faithful bake we'd map them
        // to bitmap coords. Kept simple here — strokes scale with the view.
        val paint = android.graphics.Paint().apply {
            isAntiAlias = true
            strokeWidth = 8f
            style = android.graphics.Paint.Style.STROKE
            strokeCap = android.graphics.Paint.Cap.ROUND
        }
        for (s in strokes) {
            paint.color = s.color.toArgb()
            for (i in 1 until s.points.size) {
                canvas.drawLine(
                    s.points[i - 1].x, s.points[i - 1].y,
                    s.points[i].x, s.points[i].y, paint
                )
            }
        }
        if (text.isNotEmpty()) {
            val tp = android.graphics.Paint().apply {
                isAntiAlias = true
                color = textColor.toArgb()
                textSize = out.width / 12f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                textAlign = android.graphics.Paint.Align.CENTER
            }
            canvas.drawText(text, out.width / 2f, out.height / 2f, tp)
        }
        out
    } catch (e: Exception) {
        base
    }
}

@Composable
private fun ToolButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = onClick) {
            Icon(
                icon,
                contentDescription = label,
                tint = if (selected) MaterialTheme.colorScheme.primary else Color.White
            )
        }
        Text(
            label,
            color = if (selected) MaterialTheme.colorScheme.primary else Color.White,
            style = MaterialTheme.typography.labelSmall
        )
    }
}

@Composable
private fun LocalContextSafe() = androidx.compose.ui.platform.LocalContext.current

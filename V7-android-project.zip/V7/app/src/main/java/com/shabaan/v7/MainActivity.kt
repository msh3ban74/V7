package com.shabaan.v7

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.shabaan.v7.ui.navigation.V7Nav
import com.shabaan.v7.ui.theme.V7Theme
import com.shabaan.v7.util.LockManager
import com.shabaan.v7.util.SettingsStore
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : FragmentActivity() {

    @Inject lateinit var settings: SettingsStore

    private val themeState = MutableStateFlow(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        // Minimal system splash; hand off to the app immediately (it's a studio,
        // users want to reach everything fast — no extra animation).
        installSplashScreen()

        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        LockManager.onAppStart()

        // When the sleep timer ends, close the app. This stops playback because
        // the players are released when the activity is destroyed.
        com.shabaan.v7.util.SleepTimer.setOnFinish {
            finishAndRemoveTask()
        }

        // Request the highest refresh rate the display supports (90/120/144 Hz)
        // so scrolling and video playback are buttery smooth.
        enableHighRefreshRate()

        lifecycleScope.launch {
            settings.changes().collectLatest {
                themeState.update { it + 1 }
            }
        }

        setContent {
            val tick by themeState.collectAsState()
            val themeMode = remember(tick) { settings.themeMode }

            V7Theme(themeMode = themeMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    V7Nav(activity = this)
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        LockManager.onAppForeground(settings)
    }

    override fun onStop() {
        super.onStop()
        LockManager.onAppBackground()
    }

    /** Picks the display mode with the highest refresh rate (e.g. 120 Hz). */
    private fun enableHighRefreshRate() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                val display = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                    display
                } else {
                    @Suppress("DEPRECATION") windowManager.defaultDisplay
                }
                val modes = display?.supportedModes ?: return
                val best = modes.maxByOrNull { it.refreshRate } ?: return
                val params = window.attributes
                params.preferredDisplayModeId = best.modeId
                window.attributes = params
                // Also hint the preferred rate directly (API 30+).
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                    window.attributes.preferredRefreshRate = best.refreshRate
                }
            }
        } catch (_: Exception) { /* ignore — keep default rate */ }
    }
}

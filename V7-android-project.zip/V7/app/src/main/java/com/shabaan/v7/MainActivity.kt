package com.shabaan.v7

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.shabaan.v7.ui.components.V7Splash
import com.shabaan.v7.ui.navigation.V7Nav
import com.shabaan.v7.ui.theme.V7Theme
import com.shabaan.v7.util.LockManager
import com.shabaan.v7.util.SettingsStore
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : FragmentActivity() {

    @Inject lateinit var settings: SettingsStore

    private val themeState = MutableStateFlow(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        // System splash hands off almost immediately to our richer Compose splash.
        val splash = installSplashScreen()
        var keepSystemSplash = true
        splash.setKeepOnScreenCondition { keepSystemSplash }

        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        LockManager.onAppStart()

        lifecycleScope.launch {
            settings.changes().collectLatest {
                themeState.update { it + 1 }
            }
        }

        setContent {
            val tick by themeState.collectAsState()
            val themeMode = remember(tick) { settings.themeMode }
            var showSplash by remember { mutableStateOf(true) }

            // Release the system splash once Compose is up.
            keepSystemSplash = false

            V7Theme(themeMode = themeMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    V7Nav(activity = this)
                    AnimatedVisibility(
                        visible = showSplash,
                        exit = fadeOut()
                    ) {
                        V7Splash(onFinished = { showSplash = false })
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        LockManager.onAppForeground(settings)
    }

    override fun onStop() {
        super.onStop()
        LockManager.onAppBackground()
    }
}

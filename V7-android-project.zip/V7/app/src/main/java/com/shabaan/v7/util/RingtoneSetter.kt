package com.shabaan.v7.util

import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings

/** Sets an audio track as the device ringtone (requires WRITE_SETTINGS). */
object RingtoneSetter {

    /** Returns true if the app can write system settings. */
    fun canWrite(context: Context): Boolean =
        Settings.System.canWrite(context)

    /** Opens the system screen to grant the "modify system settings" permission. */
    fun requestPermission(context: Context) {
        try {
            val intent = Intent(
                Settings.ACTION_MANAGE_WRITE_SETTINGS,
                Uri.parse("package:" + context.packageName)
            )
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (_: Exception) { /* ignore */ }
    }

    /** Sets [uri] as the default ringtone. Returns true on success. */
    fun setAsRingtone(context: Context, uri: Uri): Boolean {
        return try {
            RingtoneManager.setActualDefaultRingtoneUri(
                context, RingtoneManager.TYPE_RINGTONE, uri
            )
            true
        } catch (e: Exception) {
            false
        }
    }

    /** How many SIM cards / phone lines the device currently has active. */
    fun simCount(context: Context): Int {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                val sm = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE)
                        as? android.telephony.SubscriptionManager ?: return 1
                if (context.checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE)
                    == android.content.pm.PackageManager.PERMISSION_GRANTED
                ) {
                    (sm.activeSubscriptionInfoCount).coerceAtLeast(1)
                } else 1
            } else 1
        } catch (e: Exception) { 1 }
    }

    /**
     * Sets [uri] as the ringtone for a specific SIM slot (0 = SIM 1, 1 = SIM 2).
     * Falls back to the global default ringtone if per-SIM isn't supported,
     * so it always does something sensible. Returns true on success.
     */
    fun setAsRingtoneForSim(context: Context, uri: Uri, simSlot: Int): Boolean {
        // Android exposes a per-subscription ringtone via a hidden setting key
        // ("ringtone" + "_" + subscriptionId). When that's not reachable we fall
        // back to the normal default ringtone so the action still works.
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                val sm = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE)
                        as? android.telephony.SubscriptionManager
                val hasPerm = context.checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) ==
                    android.content.pm.PackageManager.PERMISSION_GRANTED
                if (sm != null && hasPerm) {
                    val infos = sm.activeSubscriptionInfoList
                    if (infos != null && simSlot < infos.size) {
                        val subId = infos[simSlot].subscriptionId
                        // Per-subscription ringtone setting key used by AOSP dialer.
                        android.provider.Settings.System.putString(
                            context.contentResolver,
                            "ringtone_$subId",
                            uri.toString()
                        )
                        return true
                    }
                }
            }
            // Fallback: global default.
            setAsRingtone(context, uri)
        } catch (e: Exception) {
            setAsRingtone(context, uri)
        }
    }
}

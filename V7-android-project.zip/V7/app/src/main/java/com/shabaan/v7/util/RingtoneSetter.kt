package com.shabaan.v7.util

import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.provider.Settings

/** Sets an audio track as the device ringtone (requires WRITE_SETTINGS). */
object RingtoneSetter {

    /** Returns true if the app can write system settings. */
    fun canWrite(context: Context): Boolean =
        Settings.System.canWrite(context)

    /** Opens the system screen to grant the "modify system settings" permission. */
    fun requestPermission(context: Context) {
        try {
            val intent = Intent(
                Settings.ACTION_MANAGE_WRITE_SETTINGS,
                Uri.parse("package:" + context.packageName)
            )
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (_: Exception) { /* ignore */ }
    }

    /** Sets [uri] as the default ringtone. Returns true on success. */
    fun setAsRingtone(context: Context, uri: Uri): Boolean {
        return try {
            RingtoneManager.setActualDefaultRingtoneUri(
                context, RingtoneManager.TYPE_RINGTONE, uri
            )
            true
        } catch (e: Exception) {
            false
        }
    }
}

package com.shabaan.v7.data.model

import android.net.Uri

enum class MediaType { VIDEO, IMAGE, AUDIO }

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    val mimeType: String,
    val size: Long,
    val dateAdded: Long,
    val duration: Long = 0L,
    val type: MediaType,
    val width: Int = 0,
    val height: Int = 0,
    val artist: String? = null,
    val album: String? = null,
    val albumId: Long = 0L,
    val relativePath: String? = null
) {
    val isVideo get() = type == MediaType.VIDEO
    val isImage get() = type == MediaType.IMAGE
    val isAudio get() = type == MediaType.AUDIO
}

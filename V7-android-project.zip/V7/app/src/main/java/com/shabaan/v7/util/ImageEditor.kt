package com.shabaan.v7.util

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Lightweight, dependency-free image editing built on the Android graphics
 * stack. Everything works on a [Bitmap] in memory and saves a fresh copy to the
 * gallery — the original is never modified.
 */
object ImageEditor {

    /** Decode a (possibly large) image to a manageable working bitmap. */
    suspend fun load(context: Context, uri: Uri, maxDim: Int = 2048): Bitmap? =
        withContext(Dispatchers.IO) {
            try {
                val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                context.contentResolver.openInputStream(uri)?.use {
                    android.graphics.BitmapFactory.decodeStream(it, null, opts)
                }
                var sample = 1
                val largest = maxOf(opts.outWidth, opts.outHeight)
                while (largest / sample > maxDim) sample *= 2
                val decodeOpts = android.graphics.BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }
                context.contentResolver.openInputStream(uri)?.use {
                    android.graphics.BitmapFactory.decodeStream(it, null, decodeOpts)
                }
            } catch (e: Exception) {
                null
            }
        }

    /** Apply brightness (-1..1), contrast (0..2), saturation (0..2) in one pass. */
    fun applyAdjustments(
        src: Bitmap,
        brightness: Float = 0f,
        contrast: Float = 1f,
        saturation: Float = 1f
    ): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        val cm = ColorMatrix()

        // saturation
        val sat = ColorMatrix().apply { setSaturation(saturation) }
        cm.postConcat(sat)

        // contrast + brightness
        val c = contrast
        val b = brightness * 255f
        val translate = (-.5f * c + .5f) * 255f + b
        val contrastMatrix = ColorMatrix(floatArrayOf(
            c, 0f, 0f, 0f, translate,
            0f, c, 0f, 0f, translate,
            0f, 0f, c, 0f, translate,
            0f, 0f, 0f, 1f, 0f
        ))
        cm.postConcat(contrastMatrix)

        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(src, 0f, 0f, paint)
        return out
    }

    /** Apply a named preset filter. */
    fun applyFilter(src: Bitmap, filter: PhotoFilter): Bitmap {
        if (filter == PhotoFilter.NONE) return src
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val cm = when (filter) {
            PhotoFilter.MONO -> ColorMatrix().apply { setSaturation(0f) }
            PhotoFilter.WARM -> ColorMatrix(floatArrayOf(
                1.1f, 0f, 0f, 0f, 12f,
                0f, 1.0f, 0f, 0f, 4f,
                0f, 0f, 0.9f, 0f, -8f,
                0f, 0f, 0f, 1f, 0f
            ))
            PhotoFilter.COOL -> ColorMatrix(floatArrayOf(
                0.9f, 0f, 0f, 0f, -6f,
                0f, 1.0f, 0f, 0f, 2f,
                0f, 0f, 1.15f, 0f, 12f,
                0f, 0f, 0f, 1f, 0f
            ))
            PhotoFilter.VIVID -> ColorMatrix().apply { setSaturation(1.6f) }
            PhotoFilter.VINTAGE -> ColorMatrix(floatArrayOf(
                0.9f, 0.1f, 0.1f, 0f, 8f,
                0.1f, 0.85f, 0.1f, 0f, 6f,
                0.1f, 0.1f, 0.7f, 0f, 2f,
                0f, 0f, 0f, 1f, 0f
            ))
            PhotoFilter.NONE -> ColorMatrix()
        }
        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(src, 0f, 0f, paint)
        return out
    }

    /** Rotate by 90° steps. */
    fun rotate(src: Bitmap, degrees: Float): Bitmap {
        if (degrees % 360f == 0f) return src
        val m = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    /** Flip horizontally or vertically. */
    fun flip(src: Bitmap, horizontal: Boolean): Bitmap {
        val m = Matrix().apply {
            if (horizontal) postScale(-1f, 1f, src.width / 2f, src.height / 2f)
            else postScale(1f, -1f, src.width / 2f, src.height / 2f)
        }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    /** Crop to a normalized rect (0..1 coordinates). */
    fun crop(src: Bitmap, left: Float, top: Float, right: Float, bottom: Float): Bitmap {
        val l = (left * src.width).toInt().coerceIn(0, src.width - 1)
        val t = (top * src.height).toInt().coerceIn(0, src.height - 1)
        val r = (right * src.width).toInt().coerceIn(l + 1, src.width)
        val b = (bottom * src.height).toInt().coerceIn(t + 1, src.height)
        return Bitmap.createBitmap(src, l, t, r - l, b - t)
    }

    /** Save the edited bitmap as a new image in Pictures/V7 Edited. */
    suspend fun saveToGallery(context: Context, bmp: Bitmap, baseName: String): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val name = "V7_edit_${System.currentTimeMillis()}.jpg"
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/V7 Edited")
                    }
                }
                val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                } else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                val item = resolver.insert(collection, values) ?: return@withContext false
                resolver.openOutputStream(item)?.use { os ->
                    bmp.compress(Bitmap.CompressFormat.JPEG, 95, os)
                } ?: return@withContext false
                true
            } catch (e: Exception) {
                false
            }
        }
}

enum class PhotoFilter { NONE, MONO, WARM, COOL, VIVID, VINTAGE }

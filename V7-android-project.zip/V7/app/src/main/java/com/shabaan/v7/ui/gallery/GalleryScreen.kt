package com.shabaan.v7.ui.gallery

import android.content.Intent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.shabaan.v7.data.model.MediaItem
import com.shabaan.v7.data.repository.Album
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.shabaan.v7.ui.components.*
import com.shabaan.v7.util.SettingsStore
import com.shabaan.v7.util.SortOrder

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class)
@Composable
fun GalleryScreen(
    onOpenPhoto: (Int) -> Unit,
    vm: GalleryViewModel = hiltViewModel()
) {
    val perms = rememberMediaPermissions()
    val state by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val settings = remember { SettingsStore(ctx) }
    var sortBy by remember { mutableStateOf(settings.sortBy) }
    var sortOrder by remember { mutableStateOf(settings.sortOrder) }
    val cols = settings.gridSize.coerceAtLeast(3)

    val deleteLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.StartIntentSenderForResult()
    ) { vm.refreshAfterDelete() }

    fun requestDelete(uris: List<android.net.Uri>) {
        if (uris.isEmpty()) { vm.refreshAfterDelete(); return }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            val pi = android.provider.MediaStore.createDeleteRequest(ctx.contentResolver, uris)
            deleteLauncher.launch(
                androidx.activity.result.IntentSenderRequest.Builder(pi.intentSender).build()
            )
        } else {
            uris.forEach { runCatching { ctx.contentResolver.delete(it, null, null) } }
            vm.refreshAfterDelete()
        }
    }

    LaunchedEffect(perms.allPermissionsGranted) {
        if (perms.allPermissionsGranted) vm.ensureLoaded()
    }

    Column(Modifier.fillMaxSize()) {
        if (state.selectionMode) {
            SelectionTopBar(
                count = state.selection.size,
                totalAvailable = state.items.size,
                onClose = vm::clearSelection,
                onSelectAll = vm::selectAll,
                onShare = {
                    val items = vm.selectedItems()
                    if (items.isNotEmpty()) {
                        val send = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                            type = "image/*"
                            putParcelableArrayListExtra(
                                Intent.EXTRA_STREAM,
                                ArrayList(items.map { it.uri })
                            )
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        ctx.startActivity(Intent.createChooser(send, "Share photos"))
                    }
                    vm.clearSelection()
                },
                onVault = {
                    vm.moveSelectedToVault { uris -> requestDelete(uris) }
                },
                onDelete = {
                    vm.moveSelectedToTrash { uris -> requestDelete(uris) }
                }
            )
        } else {
            V7TopBar(title = "Gallery")
            GalleryTabRow(current = state.tab, onSelect = vm::setTab)
            if (state.tab != GalleryTab.ALBUMS) {
                SearchSortBar(
                    query = state.query,
                    onQueryChange = vm::setQuery,
                    sortBy = sortBy,
                    sortOrder = sortOrder,
                    onSortBy = { sb ->
                        sortBy = sb
                        settings.sortBy = sb
                        vm.load()
                    },
                    onToggleOrder = {
                        sortOrder = if (sortOrder == SortOrder.DESCENDING) SortOrder.ASCENDING else SortOrder.DESCENDING
                        settings.sortOrder = sortOrder
                        vm.load()
                    }
                )
            }
        }

        PermissionGate(perms) {
            when {
                state.loading -> ShimmerGrid(columns = cols)
                state.tab == GalleryTab.ALBUMS -> AlbumsGrid(
                    albums = state.albums,
                    columns = (cols - 1).coerceAtLeast(2),
                    onAlbumClick = { album ->
                        if (album.items.isNotEmpty()) {
                            PhotoSession.list = album.items
                            onOpenPhoto(0)
                        }
                    }
                )
                state.items.isEmpty() -> EmptyState(
                    text = if (state.query.isNotBlank()) "No matches"
                    else if (state.tab == GalleryTab.FAVORITES) "No favorites yet"
                    else "No photos yet",
                    icon = if (state.tab == GalleryTab.FAVORITES)
                        Icons.Outlined.FavoriteBorder
                    else Icons.Outlined.PhotoLibrary,
                    subtitle = if (state.tab == GalleryTab.FAVORITES)
                        "Tap the heart on any photo to save it here"
                    else "Photos on your device will appear here"
                )
                else -> PhotosGrid(
                    items = state.items,
                    favorites = state.favorites,
                    selection = state.selection,
                    selectionMode = state.selectionMode,
                    columns = cols,
                    onClick = { item ->
                        if (state.selectionMode) vm.toggleSelection(item.id)
                        else {
                            val idx = state.items.indexOf(item).coerceAtLeast(0)
                            PhotoSession.list = state.items
                            onOpenPhoto(idx)
                        }
                    },
                    onLongClick = { vm.startSelection(it.id) },
                    onFav = { vm.toggleFavorite(it.id) }
                )
            }
        }
    }
}

@Composable
private fun GalleryTabRow(current: GalleryTab, onSelect: (GalleryTab) -> Unit) {
    val tabs = GalleryTab.entries
    TabRow(
        selectedTabIndex = tabs.indexOf(current),
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.primary
    ) {
        tabs.forEach { t ->
            Tab(
                selected = current == t,
                onClick = { onSelect(t) },
                text = {
                    Text(
                        when (t) {
                            GalleryTab.PHOTOS -> "Photos"
                            GalleryTab.ALBUMS -> "Albums"
                            GalleryTab.FAVORITES -> "Favorites"
                        },
                        fontWeight = if (current == t) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalPermissionsApi::class)
@Composable
private fun PhotosGrid(
    items: List<MediaItem>,
    favorites: Set<Long>,
    selection: Set<Long>,
    selectionMode: Boolean,
    columns: Int,
    onClick: (MediaItem) -> Unit,
    onLongClick: (MediaItem) -> Unit,
    onFav: (MediaItem) -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(columns),
        contentPadding = PaddingValues(2.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        itemsIndexed(
            items,
            key = { _, it -> it.id },
            contentType = { _, _ -> "photo_cell" }
        ) { index, item ->
            PhotoCell(
                item = item,
                index = index,
                isFavorite = item.id in favorites,
                selected = item.id in selection,
                inSelectionMode = selectionMode,
                onClick = { onClick(item) },
                onLongClick = { onLongClick(item) },
                onFav = { onFav(item) }
            )
        }
    }
}

@Composable
private fun AlbumsGrid(
    albums: List<Album>,
    columns: Int,
    onAlbumClick: (Album) -> Unit
) {
    if (albums.isEmpty()) {
        EmptyState("No albums yet")
        return
    }
    LazyVerticalGrid(
        columns = GridCells.Fixed(columns),
        contentPadding = PaddingValues(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(albums, key = { it.name }) { album ->
            AlbumCard(album = album, onClick = { onAlbumClick(album) })
        }
    }
}

@Composable
private fun AlbumCard(album: Album, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .premiumClick { onClick() }
            .padding(4.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            album.cover?.let { cover ->
                AsyncImage(
                    model = rememberThumbRequest(data = cover.uri, mediaId = cover.id, sizePx = 500),
                    contentDescription = album.name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.scrim.copy(alpha = 0.55f))
                    .padding(8.dp)
            ) {
                Column {
                    Text(
                        album.name,
                        color = MaterialTheme.colorScheme.inverseOnSurface,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1
                    )
                    Text(
                        "${album.count} item${if (album.count == 1) "" else "s"}",
                        color = MaterialTheme.colorScheme.inverseOnSurface.copy(alpha = 0.85f),
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalPermissionsApi::class)
@Composable
private fun PhotoCell(
    item: MediaItem,
    index: Int,
    isFavorite: Boolean,
    selected: Boolean,
    inSelectionMode: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onFav: () -> Unit
) {
    Box(
        Modifier
            .padding(2.dp)
            .entrance(index)
            .aspectRatio(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        AsyncImage(
            model = rememberThumbRequest(data = item.uri, mediaId = item.id, sizePx = 400),
            contentDescription = item.name,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        if (!inSelectionMode) {
            IconButton(
                onClick = onFav,
                modifier = Modifier.align(Alignment.TopEnd).size(32.dp)
            ) {
                Icon(
                    imageVector = if (isFavorite) Icons.Outlined.Favorite
                    else Icons.Outlined.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (isFavorite) Color.White
                    else Color.White.copy(alpha = 0.85f)
                )
            }
        }
        SelectionOverlay(selected = selected)
    }
}

object PhotoSession {
    @Volatile var list: List<MediaItem> = emptyList()
}

package com.shabaan.v7.ui.gallery

import android.content.Intent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.shabaan.v7.data.model.MediaItem
import com.shabaan.v7.data.repository.Album
import com.shabaan.v7.data.repository.toDateSections
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.shabaan.v7.ui.components.*
import com.shabaan.v7.util.SettingsStore
import com.shabaan.v7.util.SortOrder

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class)
@Composable
fun GalleryScreen(
    onOpenPhoto: (Int) -> Unit,
    vm: GalleryViewModel = hiltViewModel()
) {
    val perms = rememberMediaPermissions()
    val state by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val settings = remember { SettingsStore(ctx) }
    var sortBy by remember { mutableStateOf(settings.sortBy) }
    var sortOrder by remember { mutableStateOf(settings.sortOrder) }
    val cols = settings.gridSize.coerceAtLeast(3)
    var openedAlbum by remember { mutableStateOf<Album?>(null) }

    val deleteLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.StartIntentSenderForResult()
    ) { vm.refreshAfterDelete() }

    fun requestDelete(uris: List<android.net.Uri>) {
        if (uris.isEmpty()) { vm.refreshAfterDelete(); return }
        // If the user granted All-files access, delete directly (no per-item
        // system dialog — smooth). Otherwise fall back to the system delete
        // request, which asks for confirmation once.
        if (com.shabaan.v7.util.FullAccess.isGranted(ctx)) {
            uris.forEach { runCatching { ctx.contentResolver.delete(it, null, null) } }
            vm.refreshAfterDelete()
            return
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            val pi = android.provider.MediaStore.createDeleteRequest(ctx.contentResolver, uris)
            deleteLauncher.launch(
                androidx.activity.result.IntentSenderRequest.Builder(pi.intentSender).build()
            )
        } else {
            uris.forEach { runCatching { ctx.contentResolver.delete(it, null, null) } }
            vm.refreshAfterDelete()
        }
    }

    LaunchedEffect(perms.allPermissionsGranted) {
        if (perms.allPermissionsGranted) vm.ensureLoaded()
    }

    Column(Modifier.fillMaxSize()) {
        if (state.selectionMode) {
            SelectionTopBar(
                count = state.selection.size,
                totalAvailable = state.items.size,
                onClose = vm::clearSelection,
                onSelectAll = vm::selectAll,
                onShare = {
                    val items = vm.selectedItems()
                    if (items.isNotEmpty()) {
                        val send = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                            type = "image/*"
                            putParcelableArrayListExtra(
                                Intent.EXTRA_STREAM,
                                ArrayList(items.map { it.uri })
                            )
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        ctx.startActivity(Intent.createChooser(send, "Share photos"))
                    }
                    vm.clearSelection()
                },
                onVault = {
                    vm.moveSelectedToVault { uris -> requestDelete(uris) }
                },
                onDelete = {
                    vm.moveSelectedToTrash { uris -> requestDelete(uris) }
                }
            )
        } else {
            V7TopBar(title = "Gallery")
            GalleryTabRow(current = state.tab, onSelect = vm::setTab)
            if (state.tab != GalleryTab.ALBUMS) {
                SearchSortBar(
                    query = state.query,
                    onQueryChange = vm::setQuery,
                    sortBy = sortBy,
                    sortOrder = sortOrder,
                    onSortBy = { sb ->
                        sortBy = sb
                        settings.sortBy = sb
                        vm.load()
                    },
                    onToggleOrder = {
                        sortOrder = if (sortOrder == SortOrder.DESCENDING) SortOrder.ASCENDING else SortOrder.DESCENDING
                        settings.sortOrder = sortOrder
                        vm.load()
                    }
                )
            }
        }

        PermissionGate(perms) {
            when {
                state.loading -> ShimmerGrid(columns = cols)
                state.tab == GalleryTab.DUPLICATES && state.duplicatesLoading ->
                    ShimmerGrid(columns = cols)
                state.tab == GalleryTab.ALBUMS && openedAlbum != null -> {
                    val album = openedAlbum!!
                    Column(Modifier.fillMaxSize()) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { openedAlbum = null }) {
                                Icon(
                                    Icons.AutoMirrored.Outlined.ArrowBack,
                                    contentDescription = "Back"
                                )
                            }
                            Text(
                                album.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        PhotosGrid(
                            items = album.items,
                            favorites = state.favorites,
                            selection = state.selection,
                            selectionMode = state.selectionMode,
                            columns = cols,
                            showDateHeaders = false,
                            onClick = { item ->
                                if (state.selectionMode) vm.toggleSelection(item.id)
                                else {
                                    val idx = album.items.indexOf(item).coerceAtLeast(0)
                                    PhotoSession.list = album.items
                                    onOpenPhoto(idx)
                                }
                            },
                            onLongClick = { vm.startSelection(it.id) },
                            onFav = { vm.toggleFavorite(it.id) }
                        )
                    }
                }
                state.tab == GalleryTab.ALBUMS -> AlbumsGrid(
                    albums = state.albums,
                    columns = (cols - 1).coerceAtLeast(2),
                    onAlbumClick = { album ->
                        if (album.items.isNotEmpty()) {
                            openedAlbum = album
                        }
                    }
                )
                state.items.isEmpty() -> EmptyState(
                    text = when {
                        state.query.isNotBlank() -> "No matches"
                        state.tab == GalleryTab.FAVORITES -> "No favorites yet"
                        state.tab == GalleryTab.DUPLICATES -> "No duplicates found"
                        else -> "No photos yet"
                    },
                    icon = when (state.tab) {
                        GalleryTab.FAVORITES -> Icons.Outlined.FavoriteBorder
                        GalleryTab.DUPLICATES -> Icons.Outlined.ContentCopy
                        else -> Icons.Outlined.PhotoLibrary
                    },
                    subtitle = when (state.tab) {
                        GalleryTab.FAVORITES -> "Tap the heart on any photo to save it here"
                        GalleryTab.DUPLICATES -> "Your library has no duplicate photos"
                        else -> "Photos on your device will appear here"
                    }
                )
                else -> PhotosGrid(
                    items = state.items,
                    favorites = state.favorites,
                    selection = state.selection,
                    selectionMode = state.selectionMode,
                    columns = cols,
                    showDateHeaders = state.tab == GalleryTab.PHOTOS,
                    onClick = { item ->
                        if (state.selectionMode) vm.toggleSelection(item.id)
                        else {
                            val idx = state.items.indexOf(item).coerceAtLeast(0)
                            PhotoSession.list = state.items
                            onOpenPhoto(idx)
                        }
                    },
                    onLongClick = { vm.startSelection(it.id) },
                    onFav = { vm.toggleFavorite(it.id) }
                )
            }
        }
    }
}

@Composable
private fun GalleryTabRow(current: GalleryTab, onSelect: (GalleryTab) -> Unit) {
    val tabs = GalleryTab.entries
    TabRow(
        selectedTabIndex = tabs.indexOf(current),
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.primary
    ) {
        tabs.forEach { t ->
            Tab(
                selected = current == t,
                onClick = { onSelect(t) },
                text = {
                    Text(
                        when (t) {
                            GalleryTab.PHOTOS -> "Photos"
                            GalleryTab.ALBUMS -> "Albums"
                            GalleryTab.FAVORITES -> "Favorites"
                            GalleryTab.DUPLICATES -> "Duplicates"
                        },
                        fontWeight = if (current == t) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalPermissionsApi::class)
@Composable
private fun PhotosGrid(
    items: List<MediaItem>,
    favorites: Set<Long>,
    selection: Set<Long>,
    selectionMode: Boolean,
    columns: Int,
    showDateHeaders: Boolean = true,
    onClick: (MediaItem) -> Unit,
    onLongClick: (MediaItem) -> Unit,
    onFav: (MediaItem) -> Unit
) {
    // Build date sections (Today / Yesterday / months…) for a timeline feel.
    val sections = remember(items, showDateHeaders) {
        if (showDateHeaders) items.toDateSections()
        else listOf(com.shabaan.v7.data.repository.DateSection("", items))
    }
    val gridState = androidx.compose.foundation.lazy.grid.rememberLazyGridState()

    Box(Modifier.fillMaxSize()) {
        LazyVerticalGrid(
            state = gridState,
            columns = GridCells.Fixed(columns),
            contentPadding = PaddingValues(2.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            sections.forEach { section ->
                if (section.title.isNotEmpty()) {
                    item(
                        span = { GridItemSpan(maxLineSpan) },
                        key = "header_${section.title}",
                        contentType = "date_header"
                    ) {
                        Text(
                            text = section.title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(start = 10.dp, top = 14.dp, bottom = 6.dp)
                        )
                    }
                }
                itemsIndexed(
                    section.items,
                    key = { _, it -> it.id },
                    contentType = { _, _ -> "photo_cell" }
                ) { index, item ->
                    PhotoCell(
                        item = item,
                        index = index,
                        isFavorite = item.id in favorites,
                        selected = item.id in selection,
                        inSelectionMode = selectionMode,
                        onClick = { onClick(item) },
                        onLongClick = { onLongClick(item) },
                        onFav = { onFav(item) }
                    )
                }
            }
        }

        // Real fast scroller: drag the thumb to jump through months quickly,
        // with a floating label showing the current section (like OPPO/Google).
        FastScroller(
            gridState = gridState,
            sections = sections,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
        )
    }
}

@Composable
private fun BoxScope.FastScroller(
    gridState: androidx.compose.foundation.lazy.grid.LazyGridState,
    sections: List<com.shabaan.v7.data.repository.DateSection>,
    modifier: Modifier = Modifier
) {
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val totalItems by remember(sections) {
        androidx.compose.runtime.derivedStateOf {
            sections.sumOf { (if (it.title.isNotEmpty()) 1 else 0) + it.items.size }
        }
    }
    var dragging by remember { mutableStateOf(false) }
    var thumbFraction by remember { androidx.compose.runtime.mutableFloatStateOf(0f) }

    // Keep the thumb synced to the list while the user is NOT dragging.
    val firstVisible by remember {
        androidx.compose.runtime.derivedStateOf { gridState.firstVisibleItemIndex }
    }
    if (!dragging && totalItems > 0) {
        thumbFraction = (firstVisible.toFloat() / totalItems).coerceIn(0f, 1f)
    }

    // Resolve the section label nearest the current thumb position.
    val currentLabel by remember(sections) {
        androidx.compose.runtime.derivedStateOf {
            if (sections.isEmpty()) ""
            else {
                val target = (thumbFraction * totalItems).toInt()
                var acc = 0
                var label = sections.first().title
                for (s in sections) {
                    val rows = (if (s.title.isNotEmpty()) 1 else 0) + s.items.size
                    if (target < acc + rows) { label = s.title; break }
                    acc += rows
                }
                label
            }
        }
    }

    val onlyOneScreen = totalItems <= 30
    if (onlyOneScreen) return  // no need for a scroller on short lists

    androidx.compose.foundation.layout.Box(
        modifier = modifier.width(40.dp),
        contentAlignment = Alignment.TopEnd
    ) {
        androidx.compose.foundation.layout.BoxWithConstraints(
            Modifier.fillMaxHeight()
        ) {
            val density = androidx.compose.ui.platform.LocalDensity.current
            val trackHeightPx = with(density) { maxHeight.toPx() }
            val thumbHeight = 48.dp
            val thumbHeightPx = with(density) { thumbHeight.toPx() }
            val labelOffsetXpx = with(density) { (-48).dp.roundToPx() }
            val maxOffset = (trackHeightPx - thumbHeightPx).coerceAtLeast(1f)
            val thumbOffsetY = (thumbFraction * maxOffset)

            // Floating month label while dragging
            if (dragging && currentLabel.isNotEmpty()) {
                androidx.compose.material3.Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset {
                            androidx.compose.ui.unit.IntOffset(
                                x = labelOffsetXpx,
                                y = thumbOffsetY.toInt()
                            )
                        }
                        .padding(end = 4.dp)
                ) {
                    Text(
                        currentLabel,
                        color = MaterialTheme.colorScheme.onPrimary,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            // The draggable thumb
            androidx.compose.foundation.layout.Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset { androidx.compose.ui.unit.IntOffset(0, thumbOffsetY.toInt()) }
                    .padding(end = 4.dp)
                    .size(width = 8.dp, height = thumbHeight)
                    .background(
                        if (dragging) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                        RoundedCornerShape(4.dp)
                    )
                    .pointerInput(maxOffset, totalItems) {
                        detectVerticalDragGestures(
                            onDragStart = { dragging = true },
                            onDragEnd = { dragging = false },
                            onDragCancel = { dragging = false }
                        ) { change: androidx.compose.ui.input.pointer.PointerInputChange, _: Float ->
                            change.consume()
                            val newY = (thumbFraction * maxOffset + change.position.y - thumbHeightPx / 2)
                                .coerceIn(0f, maxOffset)
                            thumbFraction = newY / maxOffset
                            val targetIndex = (thumbFraction * totalItems).toInt()
                                .coerceIn(0, (totalItems - 1).coerceAtLeast(0))
                            scope.launch { gridState.scrollToItem(targetIndex) }
                        }
                    }
            )
        }
    }
}

@Composable
private fun AlbumsGrid(
    albums: List<Album>,
    columns: Int,
    onAlbumClick: (Album) -> Unit
) {
    if (albums.isEmpty()) {
        EmptyState("No albums yet")
        return
    }
    LazyVerticalGrid(
        columns = GridCells.Fixed(columns),
        contentPadding = PaddingValues(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(albums, key = { it.name }) { album ->
            AlbumCard(album = album, onClick = { onAlbumClick(album) })
        }
    }
}

@Composable
private fun AlbumCard(album: Album, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .premiumClick { onClick() }
            .padding(4.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            album.cover?.let { cover ->
                AsyncImage(
                    model = rememberThumbRequest(data = cover.uri, mediaId = cover.id, sizePx = 500),
                    contentDescription = album.name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.scrim.copy(alpha = 0.55f))
                    .padding(8.dp)
            ) {
                Column {
                    Text(
                        album.name,
                        color = MaterialTheme.colorScheme.inverseOnSurface,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1
                    )
                    Text(
                        "${album.count} item${if (album.count == 1) "" else "s"}",
                        color = MaterialTheme.colorScheme.inverseOnSurface.copy(alpha = 0.85f),
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalPermissionsApi::class)
@Composable
private fun PhotoCell(
    item: MediaItem,
    index: Int,
    isFavorite: Boolean,
    selected: Boolean,
    inSelectionMode: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onFav: () -> Unit
) {
    Box(
        Modifier
            .padding(2.dp)
            .entrance(index)
            .aspectRatio(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        AsyncImage(
            model = rememberThumbRequest(data = item.uri, mediaId = item.id, sizePx = 400),
            contentDescription = item.name,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        SelectionOverlay(selected = selected)
    }
}

object PhotoSession {
    @Volatile var list: List<MediaItem> = emptyList()
}

/** Holds the image URI to open in the photo editor. */
object EditSession {
    @Volatile var uri: android.net.Uri? = null
}

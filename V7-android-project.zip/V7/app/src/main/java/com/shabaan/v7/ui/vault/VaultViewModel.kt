package com.shabaan.v7.ui.vault

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shabaan.v7.data.local.VaultItemEntity
import com.shabaan.v7.data.repository.VaultRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class VaultViewModel @Inject constructor(
    private val repo: VaultRepository
) : ViewModel() {

    val items: StateFlow<List<VaultItemEntity>> =
        repo.vaultItems.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun restore(item: VaultItemEntity, onDone: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            val ok = repo.restore(item)
            onDone(ok)
        }
    }

    fun delete(item: VaultItemEntity, onDone: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            val ok = repo.deletePermanently(item)
            onDone(ok)
        }
    }

    /**
     * Resolve a shareable/viewable URI for an item. For encrypted items this
     * decrypts to a temp file in cache first, so it runs off the main thread.
     */
    fun resolveViewable(item: VaultItemEntity, onReady: (Uri?) -> Unit) {
        viewModelScope.launch {
            val uri = if (item.encrypted) repo.viewerUri(item) else repo.uriFor(item)
            onReady(uri)
        }
    }
}

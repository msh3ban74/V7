package com.shabaan.v7.ui.gallery

import android.net.Uri
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.PhoneAndroid
import androidx.compose.material.icons.outlined.Wallpaper
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.shabaan.v7.data.model.MediaItem
import com.shabaan.v7.util.Formatters
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun PhotoViewerRoute(
    startIndex: Int,
    onBack: () -> Unit,
    onEdit: (Uri) -> Unit = {},
    actionsVm: PhotoActionsViewModel = androidx.hilt.navigation.compose.hiltViewModel()
) {
    val items = remember { PhotoSession.list }
    if (items.isEmpty()) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    BackHandler { onBack() }
    val pager = rememberPagerState(initialPage = startIndex.coerceIn(0, items.lastIndex)) {
        items.size
    }
    val ctx = LocalContext.current

    var slideshow by remember { mutableStateOf(false) }
    var chromeVisible by remember { mutableStateOf(true) }
    var showInfo by remember { mutableStateOf(false) }
    var showMore by remember { mutableStateOf(false) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val sheetState = rememberModalBottomSheetState()

    // Slideshow auto-advance
    LaunchedEffect(slideshow) {
        if (slideshow) {
            chromeVisible = false
            while (true) {
                delay(3000)
                val next = (pager.currentPage + 1) % items.size
                pager.animateScrollToPage(next)
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(state = pager) { page ->
            val photo = items[page]
            ZoomableImage(
                model = ImageRequest.Builder(ctx)
                    .data(photo.uri)
                    .crossfade(true)
                    .build(),
                onTap = { if (!slideshow) chromeVisible = !chromeVisible },
                onSwipeDownToDismiss = { if (!slideshow) onBack() }
            )
        }

        // Top bar
        AnimatedVisibility(
            visible = chromeVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Surface(
                color = Color.Black.copy(alpha = 0.4f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    val cur = items[pager.currentPage]
                    val favorites by actionsVm.favorites.collectAsState()
                    val isFav = cur.id in favorites
                    Spacer(Modifier.weight(1f))
                    // Like
                    IconButton(onClick = { actionsVm.toggleFavorite(cur.id) }) {
                        Icon(
                            if (isFav) Icons.Outlined.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = "Like",
                            tint = if (isFav) Color(0xFFFF3B5C) else Color.White
                        )
                    }
                    // Share
                    IconButton(onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = cur.mimeType
                            putExtra(Intent.EXTRA_STREAM, cur.uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        ctx.startActivity(Intent.createChooser(send, "Share"))
                    }) {
                        Icon(Icons.Outlined.Share, contentDescription = "Share", tint = Color.White)
                    }
                    // Delete (move to trash)
                    IconButton(onClick = {
                        actionsVm.moveToTrash(cur) {
                            android.widget.Toast.makeText(
                                ctx, "Moved to Recently Deleted", android.widget.Toast.LENGTH_SHORT
                            ).show()
                            onBack()
                        }
                    }) {
                        Icon(Icons.Outlined.Delete, contentDescription = "Delete", tint = Color.White)
                    }
                    // Edit
                    IconButton(onClick = { onEdit(cur.uri) }) {
                        Icon(Icons.Outlined.Edit, contentDescription = "Edit", tint = Color.White)
                    }
                    // More (wallpaper + info)
                    Box {
                        IconButton(onClick = { showMore = true }) {
                            Icon(Icons.Outlined.MoreVert, contentDescription = "More", tint = Color.White)
                        }
                        DropdownMenu(
                            expanded = showMore,
                            onDismissRequest = { showMore = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Set as home wallpaper") },
                                leadingIcon = { Icon(Icons.Outlined.Wallpaper, contentDescription = null) },
                                onClick = {
                                    showMore = false
                                    setWallpaper(ctx, cur.uri, com.shabaan.v7.util.WallpaperSetter.Target.HOME, scope)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Set as lock screen") },
                                leadingIcon = { Icon(Icons.Outlined.Lock, contentDescription = null) },
                                onClick = {
                                    showMore = false
                                    setWallpaper(ctx, cur.uri, com.shabaan.v7.util.WallpaperSetter.Target.LOCK, scope)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Set as both") },
                                leadingIcon = { Icon(Icons.Outlined.PhoneAndroid, contentDescription = null) },
                                onClick = {
                                    showMore = false
                                    setWallpaper(ctx, cur.uri, com.shabaan.v7.util.WallpaperSetter.Target.BOTH, scope)
                                }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("Info") },
                                leadingIcon = { Icon(Icons.Outlined.Info, contentDescription = null) },
                                onClick = { showMore = false; showInfo = true }
                            )
                        }
                    }
                }
            }
        }

        // Slideshow toggle button (always visible, but subtle)
        Surface(
            color = Color.Black.copy(alpha = 0.4f),
            shape = androidx.compose.foundation.shape.CircleShape,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
        ) {
            IconButton(onClick = { slideshow = !slideshow }) {
                Icon(
                    if (slideshow) Icons.Outlined.Pause else Icons.Outlined.PlayArrow,
                    contentDescription = "Slideshow",
                    tint = Color.White
                )
            }
        }
    }

    if (showInfo) {
        ModalBottomSheet(
            onDismissRequest = { showInfo = false },
            sheetState = sheetState
        ) {
            PhotoInfo(items[pager.currentPage])
        }
    }
}

@Composable
private fun PhotoInfo(item: MediaItem) {
    val dateFmt = remember { SimpleDateFormat("MMM d, yyyy 'at' h:mm a", Locale.getDefault()) }
    Column(
        Modifier.fillMaxWidth().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Details", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        InfoRow("Name", item.name)
        InfoRow("Size", Formatters.fileSize(item.size))
        if (item.width > 0 && item.height > 0) {
            InfoRow("Dimensions", "${item.width} × ${item.height}")
        }
        InfoRow("Type", item.mimeType)
        InfoRow("Date", dateFmt.format(Date(item.dateAdded * 1000)))
        item.relativePath?.let { InfoRow("Folder", it) }
        Spacer(Modifier.padding(8.dp))
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(0.35f)
        )
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(0.65f)
        )
    }
}

@Composable
private fun ZoomableImage(
    model: ImageRequest,
    onTap: () -> Unit,
    onSwipeDownToDismiss: () -> Unit = {}
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    var dismissDrag by remember { mutableFloatStateOf(0f) }
    val zoomed = scale > 1.01f

    Box(
        Modifier
            .fillMaxSize()
            .clipToBounds()
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = {
                        if (scale > 1f) { scale = 1f; offsetX = 0f; offsetY = 0f }
                        else scale = 2.5f
                    }
                )
            }
            .pointerInput(Unit) {
                // Swipe-down to dismiss — only when not zoomed. We DON'T consume
                // horizontal movement, so the pager still receives left/right
                // swipes to move between photos.
                detectVerticalDragGestures(
                    onDragEnd = {
                        if (dismissDrag > 300f) onSwipeDownToDismiss()
                        dismissDrag = 0f
                    }
                ) { _: androidx.compose.ui.input.pointer.PointerInputChange, drag: Float ->
                    if (scale <= 1.01f && drag > 0f) dismissDrag += drag
                }
            }
            // When zoomed: intercept transform gestures for pan/zoom.
            // When NOT zoomed: attach NO pointer input here, so the parent
            // HorizontalPager freely receives left/right swipes between photos.
            // Zooming in is done via double-tap (handled above).
            .then(
                if (zoomed) Modifier.pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val newScale = (scale * zoom).coerceIn(1f, 5f)
                        scale = newScale
                        if (newScale > 1f) {
                            offsetX += pan.x
                            offsetY += pan.y
                        } else {
                            offsetX = 0f; offsetY = 0f
                        }
                    }
                } else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = model,
            contentDescription = null,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offsetX,
                    translationY = offsetY + dismissDrag * 0.5f
                )
        )
    }
}

private fun setWallpaper(
    ctx: android.content.Context,
    uri: Uri,
    target: com.shabaan.v7.util.WallpaperSetter.Target,
    scope: kotlinx.coroutines.CoroutineScope
) {
    scope.launch {
        val ok = com.shabaan.v7.util.WallpaperSetter.setWallpaper(ctx, uri, target)
        android.widget.Toast.makeText(
            ctx,
            if (ok) "Wallpaper set" else "Couldn't set wallpaper",
            android.widget.Toast.LENGTH_SHORT
        ).show()
    }
}

package com.shabaan.v7.ui.gallery

import android.net.Uri
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.Wallpaper
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.shabaan.v7.data.model.MediaItem
import com.shabaan.v7.util.Formatters
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun PhotoViewerRoute(
    startIndex: Int,
    onBack: () -> Unit,
    onEdit: (Uri) -> Unit = {},
    actionsVm: PhotoActionsViewModel = androidx.hilt.navigation.compose.hiltViewModel()
) {
    val items = remember { PhotoSession.list }
    if (items.isEmpty()) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    BackHandler { onBack() }
    val pager = rememberPagerState(initialPage = startIndex.coerceIn(0, items.lastIndex)) {
        items.size
    }
    val ctx = LocalContext.current

    var slideshow by remember { mutableStateOf(false) }
    var chromeVisible by remember { mutableStateOf(true) }
    var showInfo by remember { mutableStateOf(false) }
    var showMore by remember { mutableStateOf(false) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val sheetState = rememberModalBottomSheetState()

    // Slideshow auto-advance
    LaunchedEffect(slideshow) {
        if (slideshow) {
            chromeVisible = false
            while (true) {
                delay(3000)
                val next = (pager.currentPage + 1) % items.size
                pager.animateScrollToPage(next)
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(state = pager) { page ->
            val photo = items[page]
            ZoomableImage(
                model = ImageRequest.Builder(ctx)
                    .data(photo.uri)
                    .crossfade(true)
                    .build(),
                onTap = { if (!slideshow) chromeVisible = !chromeVisible },
                onSwipeDownToDismiss = { if (!slideshow) onBack() }
            )
        }

        // Top bar
        AnimatedVisibility(
            visible = chromeVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Surface(
                color = Color.Black.copy(alpha = 0.4f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    val cur = items[pager.currentPage]
                    val favorites by actionsVm.favorites.collectAsState()
                    val isFav = cur.id in favorites
                    Spacer(Modifier.weight(1f))
                    // Like
                    IconButton(onClick = { actionsVm.toggleFavorite(cur.id) }) {
                        Icon(
                            if (isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                            contentDescription = "Like",
                            tint = if (isFav) Color(0xFFFF3B5C) else Color.White
                        )
                    }
                    // Share
                    IconButton(onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = cur.mimeType
                            putExtra(Intent.EXTRA_STREAM, cur.uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        ctx.startActivity(Intent.createChooser(send, "Share"))
                    }) {
                        Icon(Icons.Rounded.Share, contentDescription = "Share", tint = Color.White)
                    }
                    // Delete (move to trash)
                    IconButton(onClick = {
                        actionsVm.moveToTrash(cur) {
                            android.widget.Toast.makeText(
                                ctx, "Moved to Recently Deleted", android.widget.Toast.LENGTH_SHORT
                            ).show()
                            onBack()
                        }
                    }) {
                        Icon(Icons.Rounded.Delete, contentDescription = "Delete", tint = Color.White)
                    }
                    // Edit
                    IconButton(onClick = { onEdit(cur.uri) }) {
                        Icon(Icons.Rounded.Edit, contentDescription = "Edit", tint = Color.White)
                    }
                    // More (wallpaper + info)
                    Box {
                        IconButton(onClick = { showMore = true }) {
                            Icon(Icons.Rounded.MoreVert, contentDescription = "More", tint = Color.White)
                        }
                        DropdownMenu(
                            expanded = showMore,
                            onDismissRequest = { showMore = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Set as home wallpaper") },
                                leadingIcon = { Icon(Icons.Rounded.Wallpaper, contentDescription = null) },
                                onClick = {
                                    showMore = false
                                    setWallpaper(ctx, cur.uri, com.shabaan.v7.util.WallpaperSetter.Target.HOME, scope)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Set as lock screen") },
                                leadingIcon = { Icon(Icons.Rounded.Lock, contentDescription = null) },
                                onClick = {
                                    showMore = false
                                    setWallpaper(ctx, cur.uri, com.shabaan.v7.util.WallpaperSetter.Target.LOCK, scope)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Set as both") },
                                leadingIcon = { Icon(Icons.Rounded.PhoneAndroid, contentDescription = null) },
                                onClick = {
                                    showMore = false
                                    setWallpaper(ctx, cur.uri, com.shabaan.v7.util.WallpaperSetter.Target.BOTH, scope)
                                }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("Info") },
                                leadingIcon = { Icon(Icons.Rounded.Info, contentDescription = null) },
                                onClick = { showMore = false; showInfo = true }
                            )
                        }
                    }
                }
            }
        }

        // Slideshow toggle button (always visible, but subtle)
        Surface(
            color = Color.Black.copy(alpha = 0.4f),
            shape = androidx.compose.foundation.shape.CircleShape,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
        ) {
            IconButton(onClick = { slideshow = !slideshow }) {
                Icon(
                    if (slideshow) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = "Slideshow",
                    tint = Color.White
                )
            }
        }
    }

    if (showInfo) {
        ModalBottomSheet(
            onDismissRequest = { showInfo = false },
            sheetState = sheetState
        ) {
            PhotoInfo(items[pager.currentPage])
        }
    }
}

@Composable
private fun PhotoInfo(item: MediaItem) {
    val dateFmt = remember { SimpleDateFormat("MMM d, yyyy 'at' h:mm a", Locale.getDefault()) }
    Column(
        Modifier.fillMaxWidth().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Details", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        InfoRow("Name", item.name)
        InfoRow("Size", Formatters.fileSize(item.size))
        if (item.width > 0 && item.height > 0) {
            InfoRow("Dimensions", "${item.width} × ${item.height}")
        }
        InfoRow("Type", item.mimeType)
        InfoRow("Date", dateFmt.format(Date(item.dateAdded * 1000)))
        item.relativePath?.let { InfoRow("Folder", it) }
        Spacer(Modifier.padding(8.dp))
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(0.35f)
        )
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(0.65f)
        )
    }
}

@Composable
private fun ZoomableImage(
    model: ImageRequest,
    onTap: () -> Unit,
    onSwipeDownToDismiss: () -> Unit = {}
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    Box(
        Modifier
            .fillMaxSize()
            .clipToBounds()
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = { tapOffset ->
                        if (scale > 1f) {
                            scale = 1f; offsetX = 0f; offsetY = 0f
                        } else {
                            scale = 2.5f
                            val focusX = tapOffset.x - size.width / 2f
                            val focusY = tapOffset.y - size.height / 2f
                            val maxX = (size.width * (scale - 1f)) / 2f
                            val maxY = (size.height * (scale - 1f)) / 2f
                            offsetX = (-focusX * (scale - 1f)).coerceIn(-maxX, maxX)
                            offsetY = (-focusY * (scale - 1f)).coerceIn(-maxY, maxY)
                        }
                    }
                )
            }
            // Custom multi-touch handler: two-finger pinch ALWAYS zooms (even from
            // normal zoom). A one-finger drag only pans/consumes WHEN zoomed; at
            // normal zoom one-finger gestures are left alone so the HorizontalPager
            // receives left/right swipes (and the swipe-down-to-dismiss works).
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent()
                        val pointers = event.changes.count { it.pressed }
                        val zoomChange = event.calculateZoom()
                        val panChange = event.calculatePan()

                        if (pointers >= 2) {
                            // Pinch zoom (focal point aware)
                            val oldScale = scale
                            val newScale = (scale * zoomChange).coerceIn(1f, 5f)
                            scale = newScale
                            if (newScale > 1f) {
                                val centroid = event.calculateCentroid()
                                val focusX = centroid.x - size.width / 2f
                                val focusY = centroid.y - size.height / 2f
                                offsetX = (offsetX + panChange.x) + (focusX - focusX * (newScale / oldScale))
                                offsetY = (offsetY + panChange.y) + (focusY - focusY * (newScale / oldScale))
                                val maxX = (size.width * (newScale - 1f)) / 2f
                                val maxY = (size.height * (newScale - 1f)) / 2f
                                offsetX = offsetX.coerceIn(-maxX, maxX)
                                offsetY = offsetY.coerceIn(-maxY, maxY)
                            } else {
                                offsetX = 0f; offsetY = 0f
                            }
                            event.changes.forEach { it.consume() }
                        } else if (pointers == 1 && scale > 1.01f) {
                            // One-finger pan while zoomed in (consume so pager doesn't move)
                            val maxX = (size.width * (scale - 1f)) / 2f
                            val maxY = (size.height * (scale - 1f)) / 2f
                            offsetX = (offsetX + panChange.x).coerceIn(-maxX, maxX)
                            offsetY = (offsetY + panChange.y).coerceIn(-maxY, maxY)
                            event.changes.forEach { it.consume() }
                        }
                        // else: normal zoom, single finger → don't consume,
                        // let the pager handle the horizontal swipe.
                    } while (event.changes.any { it.pressed })
                }
            },
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = model,
            contentDescription = null,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offsetX,
                    translationY = offsetY
                )
        )
    }
}

private fun setWallpaper(
    ctx: android.content.Context,
    uri: Uri,
    target: com.shabaan.v7.util.WallpaperSetter.Target,
    scope: kotlinx.coroutines.CoroutineScope
) {
    scope.launch {
        val ok = com.shabaan.v7.util.WallpaperSetter.setWallpaper(ctx, uri, target)
        android.widget.Toast.makeText(
            ctx,
            if (ok) "Wallpaper set" else "Couldn't set wallpaper",
            android.widget.Toast.LENGTH_SHORT
        ).show()
    }
}

package com.shabaan.v7.util

import android.graphics.Bitmap
import java.io.ByteArrayOutputStream

/**
 * Assembles an **animated WebP** (WhatsApp-compatible sticker) from a list of
 * bitmaps. Each frame is first encoded to a standalone lossy WebP using
 * Android's built-in encoder (Bitmap.compress), then the per-frame VP8 bitstream
 * is wrapped into ANMF chunks inside a VP8X/ANIM RIFF container.
 *
 * This needs no native library: it only does byte-level RIFF muxing, while the
 * heavy image compression is delegated to the platform encoder.
 *
 * WhatsApp sticker rules respected: canvas 512x512, animated stickers must be
 * < 500 KB and ≤ 10 s; we cap frames/quality to stay under budget.
 */
object AnimatedWebpEncoder {

    private const val CANVAS = 512

    /** Builds the animated WebP bytes, or null on failure. */
    fun encode(
        frames: List<Bitmap>,
        frameDurationMs: Int,
        quality: Int = 70,
        loopCount: Int = 0
    ): ByteArray? {
        if (frames.isEmpty()) return null
        return try {
            val anmfChunks = ArrayList<ByteArray>()
            for (frame in frames) {
                val square = toSquare(frame, CANVAS)
                val webp = compressWebp(square, quality) ?: return null
                val vp8 = extractVp8Payload(webp) ?: return null
                anmfChunks.add(buildAnmf(vp8, frameDurationMs))
                if (square !== frame) square.recycle()
            }

            // ---- Assemble the RIFF ----
            val body = ByteArrayOutputStream()
            // VP8X header (extended features: animation flag = 0x02)
            body.write(fourcc("VP8X"))
            body.write(leInt(10))                       // chunk size
            body.write(0x02)                            // flags: animation
            body.write(byteArrayOf(0, 0, 0))            // reserved
            body.write(le24(CANVAS - 1))                // canvas width - 1
            body.write(le24(CANVAS - 1))                // canvas height - 1

            // ANIM chunk (background + loop count)
            body.write(fourcc("ANIM"))
            body.write(leInt(6))
            body.write(byteArrayOf(0, 0, 0, 0))         // background (transparent)
            body.write(leShort(loopCount))              // loop count (0 = forever)

            for (chunk in anmfChunks) body.write(chunk)

            val bodyBytes = body.toByteArray()
            val out = ByteArrayOutputStream()
            out.write(fourcc("RIFF"))
            out.write(leInt(4 + bodyBytes.size))        // file size - 8
            out.write(fourcc("WEBP"))
            out.write(bodyBytes)
            out.toByteArray()
        } catch (e: Exception) {
            null
        }
    }

    /** Wraps a raw VP8 keyframe payload in an ANMF (animation frame) chunk. */
    private fun buildAnmf(vp8Payload: ByteArray, durationMs: Int): ByteArray {
        // Inner VP8 sub-chunk
        val sub = ByteArrayOutputStream()
        sub.write(fourcc("VP8 "))
        sub.write(leInt(vp8Payload.size))
        sub.write(vp8Payload)
        if (vp8Payload.size % 2 == 1) sub.write(0)      // pad to even
        val subBytes = sub.toByteArray()

        val frameData = ByteArrayOutputStream()
        frameData.write(le24(0))                        // frame X
        frameData.write(le24(0))                        // frame Y
        frameData.write(le24(CANVAS - 1))               // width - 1
        frameData.write(le24(CANVAS - 1))               // height - 1
        frameData.write(le24(durationMs))               // frame duration
        frameData.write(0x00)                           // blend/dispose flags
        frameData.write(subBytes)
        val fdBytes = frameData.toByteArray()

        val anmf = ByteArrayOutputStream()
        anmf.write(fourcc("ANMF"))
        anmf.write(leInt(fdBytes.size))
        anmf.write(fdBytes)
        if (fdBytes.size % 2 == 1) anmf.write(0)
        return anmf.toByteArray()
    }

    /** Pulls the VP8 bitstream out of a simple (lossy) WebP file. */
    private fun extractVp8Payload(webp: ByteArray): ByteArray? {
        // Layout: "RIFF"(4) size(4) "WEBP"(4) "VP8 "(4) size(4) payload...
        if (webp.size < 20) return null
        if (String(webp, 0, 4) != "RIFF") return null
        if (String(webp, 8, 4) != "WEBP") return null
        var pos = 12
        while (pos + 8 <= webp.size) {
            val tag = String(webp, pos, 4)
            val size = (webp[pos + 4].toInt() and 0xFF) or
                ((webp[pos + 5].toInt() and 0xFF) shl 8) or
                ((webp[pos + 6].toInt() and 0xFF) shl 16) or
                ((webp[pos + 7].toInt() and 0xFF) shl 24)
            val start = pos + 8
            if (tag == "VP8 ") {
                if (start + size > webp.size) return null
                return webp.copyOfRange(start, start + size)
            }
            pos = start + size + (size and 1)
        }
        return null
    }

    private fun compressWebp(bmp: Bitmap, quality: Int): ByteArray? {
        val bos = ByteArrayOutputStream()
        @Suppress("DEPRECATION")
        val ok = bmp.compress(Bitmap.CompressFormat.WEBP, quality, bos)
        return if (ok) bos.toByteArray() else null
    }

    /** Center-crops/scales [src] into a square [size]x[size] bitmap. */
    private fun toSquare(src: Bitmap, size: Int): Bitmap {
        if (src.width == size && src.height == size) return src
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(out)
        val scale = size.toFloat() / minOf(src.width, src.height)
        val sw = src.width * scale
        val sh = src.height * scale
        val left = (size - sw) / 2f
        val top = (size - sh) / 2f
        val dst = android.graphics.RectF(left, top, left + sw, top + sh)
        canvas.drawBitmap(src, null, dst, android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
        return out
    }

    // ---- little-endian helpers ----
    private fun fourcc(s: String) = s.toByteArray(Charsets.US_ASCII)
    private fun leInt(v: Int) = byteArrayOf(
        (v and 0xFF).toByte(),
        ((v shr 8) and 0xFF).toByte(),
        ((v shr 16) and 0xFF).toByte(),
        ((v shr 24) and 0xFF).toByte()
    )
    private fun leShort(v: Int) = byteArrayOf(
        (v and 0xFF).toByte(),
        ((v shr 8) and 0xFF).toByte()
    )
    private fun le24(v: Int) = byteArrayOf(
        (v and 0xFF).toByte(),
        ((v shr 8) and 0xFF).toByte(),
        ((v shr 16) and 0xFF).toByte()
    )
}

package com.shabaan.v7.util

import android.content.Context
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKey
import coil.ImageLoader
import coil.decode.DataSource
import coil.decode.ImageSource
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.fetch.SourceResult
import coil.request.Options
import okio.Buffer
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Model for loading a thumbnail of an *encrypted* vault item. The vault is
 * already protected by the app lock (fingerprint/PIN), so once the user is
 * inside it's fine to show real previews — like the stock gallery's secure
 * folder. This fetcher decrypts the bytes in memory and hands them to Coil,
 * which then caches the decoded thumbnail.
 */
data class VaultThumb(
    val storedPath: String,
    val encrypted: Boolean,
    val id: Long
)

class VaultThumbnailFetcher(
    private val context: Context,
    private val model: VaultThumb,
    private val options: Options
) : Fetcher {

    override suspend fun fetch(): FetchResult? {
        val file = File(model.storedPath)
        if (!file.exists()) return null
        val bytes: ByteArray = try {
            if (model.encrypted) {
                val masterKey = MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build()
                val enc = EncryptedFile.Builder(
                    context, file, masterKey,
                    EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
                ).build()
                val bos = ByteArrayOutputStream()
                enc.openFileInput().use { it.copyTo(bos, 64 * 1024) }
                bos.toByteArray()
            } else {
                file.readBytes()
            }
        } catch (e: Exception) {
            return null
        }
        val buffer = Buffer().apply { write(bytes) }
        return SourceResult(
            source = ImageSource(buffer, context),
            mimeType = null,
            dataSource = DataSource.DISK
        )
    }

    class Factory(private val context: Context) : Fetcher.Factory<VaultThumb> {
        override fun create(data: VaultThumb, options: Options, imageLoader: ImageLoader): Fetcher =
            VaultThumbnailFetcher(context, data, options)
    }
}

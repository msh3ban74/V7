package com.shabaan.v7.ui.videos

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shabaan.v7.data.local.PlaybackProgressEntity
import com.shabaan.v7.data.local.ProgressDao
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Persists and restores video playback position for resume support. */
@HiltViewModel
class PlaybackProgressViewModel @Inject constructor(
    private val dao: ProgressDao
) : ViewModel() {

    /** Save the current position. Clears the entry once the video is essentially finished. */
    fun save(mediaId: Long, positionMs: Long, durationMs: Long, title: String, uri: String) {
        viewModelScope.launch {
            // If within the last 5s (or <3s in), don't keep a resume point.
            val nearEnd = durationMs > 0 && positionMs >= durationMs - 5_000
            val tooEarly = positionMs < 3_000
            if (nearEnd || tooEarly) {
                dao.deleteById(mediaId)
            } else {
                dao.upsert(
                    PlaybackProgressEntity(
                        mediaId = mediaId,
                        positionMs = positionMs,
                        durationMs = durationMs,
                        title = title,
                        uri = uri,
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }
        }
    }

    /** Look up a saved position; returns 0 if none. */
    suspend fun resumePosition(mediaId: Long): Long = dao.get(mediaId)?.positionMs ?: 0L
}

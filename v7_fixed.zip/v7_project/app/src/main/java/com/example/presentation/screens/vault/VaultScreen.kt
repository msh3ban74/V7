package com.example.presentation.screens.vault

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import kotlinx.coroutines.launch
import com.example.domain.model.ImageItem
import com.example.domain.model.VideoItem
import com.example.domain.model.AudioItem
import com.example.presentation.screens.player.media3.Media3Manager
import com.example.presentation.screens.player.media3.PlayerController
import com.example.presentation.screens.player.media3.PlayerMediaItem
import com.example.presentation.screens.player.media3.VideoPlayerComposable
import com.example.presentation.screens.music.AudioPlayerScreen
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VaultScreen(
    vaultManager: VaultManager,
    vaultRepository: VaultRepository,
    securityManager: VaultSecurityManager,
    onNavigateToPlayer: (String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isLocked by securityManager.isLocked.collectAsState()
    val vaultedMedia by vaultRepository.vaultedMedia.collectAsState(initial = emptyList())
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                // Skip the auto-lock once if the stop was caused by launching a share sheet.
                if (!com.example.presentation.immersive.ShareSession.consumeShareInFlight()) {
                    securityManager.lock()
                }
            } else if (event == Lifecycle.Event.ON_START) {
                securityManager.checkTimeout()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current
    var activeImageItem by remember { mutableStateOf<ImageItem?>(null) }
    var activeVideoItem by remember { mutableStateOf<VideoItem?>(null) }
    var activeAudioItem by remember { mutableStateOf<AudioItem?>(null) }

    // In-screen player: vaulted files are physically moved out of MediaStore, so they must
    // be played directly from their private file:// URIs — never via the MediaStore-backed
    // ID player (which would report "media track not found").
    val media3Manager = remember { Media3Manager(context) }
    val playerController = remember { PlayerController(context, media3Manager) }

    DisposableEffect(Unit) {
        onDispose {
            try { media3Manager.pause() } catch (ignored: Exception) { }
            try { media3Manager.release() } catch (ignored: Exception) { }
            try { playerController.cleanup() } catch (ignored: Exception) { }
        }
    }

    LaunchedEffect(activeVideoItem, activeAudioItem) {
        if (activeVideoItem == null && activeAudioItem == null) {
            try { media3Manager.pause() } catch (ignored: Exception) { }
        }
    }

    androidx.activity.compose.BackHandler(
        enabled = activeImageItem != null || activeVideoItem != null || activeAudioItem != null
    ) {
        if (activeImageItem != null) activeImageItem = null
        if (activeVideoItem != null) {
            media3Manager.pause()
            activeVideoItem = null
        }
        if (activeAudioItem != null) {
            media3Manager.pause()
            activeAudioItem = null
        }
    }

    if (isLocked) {
        VaultLockScreen(
            securityManager = securityManager,
            onUnlocked = {}
        )
    } else {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = "Vault",
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    },
                    actions = {
                        Button(onClick = { securityManager.lock() }) {
                            Text("Lock Vault")
                        }
                    }
                )
            }
        ) { paddingValues ->
            VaultMediaGrid(
                items = vaultedMedia,
                onItemClick = { item ->
                    when (item) {
                        is ImageItem -> activeImageItem = item
                        is VideoItem -> {
                            // Play directly from the vault file:// URI — do NOT route through
                            // the MediaStore ID player (the file is no longer in MediaStore).
                            activeVideoItem = item
                            media3Manager.play(
                                PlayerMediaItem(
                                    id = item.id.toString(),
                                    title = item.displayName,
                                    uri = item.uri,
                                    isVideo = true,
                                    duration = item.duration
                                )
                            )
                        }
                        is AudioItem -> {
                            activeAudioItem = item
                            media3Manager.play(
                                PlayerMediaItem(
                                    id = item.id.toString(),
                                    title = item.displayName,
                                    uri = item.uri,
                                    isVideo = false,
                                    duration = item.duration,
                                    artist = item.artist ?: "Unknown Artist"
                                )
                            )
                        }
                    }
                },
                onRestoreClick = { item ->
                    coroutineScope.launch {
                        vaultRepository.restoreItem(item)
                    }
                },
                modifier = Modifier.padding(paddingValues)
            )
            
            // Full Screen Image Viewer
            AnimatedVisibility(
                visible = activeImageItem != null,
                enter = scaleIn() + fadeIn(),
                exit = scaleOut() + fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                val imageItems = vaultedMedia.filterIsInstance<ImageItem>()
                
                LaunchedEffect(imageItems, activeImageItem) {
                    if (activeImageItem != null && !imageItems.any { it.id == activeImageItem?.id }) {
                        activeImageItem = null
                    }
                }

                if (imageItems.isNotEmpty() && activeImageItem != null) {
                    val initialPage = imageItems.indexOfFirst { it.id == activeImageItem?.id }.coerceAtLeast(0)
                    val pagerState = androidx.compose.foundation.pager.rememberPagerState(
                        initialPage = initialPage,
                        pageCount = { imageItems.size }
                    )
                    
                    Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.95f))) {
                        androidx.compose.foundation.pager.HorizontalPager(
                            state = pagerState,
                            modifier = Modifier.fillMaxSize(),
                            key = { index -> imageItems.getOrNull(index)?.id?.toString() ?: "image_$index" }
                        ) { page ->
                            if (page >= imageItems.size || page < 0) {
                                Box(modifier = Modifier.fillMaxSize())
                                return@HorizontalPager
                            }
                            val image = imageItems[page]
                            val context = LocalContext.current
                            var scale by remember { mutableStateOf(1f) }
                            var offset by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }

                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                val fullImageRequest = remember(image.uri) {
                                    // Vault images live in app-private storage as file:// URIs.
                                    // Feed Coil the File directly — more reliable than Uri on
                                    // some OEMs, and avoids "failed to load" with file:// URIs.
                                    val dataSource: Any = if (image.uri.scheme?.lowercase() == "file" &&
                                        image.path.isNotBlank()) {
                                        java.io.File(image.path)
                                    } else {
                                        image.uri
                                    }
                                    coil.request.ImageRequest.Builder(context)
                                        .data(dataSource)
                                        .memoryCacheKey("vault_full_${image.id}")
                                        .diskCacheKey("vault_full_${image.id}")
                                        // Software bitmap prevents black-render in some layers.
                                        .allowHardware(false)
                                        .crossfade(true)
                                        .build()
                                }
                                AsyncImage(
                                    model = fullImageRequest,
                                    contentDescription = image.displayName,
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .graphicsLayer(
                                            scaleX = scale,
                                            scaleY = scale,
                                            translationX = offset.x,
                                            translationY = offset.y
                                        )
                                        // Double-tap zoom — does not consume drags, so swipes pass through.
                                        .pointerInput(Unit) {
                                            androidx.compose.foundation.gestures.detectTapGestures(
                                                onDoubleTap = {
                                                    if (scale > 1f) {
                                                        scale = 1f
                                                        offset = androidx.compose.ui.geometry.Offset.Zero
                                                    } else {
                                                        scale = 2.5f
                                                    }
                                                }
                                            )
                                        }
                                        // Pinch/pan only while zoomed; absent at 1f so swipe works.
                                        .then(
                                            if (scale > 1f) {
                                                Modifier.pointerInput(Unit) {
                                                    detectTransformGestures { _, pan, zoom, _ ->
                                                        scale = (scale * zoom).coerceIn(1f, 4f)
                                                        offset = if (scale > 1f) offset + pan
                                                                 else androidx.compose.ui.geometry.Offset.Zero
                                                    }
                                                }
                                            } else {
                                                Modifier
                                            }
                                        )
                                )
                            }
                        }

                        Box(
                            modifier = Modifier.fillMaxSize().padding(16.dp).statusBarsPadding(),
                            contentAlignment = Alignment.TopStart
                        ) {
                            IconButton(onClick = { activeImageItem = null }) {
                                Icon(Icons.Default.Close, "Close", tint = Color.White)
                            }
                        }
                    }
                }
            }

            // Full Screen Video Player (vault file:// playback)
            AnimatedVisibility(
                visible = activeVideoItem != null,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                if (activeVideoItem != null) {
                    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
                        VideoPlayerComposable(
                            controller = playerController,
                            isActivePage = true,
                            onBackClick = {
                                media3Manager.pause()
                                activeVideoItem = null
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }

            // Full Screen Audio Player (vault file:// playback)
            AnimatedVisibility(
                visible = activeAudioItem != null,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                activeAudioItem?.let { audio ->
                    val pState by playerController.playbackState.collectAsState()
                    AudioPlayerScreen(
                        item = audio,
                        playbackState = pState,
                        isShuffle = false,
                        isRepeat = false,
                        onBack = {
                            media3Manager.pause()
                            activeAudioItem = null
                        },
                        onPlayPause = {
                            if (pState.isPlaying) media3Manager.pause() else media3Manager.resume()
                        },
                        onNext = { },
                        onPrevious = { },
                        onShuffleToggle = { },
                        onRepeatToggle = { },
                        onSeek = { media3Manager.seekTo(it) },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}

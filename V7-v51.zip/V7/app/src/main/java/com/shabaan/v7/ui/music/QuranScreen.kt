package com.shabaan.v7.ui.music

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.shabaan.v7.util.Formatters
import com.shabaan.v7.util.QuranApi
import com.shabaan.v7.util.QuranApi.RareRecording
import com.shabaan.v7.util.QuranApi.Reciter
import com.shabaan.v7.util.QuranApi.Surah
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuranScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    // ---- ExoPlayer ----
    val player = remember {
        ExoPlayer.Builder(ctx)
            .setAudioAttributes(
                androidx.media3.common.AudioAttributes.Builder()
                    .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(androidx.media3.common.C.USAGE_MEDIA)
                    .build(), true
            ).build()
    }
    DisposableEffect(Unit) { onDispose { player.release() } }

    // ---- State ----
    var surahQuery     by remember { mutableStateOf("") }
    var reciterQuery   by remember { mutableStateOf("") }
    var sourceTab      by remember { mutableIntStateOf(0) }  // 0=قراء  1=روايات  2=نادرة
    var reciters       by remember { mutableStateOf(QuranApi.RECITERS) }
    var selectedReciter by remember { mutableStateOf(QuranApi.RECITERS.first()) }
    var selectedRare   by remember { mutableStateOf<RareRecording?>(null) }
    var playingSurah   by remember { mutableStateOf<Surah?>(null) }
    var nowPlayingLabel by remember { mutableStateOf("") }
    var isPlaying      by remember { mutableStateOf(false) }
    var showReciterPicker by remember { mutableStateOf(false) }
    var position       by remember { mutableLongStateOf(0L) }
    var duration       by remember { mutableLongStateOf(1L) }
    var isSeeking      by remember { mutableStateOf(false) }
    var seekValue      by remember { mutableFloatStateOf(0f) }
    var downloading    by remember { mutableStateOf(false) }
    var downloadProg   by remember { mutableFloatStateOf(0f) }
    var loadingReciters by remember { mutableStateOf(false) }

    // Fetch all reciters from API on first load
    LaunchedEffect(Unit) {
        loadingReciters = true
        reciters = QuranApi.fetchAllReciters()
        loadingReciters = false
    }

    // Player events
    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(p: Boolean) { isPlaying = p }
            override fun onPlaybackStateChanged(s: Int) {
                if (s == Player.STATE_ENDED) isPlaying = false
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l) }
    }

    // Position polling
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            position = player.currentPosition.coerceAtLeast(0)
            duration = player.duration.coerceAtLeast(1)
            delay(500)
        }
    }

    fun play(surah: Surah, uri: android.net.Uri, label: String) {
        player.stop()
        player.setMediaItem(MediaItem.fromUri(uri))
        player.prepare()
        player.play()
        playingSurah = surah
        nowPlayingLabel = label
        position = 0L; duration = 1L
    }

    fun playWithReciter(surah: Surah) =
        play(surah, QuranApi.surahAudioUrl(surah.number, selectedReciter.identifier),
            selectedReciter.arabicName)

    fun playRare(surah: Surah, rare: RareRecording) =
        play(surah, QuranApi.rareRecordingUrl(rare, surah.number), rare.arabicName)

    // ---- Filtered lists ----
    val riwayatReciters = remember(reciters) {
        reciters.filter { it.riwaya != "حفص عن عاصم" }
            .ifEmpty { QuranApi.RECITERS.filter { it.riwaya != "حفص عن عاصم" } }
    }
    val filteredSurahs = remember(surahQuery) { QuranApi.searchSurahs(surahQuery) }
    val filteredReciters = remember(reciterQuery, reciters) { QuranApi.searchReciters(reciterQuery)
        .let { res -> if (reciters.size > QuranApi.RECITERS.size) {
            val q = reciterQuery.trim()
            reciters.filter { r ->
                q.isBlank() || r.arabicName.contains(q) ||
                r.englishName.contains(q, ignoreCase = true) || r.riwaya.contains(q)
            }
        } else res } }

    // ---- UI ----
    Column(Modifier.fillMaxSize()) {

        // Search bar
        OutlinedTextField(
            value = surahQuery, onValueChange = { surahQuery = it },
            placeholder = { Text("ابحث عن سورة بالاسم أو الرقم…") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            trailingIcon = { if (surahQuery.isNotEmpty()) IconButton({ surahQuery = "" }) {
                Icon(Icons.Rounded.Close, null) } },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            shape = RoundedCornerShape(12.dp)
        )

        // Source tabs
        ScrollableTabRow(
            selectedTabIndex = sourceTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.primary,
            edgePadding = 16.dp
        ) {
            Tab(selected = sourceTab == 0, onClick = { sourceTab = 0 },
                text = { Text("القراء (${if (loadingReciters) "…" else reciters.size})") },
                icon = { Icon(Icons.Rounded.RecordVoiceOver, null, Modifier.size(16.dp)) })
            Tab(selected = sourceTab == 1, onClick = { sourceTab = 1 },
                text = { Text("الروايات (${riwayatReciters.size})") },
                icon = { Icon(Icons.Rounded.AutoStories, null, Modifier.size(16.dp)) })
            Tab(selected = sourceTab == 2, onClick = { sourceTab = 2 },
                text = { Text("تسجيلات نادرة") },
                icon = { Icon(Icons.Rounded.History, null, Modifier.size(16.dp)) })
        }

        // Reciter/Riwaya selector strip (tabs 0 & 1)
        if (sourceTab < 2) {
            val label = if (sourceTab == 0) selectedReciter.arabicName
                        else (selectedRare?.arabicName ?: riwayatReciters.firstOrNull()?.arabicName ?: "اختر رواية")
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.RecordVoiceOver, null,
                    tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text(label, style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f),
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                TextButton(onClick = { showReciterPicker = true }) { Text("تغيير") }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
        }

        // ---- Content ----
        when (sourceTab) {
            // == القراء / الروايات ==
            0, 1 -> LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = if (playingSurah != null) 150.dp else 16.dp)
            ) {
                items(filteredSurahs, key = { it.number }) { surah ->
                    val active = playingSurah?.number == surah.number
                    SurahRow(
                        surah = surah, isActive = active, isPlaying = isPlaying && active,
                        onClick = {
                            if (sourceTab == 0) playWithReciter(surah)
                            else {
                                val rec = riwayatReciters.firstOrNull() ?: return@SurahRow
                                play(surah, QuranApi.surahAudioUrl(surah.number, rec.identifier), rec.arabicName)
                            }
                        },
                        onPlayPause = { if (isPlaying) player.pause() else player.play() }
                    )
                }
            }
            // == التسجيلات النادرة ==
            2 -> LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = if (playingSurah != null) 150.dp else 16.dp)
            ) {
                // Rare recording selector cards
                items(QuranApi.RARE_RECORDINGS, key = { it.id }) { rare ->
                    val chosen = selectedRare?.id == rare.id
                    Card(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
                            .clickable { selectedRare = rare },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (chosen)
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                            else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        border = if (chosen) androidx.compose.foundation.BorderStroke(
                            1.dp, MaterialTheme.colorScheme.primary) else null
                    ) {
                        Row(Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                if (chosen) Icons.Rounded.RadioButtonChecked
                                else Icons.Rounded.RadioButtonUnchecked,
                                null, tint = if (chosen) MaterialTheme.colorScheme.primary
                                             else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(rare.arabicName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold)
                                Text(rare.description,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2)
                            }
                        }
                    }
                }
                if (selectedRare != null) {
                    item {
                        HorizontalDivider(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                        )
                        Text("اختر السورة:",
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    items(filteredSurahs, key = { "r_${it.number}" }) { surah ->
                        val active = playingSurah?.number == surah.number
                        SurahRow(
                            surah = surah, isActive = active, isPlaying = isPlaying && active,
                            onClick = { selectedRare?.let { rare -> playRare(surah, rare) } },
                            onPlayPause = { if (isPlaying) player.pause() else player.play() }
                        )
                    }
                } else {
                    item {
                        Text("اختر التسجيل أولاً من فوق",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(24.dp))
                    }
                }
            }
        }

        // ---- Mini player ----
        AnimatedVisibility(playingSurah != null, enter = fadeIn(), exit = fadeOut()) {
            playingSurah?.let { surah ->
                val dur = duration.coerceAtLeast(1)
                val prog = if (isSeeking) seekValue
                           else (position.toFloat() / dur).coerceIn(0f, 1f)
                Surface(
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    tonalElevation = 8.dp, modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.MenuBook, null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(surah.arabicName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis)
                                Text(nowPlayingLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            // Download (only for API reciters, not rare)
                            if (sourceTab < 2) {
                                if (downloading) {
                                    CircularProgressIndicator(
                                        progress = { downloadProg },
                                        modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                                } else {
                                    IconButton(onClick = {
                                        downloading = true; downloadProg = 0f
                                        scope.launch {
                                            val ok = QuranApi.downloadSurah(
                                                ctx, surah.number, surah.arabicName,
                                                selectedReciter.identifier, selectedReciter.arabicName
                                            ) { p -> downloadProg = p }
                                            downloading = false
                                            android.widget.Toast.makeText(ctx,
                                                if (ok) "تم التحميل في Music/V7 Quran"
                                                else "فشل التحميل",
                                                android.widget.Toast.LENGTH_SHORT).show()
                                        }
                                    }) { Icon(Icons.Rounded.Download, null, Modifier.size(18.dp)) }
                                }
                            }
                            // Prev
                            IconButton(enabled = surah.number > 1, onClick = {
                                QuranApi.SURAHS.getOrNull(surah.number - 2)?.let {
                                    if (sourceTab == 2) selectedRare?.let { r -> playRare(it, r) }
                                    else playWithReciter(it)
                                }
                            }) { Icon(Icons.Rounded.SkipPrevious, null, Modifier.size(22.dp)) }
                            // Play/Pause
                            IconButton(onClick = { if (isPlaying) player.pause() else player.play() }) {
                                Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                    null, tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(28.dp))
                            }
                            // Next
                            IconButton(enabled = surah.number < 114, onClick = {
                                QuranApi.SURAHS.getOrNull(surah.number)?.let {
                                    if (sourceTab == 2) selectedRare?.let { r -> playRare(it, r) }
                                    else playWithReciter(it)
                                }
                            }) { Icon(Icons.Rounded.SkipNext, null, Modifier.size(22.dp)) }
                            IconButton(onClick = {
                                player.stop(); playingSurah = null; isPlaying = false
                            }) { Icon(Icons.Rounded.Close, null, Modifier.size(18.dp)) }
                        }
                        // Seek bar
                        Slider(value = prog,
                            onValueChange = { isSeeking = true; seekValue = it },
                            onValueChangeFinished = {
                                player.seekTo((seekValue * dur).toLong())
                                position = (seekValue * dur).toLong()
                                isSeeking = false
                            },
                            modifier = Modifier.fillMaxWidth().height(24.dp))
                        Row(Modifier.fillMaxWidth()) {
                            Text(Formatters.duration(position),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.weight(1f))
                            Text(if (dur > 1) Formatters.duration(dur) else "--:--",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }

    // ---- Reciter / Riwaya picker ----
    if (showReciterPicker) {
        val list = if (sourceTab == 1) riwayatReciters else filteredReciters
        AlertDialog(
            onDismissRequest = { showReciterPicker = false; reciterQuery = "" },
            title = {
                Column {
                    Text(if (sourceTab == 1) "اختر الرواية" else "اختر الشيخ (${list.size})")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = reciterQuery, onValueChange = { reciterQuery = it },
                        placeholder = { Text("ابحث…") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp),
                        leadingIcon = { Icon(Icons.Rounded.Search, null) })
                }
            },
            text = {
                LazyColumn(Modifier.heightIn(max = 400.dp)) {
                    items(list, key = { it.identifier }) { rec ->
                        val chosen = selectedReciter.identifier == rec.identifier
                        Row(Modifier.fillMaxWidth()
                            .clickable {
                                if (sourceTab == 1) {
                                    // treat riwaya reciter as selected reciter
                                    selectedReciter = rec
                                } else {
                                    selectedReciter = rec
                                }
                                reciterQuery = ""; showReciterPicker = false
                                playingSurah?.let { playWithReciter(it) }
                            }
                            .padding(vertical = 10.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            if (chosen) {
                                Icon(Icons.Rounded.Check, null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(8.dp))
                            } else Spacer(Modifier.width(24.dp))
                            Column(Modifier.weight(1f)) {
                                Text(rec.arabicName, style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Medium)
                                Text("${rec.englishName}  ·  ${rec.riwaya}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f))
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showReciterPicker = false; reciterQuery = "" }) {
                    Text("إغلاق")
                }
            }
        )
    }
}

@Composable
private fun SurahRow(
    surah: Surah,
    isActive: Boolean,
    isPlaying: Boolean,
    onClick: () -> Unit,
    onPlayPause: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth()
            .clickable(onClick = onClick)
            .background(
                if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                else Color.Transparent
            )
            .padding(horizontal = 16.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(36.dp).clip(RoundedCornerShape(8.dp))
            .background(
                if (isActive) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.surfaceVariant
            ), contentAlignment = Alignment.Center) {
            Text(surah.number.toString(),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = if (isActive) MaterialTheme.colorScheme.onPrimary
                        else MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(surah.arabicName, style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = if (isActive) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onBackground)
            Text("${surah.englishName}  ·  ${surah.ayahCount} آية  ·  ${surah.revelationType}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (isActive) {
            IconButton(onClick = onPlayPause) {
                Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
            }
        }
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f),
        modifier = Modifier.padding(horizontal = 16.dp))
}

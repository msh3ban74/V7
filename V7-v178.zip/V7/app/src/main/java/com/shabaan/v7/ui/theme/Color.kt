package com.shabaan.v7.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * V7 brand palette — premium indigo on deep near-black.
 *
 * The identity is an indigo/violet accent family (from the V7 app icon) layered
 * over calm dark surfaces. Accents are used sparingly for state and emphasis;
 * the bulk of the UI stays dark and neutral so the indigo reads as premium, not
 * loud.
 */

// Core surfaces (dark) — brand background/surface spec.
val V7Background = Color(0xFF0F1117)
val V7Surface = Color(0xFF161A22)
val V7Card = Color(0xFF1B2029)

// Indigo brand accents.
val IndigoPrimary = Color(0xFF6C63FF)   // primary
val IndigoSecondary = Color(0xFF8B85FF) // secondary
val IndigoLight = Color(0xFFA29BFF)     // light accent

// Retained neutral silver tones for text/borders/hierarchy (kept calm so the
// indigo stays the only real colour in the UI).
val PrimarySilver = Color(0xFFC7CCD1)
val BrightSilver = Color(0xFFE5E8EB)
val AccentSilver = Color(0xFFB8BDC5)
val SecondarySilver = Color(0xFFAEB5BC)
val MutedSilver = Color(0xFF7D8790)
val SilverBorder = Color(0xFF2A3138)
val DarkSurfaceMetal = Color(0xFF141821)
val PremiumCard = Color(0xFF1B2029)

// Text.
val TextPrimary = Color(0xFFF5F5F5)
val TextSecondary = Color(0xFF9AA0A6)

// Subtle outlines / dividers.
val V7Outline = Color(0xFF2A2F3A)
val V7OutlineVariant = Color(0xFF20242E)

// --- Legacy aliases -------------------------------------------------------
// Kept so older references (LightScheme, CommonComponents) still compile.
// Mapped onto neutral tones; the brand colour now lives in the Indigo* values.
val Titanium50  = BrightSilver
val Titanium100 = Color(0xFFE8EBF0)
val Titanium200 = PrimarySilver
val Titanium300 = AccentSilver
val Titanium400 = Color(0xFF8893A4)
val Titanium500 = TextSecondary
val Titanium600 = Color(0xFF515B6A)
val Titanium700 = Color(0xFF3A4350)
val Titanium800 = V7Card
val Titanium900 = V7Surface
val TitaniumAccent = IndigoPrimary
val PlatinumGlow = BrightSilver
val PlatinumDeep = V7Background

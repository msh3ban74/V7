package com.shabaan.v7

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import coil.disk.DiskCache
import coil.memory.MemoryCache
import coil.request.CachePolicy
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.asCoroutineDispatcher
import java.util.concurrent.Executors

@HiltAndroidApp
class V7App : Application(), ImageLoaderFactory {

    override fun onCreate() {
        super.onCreate()
        installCrashCatcher()
        createMusicChannel()
    }

    /**
     * Saves the stack trace of any uncaught crash to a file so it can be shown
     * to the user on next launch. This is a diagnostics aid for devices where
     * logcat isn't available — it does not swallow the crash, it records it then
     * lets the default handler run.
     */
    private fun installCrashCatcher() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            runCatching {
                val sw = java.io.StringWriter()
                throwable.printStackTrace(java.io.PrintWriter(sw))
                java.io.File(filesDir, "last_crash.txt").writeText(
                    "V7 crash\n${java.util.Date()}\n\n$sw"
                )
            }
            previous?.uncaughtException(thread, throwable)
        }
    }

    private fun createMusicChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                getString(R.string.music_channel_id),
                getString(R.string.music_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                setShowBadge(false)
                setSound(null, null)
            }
            mgr.createNotificationChannel(channel)
        }
    }

    /**
     * A single, app-wide ImageLoader tuned for buttery thumbnail scrolling:
     *
     *  - Large in-memory cache (30% of app heap) so re-scrolling is instant.
     *  - 250 MB persistent disk cache → thumbnails survive app restarts, so the
     *    grid is never "reloaded" again after the first time.
     *  - Both caches enabled READ+WRITE explicitly.
     *  - A dedicated thread pool sized to the CPU so video-frame decoding never
     *    blocks the UI and many tiles decode in parallel.
     *  - crossfade kept short (180 ms) so images settle fast, not lazily.
     *
     * Per-request sizing (downsampling to the tile size) is done at the call
     * site via the `thumb()` helper in ThumbnailRequest.kt — that is what stops
     * full-resolution photos from being decoded into tiny cells.
     */
    override fun newImageLoader(): ImageLoader {
        val cores = Runtime.getRuntime().availableProcessors().coerceIn(4, 12)
        val decodeExecutor = Executors.newFixedThreadPool(cores)

        return ImageLoader.Builder(this)
            .components {
                add(VideoFrameDecoder.Factory())
                add(com.shabaan.v7.util.MediaStoreThumbnailFetcher.Factory(this@V7App))
                add(com.shabaan.v7.util.VaultThumbnailFetcher.Factory(this@V7App))
            }
            .memoryCache {
                MemoryCache.Builder(this)
                    // In-memory thumbnail cache. Balanced at 30% of app heap:
                    // big enough that re-scrolling stays instant, small enough
                    // that the app stays light and is far less likely to be
                    // killed in the background on mid/low-end phones.
                    // (Was 0.60 — lowered for background stability. If you ever
                    // measure that re-scrolling feels slower and your device has
                    // lots of RAM, you can raise this back toward 0.50.)
                    .maxSizePercent(0.30)
                    .strongReferencesEnabled(true)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("v7_image_cache"))
                    // Big persistent cache → thumbnails survive app restarts and
                    // never need re-extracting from the original media.
                    .maxSizeBytes(1024L * 1024 * 1024)
                    .build()
            }
            .memoryCachePolicy(CachePolicy.ENABLED)
            .diskCachePolicy(CachePolicy.ENABLED)
            .networkCachePolicy(CachePolicy.DISABLED) // all media is local
            .respectCacheHeaders(false)
            // No crossfade: thumbnails appear instantly instead of fading in,
            // which is what makes a gallery feel "snappy" like the stock one.
            .crossfade(false)
            .dispatcher(
                decodeExecutor.asCoroutineDispatcher()
            )
            .build()
    }
}

package com.example.presentation.screens.music

import android.app.Activity
import android.content.pm.ActivityInfo
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.domain.model.AudioItem
import com.example.domain.model.LocalMediaItem
import com.example.presentation.screens.gallery.GalleryViewModel
import com.example.presentation.permission.LocalPermissionManager
import com.example.presentation.permission.rememberStoragePermissionLauncher
import com.example.presentation.screens.player.media3.Media3Manager
import com.example.presentation.screens.player.media3.PlaybackState
import com.example.presentation.screens.player.media3.PlayerController
import com.example.presentation.screens.player.media3.PlayerMediaItem
import com.example.presentation.screens.player.media3.VideoPlayerComposable
import kotlin.math.sin
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.interaction.MutableInteractionSource
import com.example.presentation.screens.music.MusicLibraryScreen
import com.example.presentation.screens.music.MusicLibraryState
import com.example.presentation.screens.music.MusicLibraryViewModel
import com.example.presentation.screens.music.SortMode
import com.example.presentation.screens.music.FilterMode
import com.example.presentation.screens.music.AudioPlayerScreen
import com.example.presentation.screens.music.MiniPlayerComposable
import com.example.presentation.screens.music.AudioPlaybackManager

/**
 * Aesthetic Vault Gallery Screen.
 * Fully integrates permission verifications, local gallery grids, dynamic filters and search parameters,
 * and high-fidelity media rendering (reels-styled video players, audio visualizers, and raw image overlays).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicScreen(
    viewModel: GalleryViewModel,
    onNavigateToPlayer: (String) -> Unit,
    onNavigateToVault: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val items by viewModel.localMediaItems.collectAsState()
    val favoritesState by viewModel.favoritesState.collectAsState()
    
    val musicLibraryViewModel = androidx.lifecycle.viewmodel.compose.viewModel<MusicLibraryViewModel>()
    val libraryState by musicLibraryViewModel.state.collectAsState()

    val audioPlaybackManager = remember { AudioPlaybackManager(context) }
    
    LaunchedEffect(items, favoritesState) {
        val audioItems = items.filterIsInstance<AudioItem>()
        musicLibraryViewModel.updateSongs(audioItems, favoritesState.favoriteAudioIds)
    }

    DisposableEffect(Unit) {
        onDispose {
            audioPlaybackManager.release()
        }
    }

    var isPlayerVisible by remember { mutableStateOf(false) }

    val pState by audioPlaybackManager.media3Manager.playbackState.collectAsState()
    val isShuffle by audioPlaybackManager.isShuffle.collectAsState()
    val isRepeat by audioPlaybackManager.isRepeat.collectAsState()

    BackHandler(enabled = isPlayerVisible) {
        isPlayerVisible = false
    }

    Box(modifier = modifier.fillMaxSize()) {
        // تحويل الـ State لمتغير محلي ثابت لحل مشكلة الـ Smart Cast
        val currentTrack = audioPlaybackManager.currentItemFlow.collectAsState().value

        Scaffold(
            topBar = {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Music",
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            },
            containerColor = Color.Transparent
        ) { innerPadding ->
            Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {

                MusicLibraryScreen(
                    state = libraryState,
                    onSearch = { musicLibraryViewModel.search(it) },
                    onSortModeSelected = { musicLibraryViewModel.setSortMode(it) },
                    onFilterModeSelected = { musicLibraryViewModel.setFilterMode(it) },
                    onItemClick = { item, playlist ->
                        audioPlaybackManager.play(playlist, playlist.indexOf(item).coerceAtLeast(0))
                        isPlayerVisible = true
                    },
                    onFavoriteToggle = { viewModel.toggleFavorite(it) },
                    modifier = Modifier.fillMaxSize().padding(bottom = if (currentTrack != null && !isPlayerVisible) 80.dp else 0.dp)
                )

                // Mini Player — باستخدام المتغير المحلي الجديد الثابت
                if (currentTrack != null && !isPlayerVisible) {
                    MiniPlayerComposable(
                        item = currentTrack,
                        isPlaying = pState.isPlaying,
                        onPlayPause = {
                            if (pState.isPlaying) audioPlaybackManager.media3Manager.pause()
                            else audioPlaybackManager.media3Manager.resume()
                        },
                        onNext = { audioPlaybackManager.playNext() },
                        onClick = { isPlayerVisible = true },
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(16.dp)
                            .windowInsetsPadding(WindowInsets.navigationBars)
                    )
                }
            }
        }

        // Full Audio Player Overlay — باستخدام المتغير المحلي الجديد الثابت
        AnimatedVisibility(
            visible = isPlayerVisible && currentTrack != null,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            currentTrack?.let { activeItem ->
                AudioPlayerScreen(
                    item = activeItem,
                    playbackState = pState,
                    isShuffle = isShuffle,
                    isRepeat = isRepeat,
                    onBack = { isPlayerVisible = false },
                    onPlayPause = {
                        if (pState.isPlaying) audioPlaybackManager.media3Manager.pause()
                        else audioPlaybackManager.media3Manager.resume()
                    },
                    onNext = { audioPlaybackManager.playNext() },
                    onPrevious = { audioPlaybackManager.playPrevious() },
                    onShuffleToggle = { audioPlaybackManager.toggleShuffle() },
                    onRepeatToggle = { audioPlaybackManager.toggleRepeat() },
                    onSeek = { audioPlaybackManager.media3Manager.seekTo(it) }
                )
            }
        }
    }
}

/**
 * Scaffold Status bars calculation safe padding.
 */
@Composable
private fun Modifier.statusBarsPadding(): Modifier {
    val context = LocalContext.current
    val resourceId = context.resources.getIdentifier("status_bar_height", "dimen", "android")
    val statusBarHeight = if (resourceId > 0) {
        context.resources.getDimensionPixelSize(resourceId) / context.resources.displayMetrics.density
    } else {
        24f
    }
    return this.padding(top = statusBarHeight.dp)
}

/**
 * Duration formater logic helper.
 */
private fun formatDuration(ms: Long): String {
    val seconds = ms / 1000
    val secs = seconds % 60
    val mins = seconds / 60
    return String.format("%02d:%02d", mins, secs)
}

/**
 * Memory bytes parser formater helper.
 */
private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.toDouble())).toInt()
    return String.format("%.1f %s", bytes / Math.pow(1024.toDouble(), digitGroups.toDouble()), units[digitGroups])
}

package com.shabaan.v7.ui.videos

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Rational
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.PictureInPicture
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.outlined.Gif
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.outlined.Subtitles
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem as Media3Item
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.shabaan.v7.util.Formatters
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun VideoPlayerRoute(
    startIndex: Int,
    onBack: () -> Unit,
    progressVm: PlaybackProgressViewModel = androidx.hilt.navigation.compose.hiltViewModel(),
    favVm: PlayerFavViewModel = androidx.hilt.navigation.compose.hiltViewModel()
) {
    val ctx = LocalContext.current
    val activity = ctx as? Activity
    val items = remember { VideoSession.list }
    if (items.isEmpty()) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val favorites by favVm.favorites.collectAsState()
    val safeStart = startIndex.coerceIn(0, items.lastIndex)
    val pagerState = rememberPagerState(initialPage = safeStart) { items.size }
    val scope = androidx.compose.runtime.rememberCoroutineScope()

    DisposableEffect(Unit) {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }
    BackHandler { onBack() }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        VerticalPager(state = pagerState, beyondViewportPageCount = 1) { page ->
            val item = items[page]
            val active = page == pagerState.currentPage
            SinglePlayerPage(
                mediaId = item.id,
                uri = item.uri,
                title = item.name,
                folder = item.relativePath,
                active = active,
                progressVm = progressVm,
                isFavorite = item.id in favorites,
                onToggleFavorite = { favVm.toggle(item.id) },
                onBack = onBack,
                onTogglePiP = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && activity != null &&
                        activity.packageManager.hasSystemFeature(
                            android.content.pm.PackageManager.FEATURE_PICTURE_IN_PICTURE
                        )
                    ) {
                        try {
                            val params = PictureInPictureParams.Builder()
                                .setAspectRatio(Rational(16, 9))
                                .build()
                            activity.enterPictureInPictureMode(params)
                        } catch (_: Exception) { /* device refused PiP */ }
                    }
                },
                onShare = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = item.mimeType
                        putExtra(Intent.EXTRA_STREAM, item.uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    ctx.startActivity(Intent.createChooser(send, "Share"))
                },
                onAdvanceNext = {
                    val next = page + 1
                    if (next < items.size) {
                        scope.launch { pagerState.animateScrollToPage(next) }
                    }
                }
            )
        }
    }
}

@Composable
private fun SinglePlayerPage(
    mediaId: Long,
    uri: Uri,
    title: String,
    folder: String? = null,
    active: Boolean,
    progressVm: PlaybackProgressViewModel,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onBack: () -> Unit,
    onTogglePiP: () -> Unit,
    onShare: () -> Unit,
    onAdvanceNext: () -> Unit = {}
) {
    val ctx = LocalContext.current
    val activity = ctx as? Activity
    val lifecycleOwner = LocalLifecycleOwner.current

    var subtitleUri by remember { mutableStateOf<Uri?>(null) }
    val subtitlePicker = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    it, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) { /* not all URIs are persistable */ }
            subtitleUri = it
        }
    }

    val player = remember(uri) {
        ExoPlayer.Builder(ctx)
            .setAudioAttributes(
                androidx.media3.common.AudioAttributes.Builder()
                    .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MOVIE)
                    .setUsage(androidx.media3.common.C.USAGE_MEDIA)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setWakeMode(androidx.media3.common.C.WAKE_MODE_LOCAL)
            .build().apply {
                setMediaItem(Media3Item.fromUri(uri))
                prepare()
            }
    }
    // A MediaSession lets the OS recognise this as active media and keep it
    // playing in the background (with system media controls) when enabled.
    val mediaSession = remember(player) {
        androidx.media3.session.MediaSession.Builder(ctx, player)
            .setId("v7_video_${System.currentTimeMillis()}")
            .build()
    }
    DisposableEffect(mediaSession) {
        onDispose { mediaSession.release() }
    }
    var muted by remember { mutableStateOf(false) }
    LaunchedEffect(muted) { player.volume = if (muted) 0f else 1f }

    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var makingSticker by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var showRailMore by remember { mutableStateOf(false) }
    var showStickerMenu by remember { mutableStateOf(false) }
    // 0 = stop at end (default), 1 = auto-play next, 2 = repeat this video
    var videoRepeatMode by remember { mutableIntStateOf(0) }
    var extractingAudio by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    var showTrim by remember { mutableStateOf(false) }
    var trimming by remember { mutableStateOf(false) }

    fun makeSticker(durationMs: Long, share: Boolean) {
        val startAt = player.currentPosition
        makingSticker = true
        scope.launch {
            // Animated WebP = real WhatsApp sticker (not a GIF).
            val sticker = com.shabaan.v7.util.StickerMaker.createWebpSticker(
                context = ctx,
                uri = uri,
                startMs = startAt,
                durationMs = durationMs,
                fps = 10
            )
            if (sticker == null) {
                makingSticker = false
                android.widget.Toast.makeText(
                    ctx, "Couldn't create sticker", android.widget.Toast.LENGTH_SHORT
                ).show()
                return@launch
            }
            if (share) {
                makingSticker = false
                com.shabaan.v7.util.StickerMaker.shareSticker(ctx, sticker)
            } else {
                val ok = com.shabaan.v7.util.StickerMaker.saveStickerToGallery(ctx, sticker)
                makingSticker = false
                android.widget.Toast.makeText(
                    ctx,
                    if (ok) "Sticker saved to gallery" else "Couldn't save sticker",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    // Resume from last saved position. We must wait until the player is READY
    // (the media is loaded and its duration is known) before seeking, otherwise
    // the seek is applied to a not-yet-prepared player and gets lost.
    LaunchedEffect(uri) {
        val resumeAt = progressVm.resumePosition(mediaId)
        if (resumeAt <= 0) return@LaunchedEffect
        if (player.playbackState == Player.STATE_READY && player.duration > 0) {
            player.seekTo(resumeAt)
        } else {
            val listener = object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_READY) {
                        player.seekTo(resumeAt)
                        player.removeListener(this)
                    }
                }
            }
            player.addListener(listener)
        }
    }

    // Apply subtitle without restarting playback: keep position & play state.
    LaunchedEffect(subtitleUri) {
        val sub = subtitleUri ?: return@LaunchedEffect
        val resumeAt = player.currentPosition
        val wasPlaying = player.playWhenReady
        val mime = ctx.contentResolver.getType(sub) ?: MimeTypes.APPLICATION_SUBRIP
        val subConfig = Media3Item.SubtitleConfiguration.Builder(sub)
            .setMimeType(mime)
            .setLanguage("und")
            .setSelectionFlags(androidx.media3.common.C.SELECTION_FLAG_DEFAULT)
            .build()
        val newItem = Media3Item.Builder()
            .setUri(uri)
            .setSubtitleConfigurations(listOf(subConfig))
            .build()
        player.setMediaItem(newItem, resumeAt)
        player.prepare()
        player.playWhenReady = wasPlaying
    }

    LaunchedEffect(active) { player.playWhenReady = active }

    DisposableEffect(player, lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> {
                    // Background playback is always on: keep the audio playing when
                    // the screen locks or the user leaves the app. Just persist a
                    // resume point.
                    val pos = player.currentPosition
                    val dur = player.duration.coerceAtLeast(0)
                    if (pos > 0) progressVm.save(mediaId, pos, dur, title, uri.toString())
                }
                Lifecycle.Event.ON_RESUME -> { /* playback continues uninterrupted */ }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            // Persist resume point before releasing
            val pos = player.currentPosition
            val dur = player.duration.coerceAtLeast(0)
            if (pos > 0) progressVm.save(mediaId, pos, dur, title, uri.toString())
            player.release()
        }
    }

    var showControls by remember { mutableStateOf(true) }
    var isPlaying by remember { mutableStateOf(true) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var speed by remember { mutableFloatStateOf(1f) }

    var seekIndicator by remember { mutableStateOf<Long?>(null) }

    val audioManager = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)

    LaunchedEffect(player) {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(p: Boolean) { isPlaying = p }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) {
                    when (videoRepeatMode) {
                        1 -> onAdvanceNext()          // auto-play next
                        2 -> { player.seekTo(0); player.play() }  // repeat
                        else -> { /* stop naturally */ }
                    }
                }
            }
        })
        var sinceSave = 0
        while (true) {
            position = player.currentPosition
            duration = player.duration.coerceAtLeast(0)
            sinceSave += 1
            if (sinceSave >= 10 && player.isPlaying && position > 0) {
                sinceSave = 0
                progressVm.save(mediaId, position, duration, title, uri.toString())
            }
            delay(250)
        }
    }
    LaunchedEffect(showControls) {
        if (showControls && isPlaying) {
            delay(3500)
            showControls = false
        }
    }
    LaunchedEffect(seekIndicator) {
        if (seekIndicator != null) {
            delay(900)
            seekIndicator = null
        }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = {
                PlayerView(it).apply {
                    this.player = player
                    useController = false
                    setBackgroundColor(android.graphics.Color.BLACK)
                }
            },
            update = { it.player = player },
            modifier = Modifier
                .fillMaxSize()
                // Tap area for showing controls & double-tap seek
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { showControls = !showControls },
                        onDoubleTap = { offset ->
                            // Double-tap right half = forward 10s, left half = back 10s.
                            val w = size.width
                            val cur = player.currentPosition
                            val dur = player.duration.coerceAtLeast(0)
                            val target = if (offset.x < w / 2) cur - 10_000 else cur + 10_000
                            player.seekTo(target.coerceIn(0, if (dur > 0) dur else target))
                            seekIndicator = target.coerceAtLeast(0)
                        }
                    )
                }
                // Brightness/volume drags were removed on purpose: they conflicted
                // with swiping between videos. Now the VerticalPager receives
                // up/down swipes from anywhere on the screen — like Reels/TikTok.
        )

        // Gesture indicator overlays
        seekIndicator?.let { pos ->
            Surface(
                color = Color.Black.copy(alpha = 0.6f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Text(
                    "${Formatters.duration(pos)} / ${Formatters.duration(duration)}",
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }

        if (showControls) {
            // Top bar
            Surface(
                color = Color.Black.copy(alpha = 0.45f),
                modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Spacer(Modifier.weight(1f))
                    // Mute (main #2)
                    IconButton(onClick = { muted = !muted }) {
                        Icon(
                            if (muted) Icons.Rounded.VolumeOff
                            else Icons.Rounded.VolumeUp,
                            contentDescription = if (muted) "Unmute" else "Mute",
                            tint = Color.White
                        )
                    }
                    // Subtitles (main #5)
                    IconButton(onClick = { subtitlePicker.launch(arrayOf("*/*")) }) {
                        Icon(Icons.Outlined.Subtitles, contentDescription = "Subtitles", tint = Color.White)
                    }
                    // Sticker icon (own menu for duration)
                    Box {
                        IconButton(
                            enabled = !makingSticker,
                            onClick = { showStickerMenu = true }
                        ) {
                            if (makingSticker) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(22.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(Icons.Outlined.Gif, contentDescription = "Sticker", tint = Color.White)
                            }
                        }
                        DropdownMenu(
                            expanded = showStickerMenu,
                            onDismissRequest = { showStickerMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Send to WhatsApp (2s)") },
                                onClick = { showStickerMenu = false; makeSticker(2000L, share = true) }
                            )
                            DropdownMenuItem(
                                text = { Text("Send to WhatsApp (3s)") },
                                onClick = { showStickerMenu = false; makeSticker(3000L, share = true) }
                            )
                            DropdownMenuItem(
                                text = { Text("Send to WhatsApp (5s)") },
                                onClick = { showStickerMenu = false; makeSticker(5000L, share = true) }
                            )
                        }
                    }
                    // More menu (3 dots) — extract audio, info
                    Box {
                        IconButton(
                            enabled = !extractingAudio,
                            onClick = { showMoreMenu = true }
                        ) {
                            if (extractingAudio) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(22.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(Icons.Rounded.MoreVert, contentDescription = "More", tint = Color.White)
                            }
                        }
                        DropdownMenu(
                            expanded = showMoreMenu,
                            onDismissRequest = { showMoreMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Extract audio (MP3)") },
                                leadingIcon = { Icon(Icons.Rounded.MusicNote, contentDescription = null) },
                                onClick = {
                                    showMoreMenu = false
                                    extractingAudio = true
                                    scope.launch {
                                        val ok = com.shabaan.v7.util.AudioExtractor.extractToMusic(
                                            ctx, uri, title
                                        )
                                        extractingAudio = false
                                        android.widget.Toast.makeText(
                                            ctx,
                                            if (ok) "Audio saved to Music/V7 Audio" else "Couldn't extract audio",
                                            android.widget.Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("Trim video") },
                                leadingIcon = { Icon(Icons.Rounded.ContentCut, contentDescription = null) },
                                onClick = { showMoreMenu = false; showTrim = true }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("Info") },
                                leadingIcon = { Icon(Icons.Rounded.Info, contentDescription = null) },
                                onClick = { showMoreMenu = false; showInfo = true }
                            )
                        }
                    }
                }
            }

            // Center play/pause
            FilledIconButton(
                onClick = {
                    // If the video has finished, start it over from the beginning.
                    // Otherwise just toggle play/pause.
                    if (player.playbackState == Player.STATE_ENDED) {
                        player.seekTo(0)
                        player.play()
                    } else {
                        player.playWhenReady = !player.isPlaying
                    }
                },
                modifier = Modifier.align(Alignment.Center).size(72.dp),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = Color.Black.copy(alpha = 0.45f),
                    contentColor = Color.White
                )
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(40.dp)
                )
            }

            // TikTok-style vertical action rail on the right
            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 12.dp, bottom = 96.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                RailAction(
                    icon = if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    label = "Favorite",
                    tint = if (isFavorite) MaterialTheme.colorScheme.primary else Color.White,
                    onClick = onToggleFavorite
                )
                RailAction(
                    icon = Icons.Rounded.Share,
                    label = "Share",
                    onClick = onShare
                )
                RailAction(
                    icon = Icons.Rounded.MoreVert,
                    label = "More",
                    onClick = { showRailMore = true }
                )
                DropdownMenu(
                    expanded = showRailMore,
                    onDismissRequest = { showRailMore = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Picture-in-picture") },
                        leadingIcon = { Icon(Icons.Outlined.PictureInPicture, null) },
                        onClick = { showRailMore = false; onTogglePiP() }
                    )
                    DropdownMenuItem(
                        text = {
                            Text(
                                when (videoRepeatMode) {
                                    1 -> "Repeat: Auto-play next"
                                    2 -> "Repeat: This video"
                                    else -> "Repeat: Off"
                                }
                            )
                        },
                        leadingIcon = {
                            Icon(
                                when (videoRepeatMode) {
                                    1 -> Icons.Rounded.SkipNext
                                    2 -> Icons.Rounded.RepeatOne
                                    else -> Icons.Rounded.Repeat
                                },
                                null
                            )
                        },
                        onClick = {
                            videoRepeatMode = (videoRepeatMode + 1) % 3
                            val msg = when (videoRepeatMode) {
                                1 -> "Auto-play next"
                                2 -> "Repeat this video"
                                else -> "Stop at end"
                            }
                            android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }

            // Bottom controls
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(
                        androidx.compose.ui.graphics.Brush.verticalGradient(
                            listOf(Color.Transparent, Color.Black.copy(alpha = 0.65f))
                        )
                    )
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                // Title + folder — TikTok-style elegant overlay.
                Text(
                    title.substringBeforeLast('.'),
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
                folder?.let { f ->
                    Text(
                        f.trim('/').substringAfterLast('/').ifEmpty { f.trim('/') },
                        color = Color.White.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
                // Metadata line: resolution • duration (read-only; no playback change).
                run {
                    val vw = player.videoSize.width
                    val vh = player.videoSize.height
                    val resLabel = when {
                        vh >= 2160 || vw >= 2160 -> "4K"
                        vh >= 1080 || vw >= 1080 -> "1080p"
                        vh >= 720 || vw >= 720 -> "720p"
                        vh > 0 -> "${minOf(vw, vh)}p"
                        else -> null
                    }
                    val meta = buildString {
                        if (resLabel != null) append(resLabel)
                        if (duration > 0) {
                            if (isNotEmpty()) append("  •  ")
                            append(Formatters.duration(duration))
                        }
                    }
                    if (meta.isNotEmpty()) {
                        Text(
                            meta,
                            color = Color.White.copy(alpha = 0.6f),
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        Formatters.duration(position),
                        color = Color.White,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.width(8.dp))
                    Slider(
                        value = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f,
                        onValueChange = { player.seekTo((it * duration).toLong()) },
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                            inactiveTrackColor = Color.White.copy(alpha = 0.25f)
                        )
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        Formatters.duration(duration),
                        color = Color.White,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Medium
                    )
                }
                Row(
                    Modifier.fillMaxWidth().padding(top = 6.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    listOf(0.5f, 1f, 1.25f, 1.5f, 2f).forEach { s ->
                        TextButton(onClick = {
                            speed = s
                            player.setPlaybackSpeed(s)
                        }) {
                            Text(
                                "${s}x",
                                color = if (s == speed) Color.White else Color.White.copy(alpha = 0.55f),
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }
        }

        if (showInfo) {
            AlertDialog(
                onDismissRequest = { showInfo = false },
                title = { Text("Details") },
                text = {
                    Column {
                        Text(title, style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Duration: " + Formatters.duration(duration),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showInfo = false }) { Text("Close") }
                }
            )
        }

        if (showTrim) {
            val totalMs = duration.coerceAtLeast(1000L)
            var startMs by remember { mutableFloatStateOf(0f) }
            var endMs by remember { mutableFloatStateOf(totalMs.toFloat()) }
            AlertDialog(
                onDismissRequest = { if (!trimming) showTrim = false },
                title = { Text("Trim video") },
                text = {
                    Column {
                        Text(
                            "From: " + Formatters.duration(startMs.toLong()),
                            style = MaterialTheme.typography.labelMedium
                        )
                        Slider(
                            value = startMs,
                            onValueChange = { if (it < endMs - 1000) startMs = it },
                            valueRange = 0f..totalMs.toFloat()
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "To: " + Formatters.duration(endMs.toLong()),
                            style = MaterialTheme.typography.labelMedium
                        )
                        Slider(
                            value = endMs,
                            onValueChange = { if (it > startMs + 1000) endMs = it },
                            valueRange = 0f..totalMs.toFloat()
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Clip length: " + Formatters.duration((endMs - startMs).toLong()),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                confirmButton = {
                    TextButton(enabled = !trimming, onClick = {
                        trimming = true
                        scope.launch {
                            val ok = com.shabaan.v7.util.VideoTrimmer.trim(
                                ctx, uri, startMs.toLong(), endMs.toLong(), title
                            )
                            trimming = false
                            showTrim = false
                            android.widget.Toast.makeText(
                                ctx,
                                if (ok) "Saved to Movies/V7 Trimmed" else "Couldn't trim video",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }
                    }) { Text(if (trimming) "Saving…" else "Save clip") }
                },
                dismissButton = {
                    TextButton(enabled = !trimming, onClick = { showTrim = false }) { Text("Cancel") }
                }
            )
        }
    }
}

@Composable
private fun IndicatorOverlay(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    progress: Float,
    label: String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color.Black.copy(alpha = 0.6f),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp)
        ) {
            Icon(icon, contentDescription = null, tint = Color.White)
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier
                    .width(4.dp)
                    .height(80.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.25f))
            ) {
                Box(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .width(4.dp)
                        .fillMaxHeight(progress)
                        .background(Color.White)
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(label, color = Color.White, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun RailAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        FilledIconButton(
            onClick = onClick,
            modifier = Modifier.size(52.dp),
            colors = IconButtonDefaults.filledIconButtonColors(
                containerColor = Color.Black.copy(alpha = 0.32f),
                contentColor = tint
            )
        ) {
            Icon(icon, contentDescription = label, modifier = Modifier.size(27.dp))
        }
        Spacer(Modifier.height(5.dp))
        Text(
            label,
            color = Color.White.copy(alpha = 0.85f),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Medium
        )
    }
}

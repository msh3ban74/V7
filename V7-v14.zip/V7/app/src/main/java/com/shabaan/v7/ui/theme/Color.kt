package com.shabaan.v7.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * "Platinum Silver" — a calm, premium, monochrome palette (2026 media app).
 * No colorful accents, no gradients, no RGB. Just elegant silver on near-black.
 */

// Core surfaces (dark).
val V7Background = Color(0xFF0A0B0D)
val V7Surface = Color(0xFF111317)
val V7Card = Color(0xFF171A1F)

// Silver tones.
val PrimarySilver = Color(0xFFC7CCD1)
val BrightSilver = Color(0xFFE5E8EB)
val AccentSilver = Color(0xFFB8BDC5)

// Text.
val TextPrimary = Color(0xFFF5F5F5)
val TextSecondary = Color(0xFF9AA0A6)

// Subtle outlines / dividers derived from the silver family.
val V7Outline = Color(0xFF2A2E35)
val V7OutlineVariant = Color(0xFF20242A)

// --- Legacy aliases -------------------------------------------------------
// Kept so any older references still compile; mapped onto the new palette.
val Titanium50  = BrightSilver
val Titanium100 = Color(0xFFE8EBF0)
val Titanium200 = PrimarySilver
val Titanium300 = AccentSilver
val Titanium400 = Color(0xFF8893A4)
val Titanium500 = TextSecondary
val Titanium600 = Color(0xFF515B6A)
val Titanium700 = Color(0xFF3A4350)
val Titanium800 = V7Card
val Titanium900 = V7Surface
val TitaniumAccent = PrimarySilver
val PlatinumGlow = BrightSilver
val PlatinumDeep = V7Background

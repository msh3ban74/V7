package com.shabaan.v7.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.shabaan.v7.util.ThemeMode

private val LightScheme = lightColorScheme(
    primary = Titanium700,
    onPrimary = Titanium50,
    primaryContainer = Titanium200,
    onPrimaryContainer = Titanium900,

    secondary = Titanium600,
    onSecondary = Titanium50,
    secondaryContainer = Titanium100,
    onSecondaryContainer = Titanium800,

    tertiary = TitaniumAccent,
    onTertiary = Color.White,

    background = Titanium50,
    onBackground = Titanium900,

    surface = Color.White,
    onSurface = Titanium900,
    surfaceVariant = Titanium100,
    onSurfaceVariant = Titanium700,

    outline = Titanium300,
    outlineVariant = Titanium200,
    error = Color(0xFFB3261E),
    onError = Color.White
)

private val DarkScheme = darkColorScheme(
    primary = PrimarySilver,
    onPrimary = V7Background,
    primaryContainer = V7Card,
    onPrimaryContainer = BrightSilver,

    secondary = AccentSilver,
    onSecondary = V7Background,
    secondaryContainer = V7Card,
    onSecondaryContainer = BrightSilver,

    tertiary = BrightSilver,
    onTertiary = V7Background,

    background = V7Background,
    onBackground = TextPrimary,

    surface = V7Surface,
    onSurface = TextPrimary,
    surfaceVariant = V7Card,
    onSurfaceVariant = TextSecondary,

    surfaceContainer = V7Card,
    surfaceContainerHigh = Color(0xFF1C2026),
    surfaceContainerHighest = Color(0xFF22262D),

    outline = V7Outline,
    outlineVariant = V7OutlineVariant,
    error = Color(0xFFF2B8B5),
    onError = Color(0xFF601410)
)

private val V7Shapes = androidx.compose.material3.Shapes(
    // Softer, more rounded corners give a modern, premium, "future" feel while
    // staying calm and minimal.
    extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
    small = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
    medium = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
    large = androidx.compose.foundation.shape.RoundedCornerShape(26.dp),
    extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(34.dp)
)

@Composable
fun V7Theme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val useDark = when (themeMode) {
        ThemeMode.SYSTEM -> systemDark
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val scheme = if (useDark) DarkScheme else LightScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = Color.Transparent.value.toInt()
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = scheme.background.luminance() > 0.5f
            controller.isAppearanceLightNavigationBars = scheme.background.luminance() > 0.5f
        }
    }
    MaterialTheme(
        colorScheme = scheme,
        typography = V7Typography,
        shapes = V7Shapes,
        content = content
    )
}

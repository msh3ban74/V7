package com.shabaan.v7.util

import com.google.common.truth.Truth.assertThat
import org.junit.Test

/**
 * Unit tests for [VaultFileLogic] — the pure logic the vault's correctness
 * depends on (filename sanitization, viewer extension resolution, and backup
 * manifest round-tripping). Fast local JVM tests; no device or encryption layer
 * involved (that layer is Google's EncryptedFile and is trusted separately).
 *
 * The most important test here is the manifest round-trip with a pipe character
 * in the name: that's the case that could silently corrupt a backup import.
 */
class VaultFileLogicTest {

    // ---- sanitizeFileName ----

    @Test
    fun sanitize_keeps_safe_chars() {
        assertThat(VaultFileLogic.sanitizeFileName("photo_01.jpg")).isEqualTo("photo_01.jpg")
        assertThat(VaultFileLogic.sanitizeFileName("My-File.2.mp4")).isEqualTo("My-File.2.mp4")
    }

    @Test
    fun sanitize_replaces_spaces_and_punctuation() {
        assertThat(VaultFileLogic.sanitizeFileName("my photo (1).jpg"))
            .isEqualTo("my_photo__1_.jpg")
    }

    @Test
    fun sanitize_replaces_arabic_with_underscores() {
        // Arabic display names become underscores on disk — expected, since the
        // real name is preserved in the DB. Just verify it doesn't crash and
        // produces only safe characters.
        val out = VaultFileLogic.sanitizeFileName("صورة.jpg")
        assertThat(out).matches("[A-Za-z0-9._-]+")
        assertThat(out).endsWith(".jpg")
    }

    // ---- resolveViewerExtension ----

    @Test
    fun extension_prefers_original_name() {
        val ext = VaultFileLogic.resolveViewerExtension("vacation.png", "162534_vacation.enc", "IMAGE")
        assertThat(ext).isEqualTo(".png")
    }

    @Test
    fun extension_falls_back_to_stored_name() {
        // Original name has no extension → use the stored file's extension.
        val ext = VaultFileLogic.resolveViewerExtension("vacation", "162534_clip.mp4", "VIDEO")
        assertThat(ext).isEqualTo(".mp4")
    }

    @Test
    fun extension_falls_back_to_type_default() {
        // Neither name has an extension → type-based default.
        assertThat(VaultFileLogic.resolveViewerExtension("clip", "stored", "VIDEO")).isEqualTo(".mp4")
        assertThat(VaultFileLogic.resolveViewerExtension("pic", "stored", "IMAGE")).isEqualTo(".jpg")
        assertThat(VaultFileLogic.resolveViewerExtension("song", "stored", "AUDIO")).isEqualTo(".mp3")
    }

    // ---- manifest round-trip ----

    @Test
    fun manifest_round_trip_basic() {
        val line = VaultFileLogic.manifestLine(
            originalName = "holiday.jpg",
            mime = "image/jpeg",
            type = "IMAGE",
            size = 12345L,
            duration = 0L,
            addedAt = 1700000000000L,
            encrypted = true,
            storedFileName = "162534_holiday.enc"
        )
        val parsed = VaultFileLogic.parseManifestLine(line)!!
        assertThat(parsed.originalName).isEqualTo("holiday.jpg")
        assertThat(parsed.mime).isEqualTo("image/jpeg")
        assertThat(parsed.type).isEqualTo("IMAGE")
        assertThat(parsed.size).isEqualTo(12345L)
        assertThat(parsed.duration).isEqualTo(0L)
        assertThat(parsed.addedAt).isEqualTo(1700000000000L)
        assertThat(parsed.encrypted).isTrue()
        assertThat(parsed.storedFileName).isEqualTo("162534_holiday.enc")
    }

    @Test
    fun manifest_name_with_pipe_does_not_corrupt() {
        // THE important one: a pipe in the display name must not break parsing.
        val line = VaultFileLogic.manifestLine(
            originalName = "weird|name|file.mp4",
            mime = "video/mp4",
            type = "VIDEO",
            size = 999L,
            duration = 5000L,
            addedAt = 1700000000000L,
            encrypted = true,
            storedFileName = "162534_weird.enc"
        )
        val parsed = VaultFileLogic.parseManifestLine(line)!!
        // The pipes were neutralized to underscores, so all later fields stay aligned.
        assertThat(parsed.storedFileName).isEqualTo("162534_weird.enc")
        assertThat(parsed.type).isEqualTo("VIDEO")
        assertThat(parsed.size).isEqualTo(999L)
        assertThat(parsed.originalName).doesNotContain("|")
    }

    @Test
    fun manifest_corrupt_line_returns_null() {
        assertThat(VaultFileLogic.parseManifestLine("not|enough|fields")).isNull()
        assertThat(VaultFileLogic.parseManifestLine("")).isNull()
    }

    @Test
    fun manifest_bad_numbers_become_null_not_crash() {
        val line = "name.jpg|image/jpeg|IMAGE|notanumber|x|y|true|stored.enc"
        val parsed = VaultFileLogic.parseManifestLine(line)!!
        assertThat(parsed.size).isNull()
        assertThat(parsed.duration).isNull()
        assertThat(parsed.addedAt).isNull()
        assertThat(parsed.encrypted).isTrue()
    }

    @Test
    fun manifest_encrypted_false_parsed() {
        val line = VaultFileLogic.manifestLine(
            "a.mp3", "audio/mpeg", "AUDIO", 1L, 1L, 1L, false, "s.mp3"
        )
        val parsed = VaultFileLogic.parseManifestLine(line)!!
        assertThat(parsed.encrypted).isFalse()
    }
}

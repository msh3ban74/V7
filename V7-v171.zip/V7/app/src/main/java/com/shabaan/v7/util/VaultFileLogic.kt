package com.shabaan.v7.util

/**
 * Pure, Android-free logic extracted from VaultRepository so it can be unit
 * tested without a device. These functions mirror EXACTLY the behavior that was
 * previously inline in the repository — nothing about encryption or file I/O
 * changes; only the small string/parsing helpers move here so they're testable
 * and documented.
 *
 * Why this matters: the vault's correctness depends on these helpers as much as
 * on the (Google-provided, already-trusted) AES-256-GCM EncryptedFile layer. A
 * bug in extension resolution means a decrypted photo won't open; a bug in
 * manifest parsing means a backup import corrupts metadata. These are the parts
 * worth pinning with tests.
 */
object VaultFileLogic {

    /** Characters allowed in an on-disk stored filename; everything else → '_'. */
    private val UNSAFE = Regex("[^A-Za-z0-9._-]")

    /**
     * Sanitize a display name into a safe on-disk filename fragment. Note this
     * is only for the STORED file name; the original (possibly Arabic) name is
     * preserved separately in the database. Arabic/space/punctuation all become
     * '_', which is expected and harmless.
     */
    fun sanitizeFileName(displayName: String): String =
        displayName.replace(UNSAFE, "_")

    /**
     * Decide the extension to give a decrypted temp file so the OS/player can
     * open it. Priority: the original name's extension, then the stored file's
     * extension, then a type-based default. Mirrors materializeOrThrow().
     *
     * @return an extension INCLUDING the leading dot, e.g. ".jpg".
     */
    fun resolveViewerExtension(
        originalName: String,
        storedFileName: String,
        type: String
    ): String {
        val nameExt = originalName.substringAfterLast('.', "")
        val storedExt = storedFileName.substringAfterLast('.', "")
        return when {
            nameExt.isNotEmpty() -> ".$nameExt"
            storedExt.isNotEmpty() -> ".$storedExt"
            type == "VIDEO" -> ".mp4"
            type == "IMAGE" -> ".jpg"
            else -> ".mp3"
        }
    }

    /** Number of fields in a manifest line. */
    const val MANIFEST_FIELD_COUNT = 8

    /**
     * Build one manifest line for a backup export. Field order:
     * name|mime|type|size|duration|addedAt|encrypted|storedFileName
     * The display name has '|' replaced so the delimiter can't be broken by a
     * filename that contains a pipe character.
     */
    fun manifestLine(
        originalName: String,
        mime: String,
        type: String,
        size: Long,
        duration: Long,
        addedAt: Long,
        encrypted: Boolean,
        storedFileName: String
    ): String = buildString {
        append(originalName.replace("|", "_")).append("|")
        append(mime).append("|")
        append(type).append("|")
        append(size).append("|")
        append(duration).append("|")
        append(addedAt).append("|")
        append(encrypted).append("|")
        append(storedFileName)
    }

    /** Parsed manifest fields. Numeric fields fall back to null on bad data. */
    data class ManifestEntry(
        val originalName: String,
        val mime: String,
        val type: String,
        val size: Long?,
        val duration: Long?,
        val addedAt: Long?,
        val encrypted: Boolean,
        val storedFileName: String
    )

    /**
     * Parse one manifest line. Returns null if the line doesn't have the
     * expected number of fields (so a corrupt line is skipped, not crashed on).
     * Numeric parsing is lenient (null on failure) so the caller can fall back.
     */
    fun parseManifestLine(line: String): ManifestEntry? {
        val p = line.split("|")
        if (p.size < MANIFEST_FIELD_COUNT) return null
        return ManifestEntry(
            originalName = p[0],
            mime = p[1],
            type = p[2],
            size = p[3].toLongOrNull(),
            duration = p[4].toLongOrNull(),
            addedAt = p[5].toLongOrNull(),
            encrypted = p[6].toBoolean(),
            storedFileName = p[7]
        )
    }
}

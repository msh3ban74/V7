package com.shabaan.v7.ui.videos

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shabaan.v7.data.local.ProgressDao
import com.shabaan.v7.data.model.MediaItem
import com.shabaan.v7.data.model.MediaType
import com.shabaan.v7.data.repository.FavoritesRepository
import com.shabaan.v7.data.repository.MediaRepository
import com.shabaan.v7.data.repository.TrashRepository
import com.shabaan.v7.data.repository.VaultMoveResult
import com.shabaan.v7.data.repository.VaultRepository
import com.shabaan.v7.data.repository.filteredBy
import com.shabaan.v7.data.repository.sorted
import com.shabaan.v7.util.SettingsStore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/** A video the user hasn't finished, with how far they got. */
data class ContinueWatching(
    val item: MediaItem,
    val positionMs: Long,
    val durationMs: Long
) {
    val fraction: Float
        get() = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
}

@androidx.compose.runtime.Immutable
data class VideosUi(
    val loading: Boolean = false,
    val raw: List<MediaItem> = emptyList(),
    val selection: Set<Long> = emptySet(),
    val selectionMode: Boolean = false,
    val showFavoritesOnly: Boolean = false,
    val favorites: Set<Long> = emptySet(),
    val query: String = "",
    val continueWatching: List<ContinueWatching> = emptyList()
) {
    /**
     * Visible list = raw → favorites filter → search filter.
     * Computed ONCE per state instance (by lazy), not on every read. The old
     * `get()` recomputed filtering+search on every access — and the UI reads
     * `items` many times per scroll frame, which was heavy work on the main
     * thread. `by lazy` makes it compute once and reuse, killing that cost.
     */
    val items: List<MediaItem> by lazy {
        val base = if (showFavoritesOnly) raw.filter { it.id in favorites } else raw
        base.filteredBy(query)
    }
}

@HiltViewModel
class VideosViewModel @Inject constructor(
    private val repo: MediaRepository,
    private val favRepo: FavoritesRepository,
    private val trashRepo: TrashRepository,
    private val vaultRepo: VaultRepository,
    private val progressDao: ProgressDao,
    private val settings: SettingsStore
) : ViewModel() {

    private val _state = MutableStateFlow(VideosUi())
    val state: StateFlow<VideosUi> = _state.asStateFlow()

    private var hasLoaded = false

    init {
        viewModelScope.launch {
            favRepo.observeByType(MediaType.VIDEO).collect { favs ->
                _state.update { it.copy(favorites = favs.map { f -> f.mediaId }.toSet()) }
            }
        }
        viewModelScope.launch {
            progressDao.recent().collect { rebuildContinueWatching(it) }
        }
        // Keep in sync with the phone: if media is added/deleted anywhere, reload.
        viewModelScope.launch {
            var first = true
            repo.mediaChanges().collect {
                if (first) { first = false; return@collect }
                if (hasLoaded) load()
            }
        }
    }

    /** Loads once after permission is granted. Safe to call on every screen entry. */
    fun ensureLoaded() {
        if (hasLoaded) return
        hasLoaded = true
        load()
    }

    private fun rebuildContinueWatching(
        progress: List<com.shabaan.v7.data.local.PlaybackProgressEntity>
    ) {
        val byId = _state.value.raw.associateBy { it.id }
        val cw = progress.mapNotNull { p ->
            byId[p.mediaId]?.let { item ->
                ContinueWatching(item, p.positionMs, p.durationMs)
            }
        }.take(10)
        _state.update { it.copy(continueWatching = cw) }
    }

    /** Forces a fresh MediaStore read (used after sort change / delete). */
    fun load() {
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            val items = repo.loadVideos().sorted(settings.sortBy, settings.sortOrder)
            _state.update { it.copy(loading = false, raw = items) }
            // Re-link continue-watching against the freshly loaded list
            runCatching {
                progressDao.recent().firstOrNull()?.let { rebuildContinueWatching(it) }
            }
        }
    }

    fun setQuery(q: String) {
        _state.update { it.copy(query = q) }
    }

    fun toggleSelection(id: Long) {
        _state.update {
            val newSet = it.selection.toMutableSet()
            if (!newSet.add(id)) newSet.remove(id)
            it.copy(selection = newSet, selectionMode = newSet.isNotEmpty())
        }
    }

    fun startSelection(id: Long) {
        _state.update { it.copy(selectionMode = true, selection = it.selection + id) }
    }

    fun clearSelection() {
        _state.update { it.copy(selectionMode = false, selection = emptySet()) }
    }

    fun selectAll() {
        _state.update {
            val ids = it.items.map { v -> v.id }.toSet()
            val allSelected = it.selection.size == ids.size && ids.isNotEmpty()
            it.copy(
                selection = if (allSelected) emptySet() else ids,
                selectionMode = !allSelected
            )
        }
    }

    fun toggleFavorite(id: Long) {
        viewModelScope.launch {
            val current = _state.value.favorites
            if (current.contains(id)) favRepo.remove(id, MediaType.VIDEO)
            else favRepo.add(id, MediaType.VIDEO)
        }
    }

    fun toggleFavoritesOnly() {
        _state.update { it.copy(showFavoritesOnly = !it.showFavoritesOnly) }
    }

    fun selectedItems(): List<MediaItem> {
        val sel = _state.value.selection
        return _state.value.items.filter { it.id in sel }
    }

    /**
     * Copy selected items into the trash bin, then return the URIs that need a
     * system delete-request (Android 11+). The screen launches the request and
     * calls [onDeleteConfirmed] afterwards to refresh.
     */
    fun moveSelectedToTrash(onNeedsDelete: (List<android.net.Uri>) -> Unit) {
        viewModelScope.launch {
            val selected = selectedItems()
            selected.forEach { trashRepo.moveToTrash(it) }
            val uris = selected.map { it.uri }
            clearSelection()
            onNeedsDelete(uris)
        }
    }

    /** Move selected items into the (encrypted) vault. */
    fun moveSelectedToVault(onNeedsDelete: (List<android.net.Uri>) -> Unit) {
        viewModelScope.launch {
            val selected = selectedItems()
            val pendingDelete = mutableListOf<android.net.Uri>()
            selected.forEach { item ->
                when (val r = vaultRepo.moveToVault(item)) {
                    is VaultMoveResult.NeedsUserAction -> pendingDelete += item.uri
                    is VaultMoveResult.Success -> Unit
                    is VaultMoveResult.Error -> Unit
                }
            }
            clearSelection()
            if (pendingDelete.isNotEmpty()) onNeedsDelete(pendingDelete)
            load()
        }
    }

    fun refreshAfterDelete() = load()

    /** Clears the Continue Watching history (all saved playback positions). */
    fun clearContinueWatching() {
        viewModelScope.launch {
            progressDao.clearAll()
        }
    }
}

package com.shabaan.v7.ui.music

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.shabaan.v7.ui.components.ReciterAvatar
import com.shabaan.v7.util.QuranApi.Reciter

/**
 * A section header with a title, used across the Quran dashboard.
 */
@Composable
fun QuranSectionHeader(title: String, modifier: Modifier = Modifier) {
    Text(
        title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = modifier.padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

/**
 * A large Material 3 sheikh card: circular avatar, name, surah count and a
 * quick-play button, plus a favorite toggle. Used in horizontal strips on the
 * Quran dashboard.
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun SheikhCard(
    reciter: Reciter,
    surahCount: Int,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onQuickPlay: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = com.shabaan.v7.util.LocalAppLanguage.current
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
        ),
        shape = RoundedCornerShape(20.dp),
        modifier = modifier.width(150.dp)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.fillMaxWidth()) {
                // Favorite heart, top-end.
                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier.align(Alignment.TopEnd).size(28.dp)
                ) {
                    Icon(
                        if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        contentDescription = com.shabaan.v7.util.S.favorite(lang),
                        tint = if (isFavorite) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
                ReciterAvatar(
                    name = reciter.arabicName,
                    size = 72.dp,
                    modifier = Modifier.align(Alignment.TopCenter)
                )
            }
            Spacer(Modifier.size(10.dp))
            Text(
                reciter.arabicName,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                "$surahCount " + com.shabaan.v7.util.S.surahCountWord(lang),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.size(10.dp))
            // Quick-play pill.
            Row(
                Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
                    .clickable(onClick = onQuickPlay)
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Rounded.PlayArrow,
                    contentDescription = com.shabaan.v7.util.S.play(lang),
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.size(4.dp))
                Text(
                    com.shabaan.v7.util.S.play(lang),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            }
        }
    }
}

/**
 * A horizontal strip of sheikh cards under a section title. Lazily composed
 * (LazyRow) so long catalogs don't build off-screen cards.
 */
@Composable
fun SheikhStrip(
    title: String,
    reciters: List<Reciter>,
    surahCount: Int,
    favoriteIds: Set<String>,
    onOpen: (Reciter) -> Unit,
    onQuickPlay: (Reciter) -> Unit,
    onToggleFavorite: (Reciter) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxWidth()) {
        QuranSectionHeader(title)
        LazyRow(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(reciters, key = { it.identifier }) { rec ->
                SheikhCard(
                    reciter = rec,
                    surahCount = surahCount,
                    isFavorite = rec.identifier in favoriteIds,
                    onClick = { onOpen(rec) },
                    onQuickPlay = { onQuickPlay(rec) },
                    onToggleFavorite = { onToggleFavorite(rec) }
                )
            }
        }
    }
}

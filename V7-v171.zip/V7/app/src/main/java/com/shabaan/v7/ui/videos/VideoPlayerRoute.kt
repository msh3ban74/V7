@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.shabaan.v7.ui.videos

import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Rational
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.PictureInPicture
import androidx.compose.material.icons.rounded.Compress
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.Bookmarks
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.outlined.AddReaction
import androidx.compose.material.icons.rounded.Collections
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem as Media3Item
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.shabaan.v7.util.Formatters
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun VideoPlayerRoute(
    startIndex: Int,
    onBack: () -> Unit,
    progressVm: PlaybackProgressViewModel = androidx.hilt.navigation.compose.hiltViewModel(),
    favVm: PlayerFavViewModel = androidx.hilt.navigation.compose.hiltViewModel()
) {
    val ctx = LocalContext.current
    val activity = ctx as? Activity
    val items = remember { VideoSession.list }
    if (items.isEmpty()) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val favorites by favVm.favorites.collectAsState()
    val safeStart = startIndex.coerceIn(0, items.lastIndex)
    val pagerState = rememberPagerState(initialPage = safeStart) { items.size }
    val scope = androidx.compose.runtime.rememberCoroutineScope()

    DisposableEffect(Unit) {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }
    BackHandler { onBack() }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        VerticalPager(state = pagerState, beyondViewportPageCount = 1) { page ->
            val item = items[page]
            val active = page == pagerState.currentPage
            SinglePlayerPage(
                mediaId = item.id,
                uri = item.uri,
                title = item.name,
                folder = item.relativePath,
                active = active,
                progressVm = progressVm,
                isFavorite = item.id in favorites,
                onToggleFavorite = { favVm.toggle(item.id) },
                onBack = onBack,
                onTogglePiP = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && activity != null &&
                        activity.packageManager.hasSystemFeature(
                            android.content.pm.PackageManager.FEATURE_PICTURE_IN_PICTURE
                        )
                    ) {
                        try {
                            // Use the video's real aspect ratio so the PiP window
                            // matches the video and fills it — instead of a fixed
                            // 16:9 that leaves the video as a small letterboxed
                            // patch. PiP only allows ratios between ~0.42 and ~2.39,
                            // so we clamp into that range.
                            val vw = if (item.width > 0) item.width else 16
                            val vh = if (item.height > 0) item.height else 9
                            val ratioF = vw.toFloat() / vh.toFloat()
                            val clamped = ratioF.coerceIn(0.42f, 2.39f)
                            // Build a Rational from the clamped ratio (x1000 for precision).
                            val rational = Rational((clamped * 1000).toInt(), 1000)
                            val params = PictureInPictureParams.Builder()
                                .setAspectRatio(rational)
                                .build()
                            activity.enterPictureInPictureMode(params)
                        } catch (_: Exception) { /* device refused PiP */ }
                    }
                },
                onShare = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = item.mimeType
                        putExtra(Intent.EXTRA_STREAM, item.uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    ctx.startActivity(Intent.createChooser(send, "Share"))
                },
                onAdvanceNext = {
                    val next = page + 1
                    if (next < items.size) {
                        scope.launch { pagerState.animateScrollToPage(next) }
                    }
                }
            )
        }
    }
}

@Composable
private fun SinglePlayerPage(
    mediaId: Long,
    uri: Uri,
    title: String,
    folder: String? = null,
    active: Boolean,
    progressVm: PlaybackProgressViewModel,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onBack: () -> Unit,
    onTogglePiP: () -> Unit,
    onShare: () -> Unit,
    onAdvanceNext: () -> Unit = {}
) {
    val ctx = LocalContext.current
    val activity = ctx as? Activity
    val lifecycleOwner = LocalLifecycleOwner.current

    var subtitleUri by remember { mutableStateOf<Uri?>(null) }
    val subtitlePicker = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    it, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) { /* not all URIs are persistable */ }
            subtitleUri = it
        }
    }

    val player = remember(uri) {
        // Is a phone call already in progress at the moment this video opens?
        // If so, the user deliberately opened the video DURING a call (e.g. "open
        // that clip and tell me what's in it"), so we keep playing over the call.
        // Otherwise we use normal audio focus: a call/another app that starts
        // LATER will pause us and we resume when it ends — the expected behaviour.
        val am = ctx.getSystemService(android.content.Context.AUDIO_SERVICE) as? android.media.AudioManager
        val inCallNow = am?.mode == android.media.AudioManager.MODE_IN_CALL ||
            am?.mode == android.media.AudioManager.MODE_IN_COMMUNICATION
        ExoPlayer.Builder(ctx)
            .setAudioAttributes(
                androidx.media3.common.AudioAttributes.Builder()
                    .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MOVIE)
                    .setUsage(androidx.media3.common.C.USAGE_MEDIA)
                    .build(),
                // Normal focus handling UNLESS a call is already active — then we
                // ignore focus so the user can watch the clip during that call.
                /* handleAudioFocus = */ !inCallNow
            )
            .setWakeMode(androidx.media3.common.C.WAKE_MODE_LOCAL)
            .build().apply {
                setMediaItem(Media3Item.fromUri(uri))
                prepare()
            }
    }
    // A MediaSession lets the OS recognise this as active media and keep it
    // playing in the background (with system media controls) when enabled.
    val mediaSession = remember(player) {
        androidx.media3.session.MediaSession.Builder(ctx, player)
            .setId("v7_video_${System.currentTimeMillis()}")
            .build()
    }
    DisposableEffect(mediaSession) {
        onDispose { mediaSession.release() }
    }
    var muted by remember { mutableStateOf(false) }
    LaunchedEffect(muted) { player.volume = if (muted) 0f else 1f }

    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var showMoreMenu by remember { mutableStateOf(false) }
    var showRailMore by remember { mutableStateOf(false) }
    var showCompress by remember { mutableStateOf(false) }
    var showBookmarks by remember { mutableStateOf(false) }
    var showStickerCreator by remember { mutableStateOf(false) }
    var showStickerPacks by remember { mutableStateOf(false) }
    var compressing by remember { mutableStateOf(false) }
    // 0 = stop at end (default), 1 = auto-play next, 2 = repeat this video
    var videoRepeatMode by remember { mutableIntStateOf(0) }
    var extractingAudio by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    var showDetailsDialog by remember { mutableStateOf(false) }
    var showTrim by remember { mutableStateOf(false) }
    var trimming by remember { mutableStateOf(false) }

    // Resume from last saved position. We must wait until the player is READY
    // (the media is loaded and its duration is known) before seeking, otherwise
    // the seek is applied to a not-yet-prepared player and gets lost.
    LaunchedEffect(uri) {
        val resumeAt = progressVm.resumePosition(mediaId)
        if (resumeAt <= 0) return@LaunchedEffect
        if (player.playbackState == Player.STATE_READY && player.duration > 0) {
            player.seekTo(resumeAt)
        } else {
            val listener = object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_READY) {
                        player.seekTo(resumeAt)
                        player.removeListener(this)
                    }
                }
            }
            player.addListener(listener)
        }
    }

    // Apply subtitle without restarting playback: keep position & play state.
    LaunchedEffect(subtitleUri) {
        val sub = subtitleUri ?: return@LaunchedEffect
        val resumeAt = player.currentPosition
        val wasPlaying = player.playWhenReady
        val mime = ctx.contentResolver.getType(sub) ?: MimeTypes.APPLICATION_SUBRIP
        val subConfig = Media3Item.SubtitleConfiguration.Builder(sub)
            .setMimeType(mime)
            .setLanguage("und")
            .setSelectionFlags(androidx.media3.common.C.SELECTION_FLAG_DEFAULT)
            .build()
        val newItem = Media3Item.Builder()
            .setUri(uri)
            .setSubtitleConfigurations(listOf(subConfig))
            .build()
        player.setMediaItem(newItem, resumeAt)
        player.prepare()
        player.playWhenReady = wasPlaying
    }

    LaunchedEffect(active) { player.playWhenReady = active }

    DisposableEffect(player, lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> {
                    // Background playback is always on: keep the audio playing when
                    // the screen locks or the user leaves the app. Just persist a
                    // resume point.
                    val pos = player.currentPosition
                    val dur = player.duration.coerceAtLeast(0)
                    if (pos > 0) progressVm.save(mediaId, pos, dur, title, uri.toString())
                }
                Lifecycle.Event.ON_RESUME -> { /* playback continues uninterrupted */ }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            // Persist resume point before releasing
            val pos = player.currentPosition
            val dur = player.duration.coerceAtLeast(0)
            if (pos > 0) progressVm.save(mediaId, pos, dur, title, uri.toString())
            player.release()
        }
    }

    var showControls by remember { mutableStateOf(true) }
    var isPlaying by remember { mutableStateOf(true) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var speed by remember { mutableFloatStateOf(1f) }

    var seekIndicator by remember { mutableStateOf<Long?>(null) }

    val audioManager = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)

    LaunchedEffect(player) {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(p: Boolean) { isPlaying = p }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) {
                    when (videoRepeatMode) {
                        1 -> onAdvanceNext()          // auto-play next
                        2 -> { player.seekTo(0); player.play() }  // repeat
                        else -> {
                            // Normal end: rewind to the start and pause, so the
                            // play button immediately restarts the video instead
                            // of leaving it stuck on the last frame.
                            player.pause()
                            player.seekTo(0)
                        }
                    }
                }
            }
        })
        var sinceSave = 0
        while (true) {
            position = player.currentPosition
            duration = player.duration.coerceAtLeast(0)
            sinceSave += 1
            if (sinceSave >= 10 && player.isPlaying && position > 0) {
                sinceSave = 0
                progressVm.save(mediaId, position, duration, title, uri.toString())
            }
            delay(250)
        }
    }
    LaunchedEffect(showControls) {
        if (showControls && isPlaying) {
            delay(3500)
            showControls = false
        }
    }
    LaunchedEffect(seekIndicator) {
        if (seekIndicator != null) {
            delay(900)
            seekIndicator = null
        }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = {
                PlayerView(it).apply {
                    this.player = player
                    useController = false
                    setBackgroundColor(android.graphics.Color.BLACK)
                }
            },
            update = { it.player = player },
            modifier = Modifier
                .fillMaxSize()
                // Tap area for showing controls & double-tap seek
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { showControls = !showControls },
                        onDoubleTap = { offset ->
                            // Double-tap right half = forward 10s, left half = back 10s.
                            val w = size.width
                            val cur = player.currentPosition
                            val dur = player.duration.coerceAtLeast(0)
                            val target = if (offset.x < w / 2) cur - 10_000 else cur + 10_000
                            player.seekTo(target.coerceIn(0, if (dur > 0) dur else target))
                            seekIndicator = target.coerceAtLeast(0)
                        }
                    )
                }
                // Brightness/volume drags were removed on purpose: they conflicted
                // with swiping between videos. Now the VerticalPager receives
                // up/down swipes from anywhere on the screen — like Reels/TikTok.
        )

        // Gesture indicator overlays
        seekIndicator?.let { pos ->
            Surface(
                color = Color.Black.copy(alpha = 0.6f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Text(
                    "${Formatters.duration(pos)} / ${Formatters.duration(duration)}",
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }

        if (showControls) {
            // Top bar
            Surface(
                color = Color.Black.copy(alpha = 0.45f),
                modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Spacer(Modifier.weight(1f))
                    // Sticker icon → opens the dedicated Sticker Creator (trim +
                    // live preview + fit + real animated WebP).
                    IconButton(onClick = {
                        player.play()
                        showStickerCreator = true
                    }) {
                        Icon(Icons.Outlined.AddReaction, contentDescription = "WhatsApp Sticker", tint = Color.White)
                    }
                    // Sticker packs manager → view packs and add them to WhatsApp.
                    IconButton(onClick = { showStickerPacks = true }) {
                        Icon(Icons.Rounded.Collections, contentDescription = "Sticker packs", tint = Color.White)
                    }
                    // More menu (3 dots) — extract audio, info
                    Box {
                        IconButton(
                            enabled = !extractingAudio,
                            onClick = { showMoreMenu = true }
                        ) {
                            if (extractingAudio) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(22.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(Icons.Rounded.MoreVert, contentDescription = "More", tint = Color.White)
                            }
                        }
                        DropdownMenu(
                            expanded = showMoreMenu,
                            onDismissRequest = { showMoreMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Extract audio (MP3)") },
                                leadingIcon = { Icon(Icons.Rounded.MusicNote, contentDescription = null) },
                                onClick = {
                                    showMoreMenu = false
                                    extractingAudio = true
                                    scope.launch {
                                        val ok = com.shabaan.v7.util.AudioExtractor.extractToMusic(
                                            ctx, uri, title
                                        )
                                        extractingAudio = false
                                        android.widget.Toast.makeText(
                                            ctx,
                                            if (ok) "Audio saved to Music/V7 Audio" else "Couldn't extract audio",
                                            android.widget.Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("Trim video") },
                                leadingIcon = { Icon(Icons.Rounded.ContentCut, contentDescription = null) },
                                onClick = { showMoreMenu = false; showTrim = true }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("Info") },
                                leadingIcon = { Icon(Icons.Rounded.Info, contentDescription = null) },
                                onClick = { showMoreMenu = false; showDetailsDialog = true }
                            )
                        }
                    }
                }
            }

            // Center play/pause
            FilledIconButton(
                onClick = {
                    // If the video has finished, start it over from the beginning.
                    // Otherwise just toggle play/pause.
                    if (player.playbackState == Player.STATE_ENDED) {
                        player.seekTo(0)
                        player.play()
                    } else {
                        player.playWhenReady = !player.isPlaying
                    }
                },
                modifier = Modifier.align(Alignment.Center).size(72.dp),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = Color.Black.copy(alpha = 0.45f),
                    contentColor = Color.White
                )
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(40.dp)
                )
            }

            // TikTok-style vertical action rail on the right
            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 12.dp, bottom = 96.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                RailAction(
                    icon = if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    label = "Favorite",
                    tint = if (isFavorite) MaterialTheme.colorScheme.primary else Color.White,
                    active = isFavorite,
                    onClick = onToggleFavorite
                )
                RailAction(
                    icon = Icons.Rounded.Share,
                    label = "Share",
                    onClick = onShare
                )
                RailAction(
                    icon = Icons.Rounded.MoreVert,
                    label = "More",
                    onClick = { showRailMore = true }
                )
                DropdownMenu(
                    expanded = showRailMore,
                    onDismissRequest = { showRailMore = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Picture-in-picture") },
                        leadingIcon = { Icon(Icons.Outlined.PictureInPicture, null) },
                        onClick = { showRailMore = false; onTogglePiP() }
                    )
                    DropdownMenuItem(
                        text = {
                            Text(
                                when (videoRepeatMode) {
                                    1 -> "Repeat: Auto-play next"
                                    2 -> "Repeat: This video"
                                    else -> "Repeat: Off"
                                }
                            )
                        },
                        leadingIcon = {
                            Icon(
                                when (videoRepeatMode) {
                                    1 -> Icons.Rounded.SkipNext
                                    2 -> Icons.Rounded.RepeatOne
                                    else -> Icons.Rounded.Repeat
                                },
                                null
                            )
                        },
                        onClick = {
                            videoRepeatMode = (videoRepeatMode + 1) % 3
                            val msg = when (videoRepeatMode) {
                                1 -> "Auto-play next"
                                2 -> "Repeat this video"
                                else -> "Stop at end"
                            }
                            android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_SHORT).show()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Compress video") },
                        leadingIcon = { Icon(Icons.Rounded.Compress, null) },
                        onClick = { showRailMore = false; showCompress = true }
                    )
                    DropdownMenuItem(
                        text = { Text("Capture frame") },
                        leadingIcon = { Icon(Icons.Rounded.PhotoCamera, null) },
                        onClick = {
                            showRailMore = false
                            val pos = player.currentPosition
                            scope.launch {
                                val base = title.substringBeforeLast('.')
                                val ok = com.shabaan.v7.util.FrameExtractor.captureFrame(
                                    ctx, uri, pos, "${base}_frame_${pos}.jpg"
                                )
                                android.widget.Toast.makeText(
                                    ctx,
                                    if (ok) "Frame saved to Pictures/V7 Frames"
                                    else "Couldn't capture frame",
                                    android.widget.Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Bookmark this moment") },
                        leadingIcon = { Icon(Icons.Rounded.BookmarkAdd, null) },
                        onClick = {
                            showRailMore = false
                            com.shabaan.v7.util.VideoBookmarks.add(ctx, mediaId, player.currentPosition, "")
                            android.widget.Toast.makeText(
                                ctx, "Bookmark added", android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Bookmarks") },
                        leadingIcon = { Icon(Icons.Rounded.Bookmarks, null) },
                        onClick = { showRailMore = false; showBookmarks = true }
                    )
                }
            }

            // Bottom controls
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(
                        androidx.compose.ui.graphics.Brush.verticalGradient(
                            listOf(Color.Transparent, Color.Black.copy(alpha = 0.65f))
                        )
                    )
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                // Title + folder + resolution — hidden by default for an immersive
                // view; toggled by the Info button with a subtle 140ms fade/slide.
                androidx.compose.animation.AnimatedVisibility(
                    visible = showInfo,
                    enter = androidx.compose.animation.fadeIn(
                        androidx.compose.animation.core.tween(140)
                    ) + androidx.compose.animation.expandVertically(
                        androidx.compose.animation.core.tween(140)
                    ),
                    exit = androidx.compose.animation.fadeOut(
                        androidx.compose.animation.core.tween(140)
                    ) + androidx.compose.animation.shrinkVertically(
                        androidx.compose.animation.core.tween(140)
                    )
                ) {
                    Column {
                        Text(
                            title.substringBeforeLast('.'),
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )
                        folder?.let { f ->
                            Text(
                                f.trim('/').substringAfterLast('/').ifEmpty { f.trim('/') },
                                color = Color.White.copy(alpha = 0.7f),
                                style = MaterialTheme.typography.labelMedium,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                        run {
                            val vw = player.videoSize.width
                            val vh = player.videoSize.height
                            val resLabel = when {
                                vh >= 2160 || vw >= 2160 -> "4K"
                                vh >= 1080 || vw >= 1080 -> "1080p"
                                vh >= 720 || vw >= 720 -> "720p"
                                vh > 0 -> "${minOf(vw, vh)}p"
                                else -> null
                            }
                            val meta = buildString {
                                if (resLabel != null) append(resLabel)
                                if (duration > 0) {
                                    if (isNotEmpty()) append("  •  ")
                                    append(Formatters.duration(duration))
                                }
                            }
                            if (meta.isNotEmpty()) {
                                Text(
                                    meta,
                                    color = Color.White.copy(alpha = 0.6f),
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "${Formatters.duration(position)} / ${Formatters.duration(duration)}",
                        color = Color.White,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.width(8.dp))
                    Slider(
                        value = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f,
                        onValueChange = { player.seekTo((it * duration).toLong()) },
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                            inactiveTrackColor = Color.White.copy(alpha = 0.25f)
                        ),
                        thumb = {
                            // Small round silver thumb (instead of the bulky default).
                            Box(
                                Modifier
                                    .size(14.dp)
                                    .clip(androidx.compose.foundation.shape.CircleShape)
                                    .background(MaterialTheme.colorScheme.primary)
                            )
                        },
                        track = { st ->
                            SliderDefaults.Track(
                                sliderState = st,
                                modifier = Modifier.height(3.dp),
                                colors = SliderDefaults.colors(
                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                    inactiveTrackColor = Color.White.copy(alpha = 0.25f)
                                )
                            )
                        }
                    )
                    Spacer(Modifier.width(8.dp))
                    // Mute toggle — moved here next to the seek bar.
                    IconButton(
                        onClick = { muted = !muted },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            if (muted) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp,
                            contentDescription = if (muted) "Unmute" else "Mute",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(top = 6.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    listOf(0.5f, 1f, 1.25f, 1.5f, 2f).forEach { s ->
                        TextButton(onClick = {
                            speed = s
                            player.setPlaybackSpeed(s)
                        }) {
                            Text(
                                "${s}x",
                                color = if (s == speed) Color.White else Color.White.copy(alpha = 0.55f),
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }
        }

        if (showDetailsDialog) {
            AlertDialog(
                onDismissRequest = { showDetailsDialog = false },
                title = { Text("Details") },
                text = {
                    Column {
                        Text(title, style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Duration: " + Formatters.duration(duration),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showDetailsDialog = false }) { Text("Close") }
                }
            )
        }

        if (showTrim) {
            val totalMs = duration.coerceAtLeast(1000L)
            var startMs by remember { mutableFloatStateOf(0f) }
            var endMs by remember { mutableFloatStateOf(totalMs.toFloat()) }
            val trimSheetState = androidx.compose.material3.rememberModalBottomSheetState()
            // A bottom sheet keeps the video fully visible above it, so the live
            // frame preview is unobstructed while trimming (CapCut-style).
            androidx.compose.material3.ModalBottomSheet(
                onDismissRequest = { if (!trimming) showTrim = false },
                sheetState = trimSheetState,
                containerColor = MaterialTheme.colorScheme.surface,
                scrimColor = Color.Transparent
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .padding(bottom = 24.dp)
                ) {
                    Text(
                        "Trim video",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(16.dp))
                    com.shabaan.v7.ui.components.WaveformTrimmer(
                        uri = uri,
                        durationMs = totalMs,
                        startMs = startMs,
                        endMs = endMs,
                        onChange = { s, e -> startMs = s; endMs = e },
                        seed = mediaId,
                        // Live frame preview: seek the real player as handles move.
                        audioPreview = false,
                        onScrub = { ms ->
                            player.seekTo(ms.toLong())
                            if (!player.isPlaying) player.play()
                        }
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth()) {
                        Text(
                            "From " + Formatters.duration(startMs.toLong()),
                            style = MaterialTheme.typography.labelMedium
                        )
                        Spacer(Modifier.weight(1f))
                        Text(
                            "To " + Formatters.duration(endMs.toLong()),
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Clip length: " + Formatters.duration((endMs - startMs).toLong()),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.height(20.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(
                            enabled = !trimming,
                            onClick = { showTrim = false }
                        ) { Text("Cancel") }
                        Spacer(Modifier.width(8.dp))
                        androidx.compose.material3.Button(
                            enabled = !trimming,
                            onClick = {
                                trimming = true
                                scope.launch {
                                    val ok = com.shabaan.v7.util.VideoTrimmer.trim(
                                        ctx, uri, startMs.toLong(), endMs.toLong(), title
                                    )
                                    trimming = false
                                    showTrim = false
                                    android.widget.Toast.makeText(
                                        ctx,
                                        if (ok) "Saved to Movies/V7 Trimmed" else "Couldn't trim video",
                                        android.widget.Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        ) { Text(if (trimming) "Saving…" else "Save clip") }
                    }
                }
            }
        }

        if (showCompress) {
            AlertDialog(
                onDismissRequest = { if (!compressing) showCompress = false },
                title = { Text("Compress video") },
                text = {
                    Column {
                        if (compressing) {
                            Text(
                                "Compressing… this can take a little while.",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Spacer(Modifier.height(12.dp))
                            androidx.compose.material3.LinearProgressIndicator(
                                modifier = Modifier.fillMaxWidth()
                            )
                        } else {
                            Text(
                                "Choose a quality. The compressed copy is saved to Movies/V7 Compressed.",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Spacer(Modifier.height(12.dp))
                            com.shabaan.v7.util.VideoCompressor.Quality.values().forEach { q ->
                                TextButton(
                                    onClick = {
                                        compressing = true
                                        scope.launch {
                                            val base = title.substringBeforeLast('.')
                                            val ok = com.shabaan.v7.util.VideoCompressor.compress(
                                                ctx, uri, q, "${base}_compressed.mp4"
                                            )
                                            compressing = false
                                            showCompress = false
                                            android.widget.Toast.makeText(
                                                ctx,
                                                if (ok) "Saved to Movies/V7 Compressed"
                                                else "Couldn't compress video",
                                                android.widget.Toast.LENGTH_LONG
                                            ).show()
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(q.label, modifier = Modifier.fillMaxWidth())
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    if (!compressing) {
                        TextButton(onClick = { showCompress = false }) { Text("Cancel") }
                    }
                }
            )
        }
        if (showBookmarks) {
            var bookmarks by remember {
                mutableStateOf(com.shabaan.v7.util.VideoBookmarks.get(ctx, mediaId))
            }
            AlertDialog(
                onDismissRequest = { showBookmarks = false },
                title = { Text("Bookmarks") },
                text = {
                    if (bookmarks.isEmpty()) {
                        Text(
                            "No bookmarks yet. Use \"Bookmark this moment\" while watching.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    } else {
                        Column {
                            bookmarks.forEach { bm ->
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            player.seekTo(bm.positionMs)
                                            showBookmarks = false
                                        }
                                        .padding(vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Rounded.PlayArrow,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Text(
                                        bm.label,
                                        style = MaterialTheme.typography.bodyMedium,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(onClick = {
                                        com.shabaan.v7.util.VideoBookmarks.remove(ctx, mediaId, bm.positionMs)
                                        bookmarks = com.shabaan.v7.util.VideoBookmarks.get(ctx, mediaId)
                                    }) {
                                        Icon(Icons.Rounded.Close, contentDescription = "Remove")
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showBookmarks = false }) { Text("Close") }
                }
            )
        }
        if (showStickerCreator) {
            StickerCreatorSheet(
                uri = uri,
                mediaId = mediaId,
                durationMs = duration.coerceAtLeast(1000L),
                onScrub = { ms ->
                    player.seekTo(ms)
                    if (!player.isPlaying) player.play()
                },
                onDismiss = { showStickerCreator = false }
            )
        }
        if (showStickerPacks) {
            StickerPacksSheet(onDismiss = { showStickerPacks = false })
        }
    }
}

@Composable
private fun IndicatorOverlay(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    progress: Float,
    label: String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color.Black.copy(alpha = 0.6f),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp)
        ) {
            Icon(icon, contentDescription = null, tint = Color.White)
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier
                    .width(4.dp)
                    .height(80.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.25f))
            ) {
                Box(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .width(4.dp)
                        .fillMaxHeight(progress)
                        .background(Color.White)
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(label, color = Color.White, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun RailAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color = Color.White,
    active: Boolean = false,
    onClick: () -> Unit
) {
    // Gentle pop when the action becomes active (e.g. favorited), so the state
    // change is felt, not just seen.
    val scale by animateFloatAsState(
        targetValue = if (active) 1.12f else 1f,
        animationSpec = androidx.compose.animation.core.spring(
            dampingRatio = androidx.compose.animation.core.Spring.DampingRatioMediumBouncy,
            stiffness = androidx.compose.animation.core.Spring.StiffnessMedium
        ),
        label = "railActionScale"
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        FilledIconButton(
            onClick = onClick,
            modifier = Modifier
                .size(52.dp)
                .border(
                    1.dp,
                    Color.White.copy(alpha = 0.18f),
                    androidx.compose.foundation.shape.CircleShape
                ),
            colors = IconButtonDefaults.filledIconButtonColors(
                containerColor = Color.Black.copy(alpha = 0.32f),
                contentColor = tint
            )
        ) {
            Icon(
                icon,
                contentDescription = label,
                modifier = Modifier
                    .size(27.dp)
                    .graphicsLayer { scaleX = scale; scaleY = scale }
            )
        }
        Spacer(Modifier.height(5.dp))
        Text(
            label,
            color = Color.White.copy(alpha = 0.85f),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Medium
        )
    }
}

package com.shabaan.v7.sticker

import android.content.ContentProvider
import android.content.ContentResolver
import android.content.ContentValues
import android.content.UriMatcher
import android.content.res.AssetFileDescriptor
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.shabaan.v7.util.StickerPackStore
import java.io.File

/**
 * ContentProvider that exposes V7's sticker packs to WhatsApp.
 *
 * This is a faithful port of WhatsApp's official sample StickerContentProvider,
 * with ONE deliberate change: the official sample serves sticker files from the
 * app's `assets/` (fixed at build time). V7 generates stickers dynamically (from
 * the user's videos), so files live in `filesDir/stickers/<packId>/...` instead.
 * Therefore `openAssetFile` opens real files via ParcelFileDescriptor rather than
 * AssetManager. Everything WhatsApp reads (column names, URI shapes, MIME types)
 * is kept byte-for-byte identical to the official contract.
 *
 * The authority MUST start with the package name; we use "<package>.stickercontentprovider".
 *
 * NOTE: the column-name strings below are dictated by WhatsApp and must NOT change.
 */
class StickerContentProvider : ContentProvider() {

    companion object {
        // ---- WhatsApp query column names (DO NOT CHANGE) ----
        private const val STICKER_PACK_IDENTIFIER_IN_QUERY = "sticker_pack_identifier"
        private const val STICKER_PACK_NAME_IN_QUERY = "sticker_pack_name"
        private const val STICKER_PACK_PUBLISHER_IN_QUERY = "sticker_pack_publisher"
        private const val STICKER_PACK_ICON_IN_QUERY = "sticker_pack_icon"
        private const val ANDROID_APP_DOWNLOAD_LINK_IN_QUERY = "android_play_store_link"
        private const val IOS_APP_DOWNLOAD_LINK_IN_QUERY = "ios_app_download_link"
        private const val PUBLISHER_EMAIL = "sticker_pack_publisher_email"
        private const val PUBLISHER_WEBSITE = "sticker_pack_publisher_website"
        private const val PRIVACY_POLICY_WEBSITE = "sticker_pack_privacy_policy_website"
        private const val LICENSE_AGREEMENT_WEBSITE = "sticker_pack_license_agreement_website"
        private const val IMAGE_DATA_VERSION = "image_data_version"
        private const val AVOID_CACHE = "whatsapp_will_not_cache_stickers"
        private const val ANIMATED_STICKER_PACK = "animated_sticker_pack"
        private const val STICKER_FILE_NAME_IN_QUERY = "sticker_file_name"
        private const val STICKER_FILE_EMOJI_IN_QUERY = "sticker_emoji"
        private const val STICKER_FILE_ACCESSIBILITY_TEXT_IN_QUERY = "sticker_accessibility_text"

        // ---- URI matcher codes (DO NOT CHANGE values) ----
        private const val METADATA = "metadata"
        private const val METADATA_CODE = 1
        private const val METADATA_CODE_FOR_SINGLE_PACK = 2
        private const val STICKERS = "stickers"
        private const val STICKERS_CODE = 3
        private const val STICKERS_ASSET = "stickers_asset"
        private const val STICKERS_ASSET_CODE = 4

        /** Authority is derived from the package name at runtime. */
        fun authority(packageName: String) = "$packageName.stickercontentprovider"
    }

    private val matcher = UriMatcher(UriMatcher.NO_MATCH)
    private lateinit var auth: String

    override fun onCreate(): Boolean {
        val ctx = context ?: return false
        auth = authority(ctx.packageName)
        matcher.addURI(auth, METADATA, METADATA_CODE)
        matcher.addURI(auth, "$METADATA/*", METADATA_CODE_FOR_SINGLE_PACK)
        matcher.addURI(auth, "$STICKERS/*", STICKERS_CODE)
        // Use a single wildcard pattern for asset files instead of registering
        // each sticker at startup. Stickers are created AFTER the app launches,
        // so pre-registering specific file paths would miss them and WhatsApp
        // would fail to fetch the images. The actual file is validated against
        // the store inside openAssetFile/getType.
        matcher.addURI(auth, "$STICKERS_ASSET/*/*", STICKERS_ASSET_CODE)
        return true
    }

    /** Distinguishes a tray-icon request from a sticker request by file name. */
    private fun isTrayRequest(uri: Uri): Boolean {
        val ctx = context ?: return false
        val segments = uri.pathSegments
        if (segments.size != 3) return false
        val identifier = segments[segments.size - 2]
        val fileName = segments.last()
        val pack = StickerPackStore.getAll(ctx).firstOrNull { it.identifier == identifier }
            ?: return false
        return fileName == pack.trayImageFile
    }

    override fun query(
        uri: Uri, projection: Array<out String>?, selection: String?,
        selectionArgs: Array<out String>?, sortOrder: String?
    ): Cursor {
        return when (matcher.match(uri)) {
            METADATA_CODE -> allPacksCursor(uri)
            METADATA_CODE_FOR_SINGLE_PACK -> singlePackCursor(uri)
            STICKERS_CODE -> stickersCursor(uri)
            else -> throw IllegalArgumentException("Unknown URI: $uri")
        }
    }

    override fun openAssetFile(uri: Uri, mode: String): AssetFileDescriptor? {
        val code = matcher.match(uri)
        if (code != STICKERS_ASSET_CODE) return null
        val ctx = context ?: return null
        val segments = uri.pathSegments
        if (segments.size != 3) throw IllegalArgumentException("path segments should be 3: $uri")
        val fileName = segments.last()
        val identifier = segments[segments.size - 2]
        if (identifier.isEmpty() || fileName.isEmpty()) return null

        // Verify the requested file actually belongs to a known pack.
        val pack = StickerPackStore.getAll(ctx).firstOrNull { it.identifier == identifier }
            ?: return null
        val belongs = fileName == pack.trayImageFile || pack.stickers.any { it.fileName == fileName }
        if (!belongs) return null

        val file = File(StickerPackStore.packDir(ctx, identifier), fileName)
        if (!file.exists()) return null
        val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        return AssetFileDescriptor(pfd, 0, AssetFileDescriptor.UNKNOWN_LENGTH)
    }

    override fun getType(uri: Uri): String {
        return when (matcher.match(uri)) {
            METADATA_CODE -> "vnd.android.cursor.dir/vnd.$auth.$METADATA"
            METADATA_CODE_FOR_SINGLE_PACK -> "vnd.android.cursor.item/vnd.$auth.$METADATA"
            STICKERS_CODE -> "vnd.android.cursor.dir/vnd.$auth.$STICKERS"
            STICKERS_ASSET_CODE -> if (isTrayRequest(uri)) "image/png" else "image/webp"
            else -> throw IllegalArgumentException("Unknown URI: $uri")
        }
    }

    private fun allPacksCursor(uri: Uri): Cursor {
        val ctx = context!!
        return packInfoCursor(uri, StickerPackStore.getAll(ctx))
    }

    private fun singlePackCursor(uri: Uri): Cursor {
        val ctx = context!!
        val id = uri.lastPathSegment
        val packs = StickerPackStore.getAll(ctx).filter { it.identifier == id }
        return packInfoCursor(uri, packs)
    }

    private fun packInfoCursor(
        uri: Uri,
        packs: List<StickerPackStore.StickerPack>
    ): Cursor {
        val cursor = MatrixCursor(
            arrayOf(
                STICKER_PACK_IDENTIFIER_IN_QUERY,
                STICKER_PACK_NAME_IN_QUERY,
                STICKER_PACK_PUBLISHER_IN_QUERY,
                STICKER_PACK_ICON_IN_QUERY,
                ANDROID_APP_DOWNLOAD_LINK_IN_QUERY,
                IOS_APP_DOWNLOAD_LINK_IN_QUERY,
                PUBLISHER_EMAIL,
                PUBLISHER_WEBSITE,
                PRIVACY_POLICY_WEBSITE,
                LICENSE_AGREEMENT_WEBSITE,
                IMAGE_DATA_VERSION,
                AVOID_CACHE,
                ANIMATED_STICKER_PACK
            )
        )
        packs.forEach { pack ->
            cursor.newRow()
                .add(pack.identifier)
                .add(pack.name)
                .add(pack.publisher)
                .add(pack.trayImageFile)
                .add("")          // android play store link
                .add("")          // ios app store link
                .add("")          // publisher email
                .add("")          // publisher website
                .add("")          // privacy policy website
                .add("")          // license agreement website
                .add("1")         // image data version
                .add(0)           // avoid cache
                .add(if (pack.animated) 1 else 0)
        }
        cursor.setNotificationUri(context!!.contentResolver, uri)
        return cursor
    }

    private fun stickersCursor(uri: Uri): Cursor {
        val ctx = context!!
        val id = uri.lastPathSegment
        val cursor = MatrixCursor(
            arrayOf(
                STICKER_FILE_NAME_IN_QUERY,
                STICKER_FILE_EMOJI_IN_QUERY,
                STICKER_FILE_ACCESSIBILITY_TEXT_IN_QUERY
            )
        )
        StickerPackStore.getAll(ctx).firstOrNull { it.identifier == id }?.let { pack ->
            pack.stickers.forEach { sticker ->
                cursor.addRow(
                    arrayOf<Any>(
                        sticker.fileName,
                        sticker.emojis.joinToString(","),
                        ""   // accessibility text
                    )
                )
            }
        }
        cursor.setNotificationUri(ctx.contentResolver, uri)
        return cursor
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? =
        throw UnsupportedOperationException("Not supported")

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int =
        throw UnsupportedOperationException("Not supported")

    override fun update(
        uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?
    ): Int = throw UnsupportedOperationException("Not supported")
}

package com.shabaan.v7.ui.music

import android.app.Application
import android.content.ComponentName
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem as Media3Item
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.core.content.ContextCompat
import com.shabaan.v7.data.model.MediaItem
import com.shabaan.v7.data.model.MediaType
import com.shabaan.v7.data.repository.FavoritesRepository
import com.shabaan.v7.data.repository.MediaRepository
import com.shabaan.v7.service.MusicService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class MusicUi(
    val loading: Boolean = false,
    val tracks: List<MediaItem> = emptyList(),
    val favorites: Set<Long> = emptySet(),
    val showFavoritesOnly: Boolean = false,
    val currentIndex: Int = -1,
    val isPlaying: Boolean = false,
    val position: Long = 0L,
    val duration: Long = 0L,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val expanded: Boolean = false,
    val recentlyPlayed: List<MediaItem> = emptyList(),
    val selectionMode: Boolean = false,
    val selection: Set<Long> = emptySet(),
    /** Live search query for the music list (title / artist / album / filename). */
    val query: String = ""
) {
    /**
     * Tracks to show = all (or favorites only), then narrowed by the search
     * query. Search runs through [com.shabaan.v7.util.SmartSearch] so it gets
     * Arabic normalization, partial matching, case-insensitivity and ranking —
     * matching by name (filename/title), artist and album exactly as required.
     */
    val visibleTracks: List<MediaItem>
        get() {
            val base = if (showFavoritesOnly) tracks.filter { it.id in favorites } else tracks
            val q = query.trim()
            return if (q.isEmpty()) base
            else com.shabaan.v7.util.SmartSearch.search(base, q)
        }
}

@HiltViewModel
class MusicViewModel @Inject constructor(
    app: Application,
    private val repo: MediaRepository,
    private val favRepo: FavoritesRepository,
    private val progressDao: com.shabaan.v7.data.local.ProgressDao
) : AndroidViewModel(app) {

    private var controller: MediaController? = null

    private val _state = MutableStateFlow(MusicUi())
    val state: StateFlow<MusicUi> = _state.asStateFlow()

    private var hasLoaded = false

    init {
        connectController()
        viewModelScope.launch {
            favRepo.observeByType(MediaType.AUDIO).collect { favs ->
                _state.update { it.copy(favorites = favs.map { f -> f.mediaId }.toSet()) }
            }
        }
        viewModelScope.launch {
            progressDao.recent().collect { recent ->
                val byId = _state.value.tracks.associateBy { it.id }
                val mapped = recent.mapNotNull { byId[it.mediaId] }.take(15)
                _state.update { it.copy(recentlyPlayed = mapped) }
            }
        }
    }

    fun ensureLoaded() {
        if (hasLoaded) return
        hasLoaded = true
        load()
    }

    private fun connectController() {
        val token = SessionToken(getApplication(), ComponentName(getApplication(), MusicService::class.java))
        val future = MediaController.Builder(getApplication(), token).buildAsync()
        future.addListener({
            val c = runCatching { future.get() }.getOrNull() ?: return@addListener
            controller = c
            c.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    _state.update { it.copy(isPlaying = isPlaying) }
                }
                override fun onMediaItemTransition(item: Media3Item?, reason: Int) {
                    _state.update { it.copy(currentIndex = c.currentMediaItemIndex) }
                    // Record recently played
                    val idx = c.currentMediaItemIndex
                    val track = _state.value.tracks.getOrNull(idx)
                    if (track != null) {
                        viewModelScope.launch {
                            runCatching {
                                progressDao.upsert(
                                    com.shabaan.v7.data.local.PlaybackProgressEntity(
                                        mediaId = track.id,
                                        positionMs = 0L,
                                        durationMs = track.duration,
                                        title = track.name,
                                        uri = track.uri.toString(),
                                        updatedAt = System.currentTimeMillis()
                                    )
                                )
                            }
                        }
                    }
                }
                override fun onPlaybackStateChanged(playbackState: Int) {
                    _state.update { it.copy(duration = c.duration.coerceAtLeast(0)) }
                }
                override fun onRepeatModeChanged(repeatMode: Int) {
                    _state.update { it.copy(repeatMode = repeatMode) }
                }
                override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                    _state.update { it.copy(shuffle = shuffleModeEnabled) }
                }
            })

            // Position poller
            viewModelScope.launch {
                while (true) {
                    _state.update {
                        it.copy(
                            position = c.currentPosition.coerceAtLeast(0),
                            duration = c.duration.coerceAtLeast(0),
                            currentIndex = c.currentMediaItemIndex,
                            isPlaying = c.isPlaying
                        )
                    }
                    kotlinx.coroutines.delay(500)
                }
            }
        }, ContextCompat.getMainExecutor(getApplication()))
    }

    fun load() {
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            val tracks = repo.loadAudio()
            _state.update { it.copy(loading = false, tracks = tracks) }
            runCatching {
                val recent = progressDao.recent().firstOrNull().orEmpty()
                val byId = tracks.associateBy { it.id }
                val mapped = recent.mapNotNull { byId[it.mediaId] }.take(15)
                _state.update { it.copy(recentlyPlayed = mapped) }
            }
        }
    }

    fun play(index: Int) {
        val c = controller ?: return
        val tracks = _state.value.tracks
        if (tracks.isEmpty()) return
        val safeIndex = index.coerceIn(0, tracks.lastIndex)
        c.setMediaItems(tracks.map { it.toMedia3() }, safeIndex, 0)
        c.prepare()
        c.play()
        _state.update { it.copy(expanded = false) }
    }

    fun togglePlayPause() {
        val c = controller ?: return
        // If nothing is loaded yet (fresh launch, user taps play before picking
        // a track), start the list from the current/first item instead of
        // toggling an empty player (which would do nothing).
        if (c.mediaItemCount == 0) {
            val tracks = _state.value.tracks
            if (tracks.isEmpty()) return
            val start = _state.value.currentIndex.coerceIn(0, tracks.lastIndex)
            play(start)
            return
        }
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPreviousMediaItem() }
    fun seekTo(ms: Long) { controller?.seekTo(ms) }
    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }
    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }
    fun expand() { _state.update { it.copy(expanded = true) } }
    fun collapse() { _state.update { it.copy(expanded = false) } }

    /** Clears the Recently Played history. */
    fun clearRecentlyPlayed() {
        viewModelScope.launch {
            progressDao.clearAll()
        }
    }
    fun toggleFavorite(id: Long) {
        viewModelScope.launch {
            if (id in _state.value.favorites) favRepo.remove(id, MediaType.AUDIO)
            else favRepo.add(id, MediaType.AUDIO)
        }
    }

    /** Toggle the "favorites only" filter for the music list. */
    fun toggleFavoritesOnly() {
        _state.update { it.copy(showFavoritesOnly = !it.showFavoritesOnly) }
    }

    /** Update the live search query for the music list. */
    fun setQuery(q: String) {
        _state.update { it.copy(query = q) }
    }

    // ---- Multi-select ----
    fun startSelection(id: Long) {
        _state.update { it.copy(selectionMode = true, selection = setOf(id)) }
    }
    fun toggleSelection(id: Long) {
        _state.update {
            val s = it.selection.toMutableSet()
            if (!s.add(id)) s.remove(id)
            it.copy(selection = s, selectionMode = s.isNotEmpty())
        }
    }
    fun selectAll() {
        _state.update { it.copy(selection = it.tracks.map { t -> t.id }.toSet(), selectionMode = true) }
    }
    fun clearSelection() {
        _state.update { it.copy(selectionMode = false, selection = emptySet()) }
    }
    fun selectedTracks(): List<MediaItem> =
        _state.value.tracks.filter { it.id in _state.value.selection }

    override fun onCleared() {
        controller?.release()
        super.onCleared()
    }
}

private fun MediaItem.toMedia3(): Media3Item =
    Media3Item.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(name)
                .setArtist(artist ?: "")
                .setAlbumTitle(album ?: "")
                .build()
        )
        .build()

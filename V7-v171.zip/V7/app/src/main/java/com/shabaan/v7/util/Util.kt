package com.shabaan.v7.util

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.security.MessageDigest

/** Legacy preference accessors retained for migration. Prefer [SettingsStore]. */
object Prefs {
    private const val NAME = "v7_prefs"
    const val KEY_APP_LOCK = "app_lock_enabled"
    const val KEY_BIOMETRIC = "biometric_enabled"
    fun get(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
}

/**
 * Global vault lock state holder.
 *
 * Vault is locked when [requiresUnlock] is true. The flag is automatically raised
 * by the foreground activity on background events, and also by the auto-lock
 * timer driven by [SettingsStore.autoLockSeconds].
 */
object LockManager {
    @Volatile var requiresUnlock: Boolean = false
        private set

    @Volatile private var lastBackgroundedAt: Long = 0L

    fun onAppStart() { requiresUnlock = true }

    fun onAppForeground(store: SettingsStore) {
        if (!store.appLockEnabled) {
            requiresUnlock = false
            return
        }
        val secs = store.autoLockSeconds
        if (secs <= 0) {
            requiresUnlock = true
            return
        }
        if (lastBackgroundedAt == 0L) {
            requiresUnlock = true
            return
        }
        val elapsed = (System.currentTimeMillis() - lastBackgroundedAt) / 1000
        if (elapsed >= secs) requiresUnlock = true
    }

    fun onAppBackground() {
        lastBackgroundedAt = System.currentTimeMillis()
    }

    fun markUnlocked() { requiresUnlock = false }

    fun canUseBiometric(ctx: Context): Boolean {
        val mgr = BiometricManager.from(ctx)
        return mgr.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_WEAK or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
        ) == BiometricManager.BIOMETRIC_SUCCESS
    }

    fun authenticate(
        activity: Activity,
        title: String,
        subtitle: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit = {}
    ) {
        val fragmentActivity = activity as? FragmentActivity ?: run {
            onError("Activity must be FragmentActivity"); return
        }
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            fragmentActivity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    markUnlocked()
                    onSuccess()
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    onError(errString.toString())
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_WEAK or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()
        prompt.authenticate(info)
    }
}

/** PIN helpers — stored as SHA-256 hex so the clear PIN is never on disk. */
object PinManager {

    fun hash(pin: String): String {
        val bytes = MessageDigest.getInstance("SHA-256")
            .digest(("v7-salt::" + pin).toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun matches(pin: String, storedHash: String?): Boolean {
        if (storedHash.isNullOrEmpty()) return false
        return hash(pin) == storedHash
    }
}

object Formatters {
    fun duration(ms: Long): String {
        if (ms <= 0) return "0:00"
        val totalSec = ms / 1000
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s)
        else "%d:%02d".format(m, s)
    }

    fun fileSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        var v = bytes.toDouble()
        var i = 0
        while (v >= 1024 && i < units.size - 1) { v /= 1024; i++ }
        return "%.1f %s".format(v, units[i])
    }

    fun relativeTime(ms: Long): String {
        val now = System.currentTimeMillis()
        val diff = (now - ms).coerceAtLeast(0)
        val s = diff / 1000
        return when {
            s < 60 -> "just now"
            s < 3600 -> "${s / 60}m ago"
            s < 86_400 -> "${s / 3600}h ago"
            s < 604_800 -> "${s / 86_400}d ago"
            else -> "${s / 604_800}w ago"
        }
    }
}

/**
 * Centralized, defensive cleaning of media display names.
 *
 * MediaStore values are messy in the real world: titles can be storage paths,
 * the literal string "<unknown>", or filenames stuffed with technical prefixes
 * and underscores. This object is the single place that turns any of those into
 * something presentable, so no screen ever shows a raw path or "<unknown>".
 */
object MediaNames {

    /** True if a MediaStore value is effectively missing/unknown. */
    private fun isBlankOrUnknown(s: String?): Boolean {
        val t = s?.trim()?.lowercase() ?: return true
        return t.isEmpty() || t == "<unknown>" || t == "unknown" || t == "null"
    }

    /**
     * Cleans a title/name for display. Strips storage paths, technical prefixes,
     * file extensions and excessive separators. Falls back to [fallback] if the
     * result is empty.
     */
    fun cleanTitle(raw: String?, fallback: String = "Unknown"): String {
        if (isBlankOrUnknown(raw)) return fallback
        var s = raw!!.trim()

        // If it looks like a path, keep only the last path segment.
        if (s.contains('/') || s.contains('\\')) {
            s = s.substringAfterLast('/').substringAfterLast('\\')
        }

        // Drop a trailing file extension (e.g. .mp3, .mp4, .opus).
        val dot = s.lastIndexOf('.')
        if (dot > 0 && s.length - dot in 2..5) s = s.substring(0, dot)

        // Remove common technical prefixes that storage/recorders add.
        val prefixes = listOf(
            "AUD-", "VID-", "IMG-", "PXL_", "VID_", "IMG_", "AUD_",
            "InShot_", "Screenrecorder-", "Screenrecording_", "download_",
            "WhatsApp Audio ", "WhatsApp Video ", "WhatsApp Image "
        )
        for (p in prefixes) {
            if (s.startsWith(p, ignoreCase = true)) {
                s = s.substring(p.length); break
            }
        }

        // Replace underscores/dots used as spaces, collapse whitespace.
        s = s.replace('_', ' ').replace(Regex("(?<=\\w)\\.(?=\\w)"), " ")
        s = s.replace(Regex("\\s+"), " ").trim()
        // Trim leftover separators at the ends.
        s = s.trim(' ', '-', '·', '•')

        return if (s.isBlank()) fallback else s
    }

    /** Artist for display, or "Unknown Artist" when missing/unknown. */
    fun artist(raw: String?): String =
        if (isBlankOrUnknown(raw)) "Unknown Artist" else raw!!.trim()

    /** Album for display, or "Unknown Album" when missing/unknown. */
    fun album(raw: String?): String =
        if (isBlankOrUnknown(raw)) "Unknown Album" else raw!!.trim()

    /**
     * Optional artist: returns null (so the UI can hide the field entirely)
     * instead of a placeholder, for layouts that prefer hiding to showing
     * "Unknown Artist".
     */
    fun artistOrNull(raw: String?): String? =
        if (isBlankOrUnknown(raw)) null else raw!!.trim()
}

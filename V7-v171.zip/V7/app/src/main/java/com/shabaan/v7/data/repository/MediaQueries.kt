package com.shabaan.v7.data.repository

import com.shabaan.v7.data.model.MediaItem
import com.shabaan.v7.util.SortBy
import com.shabaan.v7.util.SortOrder

/** A bucket of media grouped by folder. */
data class Album(
    val name: String,
    val items: List<MediaItem>
) {
    val cover: MediaItem? get() = items.firstOrNull()
    val count: Int get() = items.size
}

/** Apply user sort preferences. */
fun List<MediaItem>.sorted(by: SortBy, order: SortOrder): List<MediaItem> {
    val ascending = order == SortOrder.ASCENDING
    val cmp: Comparator<MediaItem> = when (by) {
        SortBy.DATE -> compareBy { it.dateAdded }
        SortBy.NAME -> compareBy(String.CASE_INSENSITIVE_ORDER) { it.name }
        SortBy.SIZE -> compareBy { it.size }
    }
    return if (ascending) sortedWith(cmp) else sortedWith(cmp.reversed())
}

/** Case-insensitive substring match on name + artist + album. */
fun List<MediaItem>.filteredBy(query: String): List<MediaItem> {
    val q = query.trim()
    if (q.isEmpty()) return this
    // Upgraded to the Smart Search engine: aliases + fuzzy matching + ranking.
    // Same signature/behaviour contract as before (empty query => unchanged
    // list; otherwise only matching items), just smarter and ranked.
    return com.shabaan.v7.util.SmartSearch.search(this, q)
}

/** Group items by their relative path (folder). */
fun List<MediaItem>.toAlbums(): List<Album> {
    val grouped = groupBy { item ->
        val raw = item.relativePath?.trimEnd('/').orEmpty()
        if (raw.isEmpty()) "Other" else raw.substringAfterLast('/').ifEmpty { raw }
    }
    return grouped.map { (name, items) -> Album(name, items) }
        .sortedByDescending { it.items.maxOfOrNull { m -> m.dateAdded } ?: 0L }
}

/**
 * Albums view with auto "smart" albums prepended before the device folders.
 * The smart albums are virtual groupings (Videos, Screenshots, Camera, …) that
 * help the user jump to common buckets without scrolling folders. Only the
 * smart albums that actually have items are shown, so the grid never has empty
 * cards. Device folders follow, exactly as before.
 *
 * @param favoriteIds optional set of favorited media ids → adds a "Favorites"
 *        album at the very top when non-empty.
 */
fun List<MediaItem>.toAlbumsWithSmart(favoriteIds: Set<Long> = emptySet()): List<Album> {
    val smart = mutableListOf<Album>()

    // Favorites first (most personal).
    if (favoriteIds.isNotEmpty()) {
        val favs = filter { it.id in favoriteIds }
        if (favs.isNotEmpty()) smart += Album("Favorites", favs.sortedByDescending { it.dateAdded })
    }

    // Videos bucket.
    val videos = filter { it.isVideo }
    if (videos.isNotEmpty()) smart += Album("Videos", videos.sortedByDescending { it.dateAdded })

    // Screenshots (folder name contains "screenshot").
    val screenshots = filter {
        it.relativePath?.contains("screenshot", ignoreCase = true) == true
    }
    if (screenshots.isNotEmpty()) smart += Album("Screenshots", screenshots.sortedByDescending { it.dateAdded })

    // Camera (DCIM/Camera).
    val camera = filter {
        val p = it.relativePath?.lowercase().orEmpty()
        p.contains("dcim") && p.contains("camera")
    }
    if (camera.isNotEmpty()) smart += Album("Camera", camera.sortedByDescending { it.dateAdded })

    // Then the regular device folders.
    return smart + toAlbums()
}

/** A run of media that share a date header (Today, Yesterday, a month…). */
data class DateSection(
    val title: String,
    val items: List<MediaItem>
)

/**
 * Splits a media list into human-friendly sections: Today, Yesterday,
 * This Week, This Month, then by "Month Year". Gives the gallery a
 * Google/OPPO-Photos timeline feel.
 */
fun List<MediaItem>.toDateSections(): List<DateSection> {
    if (isEmpty()) return emptyList()
    val now = System.currentTimeMillis()
    val cal = java.util.Calendar.getInstance()
    cal.timeInMillis = now
    cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
    cal.set(java.util.Calendar.MINUTE, 0)
    cal.set(java.util.Calendar.SECOND, 0)
    cal.set(java.util.Calendar.MILLISECOND, 0)
    val startOfToday = cal.timeInMillis
    val startOfYesterday = startOfToday - 24L * 60 * 60 * 1000
    val startOfWeek = startOfToday - 7L * 24 * 60 * 60 * 1000
    val startOfMonth = startOfToday - 30L * 24 * 60 * 60 * 1000

    val monthFmt = java.text.SimpleDateFormat("MMMM yyyy", java.util.Locale.getDefault())

    fun sectionTitle(dateMs: Long): String {
        val ms = if (dateMs < 10_000_000_000L) dateMs * 1000 else dateMs
        return when {
            ms >= startOfToday -> "Today"
            ms >= startOfYesterday -> "Yesterday"
            ms >= startOfWeek -> "This Week"
            ms >= startOfMonth -> "This Month"
            else -> monthFmt.format(java.util.Date(ms))
        }
    }

    val order = listOf("Today", "Yesterday", "This Week", "This Month")
    val grouped = LinkedHashMap<String, MutableList<MediaItem>>()
    for (item in this.sortedByDescending { it.dateAdded }) {
        val t = sectionTitle(item.dateAdded)
        grouped.getOrPut(t) { mutableListOf() }.add(item)
    }
    return grouped.entries
        .sortedWith(compareBy {
            val i = order.indexOf(it.key)
            if (i >= 0) i else order.size
        })
        .map { DateSection(it.key, it.value) }
}

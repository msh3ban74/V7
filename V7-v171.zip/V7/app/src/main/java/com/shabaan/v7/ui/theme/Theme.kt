package com.shabaan.v7.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.shabaan.v7.util.ThemeMode

private val LightScheme = lightColorScheme(
    primary = Titanium700,
    onPrimary = Titanium50,
    primaryContainer = Titanium200,
    onPrimaryContainer = Titanium900,

    secondary = Titanium600,
    onSecondary = Titanium50,
    secondaryContainer = Titanium100,
    onSecondaryContainer = Titanium800,

    tertiary = TitaniumAccent,
    onTertiary = Color.White,

    background = Titanium50,
    onBackground = Titanium900,

    surface = Color.White,
    onSurface = Titanium900,
    surfaceVariant = Titanium100,
    onSurfaceVariant = Titanium700,

    outline = Titanium300,
    outlineVariant = Titanium200,
    error = Color(0xFFB3261E),
    onError = Color.White
)

private val DarkScheme = darkColorScheme(
    primary = IndigoPrimary,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFF2A2755),
    onPrimaryContainer = IndigoLight,

    secondary = IndigoSecondary,
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFF26243F),
    onSecondaryContainer = IndigoLight,

    tertiary = IndigoLight,
    onTertiary = V7Background,

    background = V7Background,
    onBackground = TextPrimary,

    surface = V7Surface,
    onSurface = TextPrimary,
    surfaceVariant = PremiumCard,
    onSurfaceVariant = TextSecondary,

    surfaceContainer = PremiumCard,
    surfaceContainerHigh = Color(0xFF1F2530),
    surfaceContainerHighest = Color(0xFF252C39),

    outline = SilverBorder,
    outlineVariant = SilverBorder,
    error = Color(0xFFF2B8B5),
    onError = Color(0xFF601410)
)

// Optional "Titanium Silver" skin — metallic blue-grey accents on the same
// near-black surfaces. Selected from Settings; the default look stays Platinum.
// (Optional premium skins were removed — the app uses the single DarkScheme.)

private val V7Shapes = androidx.compose.material3.Shapes(
    // Softer, more rounded corners give a modern, premium, "future" feel while
    // staying calm and minimal.
    extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
    small = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
    medium = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
    large = androidx.compose.foundation.shape.RoundedCornerShape(26.dp),
    extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(34.dp)
)

@Composable
fun V7Theme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    // The app has a single signature look: the dark "Platinum Silver" palette.
    val scheme = DarkScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = Color.Transparent.value.toInt()
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = scheme.background.luminance() > 0.5f
            controller.isAppearanceLightNavigationBars = scheme.background.luminance() > 0.5f
        }
    }
    MaterialTheme(
        colorScheme = scheme,
        typography = V7Typography,
        shapes = V7Shapes,
        content = content
    )
}

package com.shabaan.v7.ui.gallery

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shabaan.v7.data.model.MediaItem
import com.shabaan.v7.data.model.MediaType
import com.shabaan.v7.data.repository.Album
import com.shabaan.v7.data.repository.FavoritesRepository
import com.shabaan.v7.data.repository.MediaRepository
import com.shabaan.v7.data.repository.TrashRepository
import com.shabaan.v7.data.repository.VaultMoveResult
import com.shabaan.v7.data.repository.VaultRepository
import com.shabaan.v7.data.repository.filteredBy
import com.shabaan.v7.data.repository.sorted
import com.shabaan.v7.data.repository.toAlbums
import com.shabaan.v7.data.repository.toAlbumsWithSmart
import com.shabaan.v7.util.SettingsStore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class GalleryTab { PHOTOS, ALBUMS, FAVORITES, DUPLICATES }

/** Quick-filter category chips shown above the photo grid. */
enum class QuickCategory { ALL, VIDEOS, SCREENSHOTS, FAVORITES, DOWNLOADS }

@androidx.compose.runtime.Immutable
data class GalleryUi(
    val loading: Boolean = false,
    val raw: List<MediaItem> = emptyList(),
    val selection: Set<Long> = emptySet(),
    val selectionMode: Boolean = false,
    val favorites: Set<Long> = emptySet(),
    val tab: GalleryTab = GalleryTab.PHOTOS,
    val query: String = "",
    val duplicates: List<MediaItem> = emptyList(),
    val duplicatesLoading: Boolean = false,
    val category: QuickCategory = QuickCategory.ALL,
    /** Videos count + bytes for statistics (photos come from [raw]). */
    val videoCount: Int = 0,
    val videoBytes: Long = 0L
) {
    // Computed ONCE per state instance (by lazy) instead of on every read, so
    // the grid doesn't redo filtering/album-grouping each scroll frame.
    val items: List<MediaItem> by lazy {
        val base = when (tab) {
            GalleryTab.PHOTOS -> raw.byCategory(category, favorites)
            GalleryTab.FAVORITES -> raw.filter { it.id in favorites }
            GalleryTab.ALBUMS -> raw
            GalleryTab.DUPLICATES -> duplicates
        }
        base.filteredBy(query)
    }

    val albums: List<Album> by lazy { raw.toAlbumsWithSmart(favorites) }

    /** Recently added photos (newest first; list is already sorted by date). */
    val recent: List<MediaItem> by lazy { raw.take(20) }
}

/** Apply a quick-category filter to a photo list. */
private fun List<MediaItem>.byCategory(cat: QuickCategory, favorites: Set<Long>): List<MediaItem> =
    when (cat) {
        QuickCategory.ALL -> this
        QuickCategory.VIDEOS -> emptyList() // videos live in the Videos tab; chip is a hint
        QuickCategory.SCREENSHOTS -> filter {
            val p = (it.relativePath ?: "").lowercase()
            "screenshot" in p || it.name.lowercase().startsWith("screenshot")
        }
        QuickCategory.FAVORITES -> filter { it.id in favorites }
        QuickCategory.DOWNLOADS -> filter { "download" in (it.relativePath ?: "").lowercase() }
    }

@HiltViewModel
class GalleryViewModel @Inject constructor(
    private val repo: MediaRepository,
    private val favRepo: FavoritesRepository,
    private val trashRepo: TrashRepository,
    private val vaultRepo: VaultRepository,
    private val settings: SettingsStore
) : ViewModel() {

    private val _state = MutableStateFlow(GalleryUi())
    val state: StateFlow<GalleryUi> = _state.asStateFlow()

    private var hasLoaded = false

    init {
        viewModelScope.launch {
            favRepo.observeByType(MediaType.IMAGE).collect { favs ->
                _state.update { it.copy(favorites = favs.map { f -> f.mediaId }.toSet()) }
            }
        }
        // Stay in sync with the phone's photo library.
        viewModelScope.launch {
            var first = true
            repo.mediaChanges().collect {
                if (first) { first = false; return@collect }
                if (hasLoaded) load()
            }
        }
    }

    /** Loads once; safe to call on every screen entry. */
    fun ensureLoaded() {
        if (hasLoaded) return
        hasLoaded = true
        load()
    }

    fun load() {
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            val items = repo.loadImages().sorted(settings.sortBy, settings.sortOrder)
            _state.update { it.copy(loading = false, raw = items) }
            // Load video count/bytes for statistics (off the main thread). This
            // is read-only — it does NOT touch the Videos screen or its VM.
            runCatching {
                val vids = repo.loadVideos()
                _state.update {
                    it.copy(videoCount = vids.size, videoBytes = vids.sumOf { v -> v.size })
                }
            }
        }
    }

    fun setCategory(c: QuickCategory) {
        _state.update { it.copy(category = c) }
    }

    fun setTab(t: GalleryTab) {
        _state.update { it.copy(tab = t) }
        if (t == GalleryTab.DUPLICATES && _state.value.duplicates.isEmpty()) {
            loadDuplicates()
        }
    }

    /** Scan for likely-duplicate photos (same size + dimensions). */
    fun loadDuplicates() {
        viewModelScope.launch {
            _state.update { it.copy(duplicatesLoading = true) }
            val dups = repo.findDuplicateImages()
            _state.update { it.copy(duplicatesLoading = false, duplicates = dups) }
        }
    }
    fun setQuery(q: String) { _state.update { it.copy(query = q) } }

    fun toggleSelection(id: Long) {
        _state.update {
            val s = it.selection.toMutableSet()
            if (!s.add(id)) s.remove(id)
            it.copy(selection = s, selectionMode = s.isNotEmpty())
        }
    }

    fun startSelection(id: Long) {
        _state.update { it.copy(selectionMode = true, selection = it.selection + id) }
    }

    fun clearSelection() {
        _state.update { it.copy(selectionMode = false, selection = emptySet()) }
    }

    fun selectAll() {
        _state.update {
            val ids = it.items.map { v -> v.id }.toSet()
            val all = it.selection.size == ids.size && ids.isNotEmpty()
            it.copy(
                selection = if (all) emptySet() else ids,
                selectionMode = !all
            )
        }
    }

    fun toggleFavorite(id: Long) {
        viewModelScope.launch {
            val current = _state.value.favorites
            if (current.contains(id)) favRepo.remove(id, MediaType.IMAGE)
            else favRepo.add(id, MediaType.IMAGE)
        }
    }

    fun selectedItems(): List<MediaItem> {
        val sel = _state.value.selection
        return _state.value.items.filter { it.id in sel }
    }

    fun moveSelectedToTrash(onNeedsDelete: (List<android.net.Uri>) -> Unit) {
        viewModelScope.launch {
            val selected = selectedItems()
            selected.forEach { trashRepo.moveToTrash(it) }
            val uris = selected.map { it.uri }
            clearSelection()
            onNeedsDelete(uris)
        }
    }

    fun moveSelectedToVault(onNeedsDelete: (List<android.net.Uri>) -> Unit) {
        viewModelScope.launch {
            val selected = selectedItems()
            val pendingDelete = mutableListOf<android.net.Uri>()
            selected.forEach { item ->
                when (vaultRepo.moveToVault(item)) {
                    is VaultMoveResult.NeedsUserAction -> pendingDelete += item.uri
                    else -> Unit
                }
            }
            clearSelection()
            if (pendingDelete.isNotEmpty()) onNeedsDelete(pendingDelete)
            load()
        }
    }

    fun refreshAfterDelete() = load()
}

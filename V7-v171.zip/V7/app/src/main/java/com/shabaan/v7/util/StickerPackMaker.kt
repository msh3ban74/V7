package com.shabaan.v7.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * Bridges the animated-WebP encoder (StickerMaker) with pack storage
 * (StickerPackStore). Given a video clip and a target pack, it:
 *   1. encodes a 512x512 animated WebP for the clip,
 *   2. copies it into the pack's folder with a stable file name,
 *   3. registers it in the pack,
 *   4. ensures the pack has a tray icon (96x96 PNG) — created from the first
 *      sticker's first frame if one doesn't exist yet.
 *
 * Kept separate from both the encoder (pure media work) and the store (pure
 * persistence) so each piece has a single responsibility.
 */
object StickerPackMaker {

    /** Result of trying to add a sticker to a pack. */
    sealed class Result {
        data class Success(val pack: StickerPackStore.StickerPack) : Result()
        data class Error(val message: String) : Result()
    }

    /**
     * Encodes [videoUri] into an animated sticker and adds it to [packId].
     * Returns the updated pack on success.
     */
    suspend fun addStickerFromVideo(
        context: Context,
        packId: String,
        videoUri: Uri,
        startMs: Long,
        durationMs: Long = 2500,
        emojis: List<String> = listOf("⭐")
    ): Result = withContext(Dispatchers.IO) {
        val pack = StickerPackStore.get(context, packId)
            ?: return@withContext Result.Error("Pack not found")
        if (pack.stickers.size >= StickerPackStore.MAX_STICKERS) {
            return@withContext Result.Error("Pack is full (max ${StickerPackStore.MAX_STICKERS})")
        }

        // 1) Encode the animated WebP (lands in cache).
        val encoded = StickerMaker.createRealAnimatedWebp(
            context, videoUri, startMs, durationMs
        ) ?: return@withContext Result.Error("Could not create animated sticker")

        try {
            // 2) Move it into the pack folder with a stable, unique name.
            val fileName = "sticker_${System.currentTimeMillis()}.webp"
            val dest = StickerPackStore.stickerFile(context, packId, fileName)
            encoded.copyTo(dest, overwrite = true)
            runCatching { encoded.delete() }

            // 3) Register in the pack.
            val updated = StickerPackStore.addSticker(context, packId, fileName, emojis)
                ?: return@withContext Result.Error("Could not register sticker")

            // 4) Make sure a tray icon exists.
            ensureTrayIcon(context, packId, dest)

            Result.Success(updated)
        } catch (e: Throwable) {
            Result.Error(e.message ?: "Unknown error")
        }
    }

    /**
     * Creates the pack's tray icon (96x96 PNG) from [sourceSticker]'s first frame
     * if it doesn't already exist. WhatsApp requires a tray image per pack.
     */
    private fun ensureTrayIcon(context: Context, packId: String, sourceSticker: File) {
        val pack = StickerPackStore.get(context, packId) ?: return
        val tray = StickerPackStore.trayFile(context, packId, pack.trayImageFile)
        if (tray.exists() && tray.length() > 0) return

        try {
            // Decode the sticker's first frame and downscale it to a 96x96 PNG.
            val src = android.graphics.BitmapFactory.decodeFile(sourceSticker.absolutePath)
                ?: return
            val size = 96
            val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(out)
            val scale = size.toFloat() / maxOf(src.width, src.height)
            val sw = src.width * scale
            val sh = src.height * scale
            val left = (size - sw) / 2f
            val top = (size - sh) / 2f
            canvas.drawBitmap(src, null, RectF(left, top, left + sw, top + sh),
                Paint(Paint.FILTER_BITMAP_FLAG))
            FileOutputStream(tray).use { fos ->
                out.compress(Bitmap.CompressFormat.PNG, 100, fos)
            }
            if (src !== out) src.recycle()
            out.recycle()
        } catch (_: Throwable) {
            // Tray is best-effort; pack still works if WhatsApp falls back.
        }
    }

    /**
     * Adds a sticker to the user's current "open" pack — the most recent pack
     * that still has room — creating a new pack only if none exists yet. This is
     * the right default for the simple "make a sticker" button, so repeated
     * stickers collect into one pack (WhatsApp needs 3+ per pack) instead of
     * making a new single-sticker pack each time.
     */
    suspend fun addToCurrentPack(
        context: Context,
        videoUri: Uri,
        startMs: Long,
        durationMs: Long = 2500,
        packName: String = "V7 Stickers"
    ): Result = withContext(Dispatchers.IO) {
        val openPack = StickerPackStore.getAll(context)
            .lastOrNull { it.stickers.size < StickerPackStore.MAX_STICKERS }
        val targetId = openPack?.identifier
            ?: StickerPackStore.createPack(context, packName).identifier
        addStickerFromVideo(context, targetId, videoUri, startMs, durationMs)
    }

    /**
     * Creates a brand-new pack and immediately adds the first sticker from a
     * video. Convenience for the common "make a sticker" flow.
     */
    suspend fun createPackWithFirstSticker(
        context: Context,
        packName: String,
        videoUri: Uri,
        startMs: Long,
        durationMs: Long = 2500
    ): Result = withContext(Dispatchers.IO) {
        val pack = StickerPackStore.createPack(context, packName)
        addStickerFromVideo(context, pack.identifier, videoUri, startMs, durationMs)
    }
}

package com.shabaan.v7.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.shabaan.v7.util.SortBy
import com.shabaan.v7.util.SortOrder

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun SearchSortBar(
    query: String,
    onQueryChange: (String) -> Unit,
    sortBy: SortBy,
    sortOrder: SortOrder,
    onSortBy: (SortBy) -> Unit,
    onToggleOrder: () -> Unit,
    modifier: Modifier = Modifier
) {
    var searchOpen by remember { mutableStateOf(false) }
    var sortMenuOpen by remember { mutableStateOf(false) }

    val ctx = androidx.compose.ui.platform.LocalContext.current
    val recentStore = remember { com.shabaan.v7.util.RecentSearches(ctx) }
    var recent by remember { androidx.compose.runtime.mutableStateOf(recentStore.get()) }

    // Live suggestions while typing (alias-aware), plus recent searches when the
    // box is open but empty.
    val suggestions = remember(query) {
        if (query.isBlank()) emptyList()
        else com.shabaan.v7.util.SmartSearch.suggestions(query)
    }

    androidx.compose.foundation.layout.Column(modifier = modifier.fillMaxWidth()) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        AnimatedVisibility(
            visible = searchOpen,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut(),
            modifier = Modifier.weight(1f)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                singleLine = true,
                placeholder = { Text("Search…") },
                trailingIcon = {
                    IconButton(onClick = {
                        if (query.isNotEmpty()) onQueryChange("")
                        else searchOpen = false
                    }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Close search")
                    }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                    onSearch = {
                        if (query.isNotBlank()) {
                            recentStore.add(query)
                            recent = recentStore.get()
                        }
                    }
                ),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (!searchOpen) {
            // Spacer so icons sit at the right
            androidx.compose.foundation.layout.Spacer(Modifier.weight(1f))
            IconButton(onClick = { searchOpen = true }, modifier = Modifier.size(40.dp)) {
                Icon(
                    Icons.Rounded.Search,
                    contentDescription = "Search",
                    modifier = Modifier.size(21.dp)
                )
            }
            IconButton(onClick = { sortMenuOpen = true }, modifier = Modifier.size(40.dp)) {
                Icon(
                    Icons.Rounded.Sort,
                    contentDescription = "Sort",
                    modifier = Modifier.size(21.dp)
                )
            }
            IconButton(onClick = onToggleOrder, modifier = Modifier.size(40.dp)) {
                Icon(
                    if (sortOrder == SortOrder.DESCENDING) Icons.Rounded.ArrowDownward
                    else Icons.Rounded.ArrowUpward,
                    contentDescription = "Toggle order",
                    modifier = Modifier.size(21.dp)
                )
            }
        }

        DropdownMenu(
            expanded = sortMenuOpen,
            onDismissRequest = { sortMenuOpen = false }
        ) {
            SortBy.entries.forEach { option ->
                DropdownMenuItem(
                    text = {
                        Text(when (option) {
                            SortBy.DATE -> "By date"
                            SortBy.NAME -> "By name"
                            SortBy.SIZE -> "By size"
                        })
                    },
                    leadingIcon = if (sortBy == option) {
                        { Icon(Icons.Rounded.Check, contentDescription = null) }
                    } else null,
                    onClick = {
                        onSortBy(option)
                        sortMenuOpen = false
                    }
                )
            }
        }
    }

        // Suggestions while typing + recent searches when empty.
        AnimatedVisibility(visible = searchOpen) {
            val chips: List<Pair<String, Boolean>> = when {
                suggestions.isNotEmpty() -> suggestions.map { it to false }   // false = suggestion
                query.isBlank() -> recent.map { it to true }                 // true = recent
                else -> emptyList()
            }
            if (chips.isNotEmpty()) {
                androidx.compose.foundation.layout.FlowRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    chips.forEach { (text, isRecent) ->
                        androidx.compose.material3.SuggestionChip(
                            onClick = {
                                onQueryChange(text)
                                recentStore.add(text)
                                recent = recentStore.get()
                            },
                            label = { Text(text, style = MaterialTheme.typography.labelMedium) },
                            icon = {
                                Icon(
                                    if (isRecent) Icons.Rounded.History else Icons.Rounded.Search,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        )
                    }
                }
            }
        }
    }
}

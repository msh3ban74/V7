package com.shabaan.v7.ui.navigation

import androidx.compose.foundation.border
import com.shabaan.v7.ui.theme.SilverBorder
import androidx.compose.ui.Alignment
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import android.net.Uri
import android.app.Activity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import com.shabaan.v7.ui.theme.BrightSilver
import com.shabaan.v7.ui.theme.MutedSilver
import com.shabaan.v7.ui.theme.V7Motion
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.shabaan.v7.ui.gallery.GalleryScreen
import com.shabaan.v7.ui.gallery.PhotoViewerRoute
import com.shabaan.v7.ui.music.MusicScreen
import com.shabaan.v7.ui.settings.SettingsScreen
import com.shabaan.v7.ui.trash.TrashScreen
import com.shabaan.v7.ui.vault.VaultScreen
import com.shabaan.v7.ui.videos.ReelsRoute
import com.shabaan.v7.ui.videos.VideoPlayerRoute
import com.shabaan.v7.ui.videos.VideosScreen

sealed class V7Route(val route: String) {
    object Videos    : V7Route("videos")
    object Gallery   : V7Route("gallery")
    object Music     : V7Route("music")
    object Vault     : V7Route("vault")
    object Settings  : V7Route("settings")
    object Player    : V7Route("player/{index}") {
        fun build(index: Int) = "player/$index"
    }
    object PhotoViewer : V7Route("photo/{index}") {
        fun build(index: Int) = "photo/$index"
    }
    object Reels : V7Route("reels/{index}") {
        fun build(index: Int) = "reels/$index"
    }
    object Trash : V7Route("trash")
    object Status : V7Route("status")
    object PhotoEditor : V7Route("photo_editor")
}

private data class TabItem(
    val route: V7Route,
    val label: String,
    val icon: ImageVector
)

private val tabs = listOf(
    TabItem(V7Route.Videos,   "Videos",   Icons.Outlined.Videocam),
    TabItem(V7Route.Gallery,  "Gallery",  Icons.Outlined.Image),
    TabItem(V7Route.Music,    "Music",    Icons.Outlined.MusicNote),
    TabItem(V7Route.Vault,    "Vault",    Icons.Outlined.Lock),
    TabItem(V7Route.Settings, "Settings", Icons.Outlined.Settings),
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun V7Nav(activity: Activity) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route
    // The bottom bar shows only on the home (tabbed) destination.
    val showBottomBar = currentRoute == ROUTE_HOME
    val homePager = rememberPagerState(initialPage = 0) { tabs.size }
    val scope = rememberCoroutineScope()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            AnimatedVisibility(
                visible = showBottomBar,
                enter = expandVertically(),
                exit = shrinkVertically()
            ) {
                androidx.compose.foundation.layout.Column {
                    // Thin solid hairline that separates the bar (calm, no gradient).
                    androidx.compose.foundation.layout.Box(
                        Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(MaterialTheme.colorScheme.outlineVariant)
                    )
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 2.dp
                    ) {
                        val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
                    tabs.forEachIndexed { index, tab ->
                        // Selected = the pager's current page (kept in sync whether
                        // the user swiped or tapped).
                        val selected = homePager.currentPage == index
                        val iconScale by animateFloatAsState(
                            targetValue = if (selected) 1.08f else 1f,
                            animationSpec = androidx.compose.animation.core.tween(140),
                            label = "tabIconScale"
                        )
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                if (!selected) {
                                    haptic.performHapticFeedback(
                                        androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove
                                    )
                                    scope.launch { homePager.animateScrollToPage(index) }
                                }
                            },
                            icon = {
                                // When selected, a 1dp silver outline traces the pill
                                // so it reads as premium metal rather than a flat shape.
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .then(
                                            if (selected) Modifier
                                                .size(width = 64.dp, height = 32.dp)
                                                .border(
                                                    1.dp,
                                                    SilverBorder,
                                                    androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
                                                )
                                            else Modifier
                                        )
                                ) {
                                    Icon(
                                        tab.icon,
                                        contentDescription = tab.label,
                                        modifier = Modifier.scale(iconScale)
                                    )
                                }
                            },
                            label = {
                                Text(
                                    tab.label,
                                    fontWeight = if (selected)
                                        androidx.compose.ui.text.font.FontWeight.SemiBold
                                    else androidx.compose.ui.text.font.FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BrightSilver,
                                selectedTextColor = BrightSilver,
                                indicatorColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                                unselectedIconColor = MutedSilver,
                                unselectedTextColor = MutedSilver
                            )
                        )
                    }
                }
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            NavHost(
                navController = nav,
                startDestination = ROUTE_HOME,
                enterTransition = { fadeIn(animationSpec = tween(V7Motion.Fast)) },
                exitTransition = { fadeOut(animationSpec = tween(V7Motion.Fast)) },
                popEnterTransition = { fadeIn(animationSpec = tween(V7Motion.Fast)) },
                popExitTransition = { fadeOut(animationSpec = tween(V7Motion.Fast)) }
            ) {
                // HOME = the five main tabs inside a HorizontalPager. Swiping the
                // pager and tapping the bottom bar both drive the same pagerState,
                // so page and selected tab stay perfectly in sync.
                composable(ROUTE_HOME) {
                    HomePager(
                        pagerState = homePager,
                        activity = activity,
                        onOpenPlayer = { i -> nav.navigate(V7Route.Player.build(i)) },
                        onOpenReels  = { i -> nav.navigate(V7Route.Reels.build(i)) },
                        onOpenStatus = { nav.navigate(V7Route.Status.route) },
                        onOpenPhoto  = { i -> nav.navigate(V7Route.PhotoViewer.build(i)) },
                        onOpenTrash  = { nav.navigate(V7Route.Trash.route) }
                    )
                }
                composable(V7Route.Trash.route) {
                    TrashScreen(onBack = { nav.popBackStack() })
                }
                composable(V7Route.Status.route) {
                    com.shabaan.v7.ui.status.StatusScreen(onBack = { nav.popBackStack() })
                }
                composable(V7Route.PhotoEditor.route) {
                    val uri = com.shabaan.v7.ui.gallery.EditSession.uri
                    if (uri != null) {
                        com.shabaan.v7.ui.editor.PhotoEditorScreen(
                            uri = uri,
                            onBack = { nav.popBackStack() }
                        )
                    } else {
                        androidx.compose.runtime.LaunchedEffect(Unit) { nav.popBackStack() }
                    }
                }
                composable(
                    V7Route.Player.route,
                    enterTransition = {
                        scaleIn(initialScale = 0.85f, animationSpec = tween(V7Motion.Medium, easing = V7Motion.Emphasized)) +
                            fadeIn(animationSpec = tween(V7Motion.Medium))
                    },
                    popExitTransition = {
                        scaleOut(targetScale = 0.85f, animationSpec = tween(V7Motion.Medium, easing = V7Motion.Emphasized)) +
                            fadeOut(animationSpec = tween(V7Motion.Medium))
                    }
                ) { entry ->
                    val idx = entry.arguments?.getString("index")?.toIntOrNull() ?: 0
                    VideoPlayerRoute(startIndex = idx, onBack = { nav.popBackStack() })
                }
                composable(
                    V7Route.Reels.route,
                    enterTransition = {
                        slideInVertically(initialOffsetY = { it / 6 }, animationSpec = tween(V7Motion.Medium, easing = V7Motion.Emphasized)) +
                            fadeIn(animationSpec = tween(V7Motion.Medium))
                    },
                    popExitTransition = {
                        slideOutVertically(targetOffsetY = { it / 6 }, animationSpec = tween(V7Motion.Medium, easing = V7Motion.Emphasized)) +
                            fadeOut(animationSpec = tween(V7Motion.Medium))
                    }
                ) { entry ->
                    val idx = entry.arguments?.getString("index")?.toIntOrNull() ?: 0
                    ReelsRoute(startIndex = idx, onBack = { nav.popBackStack() })
                }
                composable(
                    V7Route.PhotoViewer.route,
                    enterTransition = {
                        scaleIn(initialScale = 0.85f, animationSpec = tween(V7Motion.Medium, easing = V7Motion.Emphasized)) +
                            fadeIn(animationSpec = tween(V7Motion.Medium))
                    },
                    popExitTransition = {
                        scaleOut(targetScale = 0.85f, animationSpec = tween(V7Motion.Medium, easing = V7Motion.Emphasized)) +
                            fadeOut(animationSpec = tween(V7Motion.Medium))
                    }
                ) { entry ->
                    val idx = entry.arguments?.getString("index")?.toIntOrNull() ?: 0
                    PhotoViewerRoute(
                        startIndex = idx,
                        onBack = { nav.popBackStack() },
                        onEdit = { editUri ->
                            com.shabaan.v7.ui.gallery.EditSession.uri = editUri
                            nav.navigate(V7Route.PhotoEditor.route)
                        }
                    )
                }
            }
        }
    }
}

private const val ROUTE_HOME = "v7_home"

/**
 * The five main tabs hosted in a HorizontalPager. Swiping moves between tabs and
 * tapping the bottom bar animates the pager — both share [pagerState], so the
 * page and the selected tab are always in sync.
 *
 * Performance notes:
 *  - beyondViewportPageCount = 0 keeps only the current page composed (plus the
 *    one being swiped to), so off-screen tabs don't run their preloaders/grids.
 *  - The pager fling is snappy (no bounce/overscroll); each tab keeps its own
 *    scroll state via the pager's internal saveable state.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun HomePager(
    pagerState: androidx.compose.foundation.pager.PagerState,
    activity: Activity,
    onOpenPlayer: (Int) -> Unit,
    onOpenReels: (Int) -> Unit,
    onOpenStatus: () -> Unit,
    onOpenPhoto: (Int) -> Unit,
    onOpenTrash: () -> Unit
) {
    androidx.compose.foundation.pager.HorizontalPager(
        state = pagerState,
        beyondViewportPageCount = 0,
        modifier = Modifier.fillMaxSize()
    ) { page ->
        when (page) {
            0 -> VideosScreen(
                onOpenPlayer = onOpenPlayer,
                onOpenReels = onOpenReels,
                onOpenStatus = onOpenStatus
            )
            1 -> GalleryScreen(onOpenPhoto = onOpenPhoto)
            2 -> MusicScreen()
            3 -> VaultScreen(activity = activity)
            4 -> SettingsScreen(activity = activity, onOpenTrash = onOpenTrash)
        }
    }
}

package com.shabaan.v7.ui.music

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

/**
 * Reusable music UI components extracted from MusicScreen to keep that file
 * focused. These are pure, stateless composables — they take everything they
 * need as parameters and hold no playback state — so moving them here changes
 * nothing about behavior; it only shrinks the screen file.
 *
 * (First extraction as part of breaking up the oversized MusicScreen; more
 * components can follow the same pattern once this is verified to build.)
 */

/**
 * Square album artwork with a rounded background and a music-note fallback icon
 * shown behind the image (visible when art fails to load).
 */
@Composable
internal fun AlbumArt(uri: android.net.Uri, albumId: Long, size: Dp) {
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = com.shabaan.v7.ui.components.rememberThumbRequest(
                data = uri, mediaId = albumId, sizePx = 300, useOsThumb = false
            ),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Icon(
            Icons.Rounded.MusicNote,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(size / 2)
        )
    }
}

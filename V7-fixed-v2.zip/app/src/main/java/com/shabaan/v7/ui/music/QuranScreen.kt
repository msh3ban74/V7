package com.shabaan.v7.ui.music

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.shabaan.v7.util.Formatters
import com.shabaan.v7.util.QuranApi
import com.shabaan.v7.util.QuranApi.Reciter
import com.shabaan.v7.util.QuranApi.Surah
import com.shabaan.v7.util.QuranSources
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuranScreen(
    onStartPlaying: () -> Unit = {}
) {
    val ctx = LocalContext.current
    val lang = com.shabaan.v7.util.LocalAppLanguage.current
    val scope = rememberCoroutineScope()

    // ---- ExoPlayer ----
    val player = remember {
        ExoPlayer.Builder(ctx)
            .setAudioAttributes(
                androidx.media3.common.AudioAttributes.Builder()
                    .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(androidx.media3.common.C.USAGE_MEDIA)
                    .build(), true
            ).build()
    }
    DisposableEffect(Unit) { onDispose { player.release() } }

    // ---- State ----
    var surahQuery      by remember { mutableStateOf("") }
    var reciterQuery    by remember { mutableStateOf("") }
    var selectedReciter by remember { 
        mutableStateOf(QuranApi.RECITERS.firstOrNull() ?: QuranApi.CATALOG.firstOrNull() ?: QuranApi.Reciter("", "القارئ", "Reciter")) 
    }
    var playingSurah    by remember { mutableStateOf<Surah?>(null) }
    var isPlaying       by remember { mutableStateOf(false) }
    var isBuffering     by remember { mutableStateOf(false) }
    var playError       by remember { mutableStateOf<String?>(null) }
    // Bumped whenever ExoPlayer reports an error, so a watcher effect can drive
    // automatic source failover (defined after play()/tryNextSource()).
    var playerErrorTick by remember { mutableIntStateOf(0) }
    var showPicker      by remember { mutableStateOf(false) }
    var position        by remember { mutableLongStateOf(0L) }
    var duration        by remember { mutableLongStateOf(0L) }
    var isSeeking       by remember { mutableStateOf(false) }
    var seekValue       by remember { mutableFloatStateOf(0f) }
    var downloading     by remember { mutableStateOf(false) }
    var dlProgress      by remember { mutableFloatStateOf(0f) }

    // Validate the reciter catalog at startup — only keep ones whose audio
    // actually responds, so the user never sees a broken reciter.
    var reciters by remember { mutableStateOf(QuranApi.RECITERS) }
    var loadingReciters by remember { mutableStateOf(true) }
    // Last saved listening session (for "Continue listening" + sheikh restore).
    var savedSession by remember {
        mutableStateOf(com.shabaan.v7.util.QuranProgress.get(ctx))
    }
    // Quran favorites (sheikhs by id, surahs by number). Held in state so the
    // UI updates instantly on toggle; persisted through QuranFavorites.
    var favSheikhs by remember {
        mutableStateOf(com.shabaan.v7.util.QuranFavorites.sheikhIds(ctx))
    }
    var favSurahs by remember {
        mutableStateOf(com.shabaan.v7.util.QuranFavorites.surahNumbers(ctx))
    }
    LaunchedEffect(Unit) {
        reciters = try {
            QuranApi.validateReciters()
        } catch (t: Throwable) {
            emptyList()
        }
        loadingReciters = false
        // Restore the last reciter the user listened to, if it's still valid.
        val saved = savedSession
        val restored = if (saved != null)
            reciters.firstOrNull { it.identifier == saved.reciterId } else null
        if (restored != null) {
            selectedReciter = restored
        } else if (reciters.isNotEmpty() && reciters.none { it.identifier == selectedReciter.identifier }) {
            // If the currently selected reciter got filtered out, pick the first valid.
            selectedReciter = reciters.first()
        }
    }

    // Persist the session when leaving the Quran screen (so it survives even if
    // the periodic save hasn't fired yet).
    DisposableEffect(Unit) {
        onDispose {
            val s = playingSurah
            if (s != null && position > 0) {
                com.shabaan.v7.util.QuranProgress.save(
                    ctx,
                    reciterId = selectedReciter.identifier,
                    reciterArabicName = selectedReciter.arabicName,
                    surahNumber = s.number,
                    surahArabicName = s.arabicName,
                    positionMs = position,
                    durationMs = duration
                )
            }
        }
    }

    // Player listener
    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(p: Boolean) {
                isPlaying = p
                if (p) isBuffering = false
            }
            override fun onPlaybackStateChanged(s: Int) {
                isBuffering = s == Player.STATE_BUFFERING
                if (s == Player.STATE_ENDED) { isPlaying = false; isBuffering = false }
            }
            override fun onPlayerError(e: androidx.media3.common.PlaybackException) {
                isPlaying = false
                // Don't show an error yet — request a source failover. The
                // effect watching this flag will try the next provider, and only
                // surface an error if every source is exhausted.
                playerErrorTick++
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l) }
    }

    // The position to seek to once the current surah is ready (resume point).
    var pendingResumeMs by remember { mutableLongStateOf(0L) }

    // ---- Runtime multi-source failover state ----
    // The ordered candidate URLs for the surah currently playing, the index of
    // the one we're on, and the reciter sources they belong to. When ExoPlayer
    // errors mid-stream we advance to the next candidate automatically.
    var srcCandidates by remember { mutableStateOf<List<com.shabaan.v7.util.QuranSources.Candidate>>(emptyList()) }
    var srcIndex by remember { mutableIntStateOf(0) }
    var srcReciter by remember { mutableStateOf<com.shabaan.v7.util.QuranSources.ReciterSources?>(null) }
    var switchingSource by remember { mutableStateOf(false) }

    // Continuous position poll + periodic resume-point save (every ~5s while
    // playing). Persistence is plain SharedPreferences writes off the hot path.
    LaunchedEffect(player) {
        var sinceSave = 0
        while (true) {
            val d = player.duration
            duration = if (d > 0) d else 0L
            position = player.currentPosition.coerceAtLeast(0L)
            sinceSave++
            // Every ~5s (10 * 500ms) while actually playing a known surah.
            if (sinceSave >= 10 && player.isPlaying && playingSurah != null && position > 0) {
                sinceSave = 0
                playingSurah?.let { s ->
                    com.shabaan.v7.util.QuranProgress.save(
                        ctx,
                        reciterId = selectedReciter.identifier,
                        reciterArabicName = selectedReciter.arabicName,
                        surahNumber = s.number,
                        surahArabicName = s.arabicName,
                        positionMs = position,
                        durationMs = duration
                    )
                }
            }
            delay(500)
        }
    }

    // When a surah becomes ready and we have a resume point, seek to it once.
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY && pendingResumeMs > 0) {
                    val target = pendingResumeMs
                    pendingResumeMs = 0L
                    runCatching { player.seekTo(target) }
                }
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    // Auto-clear error
    LaunchedEffect(playError) {
        if (playError != null) { delay(3000); playError = null }
    }

    // Play a specific candidate index for the current surah.
    fun playCandidate(index: Int, resumeMs: Long) {
        val list = srcCandidates
        if (index !in list.indices) {
            isBuffering = false
            playError = com.shabaan.v7.util.S.quranPlayAllFailed(lang)
            return
        }
        srcIndex = index
        pendingResumeMs = resumeMs
        val cand = list[index]
        player.stop()
        player.setMediaItem(MediaItem.fromUri(cand.url))
        player.prepare()
        player.playWhenReady = true
    }

    fun play(surah: Surah, resumeMs: Long = 0L) {
        onStartPlaying()
        playError = null
        switchingSource = false
        isBuffering = true
        playingSurah = surah
        position = 0L; duration = 0L
        scope.launch {
            val sources = QuranSources.CATALOG.firstOrNull {
                it.mp3quran == selectedReciter.identifier ||
                it.englishName == selectedReciter.englishName ||
                it.arabicName == selectedReciter.arabicName
            }
            srcReciter = sources
            if (sources != null) {
                // Build the ordered candidate list (cached + healthiest first).
                // No network check here — we let the player try them and fail
                // over instantly on a real error.
                val cands = QuranSources.candidatesFor(ctx, sources, surah.number)
                if (cands.isEmpty()) {
                    isBuffering = false
                    playError = com.shabaan.v7.util.S.quranPlayAllFailed(lang)
                    return@launch
                }
                srcCandidates = cands
                playCandidate(0, resumeMs)
            } else {
                // No catalog mapping → single source from the reciter identifier.
                srcCandidates = emptyList()
                val url = QuranApi.surahAudioUrl(surah.number, selectedReciter.identifier).toString()
                pendingResumeMs = resumeMs
                player.stop()
                player.setMediaItem(MediaItem.fromUri(url))
                player.prepare()
                player.playWhenReady = true
            }
        }
    }

    // Advance to the next available source after a playback error. Shows a brief
    // "switching to backup" hint. If we run out, surface a final error.
    fun tryNextSource() {
        val r = srcReciter
        val cands = srcCandidates
        // Report the failed source for health tracking.
        if (r != null && srcIndex in cands.indices) {
            QuranSources.reportPlaybackResult(ctx, r, cands[srcIndex].providerKey, success = false)
        }
        val next = srcIndex + 1
        if (next in cands.indices) {
            switchingSource = true
            isBuffering = true
            // Resume from where we were so the listener barely notices the switch.
            playCandidate(next, resumeMs = position.coerceAtLeast(0L))
            scope.launch { delay(2500); switchingSource = false }
        } else {
            switchingSource = false
            isBuffering = false; isPlaying = false
            playError = com.shabaan.v7.util.S.quranPlayAllFailed(lang)
        }
    }

    // Watch for player errors → automatic failover to the next source.
    LaunchedEffect(playerErrorTick) {
        if (playerErrorTick > 0) tryNextSource()
    }

    // When playback actually starts (becomes ready & playing), report the current
    // source as healthy so future plays prefer it.
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            switchingSource = false
            val r = srcReciter
            val cands = srcCandidates
            if (r != null && srcIndex in cands.indices) {
                QuranSources.reportPlaybackResult(ctx, r, cands[srcIndex].providerKey, success = true)
            }
        }
    }

    val filteredSurahs = remember(surahQuery) { QuranApi.searchSurahs(surahQuery) }
    val filteredReciters = remember(reciterQuery, reciters) {
        val q = reciterQuery.trim()
        if (q.isBlank()) reciters
        else {
            val nq = com.shabaan.v7.util.SmartSearch.normalize(q)
            reciters.filter {
                com.shabaan.v7.util.SmartSearch.normalize(it.arabicName).contains(nq) ||
                com.shabaan.v7.util.SmartSearch.normalize(it.englishName).contains(nq)
            }
        }
    }

    Column(Modifier.fillMaxSize()) {

        // Tabs: القراء / تلاوات نادرة
        var quranTab by remember { mutableIntStateOf(0) }
        TabRow(
            selectedTabIndex = quranTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.primary,
            indicator = { tabPositions ->
                Box(
                    Modifier
                        .tabIndicatorOffset(tabPositions[quranTab])
                        .padding(horizontal = 28.dp)
                        .height(3.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(
                            androidx.compose.ui.graphics.Brush.horizontalGradient(
                                listOf(
                                    com.shabaan.v7.ui.theme.PrimarySilver,
                                    com.shabaan.v7.ui.theme.BrightSilver
                                )
                            )
                        )
                )
            },
            divider = {
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
            }
        ) {
            Tab(selected = quranTab == 0, onClick = { quranTab = 0 },
                text = {
                    Text(com.shabaan.v7.util.S.reciters(lang),
                        fontWeight = if (quranTab == 0) FontWeight.Bold else FontWeight.Normal)
                },
                icon = { Icon(Icons.Rounded.RecordVoiceOver, null, Modifier.size(18.dp)) })
            Tab(selected = quranTab == 1, onClick = { quranTab = 1 },
                text = {
                    Text(com.shabaan.v7.util.S.rareRecitations(lang),
                        fontWeight = if (quranTab == 1) FontWeight.Bold else FontWeight.Normal)
                },
                icon = { Icon(Icons.Rounded.History, null, Modifier.size(18.dp)) })
        }

        if (quranTab == 1) {
            RareRecitationsTab(
                player = player,
                onError = { msg -> playError = msg },
                onStartPlaying = onStartPlaying
            )
            return@Column
        }

        // Continue listening — shows the last saved session so the user can
        // resume the exact surah + position with one tap. Hidden once they're
        // already playing something.
        val cont = savedSession
        if (cont != null && playingSurah == null) {
            ContinueListeningCard(
                session = cont,
                onClick = {
                    val surah = QuranApi.SURAHS.firstOrNull { it.number == cont.surahNumber }
                    if (surah != null) {
                        // Make sure the saved reciter is selected, then resume.
                        reciters.firstOrNull { it.identifier == cont.reciterId }?.let {
                            selectedReciter = it
                        }
                        play(surah, resumeMs = cont.positionMs)
                    }
                },
                onDismiss = {
                    com.shabaan.v7.util.QuranProgress.clear(ctx)
                    savedSession = null
                }
            )
        }

        // Search — large, prominent field. Instant filtering (searchSurahs runs
        // on every keystroke over the in-memory surah list, which is tiny).
        OutlinedTextField(
            value = surahQuery, onValueChange = { surahQuery = it },
            placeholder = { Text(com.shabaan.v7.util.S.searchSurahHint(lang)) },
            leadingIcon = { Icon(Icons.Rounded.Search, null, Modifier.size(24.dp)) },
            trailingIcon = { if (surahQuery.isNotEmpty())
                IconButton({ surahQuery = "" }) { Icon(Icons.Rounded.Close, null) } },
            singleLine = true,
            textStyle = MaterialTheme.typography.titleSmall,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            shape = RoundedCornerShape(16.dp)
        )

        // "Switching to backup source…" — shown only during an automatic failover.
        AnimatedVisibility(switchingSource) {
            Surface(color = MaterialTheme.colorScheme.secondaryContainer,
                modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(com.shabaan.v7.util.S.switchingSource(lang),
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        // Error banner
        AnimatedVisibility(playError != null) {
            Surface(color = MaterialTheme.colorScheme.errorContainer,
                modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.ErrorOutline, null,
                        tint = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(playError ?: "",
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        // Reciter strip
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically) {
            com.shabaan.v7.ui.components.ReciterAvatar(
                name = selectedReciter.arabicName,
                size = 32.dp
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(selectedReciter.arabicName,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (loadingReciters) Text(com.shabaan.v7.util.S.loadingReciters(lang),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                else Text("${reciters.size} " + com.shabaan.v7.util.S.recitersAvailable(lang),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton({ showPicker = true }) { Text(com.shabaan.v7.util.S.changeSheikh(lang)) }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))

        // Surahs list
        if (filteredSurahs.isEmpty()) {
            com.shabaan.v7.ui.components.EmptyState(
                text = com.shabaan.v7.util.S.noResults(lang),
                icon = Icons.Rounded.SearchOff,
                subtitle = com.shabaan.v7.util.S.trySurahNameNum(lang),
                modifier = Modifier.weight(1f)
            )
        } else {
        // Quick-play helper for a sheikh card: select that reciter, then resume
        // the saved surah if any, else play Al-Fatiha (surah 1).
        fun quickPlaySheikh(rec: com.shabaan.v7.util.QuranApi.Reciter) {
            selectedReciter = rec
            val surah = QuranApi.SURAHS.firstOrNull { it.number == 1 }
            if (surah != null) play(surah)
        }
        LazyColumn(Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = if (playingSurah != null) 150.dp else 16.dp)) {

            // --- Dashboard sections (only when not actively searching) ---
            if (surahQuery.isBlank()) {
                // Favorite Sheikhs
                val favReciters = reciters.filter { it.identifier in favSheikhs }
                if (favReciters.isNotEmpty()) {
                    item(key = "fav_sheikhs") {
                        SheikhStrip(
                            title = com.shabaan.v7.util.S.favoriteSheikhs(lang),
                            reciters = favReciters,
                            surahCount = QuranApi.SURAH_COUNT,
                            favoriteIds = favSheikhs,
                            onOpen = { rec -> 
                    selectedReciter = rec
                    surahQuery = "" 
                },
                            onQuickPlay = { rec -> quickPlaySheikh(rec) },
                            onToggleFavorite = { rec ->
                                com.shabaan.v7.util.QuranFavorites.toggleSheikh(ctx, rec.identifier)
                                favSheikhs = com.shabaan.v7.util.QuranFavorites.sheikhIds(ctx)
                            }
                        )
                    }
                }
                // Popular Reciters
                item(key = "popular_reciters") {
                    SheikhStrip(
                        title = com.shabaan.v7.util.S.popularReciters(lang),
                        reciters = QuranApi.popularReciters().ifEmpty { reciters.take(8) },
                        surahCount = QuranApi.SURAH_COUNT,
                        favoriteIds = favSheikhs,
                        onOpen = { rec -> 
                    selectedReciter = rec
                    surahQuery = "" 
                },
                        onQuickPlay = { rec -> quickPlaySheikh(rec) },
                        onToggleFavorite = { rec ->
                            com.shabaan.v7.util.QuranFavorites.toggleSheikh(ctx, rec.identifier)
                            favSheikhs = com.shabaan.v7.util.QuranFavorites.sheikhIds(ctx)
                        }
                    )
                }
                // Favorite Surahs (if any)
                val favSurahList = QuranApi.SURAHS.filter { it.number in favSurahs }
                if (favSurahList.isNotEmpty()) {
                    item(key = "fav_surahs_header") {
                        QuranSectionHeader(com.shabaan.v7.util.S.favoriteSurahs(lang))
                    }
                    items(favSurahList, key = { "favsurah_${it.number}" }) { surah ->
                        val active = playingSurah?.number == surah.number
                        SurahRow(
                            surah = surah,
                            isActive = active,
                            isPlaying = isPlaying && active,
                            isBuffering = isBuffering && active,
                            isFavorite = true,
                            onClick = { play(surah) },
                            onPlayPause = { if (isPlaying) player.pause() else player.play() },
                            onToggleFavorite = {
                                com.shabaan.v7.util.QuranFavorites.toggleSurah(ctx, surah.number)
                                favSurahs = com.shabaan.v7.util.QuranFavorites.surahNumbers(ctx)
                            }
                        )
                    }
                }
                item(key = "all_surahs_header") {
                    QuranSectionHeader(com.shabaan.v7.util.S.allSurahs(lang))
                }
            }

            items(filteredSurahs, key = { it.number }) { surah ->
                val active = playingSurah?.number == surah.number
                SurahRow(
                    surah = surah,
                    isActive = active,
                    isPlaying = isPlaying && active,
                    isBuffering = isBuffering && active,
                    isFavorite = surah.number in favSurahs,
                    onClick = { play(surah) },
                    onPlayPause = { if (isPlaying) player.pause() else player.play() },
                    onToggleFavorite = {
                        com.shabaan.v7.util.QuranFavorites.toggleSurah(ctx, surah.number)
                        favSurahs = com.shabaan.v7.util.QuranFavorites.surahNumbers(ctx)
                    }
                )
            }
        }
        }

        // ---- Mini player ----
        AnimatedVisibility(playingSurah != null, enter = fadeIn(), exit = fadeOut()) {
            playingSurah?.let { surah ->
                val dur = duration
                val pos = position
                val prog = if (dur > 0) {
                    if (isSeeking) seekValue
                    else (pos.toFloat() / dur).coerceIn(0f, 1f)
                } else 0f

                Surface(
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                    tonalElevation = 4.dp,
                    shadowElevation = 14.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                  Box(
                    Modifier
                        .background(
                            androidx.compose.ui.graphics.Brush.verticalGradient(
                                listOf(
                                    MaterialTheme.colorScheme.surfaceContainerHighest,
                                    MaterialTheme.colorScheme.surfaceContainerHigh
                                )
                            )
                        )
                        .border(
                            1.dp,
                            androidx.compose.ui.graphics.Brush.verticalGradient(
                                listOf(
                                    com.shabaan.v7.ui.theme.BrightSilver.copy(alpha = 0.35f),
                                    MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                                )
                            ),
                            RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
                        )
                  ) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Art / buffering
                            if (isBuffering) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp), strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.primary)
                            } else {
                                Icon(Icons.Rounded.MenuBook, null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(24.dp))
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(surah.arabicName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis)
                                Text(selectedReciter.arabicName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            // Download
                            if (downloading) {
                                CircularProgressIndicator(
                                    progress = { dlProgress },
                                    modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                            } else {
                                IconButton(onClick = {
                                    downloading = true; dlProgress = 0f
                                    scope.launch {
                                        val ok = QuranApi.downloadSurah(ctx,
                                            surah.number, surah.arabicName,
                                            selectedReciter.identifier, selectedReciter.arabicName
                                        ) { p -> dlProgress = p }
                                        downloading = false
                                        android.widget.Toast.makeText(ctx,
                                            if (ok) com.shabaan.v7.util.S.downloadedToQuran(lang)
                                            else com.shabaan.v7.util.S.downloadFailed(lang),
                                            android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                }) {
                                    Icon(Icons.Rounded.Download, com.shabaan.v7.util.S.download(lang),
                                        modifier = Modifier.size(18.dp))
                                }
                            }
                            // Prev
                            IconButton(enabled = surah.number > 1, onClick = {
                                QuranApi.SURAHS.getOrNull(surah.number - 2)?.let { play(it) }
                            }) { Icon(Icons.Rounded.SkipPrevious, null, Modifier.size(22.dp)) }
                            // Play/Pause
                            IconButton(onClick = {
                                if (isPlaying) player.pause() else player.play()
                            }) {
                                Icon(
                                    if (isPlaying) Icons.Rounded.Pause
                                    else Icons.Rounded.PlayArrow,
                                    null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            // Next
                            IconButton(enabled = surah.number < 114, onClick = {
                                QuranApi.SURAHS.getOrNull(surah.number)?.let { play(it) }
                            }) { Icon(Icons.Rounded.SkipNext, null, Modifier.size(22.dp)) }
                            // Close
                            IconButton(onClick = {
                                player.stop(); playingSurah = null
                                isPlaying = false; isBuffering = false
                            }) { Icon(Icons.Rounded.Close, null, Modifier.size(18.dp)) }
                        }

                        // Seek bar
                        Slider(value = prog,
                            onValueChange = { isSeeking = true; seekValue = it },
                            onValueChangeFinished = {
                                if (dur > 0) {
                                    val t = (seekValue * dur).toLong()
                                    player.seekTo(t); position = t
                                }
                                isSeeking = false
                            },
                            enabled = dur > 0,
                            modifier = Modifier.fillMaxWidth().height(24.dp))

                        Row(Modifier.fillMaxWidth()) {
                            Text(Formatters.duration(pos),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.weight(1f))
                            Text(if (dur > 0) Formatters.duration(dur) else com.shabaan.v7.util.S.loadingDots(lang),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                  }
                }
            }
        }
    }

    // ---- Reciter picker ----
    if (showPicker) {
        AlertDialog(
            onDismissRequest = { showPicker = false; reciterQuery = "" },
            title = {
                Column {
                    Text(com.shabaan.v7.util.S.chooseSheikh(lang) + " (${filteredReciters.size})")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = reciterQuery, onValueChange = { reciterQuery = it },
                        placeholder = { Text(com.shabaan.v7.util.S.searchSheikhHint(lang)) }, singleLine = true,
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp),
                        leadingIcon = { Icon(Icons.Rounded.Search, null) }
                    )
                }
            },
            text = {
                LazyColumn(Modifier.heightIn(max = 400.dp)) {
                    if (filteredReciters.isEmpty()) {
                        item {
                            Text(
                                com.shabaan.v7.util.S.noSheikhFound(lang),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                    items(filteredReciters, key = { it.identifier }) { rec ->
                        val chosen = selectedReciter.identifier == rec.identifier
                        Row(Modifier.fillMaxWidth()
                            .clickable {
                                selectedReciter = rec
                                reciterQuery = ""; showPicker = false
                                playingSurah?.let { play(it) }
                            }
                            .padding(vertical = 10.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            if (chosen) {
                                Icon(Icons.Rounded.Check, null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(8.dp))
                            } else Spacer(Modifier.width(24.dp))
                            Column(Modifier.weight(1f)) {
                                Text(rec.arabicName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Medium)
                                Text(rec.englishName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f))
                    }
                }
            },
            confirmButton = {
                TextButton({ showPicker = false; reciterQuery = "" }) { Text(com.shabaan.v7.util.S.close(lang)) }
            }
        )
    }
}

@Composable
private fun RareRecitationsTab(
    player: ExoPlayer,
    onError: (String) -> Unit,
    onStartPlaying: () -> Unit = {}
) {
    val scope = rememberCoroutineScope()
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val lang = com.shabaan.v7.util.LocalAppLanguage.current
    var selectedItem by remember { mutableStateOf<com.shabaan.v7.util.QuranArchive.RareItem?>(null) }
    var tracks by remember { mutableStateOf<List<com.shabaan.v7.util.QuranArchive.ArchiveTrack>>(emptyList()) }
    var loadingTracks by remember { mutableStateOf(false) }
    var playingUrl by remember { mutableStateOf<String?>(null) }
    var searchQ by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf<List<com.shabaan.v7.util.QuranArchive.RareItem>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }

    // ---- Mini player state ----
    var nowTrack by remember { mutableStateOf<com.shabaan.v7.util.QuranArchive.ArchiveTrack?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var isBuffering by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var isSeeking by remember { mutableStateOf(false) }
    var seekValue by remember { mutableFloatStateOf(0f) }
    var downloading by remember { mutableStateOf(false) }
    var dlProgress by remember { mutableFloatStateOf(0f) }

    // Player listener (rare tab)
    DisposableEffect(player) {
        val l = object : androidx.media3.common.Player.Listener {
            override fun onIsPlayingChanged(p: Boolean) {
                isPlaying = p; if (p) isBuffering = false
            }
            override fun onPlaybackStateChanged(s: Int) {
                isBuffering = s == androidx.media3.common.Player.STATE_BUFFERING
                if (s == androidx.media3.common.Player.STATE_ENDED) {
                    isPlaying = false; isBuffering = false
                }
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l) }
    }
    LaunchedEffect(player) {
        while (true) {
            val d = player.duration
            duration = if (d > 0) d else 0L
            position = player.currentPosition.coerceAtLeast(0L)
            kotlinx.coroutines.delay(500)
        }
    }

    fun playTrack(track: com.shabaan.v7.util.QuranArchive.ArchiveTrack) {
        onStartPlaying()
        onError("")
        isBuffering = true
        player.stop()
        player.setMediaItem(MediaItem.fromUri(track.url))
        player.prepare()
        player.playWhenReady = true
        nowTrack = track
        playingUrl = track.url
        position = 0L; duration = 0L
    }

    // When a rare recitation is open, Back returns to the list instead of
    // leaving the screen (mirrors the Close button).
    androidx.activity.compose.BackHandler(enabled = selectedItem != null) {
        selectedItem = null
    }

    val items = if (searchResults.isNotEmpty()) searchResults
                else com.shabaan.v7.util.QuranArchive.CURATED

    // On open, auto-load real, existing items from archive.org (famous reciters)
    // so the tab isn't relying only on the guessed curated identifiers.
    LaunchedEffect(Unit) {
        searching = true
        val auto = com.shabaan.v7.util.QuranArchive.search("مصطفى إسماعيل قرآن")
        if (auto.isNotEmpty()) searchResults = auto
        searching = false
    }

    Column(Modifier.fillMaxSize()) {
        // Search archive.org
        OutlinedTextField(
            value = searchQ,
            onValueChange = { searchQ = it },
            placeholder = { Text(com.shabaan.v7.util.S.searchArchiveHint(lang)) },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            trailingIcon = {
                Row {
                    if (searchQ.isNotEmpty()) {
                        IconButton(onClick = { searchQ = ""; searchResults = emptyList() }) {
                            Icon(Icons.Rounded.Close, null)
                        }
                    }
                    IconButton(onClick = {
                        if (searchQ.isNotBlank()) {
                            searching = true
                            scope.launch {
                                searchResults = com.shabaan.v7.util.QuranArchive.search(searchQ)
                                searching = false
                            }
                        }
                    }) { Icon(Icons.Rounded.Search, com.shabaan.v7.util.S.search(lang)) }
                }
            },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            shape = RoundedCornerShape(12.dp)
        )

        if (searching || loadingTracks) {
            Row(Modifier.fillMaxWidth().padding(8.dp),
                horizontalArrangement = Arrangement.Center) {
                CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
            }
        }

        if (selectedItem == null) {
            // List of rare items
            LazyColumn(Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 16.dp)) {
                items(items, key = { it.identifier }) { item ->
                    Card(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
                            .clickable {
                                selectedItem = item
                                loadingTracks = true
                                scope.launch {
                                    tracks = com.shabaan.v7.util.QuranArchive.tracksFor(item.identifier)
                                    loadingTracks = false
                                    if (tracks.isEmpty())
                                        onError(com.shabaan.v7.util.S.noFilesInRec(lang))
                                }
                            },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.History, null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.arabicName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold)
                                Text(item.description,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2)
                            }
                            Icon(Icons.Rounded.KeyboardArrowLeft, null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        } else {
            // Tracks inside the selected item
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {
                    selectedItem = null; tracks = emptyList()
                    player.stop(); playingUrl = null
                }) { Icon(Icons.Rounded.Close, com.shabaan.v7.util.S.back(lang)) }
                Text(selectedItem!!.arabicName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))

            LazyColumn(Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 16.dp)) {
                items(tracks, key = { it.url }) { track ->
                    val active = playingUrl == track.url
                    Row(Modifier.fillMaxWidth()
                        .clickable { playTrack(track) }
                        .background(if (active)
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                            else androidx.compose.ui.graphics.Color.Transparent)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        if (active && isBuffering) {
                            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(
                                if (active && isPlaying) Icons.Rounded.VolumeUp
                                else Icons.Rounded.PlayArrow,
                                null,
                                tint = if (active) MaterialTheme.colorScheme.primary
                                       else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Text(track.title,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (active) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onBackground,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f),
                        modifier = Modifier.padding(horizontal = 16.dp))
                }
            }
        }

        // ---- Mini player for rare recitations ----
        nowTrack?.let { track ->
            val idx = tracks.indexOfFirst { it.url == track.url }
            val dur = duration
            val prog = if (dur > 0) {
                if (isSeeking) seekValue else (position.toFloat() / dur).coerceIn(0f, 1f)
            } else 0f
            Surface(
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                tonalElevation = 4.dp,
                shadowElevation = 14.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
              Box(
                Modifier
                    .background(
                        androidx.compose.ui.graphics.Brush.verticalGradient(
                            listOf(
                                MaterialTheme.colorScheme.surfaceContainerHighest,
                                MaterialTheme.colorScheme.surfaceContainerHigh
                            )
                        )
                    )
                    .border(
                        1.dp,
                        androidx.compose.ui.graphics.Brush.verticalGradient(
                            listOf(
                                com.shabaan.v7.ui.theme.BrightSilver.copy(alpha = 0.35f),
                                MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                            )
                        ),
                        RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
                    )
              ) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (isBuffering) {
                            CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.primary)
                        } else {
                            Icon(Icons.Rounded.History, null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(track.title, style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                            Text(selectedItem?.arabicName ?: com.shabaan.v7.util.S.rareRecitation(lang),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        // Download
                        if (downloading) {
                            CircularProgressIndicator(progress = { dlProgress },
                                modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                        } else {
                            IconButton(onClick = {
                                downloading = true; dlProgress = 0f
                                scope.launch {
                                    val ok = com.shabaan.v7.util.QuranArchive.downloadTrack(
                                        ctx, track
                                    ) { p -> dlProgress = p }
                                    downloading = false
                                    android.widget.Toast.makeText(ctx,
                                        if (ok) com.shabaan.v7.util.S.downloadedToQuran(lang)
                                        else com.shabaan.v7.util.S.downloadFailed(lang),
                                        android.widget.Toast.LENGTH_SHORT).show()
                                }
                            }) { Icon(Icons.Rounded.Download, null, Modifier.size(18.dp)) }
                        }
                        // Prev track
                        IconButton(enabled = idx > 0, onClick = {
                            tracks.getOrNull(idx - 1)?.let { playTrack(it) }
                        }) { Icon(Icons.Rounded.SkipPrevious, null, Modifier.size(22.dp)) }
                        // Play/Pause
                        IconButton(onClick = {
                            if (isPlaying) player.pause() else player.play()
                        }) {
                            Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                null, tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp))
                        }
                        // Next track
                        IconButton(enabled = idx >= 0 && idx < tracks.size - 1, onClick = {
                            tracks.getOrNull(idx + 1)?.let { playTrack(it) }
                        }) { Icon(Icons.Rounded.SkipNext, null, Modifier.size(22.dp)) }
                        // Close
                        IconButton(onClick = {
                            player.stop(); nowTrack = null; playingUrl = null
                            isPlaying = false; isBuffering = false
                        }) { Icon(Icons.Rounded.Close, null, Modifier.size(18.dp)) }
                    }
                    // Seek bar
                    Slider(value = prog,
                        onValueChange = { isSeeking = true; seekValue = it },
                        onValueChangeFinished = {
                            if (dur > 0) {
                                val t = (seekValue * dur).toLong()
                                player.seekTo(t); position = t
                            }
                            isSeeking = false
                        },
                        enabled = dur > 0,
                        modifier = Modifier.fillMaxWidth().height(24.dp))
                    Row(Modifier.fillMaxWidth()) {
                        Text(Formatters.duration(position),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.weight(1f))
                        Text(if (dur > 0) Formatters.duration(dur) else com.shabaan.v7.util.S.loadingDots(lang),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
              }
            }
        }
    }
}

package com.shabaan.v7.ui.navigation

import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import android.net.Uri
import android.app.Activity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import com.shabaan.v7.ui.theme.BrightSilver
import com.shabaan.v7.ui.theme.MutedSilver
import com.shabaan.v7.ui.theme.V7Motion
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.shabaan.v7.ui.gallery.GalleryScreen
import com.shabaan.v7.ui.gallery.PhotoViewerRoute
import com.shabaan.v7.ui.music.MusicScreen
import com.shabaan.v7.ui.settings.SettingsScreen
import com.shabaan.v7.ui.trash.TrashScreen
import com.shabaan.v7.ui.vault.VaultScreen
import com.shabaan.v7.ui.videos.ReelsRoute
import com.shabaan.v7.ui.videos.VideoPlayerRoute
import com.shabaan.v7.ui.videos.VideosScreen

sealed class V7Route(val route: String) {
    object Videos    : V7Route("videos")
    object Gallery   : V7Route("gallery")
    object Music     : V7Route("music")
    object Vault     : V7Route("vault")
    object Settings  : V7Route("settings")
    object Player    : V7Route("player/{index}") {
        fun build(index: Int) = "player/$index"
    }
    object PhotoViewer : V7Route("photo/{index}") {
        fun build(index: Int) = "photo/$index"
    }
    object Reels : V7Route("reels/{index}") {
        fun build(index: Int) = "reels/$index"
    }
    object Trash : V7Route("trash")
    object Status : V7Route("status")
    object PhotoEditor : V7Route("photo_editor")
}

private data class TabItem(
    val route: V7Route,
    val label: String,
    val icon: ImageVector
)

private val tabs = listOf(
    TabItem(V7Route.Videos,   "Videos",   Icons.Outlined.Videocam),
    TabItem(V7Route.Gallery,  "Gallery",  Icons.Outlined.Image),
    TabItem(V7Route.Music,    "Music",    Icons.Outlined.MusicNote),
    TabItem(V7Route.Vault,    "Vault",    Icons.Outlined.Lock),
    TabItem(V7Route.Settings, "Settings", Icons.Outlined.Settings),
)

@Composable
fun V7Nav(activity: Activity) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route
    val showBottomBar = currentRoute in tabs.map { it.route.route }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            AnimatedVisibility(
                visible = showBottomBar,
                enter = expandVertically(),
                exit = shrinkVertically()
            ) {
                androidx.compose.foundation.layout.Column {
                    // Thin solid hairline that separates the bar (calm, no gradient).
                    androidx.compose.foundation.layout.Box(
                        Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(MaterialTheme.colorScheme.outlineVariant)
                    )
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 2.dp
                    ) {
                        val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
                    tabs.forEach { tab ->
                        val selected = backStack?.destination?.hierarchy?.any {
                            it.route == tab.route.route
                        } == true
                        val iconScale by animateFloatAsState(
                            targetValue = if (selected) 1.08f else 1f,
                            animationSpec = androidx.compose.animation.core.tween(140),
                            label = "tabIconScale"
                        )
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                if (!selected) {
                                    haptic.performHapticFeedback(
                                        androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove
                                    )
                                    nav.navigate(tab.route.route) {
                                        popUpTo(V7Route.Videos.route) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                Icon(
                                    tab.icon,
                                    contentDescription = tab.label,
                                    modifier = Modifier.scale(iconScale)
                                )
                            },
                            label = {
                                Text(
                                    tab.label,
                                    fontWeight = if (selected)
                                        androidx.compose.ui.text.font.FontWeight.SemiBold
                                    else androidx.compose.ui.text.font.FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BrightSilver,
                                selectedTextColor = BrightSilver,
                                indicatorColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                                unselectedIconColor = MutedSilver,
                                unselectedTextColor = MutedSilver
                            )
                        )
                    }
                }
                }
            }
        }
    ) { padding ->
        // Helper: jump to the tab at [index] (same nav behaviour as tapping it).
        fun goToTab(index: Int) {
            val target = tabs.getOrNull(index) ?: return
            nav.navigate(target.route.route) {
                popUpTo(V7Route.Videos.route) { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        }
        // Which tab are we on right now (if any)?
        val currentTabIndex = tabs.indexOfFirst { it.route.route == currentRoute }

        Box(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .then(
                    // Only enable horizontal swipe-between-tabs while on a main tab
                    // screen (not inside the player, reels, viewer, etc.).
                    if (currentTabIndex >= 0) {
                        Modifier.pointerInput(currentTabIndex) {
                            var totalDrag = 0f
                            detectHorizontalDragGestures(
                                onDragStart = { totalDrag = 0f },
                                onDragEnd = {
                                    // Threshold so small/accidental drags are ignored.
                                    val threshold = 80.dp.toPx()
                                    // Swipe LEFT → next tab (Videos→Gallery…),
                                    // swipe RIGHT → previous tab.
                                    if (totalDrag <= -threshold && currentTabIndex < tabs.lastIndex) {
                                        goToTab(currentTabIndex + 1)   // swipe left → next tab
                                    } else if (totalDrag >= threshold && currentTabIndex > 0) {
                                        goToTab(currentTabIndex - 1)   // swipe right → previous tab
                                    }
                                }
                            ) { _, dragAmount -> totalDrag += dragAmount }
                        }
                    } else Modifier
                )
        ) {
            // Helper: index of a route within the main tabs (or -1).
            fun tabIndexOf(route: String?): Int = tabs.indexOfFirst { it.route.route == route }
            val slideDur = 240

            NavHost(
                navController = nav,
                startDestination = V7Route.Videos.route,
                // Tabs slide horizontally in the direction of travel (next tab
                // enters from the right, previous from the left) with a soft fade.
                // Non-tab destinations (player/viewer) just fade.
                enterTransition = {
                    val from = tabIndexOf(initialState.destination.route)
                    val to = tabIndexOf(targetState.destination.route)
                    if (from >= 0 && to >= 0) {
                        val dir = if (to > from) 1 else -1
                        slideInHorizontally(
                            animationSpec = tween(slideDur, easing = V7Motion.Emphasized)
                        ) { full -> dir * full / 4 } +
                            fadeIn(animationSpec = tween(slideDur, easing = V7Motion.Emphasized))
                    } else {
                        fadeIn(animationSpec = tween(V7Motion.Medium, easing = V7Motion.Emphasized))
                    }
                },
                exitTransition = {
                    val from = tabIndexOf(initialState.destination.route)
                    val to = tabIndexOf(targetState.destination.route)
                    if (from >= 0 && to >= 0) {
                        val dir = if (to > from) 1 else -1
                        slideOutHorizontally(
                            animationSpec = tween(slideDur, easing = V7Motion.Emphasized)
                        ) { full -> -dir * full / 4 } +
                            fadeOut(animationSpec = tween(slideDur, easing = V7Motion.Standard))
                    } else {
                        fadeOut(animationSpec = tween(V7Motion.Fast, easing = V7Motion.Standard))
                    }
                },
                popEnterTransition = {
                    fadeIn(animationSpec = tween(V7Motion.Medium, easing = V7Motion.Emphasized))
                },
                popExitTransition = {
                    fadeOut(animationSpec = tween(V7Motion.Fast, easing = V7Motion.Standard)) +
                        scaleOut(
                            targetScale = 0.98f,
                            animationSpec = tween(V7Motion.Fast, easing = V7Motion.Standard)
                        )
                }
            ) {
                composable(V7Route.Videos.route) {
                    VideosScreen(
                        onOpenPlayer = { i -> nav.navigate(V7Route.Player.build(i)) },
                        onOpenReels  = { i -> nav.navigate(V7Route.Reels.build(i)) },
                        onOpenStatus = { nav.navigate(V7Route.Status.route) }
                    )
                }
                composable(V7Route.Gallery.route) {
                    GalleryScreen(
                        onOpenPhoto = { i -> nav.navigate(V7Route.PhotoViewer.build(i)) }
                    )
                }
                composable(V7Route.Music.route) {
                    MusicScreen()
                }
                composable(V7Route.Vault.route) {
                    VaultScreen(activity = activity)
                }
                composable(V7Route.Settings.route) {
                    SettingsScreen(
                        activity = activity,
                        onOpenTrash = { nav.navigate(V7Route.Trash.route) }
                    )
                }
                composable(V7Route.Trash.route) {
                    TrashScreen(onBack = { nav.popBackStack() })
                }
                composable(V7Route.Status.route) {
                    com.shabaan.v7.ui.status.StatusScreen(onBack = { nav.popBackStack() })
                }
                composable(V7Route.PhotoEditor.route) {
                    val uri = com.shabaan.v7.ui.gallery.EditSession.uri
                    if (uri != null) {
                        com.shabaan.v7.ui.editor.PhotoEditorScreen(
                            uri = uri,
                            onBack = { nav.popBackStack() }
                        )
                    } else {
                        androidx.compose.runtime.LaunchedEffect(Unit) { nav.popBackStack() }
                    }
                }
                composable(
                    V7Route.Player.route,
                    enterTransition = {
                        scaleIn(initialScale = 0.85f, animationSpec = tween(V7Motion.Medium, easing = V7Motion.Emphasized)) +
                            fadeIn(animationSpec = tween(V7Motion.Medium))
                    },
                    popExitTransition = {
                        scaleOut(targetScale = 0.85f, animationSpec = tween(V7Motion.Medium, easing = V7Motion.Emphasized)) +
                            fadeOut(animationSpec = tween(V7Motion.Medium))
                    }
                ) { entry ->
                    val idx = entry.arguments?.getString("index")?.toIntOrNull() ?: 0
                    VideoPlayerRoute(startIndex = idx, onBack = { nav.popBackStack() })
                }
                composable(
                    V7Route.Reels.route,
                    enterTransition = {
                        slideInVertically(initialOffsetY = { it / 6 }, animationSpec = tween(V7Motion.Medium, easing = V7Motion.Emphasized)) +
                            fadeIn(animationSpec = tween(V7Motion.Medium))
                    },
                    popExitTransition = {
                        slideOutVertically(targetOffsetY = { it / 6 }, animationSpec = tween(V7Motion.Medium, easing = V7Motion.Emphasized)) +
                            fadeOut(animationSpec = tween(V7Motion.Medium))
                    }
                ) { entry ->
                    val idx = entry.arguments?.getString("index")?.toIntOrNull() ?: 0
                    ReelsRoute(startIndex = idx, onBack = { nav.popBackStack() })
                }
                composable(
                    V7Route.PhotoViewer.route,
                    enterTransition = {
                        scaleIn(initialScale = 0.85f, animationSpec = tween(V7Motion.Medium, easing = V7Motion.Emphasized)) +
                            fadeIn(animationSpec = tween(V7Motion.Medium))
                    },
                    popExitTransition = {
                        scaleOut(targetScale = 0.85f, animationSpec = tween(V7Motion.Medium, easing = V7Motion.Emphasized)) +
                            fadeOut(animationSpec = tween(V7Motion.Medium))
                    }
                ) { entry ->
                    val idx = entry.arguments?.getString("index")?.toIntOrNull() ?: 0
                    PhotoViewerRoute(
                        startIndex = idx,
                        onBack = { nav.popBackStack() },
                        onEdit = { editUri ->
                            com.shabaan.v7.ui.gallery.EditSession.uri = editUri
                            nav.navigate(V7Route.PhotoEditor.route)
                        }
                    )
                }
            }
        }
    }
}

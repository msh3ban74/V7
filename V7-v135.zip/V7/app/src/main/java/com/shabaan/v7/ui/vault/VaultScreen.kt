package com.shabaan.v7.ui.vault
import com.shabaan.v7.R
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput

import androidx.compose.foundation.border
import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pin
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.rounded.Compress
import androidx.compose.material.icons.rounded.FitScreen
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Bookmarks
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.compose.ui.graphics.Color
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.shabaan.v7.data.local.VaultItemEntity
import com.shabaan.v7.data.model.MediaType
import com.shabaan.v7.util.Formatters
import com.shabaan.v7.util.LockManager
import com.shabaan.v7.util.PinManager
import com.shabaan.v7.util.SettingsStore

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun VaultScreen(
    activity: Activity?,
    vm: VaultViewModel = hiltViewModel()
) {
    val ctx = LocalContext.current
    val lang = com.shabaan.v7.util.LocalAppLanguage.current
    val settings = remember { SettingsStore(ctx) }
    val lockEnabled = settings.appLockEnabled
    val biometricEnabled = settings.biometricEnabled
    val hasPin = settings.pinHash != null

    // Vault always requires auth IF an auth method exists. If the user has neither
    // biometric nor a PIN set up, we can't lock them out — so it opens directly.
    val canAuthenticate = (biometricEnabled && activity != null && LockManager.canUseBiometric(ctx)) || hasPin
    var unlocked by remember { mutableStateOf(!canAuthenticate) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var pinMode by remember { mutableStateOf(false) }

    // The Vault has NO grace period: it re-locks the instant you leave the screen,
    // background the app, switch apps, or the screen turns off. Returning always
    // requires authentication again.
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_PAUSE ||
                event == androidx.lifecycle.Lifecycle.Event.ON_STOP
            ) {
                unlocked = false
                pinMode = false
                LockManager.onAppBackground()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        // Leaving the composable (navigating away) also locks immediately.
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            unlocked = false
        }
    }

    // Auto-prompt biometric when locked + enabled + available
    LaunchedEffect(unlocked, biometricEnabled, pinMode) {
        if (!unlocked && !pinMode && biometricEnabled && activity != null && LockManager.canUseBiometric(ctx)) {
            LockManager.authenticate(
                activity = activity,
                title = com.shabaan.v7.util.S.vaultUnlock(lang),
                subtitle = com.shabaan.v7.util.S.vaultUnlockSub(lang),
                onSuccess = { unlocked = true },
                onError = { errorMsg = it }
            )
        }
    }

    if (!unlocked) {
        if (pinMode || (hasPin && (!biometricEnabled || activity == null || !LockManager.canUseBiometric(ctx)))) {
            PinUnlockScreen(
                storedHash = settings.pinHash,
                onSuccess = {
                    LockManager.markUnlocked()
                    unlocked = true
                },
                onUseBiometric = {
                    pinMode = false
                    if (activity != null && biometricEnabled && LockManager.canUseBiometric(ctx)) {
                        LockManager.authenticate(
                            activity = activity,
                            title = com.shabaan.v7.util.S.vaultUnlock(lang),
                            subtitle = com.shabaan.v7.util.S.vaultUnlockSub(lang),
                            onSuccess = { unlocked = true },
                            onError = { errorMsg = it }
                        )
                    }
                },
                showBiometric = biometricEnabled && activity != null && LockManager.canUseBiometric(ctx)
            )
        } else {
            VaultLockedScreen(
                hasPin = hasPin,
                biometricEnabled = biometricEnabled,
                errorMsg = errorMsg,
                onAuthenticate = {
                    errorMsg = null
                    if (activity != null) {
                        LockManager.authenticate(
                            activity = activity,
                            title = com.shabaan.v7.util.S.vaultUnlock(lang),
                            subtitle = com.shabaan.v7.util.S.vaultUnlockSub(lang),
                            onSuccess = { unlocked = true },
                            onError = { errorMsg = it }
                        )
                    }
                },
                onUsePin = { pinMode = true }
            )
        }
        return
    }

    val items by vm.items.collectAsState()
    var confirmDelete by remember { mutableStateOf<VaultItemEntity?>(null) }
    // Index of the item currently open in the full-screen viewer (-1 = none).
    // Holding an index lets the viewer swipe between items like the gallery.
    var viewingIndex by remember { mutableIntStateOf(-1) }

    // ---- Backup / Restore file pickers ----
    // Export: user picks where to save the .v7vault backup file.
    val backupLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            vm.exportVault(uri) { count ->
                android.widget.Toast.makeText(
                    ctx,
                    if (count >= 0) com.shabaan.v7.util.S.backupDone(lang) + " ($count)" else com.shabaan.v7.util.S.backupFailed(lang),
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
        }
    }
    // Import: user picks an existing .v7vault backup file to restore.
    val restoreLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            vm.importVault(uri) { count ->
                android.widget.Toast.makeText(
                    ctx,
                    if (count >= 0) com.shabaan.v7.util.S.restoreDone(lang) + " $count" else com.shabaan.v7.util.S.restoreFailed(lang),
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
        }
    }
    // Selected item ids for the top-bar actions (Restore / Share / Delete).
    val selected = remember { androidx.compose.runtime.mutableStateListOf<Long>() }
    val selectedItems = items.filter { it.id in selected }
    fun clearSelection() = selected.clear()

    // ---- Quick-import pickers (Photos / Videos / Audio) ----
    fun importToast(n: Int) {
        android.widget.Toast.makeText(
            ctx,
            if (n > 0) com.shabaan.v7.util.S.importedToVault(lang) + " $n " + com.shabaan.v7.util.S.itemWord(lang) else com.shabaan.v7.util.S.nothingImported(lang),
            android.widget.Toast.LENGTH_SHORT
        ).show()
    }
    val photoImportLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetMultipleContents()
    ) { uris -> if (uris.isNotEmpty()) vm.importFromUris(ctx, uris, "IMAGE") { importToast(it) } }
    val videoImportLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetMultipleContents()
    ) { uris -> if (uris.isNotEmpty()) vm.importFromUris(ctx, uris, "VIDEO") { importToast(it) } }
    val audioImportLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetMultipleContents()
    ) { uris -> if (uris.isNotEmpty()) vm.importFromUris(ctx, uris, "AUDIO") { importToast(it) } }

    Box(Modifier.fillMaxSize()) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            if (selected.isEmpty()) com.shabaan.v7.util.S.vaultTitle(lang) else "${selected.size} " + com.shabaan.v7.util.S.selectedCount(lang),
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            "${items.size} secured item${if (items.size == 1) "" else "s"}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    if (selected.isNotEmpty()) {
                        IconButton(onClick = { clearSelection() }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Clear selection")
                        }
                    }
                },
                actions = {
                    if (selected.isNotEmpty()) {
                        // Restore selected items back to the public gallery.
                        IconButton(onClick = {
                            selectedItems.forEach { vm.restore(it) }
                            clearSelection()
                        }) {
                            Icon(Icons.Filled.Restore, contentDescription = "Restore to gallery")
                        }
                        // Share selected (decrypts to a shareable temp uri first).
                        IconButton(onClick = {
                            vm.shareItems(selectedItems) { clearSelection() }
                        }) {
                            Icon(Icons.Rounded.Share, contentDescription = "Share")
                        }
                        // Delete selected permanently (asks for confirmation).
                        IconButton(onClick = {
                            confirmDelete = selectedItems.firstOrNull()
                        }) {
                            Icon(Icons.Rounded.Delete, contentDescription = "Delete")
                        }
                    } else {
                        // Backup the whole vault to a file.
                        IconButton(onClick = {
                            backupLauncher.launch("V7_Vault_Backup.v7vault.zip")
                        }) {
                            Icon(Icons.Rounded.Backup, contentDescription = "Backup")
                        }
                        // Restore a vault backup file.
                        IconButton(onClick = {
                            restoreLauncher.launch("application/zip")
                        }) {
                            Icon(Icons.Rounded.Restore, contentDescription = "Restore backup")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        if (items.isEmpty()) {
            // Premium empty state + quick-import cards so a new user can start
            // adding files right away.
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(androidx.compose.foundation.rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                VaultEmptyState(onAddFiles = { photoImportLauncher.launch("image/*") })
                Spacer(Modifier.height(8.dp))
                VaultSectionHeader(com.shabaan.v7.util.S.quickImport(lang))
                QuickImportRow(
                    onImportPhotos = { photoImportLauncher.launch("image/*") },
                    onImportVideos = { videoImportLauncher.launch("video/*") },
                    onImportAudio = { audioImportLauncher.launch("audio/*") }
                )
                Spacer(Modifier.height(16.dp))
                SecurityStatusCard(
                    appLockEnabled = lockEnabled,
                    biometricEnabled = biometricEnabled
                )
                Spacer(Modifier.height(24.dp))
            }
        } else {
            val photoCount = items.count { it.type == "IMAGE" }
            val videoCount = items.count { it.type == "VIDEO" }
            val audioCount = items.count { it.type == "AUDIO" }
            // Recently added = newest items by addedAt (vault list is already
            // newest-first from the DAO).
            val recentItems = items.take(10)

            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(8.dp, 8.dp, 8.dp, 96.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize().padding(padding)
            ) {
                // --- Dashboard header (only when not selecting) ---
                if (selected.isEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Column {
                            QuickImportRow(
                                onImportPhotos = { photoImportLauncher.launch("image/*") },
                                onImportVideos = { videoImportLauncher.launch("video/*") },
                                onImportAudio = { audioImportLauncher.launch("audio/*") }
                            )
                            Spacer(Modifier.height(12.dp))
                            VaultStatsRow(
                                photos = photoCount,
                                videos = videoCount,
                                audio = audioCount
                            )
                            Spacer(Modifier.height(12.dp))
                            SecurityStatusCard(
                                appLockEnabled = lockEnabled,
                                biometricEnabled = biometricEnabled
                            )
                            VaultSectionHeader(com.shabaan.v7.util.S.allItems(lang))
                        }
                    }
                }
                items(items, key = { it.id }) { item ->
                    VaultCell(
                        item = item,
                        selected = item.id in selected,
                        selectionMode = selected.isNotEmpty(),
                        onView = {
                            if (selected.isNotEmpty()) {
                                if (item.id in selected) selected.remove(item.id) else selected.add(item.id)
                            } else {
                                // Open the full-screen pager at this item's index.
                                viewingIndex = items.indexOfFirst { it.id == item.id }
                            }
                        },
                        onToggleSelect = {
                            if (item.id in selected) selected.remove(item.id) else selected.add(item.id)
                        }
                    )
                }
            }
        }
    }

    confirmDelete?.let { item ->
        // If we're in selection mode, delete the whole selection; otherwise just
        // the single item.
        val targets = if (selected.isNotEmpty()) selectedItems else listOf(item)
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text(com.shabaan.v7.util.S.deletePermanentQ(lang)) },
            text = {
                Text(
                    if (targets.size > 1)
                        "${targets.size} items will be removed from the vault and cannot be recovered."
                    else
                        "\"${item.originalName}\" will be removed from the vault and cannot be recovered."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    targets.forEach { vm.delete(it) }
                    clearSelection()
                    confirmDelete = null
                }) { Text(com.shabaan.v7.util.S.delete(lang), color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = null }) { Text(com.shabaan.v7.util.S.cancel(lang)) }
            }
        )
    }

    if (viewingIndex in items.indices) {
        VaultPagerViewer(
            items = items,
            startIndex = viewingIndex,
            vm = vm,
            onClose = { viewingIndex = -1 }
        )
    }
    }
}

@Composable
private fun VaultPagerViewer(
    items: List<VaultItemEntity>,
    startIndex: Int,
    vm: VaultViewModel,
    onClose: () -> Unit
) {
    val pager = androidx.compose.foundation.pager.rememberPagerState(
        initialPage = startIndex,
        pageCount = { items.size }
    )
    val lang = com.shabaan.v7.util.LocalAppLanguage.current
    androidx.compose.foundation.pager.HorizontalPager(
        state = pager,
        modifier = Modifier.fillMaxSize()
    ) { page ->
        val item = items[page]
        // Each page decrypts its own item to a file, then shows it. Only the
        // current page (and Compose's small offscreen window) decrypts, so this
        // stays light.
        var file by remember(item.id) { mutableStateOf<java.io.File?>(null) }
        var error by remember(item.id) { mutableStateOf<String?>(null) }
        LaunchedEffect(item.id) {
            vm.resolveViewableFile(item, prepFailedMsg = com.shabaan.v7.util.S.prepFileFailed(lang), onError = { error = it }) { f -> file = f }
        }
        val f = file
        if (f != null) {
            VaultViewerOverlay(
                item = item,
                file = f,
                vmRef = vm,
                onClose = onClose,
                onRestore = { vm.restore(item) { onClose() } },
                onDelete = { vm.delete(item) { onClose() } }
            )
        } else {
            Box(
                Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black),
                contentAlignment = Alignment.Center
            ) {
                if (error != null) {
                    Text(com.shabaan.v7.util.S.openFileFailed(lang) + ": $error",
                        color = androidx.compose.ui.graphics.Color.White,
                        modifier = Modifier.padding(24.dp))
                } else {
                    CircularProgressIndicator(color = androidx.compose.ui.graphics.Color.White)
                }
            }
        }
    }
}

@Composable
private fun VaultViewerOverlay(
    item: VaultItemEntity,
    file: java.io.File,
    vmRef: VaultViewModel,
    onClose: () -> Unit,
    onRestore: () -> Unit = {},
    onDelete: () -> Unit = {}
) {
    val lang = com.shabaan.v7.util.LocalAppLanguage.current
    val ctx = LocalContext.current
    androidx.activity.compose.BackHandler { onClose() }

    Box(
        Modifier
            .fillMaxSize()
            .background(androidx.compose.ui.graphics.Color.Black)
    ) {
        when (item.type) {
            MediaType.IMAGE.name -> {
                var imgError by remember { mutableStateOf<String?>(null) }
                // Pinch-to-zoom + pan, like the gallery viewer.
                var scale by remember { mutableFloatStateOf(1f) }
                var offsetX by remember { mutableFloatStateOf(0f) }
                var offsetY by remember { mutableFloatStateOf(0f) }
                val zoomState = androidx.compose.foundation.gestures.rememberTransformableState {
                    zoomChange, panChange, _ ->
                    scale = (scale * zoomChange).coerceIn(1f, 5f)
                    if (scale > 1f) {
                        offsetX += panChange.x
                        offsetY += panChange.y
                    } else {
                        offsetX = 0f; offsetY = 0f
                    }
                }
                AsyncImage(
                    model = ImageRequest.Builder(ctx)
                        .data(file)
                        .size(2048)
                        .crossfade(true)
                        .listener(
                            onError = { _, result ->
                                imgError = result.throwable.message ?: result.throwable.toString()
                            }
                        )
                        .build(),
                    contentDescription = item.originalName,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer(
                            scaleX = scale, scaleY = scale,
                            translationX = offsetX, translationY = offsetY
                        )
                        .transformable(zoomState)
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onDoubleTap = {
                                    // Double-tap toggles 1x ↔ 2.5x
                                    if (scale > 1f) { scale = 1f; offsetX = 0f; offsetY = 0f }
                                    else scale = 2.5f
                                }
                            )
                        },
                    contentScale = androidx.compose.ui.layout.ContentScale.Fit
                )
                imgError?.let { msg ->
                    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Rounded.Warning, null,
                                tint = androidx.compose.ui.graphics.Color.Red,
                                modifier = Modifier.size(48.dp))
                            Spacer(Modifier.height(12.dp))
                            Text(com.shabaan.v7.util.S.openImageFailed(lang),
                                color = androidx.compose.ui.graphics.Color.White,
                                style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(8.dp))
                            Text(msg,
                                color = androidx.compose.ui.graphics.Color(0xFFFFCDD2),
                                style = MaterialTheme.typography.bodySmall,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                            Spacer(Modifier.height(8.dp))
                            Text("path: ${item.storedPath}\nencrypted: ${item.encrypted}",
                                color = androidx.compose.ui.graphics.Color(0xFF90A4AE),
                                style = MaterialTheme.typography.labelSmall,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                    }
                }
            }
            MediaType.VIDEO.name -> {
                var vidError by remember { mutableStateOf<String?>(null) }
                val player = remember(file) {
                    androidx.media3.exoplayer.ExoPlayer.Builder(ctx).build().apply {
                        addListener(object : androidx.media3.common.Player.Listener {
                            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                                vidError = "${error.errorCodeName}: ${error.message}"
                                android.util.Log.e("VaultVideo",
                                    "PlayerError ${error.errorCodeName}: ${error.message}")
                            }
                            override fun onVideoSizeChanged(videoSize: androidx.media3.common.VideoSize) {
                                android.util.Log.i("VaultVideo",
                                    "videoSize = ${videoSize.width}x${videoSize.height}")
                            }
                            override fun onRenderedFirstFrame() {
                                android.util.Log.i("VaultVideo", "FIRST FRAME rendered ✅")
                            }
                            override fun onPlaybackStateChanged(state: Int) {
                                android.util.Log.i("VaultVideo", "playbackState = $state")
                            }
                        })
                        val item2 = androidx.media3.common.MediaItem.fromUri(
                            android.net.Uri.fromFile(file)
                        )
                        setMediaItem(item2)
                        prepare()
                        playWhenReady = true
                    }
                }
                androidx.compose.runtime.DisposableEffect(player) {
                    onDispose { player.release() }
                }
                // Safe extra controls: speed, repeat, mute, fit. These never
                // expose the decrypted file outside the vault.
                var speed by remember { mutableFloatStateOf(1f) }
                var repeatOn by remember { mutableStateOf(false) }
                var muted by remember { mutableStateOf(false) }
                var fillMode by remember { mutableStateOf(false) }
                Box(Modifier.fillMaxSize()) {
                    androidx.compose.ui.viewinterop.AndroidView(
                        factory = { context ->
                            val view = android.view.LayoutInflater.from(context)
                                .inflate(R.layout.vault_player_view, null)
                                as androidx.media3.ui.PlayerView
                            view.player = player
                            view.useController = true
                            view.controllerAutoShow = true
                            android.util.Log.i("VaultVideo",
                                "PlayerView attached (TextureView). videoSize=${player.videoSize.width}x${player.videoSize.height}")
                            view
                        },
                        update = { view ->
                            if (view.player !== player) view.player = player
                            view.resizeMode = if (fillMode)
                                androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                            else androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                    // Control chips — horizontally scrollable so they all fit
                    // nicely on any screen width.
                    Row(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 80.dp)
                            .horizontalScroll(androidx.compose.foundation.rememberScrollState())
                            .padding(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Mute / unmute
                        AssistChip(
                            onClick = {
                                muted = !muted
                                player.volume = if (muted) 0f else 1f
                            },
                            label = { Text(if (muted) com.shabaan.v7.util.S.muted(lang) else com.shabaan.v7.util.S.sound(lang)) },
                            leadingIcon = {
                                Icon(
                                    if (muted) Icons.AutoMirrored.Rounded.VolumeOff
                                    else Icons.AutoMirrored.Rounded.VolumeUp,
                                    null, Modifier.size(16.dp)
                                )
                            }
                        )
                        // Fit / Fill (resize mode)
                        AssistChip(
                            onClick = { fillMode = !fillMode },
                            label = { Text(if (fillMode) com.shabaan.v7.util.S.fill(lang) else com.shabaan.v7.util.S.fit(lang)) },
                            leadingIcon = {
                                Icon(
                                    if (fillMode) Icons.Rounded.Fullscreen
                                    else Icons.Rounded.FitScreen,
                                    null, Modifier.size(16.dp)
                                )
                            }
                        )
                        // Speed cycles 1x → 1.5x → 2x → 0.5x → 1x
                        AssistChip(
                            onClick = {
                                speed = when (speed) {
                                    1f -> 1.5f; 1.5f -> 2f; 2f -> 0.5f; else -> 1f
                                }
                                player.setPlaybackSpeed(speed)
                            },
                            label = { Text("${speed}x") },
                            leadingIcon = { Icon(Icons.Rounded.Speed, null, Modifier.size(16.dp)) }
                        )
                        // Repeat toggle
                        AssistChip(
                            onClick = {
                                repeatOn = !repeatOn
                                player.repeatMode = if (repeatOn)
                                    androidx.media3.common.Player.REPEAT_MODE_ONE
                                else androidx.media3.common.Player.REPEAT_MODE_OFF
                            },
                            label = { Text(if (repeatOn) com.shabaan.v7.util.S.repeatOn(lang) else com.shabaan.v7.util.S.once(lang)) },
                            leadingIcon = {
                                Icon(
                                    if (repeatOn) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                                    null, Modifier.size(16.dp)
                                )
                            }
                        )
                        // Capture current frame → save encrypted inside the vault.
                        val scopeCap = rememberCoroutineScope()
                        AssistChip(
                            onClick = {
                                scopeCap.launch {
                                    val bmp = withContext(Dispatchers.IO) {
                                        try {
                                            val r = android.media.MediaMetadataRetriever()
                                            r.setDataSource(file.absolutePath)
                                            val frame = r.getFrameAtTime(
                                                player.currentPosition * 1000,
                                                android.media.MediaMetadataRetriever.OPTION_CLOSEST
                                            )
                                            r.release()
                                            frame
                                        } catch (e: Exception) { null }
                                    }
                                    if (bmp != null) {
                                        val bytes = withContext(Dispatchers.IO) {
                                            val bos = java.io.ByteArrayOutputStream()
                                            bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 95, bos)
                                            bos.toByteArray()
                                        }
                                        vmRef.saveBytesToVault(
                                            bytes,
                                            "frame_${System.currentTimeMillis()}.jpg",
                                            "image/jpeg",
                                            MediaType.IMAGE.name
                                        ) { ok ->
                                            android.widget.Toast.makeText(
                                                ctx,
                                                if (ok) com.shabaan.v7.util.S.snapshotSaved(lang) else com.shabaan.v7.util.S.failed(lang),
                                                android.widget.Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    } else {
                                        android.widget.Toast.makeText(
                                            ctx, com.shabaan.v7.util.S.snapshotFailed(lang),
                                            android.widget.Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            },
                            label = { Text(com.shabaan.v7.util.S.snapshot(lang)) },
                            leadingIcon = {
                                Icon(Icons.Rounded.PhotoCamera, null, Modifier.size(16.dp))
                            }
                        )
                        // Compress → re-encode smaller, save encrypted in vault.
                        var compressing by remember { mutableStateOf(false) }
                        AssistChip(
                            onClick = {
                                if (compressing) return@AssistChip
                                compressing = true
                                scopeCap.launch {
                                    android.widget.Toast.makeText(
                                        ctx, com.shabaan.v7.util.S.compressing(lang), android.widget.Toast.LENGTH_SHORT
                                    ).show()
                                    val out = com.shabaan.v7.util.VideoCompressor.compressToVaultFile(
                                        ctx,
                                        android.net.Uri.fromFile(file),
                                        com.shabaan.v7.util.VideoCompressor.Quality.MEDIUM
                                    )
                                    if (out != null) {
                                        val bytes = withContext(Dispatchers.IO) { out.readBytes() }
                                        out.delete()
                                        vmRef.saveBytesToVault(
                                            bytes,
                                            "compressed_${System.currentTimeMillis()}.mp4",
                                            "video/mp4",
                                            MediaType.VIDEO.name
                                        ) { ok ->
                                            compressing = false
                                            android.widget.Toast.makeText(
                                                ctx,
                                                if (ok) com.shabaan.v7.util.S.compressedSaved(lang) else com.shabaan.v7.util.S.failed(lang),
                                                android.widget.Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    } else {
                                        compressing = false
                                        android.widget.Toast.makeText(
                                            ctx, com.shabaan.v7.util.S.compressFailed(lang), android.widget.Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            },
                            label = { Text(if (compressing) com.shabaan.v7.util.S.compressingShort(lang) else com.shabaan.v7.util.S.compress(lang)) },
                            leadingIcon = {
                                if (compressing) CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp)
                                else Icon(Icons.Rounded.Compress, null, Modifier.size(16.dp))
                            }
                        )
                        // Bookmark current position
                        var bookmarkTick by remember { mutableIntStateOf(0) }
                        AssistChip(
                            onClick = {
                                com.shabaan.v7.util.VideoBookmarks.add(
                                    ctx, item.id, player.currentPosition, ""
                                )
                                bookmarkTick++
                                android.widget.Toast.makeText(
                                    ctx, com.shabaan.v7.util.S.bookmarkSaved(lang),
                                    android.widget.Toast.LENGTH_SHORT
                                ).show()
                            },
                            label = { Text(com.shabaan.v7.util.S.bookmark(lang)) },
                            leadingIcon = {
                                Icon(Icons.Rounded.BookmarkAdd, null, Modifier.size(16.dp))
                            }
                        )
                        // Show bookmarks list
                        var showBookmarks by remember { mutableStateOf(false) }
                        AssistChip(
                            onClick = { showBookmarks = true },
                            label = { Text(com.shabaan.v7.util.S.bookmarks(lang)) },
                            leadingIcon = {
                                Icon(Icons.Rounded.Bookmarks, null, Modifier.size(16.dp))
                            }
                        )
                        if (showBookmarks) {
                            // Re-read whenever a bookmark was added (bookmarkTick).
                            val marks = remember(bookmarkTick, showBookmarks) {
                                com.shabaan.v7.util.VideoBookmarks.get(ctx, item.id)
                            }
                            AlertDialog(
                                onDismissRequest = { showBookmarks = false },
                                confirmButton = {
                                    TextButton(onClick = { showBookmarks = false }) { Text(com.shabaan.v7.util.S.close(lang)) }
                                },
                                title = { Text(com.shabaan.v7.util.S.bookmarks(lang)) },
                                text = {
                                    if (marks.isEmpty()) {
                                        Text(com.shabaan.v7.util.S.noBookmarks(lang))
                                    } else {
                                        Column {
                                            marks.forEach { bm ->
                                                Row(
                                                    Modifier.fillMaxWidth()
                                                        .clickable {
                                                            player.seekTo(bm.positionMs)
                                                            showBookmarks = false
                                                        }
                                                        .padding(vertical = 10.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Icon(Icons.Rounded.PlayArrow, null,
                                                        Modifier.size(18.dp))
                                                    Spacer(Modifier.width(10.dp))
                                                    Text(bm.label, Modifier.weight(1f))
                                                    IconButton(onClick = {
                                                        com.shabaan.v7.util.VideoBookmarks.remove(
                                                            ctx, item.id, bm.positionMs
                                                        )
                                                        bookmarkTick++
                                                    }) {
                                                        Icon(Icons.Rounded.Delete, null,
                                                            Modifier.size(18.dp))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
                vidError?.let { msg ->
                    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Rounded.Warning, null,
                                tint = androidx.compose.ui.graphics.Color.Red,
                                modifier = Modifier.size(48.dp))
                            Spacer(Modifier.height(12.dp))
                            Text(com.shabaan.v7.util.S.playVideoFailed(lang),
                                color = androidx.compose.ui.graphics.Color.White,
                                style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(8.dp))
                            Text(msg,
                                color = androidx.compose.ui.graphics.Color(0xFFFFCDD2),
                                style = MaterialTheme.typography.bodySmall,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                            Spacer(Modifier.height(8.dp))
                            Text("file: ${file.absolutePath}\nexists: ${file.exists()}  size: ${file.length()}",
                                color = androidx.compose.ui.graphics.Color(0xFF90A4AE),
                                style = MaterialTheme.typography.labelSmall,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                    }
                }
            }
            else -> {
                // Audio — simple play with controls
                val player = remember(file) {
                    androidx.media3.exoplayer.ExoPlayer.Builder(ctx).build().apply {
                        setMediaItem(androidx.media3.common.MediaItem.fromUri(android.net.Uri.fromFile(file)))
                        prepare()
                        playWhenReady = true
                    }
                }
                androidx.compose.runtime.DisposableEffect(player) {
                    onDispose { player.release() }
                }
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Rounded.MusicNote,
                            contentDescription = null,
                            modifier = Modifier.size(96.dp),
                            tint = androidx.compose.ui.graphics.Color.White
                        )
                        Spacer(Modifier.height(16.dp))
                        Text(
                            item.originalName,
                            color = androidx.compose.ui.graphics.Color.White,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }
            }
        }

        IconButton(
            onClick = onClose,
            modifier = Modifier.align(Alignment.TopStart).padding(8.dp)
        ) {
            Icon(
                Icons.AutoMirrored.Outlined.ArrowBack,
                contentDescription = "Close",
                tint = androidx.compose.ui.graphics.Color.White
            )
        }

        // Top-right actions: Info + Restore + Delete + Share
        var showInfo by remember { mutableStateOf(false) }
        var confirmRemove by remember { mutableStateOf(false) }
        var showEditor by remember { mutableStateOf(false) }
        Row(
            modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)
        ) {
            // Edit = open the full photo editor (crop / draw / text / rotate).
            // Saves back as a new ENCRYPTED item inside the vault.
            if (item.type == MediaType.IMAGE.name) {
                IconButton(onClick = { showEditor = true }) {
                    Icon(
                        Icons.Rounded.Edit,
                        contentDescription = "Edit",
                        tint = androidx.compose.ui.graphics.Color.White
                    )
                }
            }
            IconButton(onClick = { showInfo = true }) {
                Icon(
                    Icons.Rounded.Info,
                    contentDescription = "Info",
                    tint = androidx.compose.ui.graphics.Color.White
                )
            }
            // Restore (take out of vault)
            IconButton(onClick = onRestore) {
                Icon(
                    Icons.Rounded.LockOpen,
                    contentDescription = "Restore",
                    tint = androidx.compose.ui.graphics.Color.White
                )
            }
            // Delete permanently
            IconButton(onClick = { confirmRemove = true }) {
                Icon(
                    Icons.Rounded.Delete,
                    contentDescription = "Delete",
                    tint = androidx.compose.ui.graphics.Color.White
                )
            }
            IconButton(
                onClick = {
                    val shareUri = androidx.core.content.FileProvider.getUriForFile(
                        ctx, "${ctx.packageName}.fileprovider", file
                    )
                    val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                        type = item.mimeType
                        putExtra(android.content.Intent.EXTRA_STREAM, shareUri)
                        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    ctx.startActivity(android.content.Intent.createChooser(send, "Share"))
                }
            ) {
                Icon(
                    Icons.Rounded.Share,
                    contentDescription = "Share",
                    tint = androidx.compose.ui.graphics.Color.White
                )
            }
        }

        if (confirmRemove) {
            AlertDialog(
                onDismissRequest = { confirmRemove = false },
                confirmButton = {
                    TextButton(onClick = { confirmRemove = false; onDelete() }) {
                        Text(com.shabaan.v7.util.S.delete(lang), color = androidx.compose.ui.graphics.Color.Red)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { confirmRemove = false }) { Text(com.shabaan.v7.util.S.cancel(lang)) }
                },
                title = { Text(com.shabaan.v7.util.S.deletePermanent(lang)) },
                text = { Text(com.shabaan.v7.util.S.deletePermanentMsg(lang)) }
            )
        }

        // Full photo editor — opens over the viewer, saves encrypted into vault.
        if (showEditor && item.type == MediaType.IMAGE.name) {
            val editUri = remember(file) {
                androidx.core.content.FileProvider.getUriForFile(
                    ctx, "${ctx.packageName}.fileprovider", file
                )
            }
            Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black)) {
                com.shabaan.v7.ui.editor.PhotoEditorScreen(
                    uri = editUri,
                    onBack = { showEditor = false },
                    onSaveBytes = { bytes ->
                        vmRef.saveBytesToVault(
                            bytes,
                            "edit_${System.currentTimeMillis()}.jpg",
                            "image/jpeg",
                            MediaType.IMAGE.name
                        ) { ok ->
                            android.widget.Toast.makeText(
                                ctx,
                                if (ok) com.shabaan.v7.util.S.savedEditedImage(lang) else com.shabaan.v7.util.S.failed(lang),
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                )
            }
        }

        if (showInfo) {
            AlertDialog(
                onDismissRequest = { showInfo = false },
                confirmButton = {
                    TextButton(onClick = { showInfo = false }) { Text(com.shabaan.v7.util.S.ok(lang)) }
                },
                title = { Text(com.shabaan.v7.util.S.fileInfo(lang)) },
                text = {
                    Column {
                        VaultInfoRow(com.shabaan.v7.util.S.infoName(lang), item.originalName)
                        VaultInfoRow(com.shabaan.v7.util.S.infoSize(lang), Formatters.fileSize(file.length()))
                        VaultInfoRow(com.shabaan.v7.util.S.infoType(lang), item.mimeType)
                        VaultInfoRow(com.shabaan.v7.util.S.infoEncrypted(lang), if (item.encrypted) com.shabaan.v7.util.S.yesLocked(lang) else com.shabaan.v7.util.S.noWord(lang))
                    }
                }
            )
        }
    }
}

@Composable
private fun PinUnlockScreen(
    storedHash: String?,
    onSuccess: () -> Unit,
    onUseBiometric: () -> Unit,
    showBiometric: Boolean
) {
    val lang = com.shabaan.v7.util.LocalAppLanguage.current
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Box(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(32.dp).fillMaxWidth()
        ) {
            Icon(
                Icons.Rounded.Pin,
                contentDescription = null,
                modifier = Modifier.size(56.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Text(com.shabaan.v7.util.S.enterCode(lang), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(
                value = pin,
                onValueChange = {
                    if (it.length <= 8 && it.all { c -> c.isDigit() }) {
                        pin = it
                        error = null
                    }
                },
                label = { Text(com.shabaan.v7.util.S.code(lang)) },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            Button(
                onClick = {
                    if (PinManager.matches(pin, storedHash)) onSuccess()
                    else { error = "Incorrect PIN"; pin = "" }
                },
                enabled = pin.length >= 4,
                modifier = Modifier.fillMaxWidth()
            ) { Text(com.shabaan.v7.util.S.unlock(lang)) }
            if (showBiometric) {
                TextButton(onClick = onUseBiometric) {
                    Text(com.shabaan.v7.util.S.useBiometricInstead(lang))
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun VaultCell(
    item: VaultItemEntity,
    selected: Boolean,
    selectionMode: Boolean,
    onView: () -> Unit,
    onToggleSelect: () -> Unit
) {
    val ctx = LocalContext.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(RoundedCornerShape(16.dp))
            .then(
                if (selected) Modifier.border(
                    2.dp,
                    MaterialTheme.colorScheme.primary,
                    RoundedCornerShape(16.dp)
                ) else Modifier
            )
            .combinedClickable(
                onClick = { onView() },
                onLongClick = { onToggleSelect() }
            ),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(16.dp)
    ) {
        Box(Modifier.fillMaxSize()) {
            val typeIcon = when (item.type) {
                MediaType.VIDEO.name -> Icons.Rounded.PlayCircle
                MediaType.IMAGE.name -> Icons.Rounded.Image
                else -> Icons.Rounded.MusicNote
            }

            when (item.type) {
                MediaType.IMAGE.name, MediaType.VIDEO.name -> {
                    // The vault is already protected by the app lock, so it's safe
                    // to show real previews here. Encrypted items are decrypted
                    // in-memory just for the thumbnail by VaultThumbnailFetcher.
                    AsyncImage(
                        model = coil.request.ImageRequest.Builder(ctx)
                            .data(
                                com.shabaan.v7.util.VaultThumb(
                                    storedPath = item.storedPath,
                                    encrypted = item.encrypted,
                                    id = item.id,
                                    isVideo = item.type == MediaType.VIDEO.name,
                                    originalName = item.originalName
                                )
                            )
                            .size(400)
                            .crossfade(false)
                            .build(),
                        contentDescription = item.originalName,
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    if (item.type == MediaType.VIDEO.name) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Rounded.PlayCircle,
                                contentDescription = null,
                                tint = Color.White.copy(alpha = 0.85f),
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }
                }
                else -> {
                    Box(
                        Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            typeIcon,
                            contentDescription = null,
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Small lock chip (top-start) for encrypted items — replaces the old
            // translucent full-width strip that looked like an artifact.
            if (item.encrypted) {
                Box(
                    Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black.copy(alpha = 0.45f))
                        .padding(4.dp)
                ) {
                    Icon(
                        Icons.Filled.Lock,
                        contentDescription = null,
                        modifier = Modifier.size(12.dp),
                        tint = Color.White
                    )
                }
            }

            // Selection checkmark (top-end) when in selection mode.
            if (selectionMode) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .size(24.dp)
                        .clip(androidx.compose.foundation.shape.CircleShape)
                        .background(
                            if (selected) MaterialTheme.colorScheme.primary
                            else Color.Black.copy(alpha = 0.4f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (selected) {
                        Icon(
                            Icons.Rounded.Check,
                            contentDescription = "Selected",
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            }
        }
    }
}

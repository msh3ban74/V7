package com.shabaan.v7.ui.music

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.shabaan.v7.data.model.MediaItem

/**
 * Reusable music UI components extracted from MusicScreen to keep that file
 * focused. These are pure, stateless composables — they take everything they
 * need as parameters and hold no playback state — so moving them here changes
 * nothing about behavior; it only shrinks the screen file.
 *
 * (First extraction as part of breaking up the oversized MusicScreen; more
 * components can follow the same pattern once this is verified to build.)
 */

/**
 * Square album artwork with a rounded background and a music-note fallback icon
 * shown behind the image (visible when art fails to load).
 */
@Composable
internal fun AlbumArt(uri: android.net.Uri, albumId: Long, size: Dp) {
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = com.shabaan.v7.ui.components.rememberThumbRequest(
                data = uri, mediaId = albumId, sizePx = 300, useOsThumb = false
            ),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Icon(
            Icons.Rounded.MusicNote,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(size / 2)
        )
    }
}

/**
 * Contextual action bar shown while tracks are multi-selected: close, select
 * all, share, delete. Pure — all actions are passed in as callbacks.
 */
@Composable
internal fun MusicSelectionBar(
    count: Int,
    onClose: () -> Unit,
    onSelectAll: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 4.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onClose) {
            Icon(Icons.Rounded.Close, contentDescription = "Close")
        }
        Text(
            "$count selected",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(1f)
        )
        IconButton(onClick = onSelectAll) {
            Icon(Icons.Rounded.SelectAll, contentDescription = "Select all")
        }
        IconButton(onClick = onShare) {
            Icon(Icons.Rounded.Share, contentDescription = "Share")
        }
        IconButton(onClick = onDelete) {
            Icon(Icons.Rounded.Delete, contentDescription = "Delete")
        }
    }
}

/**
 * Horizontal "Recently played" strip of square cards. Pure — the track list,
 * art resolver and click handler are all provided by the caller.
 */
@Composable
internal fun RecentlyPlayedSection(
    tracks: List<MediaItem>,
    artUriFor: (MediaItem) -> android.net.Uri,
    onClick: (MediaItem) -> Unit
) {
    val lang = com.shabaan.v7.util.LocalAppLanguage.current
    Column(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 8.dp)) {
        Text(
            com.shabaan.v7.util.S.recentlyPlayed(lang),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(tracks, key = { "recent_${it.id}" }) { track ->
                Column(
                    Modifier
                        .width(96.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onClick(track) }
                        .padding(4.dp)
                ) {
                    AlbumArt(uri = artUriFor(track), albumId = track.albumId, size = 88.dp)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        track.name,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.shabaan.v7.ui.music

import com.shabaan.v7.ui.theme.BrightSilver
import com.shabaan.v7.ui.theme.PrimarySilver
import androidx.compose.foundation.border
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import android.content.Intent
import kotlinx.coroutines.launch
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.Share
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.media3.common.Player
import coil.compose.AsyncImage
import com.shabaan.v7.data.model.MediaItem
import com.shabaan.v7.data.repository.MediaRepository
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.shabaan.v7.ui.components.*
import com.shabaan.v7.util.Formatters

@OptIn(ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class, ExperimentalFoundationApi::class)
@Composable
fun MusicScreen(
    onOpenVideoItem: (com.shabaan.v7.data.model.MediaItem) -> Unit = {},
    onOpenImageItem: (com.shabaan.v7.data.model.MediaItem) -> Unit = {},
    onOpenAudioItem: (com.shabaan.v7.data.model.MediaItem) -> Unit = {},
    vm: MusicViewModel = hiltViewModel()
) {
    val perms = rememberMediaPermissions()
    val state by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val lang = com.shabaan.v7.util.LocalAppLanguage.current

    var musicDeleteUris by remember { mutableStateOf<List<android.net.Uri>>(emptyList()) }
    // Tab state at top level so both PermissionGate and the mini player can read it.
    var musicTab by remember { mutableStateOf(0) }
    // Playlist UI state.
    var addToPlaylistTrack by remember { mutableStateOf<MediaItem?>(null) }
    var showPlaylists by remember { mutableStateOf(false) }
    var openPlaylistId by remember { mutableStateOf<String?>(null) }
    var playlistsVersion by remember { mutableIntStateOf(0) }
    val musicDeleteLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.StartIntentSenderForResult()
    ) {
        vm.clearSelection()
        vm.load()
    }
    fun requestDeleteMusic(uris: List<android.net.Uri>) {
        if (uris.isEmpty()) return
        if (!com.shabaan.v7.util.FullAccess.isGranted(ctx)) {
            // Send the user to grant all-files access. Don't also fire the system
            // delete dialog here — it would pop on top and hide the grant screen.
            // Once granted, deletes below run instantly.
            android.widget.Toast.makeText(
                ctx,
                "Allow full access, then delete again — it'll be instant after that",
                android.widget.Toast.LENGTH_LONG
            ).show()
            com.shabaan.v7.util.FullAccess.request(ctx)
            return
        }
        uris.forEach { runCatching { ctx.contentResolver.delete(it, null, null) } }
        vm.clearSelection(); vm.load()
    }

    LaunchedEffect(perms.allPermissionsGranted) {
        if (perms.allPermissionsGranted) vm.ensureLoaded()
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            if (state.selectionMode) {
                MusicSelectionBar(
                    count = state.selection.size,
                    onClose = vm::clearSelection,
                    onSelectAll = vm::selectAll,
                    onShare = {
                        val sel = vm.selectedTracks()
                        if (sel.isNotEmpty()) {
                            val send = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                                type = "audio/*"
                                putParcelableArrayListExtra(
                                    Intent.EXTRA_STREAM, ArrayList(sel.map { it.uri })
                                )
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            ctx.startActivity(Intent.createChooser(send, "Share"))
                        }
                    },
                    onDelete = {
                        val sel = vm.selectedTracks()
                        if (sel.isNotEmpty()) {
                            musicDeleteUris = sel.map { it.uri }
                            requestDeleteMusic(musicDeleteUris)
                        }
                    }
                )
            } else {
                V7TopBar(
                    title = com.shabaan.v7.util.S.audioTitle(lang),
                    subtitle = if (state.tracks.isNotEmpty())
                        "%,d ".format(state.tracks.size) + com.shabaan.v7.util.S.tracksCount(lang) else null,
                    actions = {
                        IconButton(onClick = { vm.toggleFavoritesOnly() }) {
                            Icon(
                                imageVector = if (state.showFavoritesOnly)
                                    Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                                contentDescription = "Favorites",
                                tint = if (state.showFavoritesOnly)
                                    MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        IconButton(onClick = { showPlaylists = true }) {
                            Icon(
                                Icons.AutoMirrored.Rounded.QueueMusic,
                                contentDescription = "Playlists"
                            )
                        }
                    }
                )
            }
            PermissionGate(perms) {
                // Returning to the songs tab → reload so any surah just downloaded
                // from the Quran tab shows up without a restart. We intentionally
                // do NOT pause music when opening the Quran tab — music keeps
                // playing in its mini-player; it only pauses if the user actually
                // starts a recitation (handled in the Quran player itself).
                LaunchedEffect(musicTab) {
                    if (musicTab == 0) vm.load()
                }
                TabRow(
                    selectedTabIndex = musicTab,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.primary,
                    indicator = { tabPositions ->
                        // Metallic silver underline indicator.
                        Box(
                            Modifier
                                .tabIndicatorOffset(tabPositions[musicTab])
                                .padding(horizontal = 28.dp)
                                .height(3.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(
                                    androidx.compose.ui.graphics.Brush.horizontalGradient(
                                        listOf(PrimarySilver, BrightSilver)
                                    )
                                )
                        )
                    },
                    divider = {
                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                        )
                    }
                ) {
                    Tab(
                        selected = musicTab == 0,
                        onClick = { musicTab = 0 },
                        text = {
                            Text(com.shabaan.v7.util.S.audioTitle(lang),
                                fontWeight = if (musicTab == 0) FontWeight.Bold else FontWeight.Normal)
                        },
                        icon = { Icon(Icons.Rounded.MusicNote, null, Modifier.size(18.dp)) }
                    )
                    Tab(
                        selected = musicTab == 1,
                        onClick = { musicTab = 1 },
                        text = {
                            Text(com.shabaan.v7.util.S.quranKareem(lang),
                                fontWeight = if (musicTab == 1) FontWeight.Bold else FontWeight.Normal)
                        },
                        icon = { Icon(Icons.Rounded.MenuBook, null, Modifier.size(18.dp)) }
                    )
                }

                when (musicTab) {
                    1 -> QuranScreen(
                        onStartPlaying = {
                            // A recitation started → pause music so we never have
                            // two streams playing together.
                            if (state.isPlaying) vm.togglePlayPause()
                        }
                    )
                    else -> {
                      Column(Modifier.fillMaxSize()) {
                        // Unified search (always visible on the Audio tab):
                        // searches across videos + images + audio and opens the
                        // chosen item directly. No sort controls here (audio list
                        // isn't sorted by the date/name/size options).
                        com.shabaan.v7.ui.search.UnifiedSearchBar(
                            onOpenVideo = onOpenVideoItem,
                            onOpenImage = onOpenImageItem,
                            onOpenAudio = onOpenAudioItem
                        )
                        when {
                        state.loading -> LoadingState()
                        state.tracks.isEmpty() -> EmptyState(com.shabaan.v7.util.S.noMusic(lang))
                        state.showFavoritesOnly && state.tracks.none { it.id in state.favorites } ->
                            EmptyState(com.shabaan.v7.util.S.noFavSongs(lang))
                        else -> {
                        val repo = remember { MediaRepository(ctx) }
                        LazyColumn(
                            Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(bottom = 96.dp)
                        ) {
                            // Recently Played — compact horizontal cards at the
                            // top. Hidden in favorites-only mode and when empty.
                            if (!state.showFavoritesOnly && state.recentlyPlayed.isNotEmpty()) {
                                item(key = "recently_played_section") {
                                    RecentlyPlayedSection(
                                        tracks = state.recentlyPlayed,
                                        artUriFor = { repo.albumArtUri(it.albumId) },
                                        onClick = { track ->
                                            val idx = state.tracks.indexOf(track)
                                            if (idx >= 0) vm.play(idx)
                                        }
                                    )
                                }
                            }
                            items(state.visibleTracks, key = { it.id }) { track ->
                                TrackRow(
                                    track = track,
                                    artUri = repo.albumArtUri(track.albumId),
                                    isFavorite = track.id in state.favorites,
                                    isCurrent = state.tracks.indexOf(track) == state.currentIndex,
                                    selectionMode = state.selectionMode,
                                    selected = track.id in state.selection,
                                    onClick = {
                                        if (state.selectionMode) vm.toggleSelection(track.id)
                                        else vm.play(state.tracks.indexOf(track))
                                    },
                                    onLongClick = { vm.startSelection(track.id) },
                                    onFav = { vm.toggleFavorite(track.id) },
                                    onAddToPlaylist = { addToPlaylistTrack = track }
                                )
                            }
                        }
                        }
                        } // end inner when
                      } // end Column
                    } // end audio-tab else
                } // end when(musicTab)
            }
        }

        // Music mini player — shown on the Songs tab. Music keeps PLAYING when
        // you browse the Quran tab (we no longer auto-pause it), but its mini
        // player only appears here so it never overlaps the Quran mini player.
        val current = state.tracks.getOrNull(state.currentIndex)
        if (current != null && !state.expanded && musicTab == 0) {
            MiniPlayer(
                track = current,
                isPlaying = state.isPlaying,
                progress = if (state.duration > 0)
                    (state.position.toFloat() / state.duration).coerceIn(0f, 1f) else 0f,
                onClick = vm::expand,
                onPlayPause = vm::togglePlayPause,
                onNext = vm::next,
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }

        // Full player
        // When the full player is expanded, Back collapses it (returns to the
        // track list / mini player) instead of exiting the app.
        androidx.activity.compose.BackHandler(enabled = state.expanded) {
            vm.collapse()
        }
        AnimatedVisibility(
            visible = state.expanded && current != null,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
        ) {
            if (current != null) {
                val repo = remember { MediaRepository(ctx) }
                FullPlayer(
                    track = current,
                    state = state,
                    artUri = repo.albumArtUri(current.albumId),
                    onCollapse = vm::collapse,
                    onPlayPause = vm::togglePlayPause,
                    onNext = vm::next,
                    onPrev = vm::previous,
                    onSeek = vm::seekTo,
                    onShuffle = vm::toggleShuffle,
                    onRepeat = vm::cycleRepeat,
                    onFavorite = { vm.toggleFavorite(current.id) }
                )
            }
        }

        // ---- Add to playlist picker ----
        addToPlaylistTrack?.let { track ->
            val playlists = remember(playlistsVersion) {
                com.shabaan.v7.util.PlaylistStore.getAll(ctx)
            }
            var creatingNew by remember { mutableStateOf(false) }
            var newName by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { addToPlaylistTrack = null },
                title = { Text(com.shabaan.v7.util.S.addToPlaylist(lang)) },
                text = {
                    Column {
                        if (playlists.isEmpty() && !creatingNew) {
                            Text(com.shabaan.v7.util.S.noPlaylistsCreate(lang))
                        }
                        playlists.forEach { pl ->
                            TextButton(
                                onClick = {
                                    com.shabaan.v7.util.PlaylistStore.addTrack(ctx, pl.id, track.id)
                                    playlistsVersion++
                                    addToPlaylistTrack = null
                                    android.widget.Toast.makeText(
                                        ctx, "Added to ${pl.name}", android.widget.Toast.LENGTH_SHORT
                                    ).show()
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    "${pl.name}  (${pl.trackIds.size})",
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                        if (creatingNew) {
                            OutlinedTextField(
                                value = newName,
                                onValueChange = { newName = it },
                                singleLine = true,
                                label = { Text(com.shabaan.v7.util.S.playlistName(lang)) },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                },
                confirmButton = {
                    if (creatingNew) {
                        TextButton(onClick = {
                            val pl = com.shabaan.v7.util.PlaylistStore.create(ctx, newName)
                            com.shabaan.v7.util.PlaylistStore.addTrack(ctx, pl.id, track.id)
                            playlistsVersion++
                            addToPlaylistTrack = null
                            android.widget.Toast.makeText(
                                ctx, "Added to ${pl.name}", android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }) { Text(com.shabaan.v7.util.S.createAndAdd(lang)) }
                    } else {
                        TextButton(onClick = { creatingNew = true }) { Text(com.shabaan.v7.util.S.newPlaylist(lang)) }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { addToPlaylistTrack = null }) { Text(com.shabaan.v7.util.S.cancel(lang)) }
                }
            )
        }

        // ---- Playlists list ----
        if (showPlaylists) {
            val playlists = remember(playlistsVersion) {
                com.shabaan.v7.util.PlaylistStore.getAll(ctx)
            }
            AlertDialog(
                onDismissRequest = { showPlaylists = false },
                title = { Text(com.shabaan.v7.util.S.playlists(lang)) },
                text = {
                    if (playlists.isEmpty()) {
                        Text(com.shabaan.v7.util.S.noPlaylistsHint(lang))
                    } else {
                        Column {
                            playlists.forEach { pl ->
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            showPlaylists = false
                                            openPlaylistId = pl.id
                                        }
                                        .padding(vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.AutoMirrored.Rounded.QueueMusic,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(pl.name, style = MaterialTheme.typography.titleMedium)
                                        Text(
                                            "${pl.trackIds.size} tracks",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    IconButton(onClick = {
                                        com.shabaan.v7.util.PlaylistStore.delete(ctx, pl.id)
                                        playlistsVersion++
                                    }) {
                                        Icon(Icons.Rounded.Delete, contentDescription = "Delete playlist")
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showPlaylists = false }) { Text(com.shabaan.v7.util.S.close(lang)) }
                }
            )
        }

        // ---- Open a playlist → play its tracks ----
        openPlaylistId?.let { plId ->
            val pl = remember(plId, playlistsVersion) {
                com.shabaan.v7.util.PlaylistStore.get(ctx, plId)
            }
            val plTracks = remember(pl, state.tracks) {
                pl?.trackIds?.mapNotNull { id -> state.tracks.firstOrNull { it.id == id } } ?: emptyList()
            }
            AlertDialog(
                onDismissRequest = { openPlaylistId = null },
                title = { Text(pl?.name ?: com.shabaan.v7.util.S.playlistFallback(lang)) },
                text = {
                    if (plTracks.isEmpty()) {
                        Text(com.shabaan.v7.util.S.emptyPlaylist(lang))
                    } else {
                        Column {
                            plTracks.forEach { track ->
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            // Play within the main list so the queue works.
                                            val idx = state.tracks.indexOf(track)
                                            if (idx >= 0) {
                                                vm.play(idx)
                                                openPlaylistId = null
                                            }
                                        }
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Rounded.PlayArrow,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Text(
                                        track.name,
                                        style = MaterialTheme.typography.bodyMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(onClick = {
                                        com.shabaan.v7.util.PlaylistStore.removeTrack(ctx, plId, track.id)
                                        playlistsVersion++
                                    }) {
                                        Icon(Icons.Rounded.Close, contentDescription = "Remove")
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { openPlaylistId = null }) { Text(com.shabaan.v7.util.S.close(lang)) }
                }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TrackRow(
    track: MediaItem,
    artUri: android.net.Uri,
    isFavorite: Boolean,
    isCurrent: Boolean,
    selectionMode: Boolean,
    selected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onFav: () -> Unit,
    onAddToPlaylist: () -> Unit = {}
) {
    val lang = com.shabaan.v7.util.LocalAppLanguage.current
    Row(
        Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .background(
                if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                else androidx.compose.ui.graphics.Color.Transparent
            )
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (selectionMode) {
            Icon(
                imageVector = if (selected) Icons.Filled.CheckCircle
                else Icons.Rounded.RadioButtonUnchecked,
                contentDescription = null,
                tint = if (selected) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(end = 10.dp)
            )
        }
        AlbumArt(uri = artUri, albumId = track.albumId, size = 56.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                track.name,
                style = MaterialTheme.typography.titleMedium,
                color = if (isCurrent) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                track.artist ?: "Unknown artist",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (!selectionMode) {
            Text(
                Formatters.duration(track.duration),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            IconButton(onClick = onFav) {
                Icon(
                    imageVector = if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (isFavorite) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            // Per-track overflow menu so "Set as ringtone" is reachable directly
            // from the list — no need to open the full player or the trim screen.
            val ctxRt = LocalContext.current
            var showMenu by remember(track.id) { mutableStateOf(false) }
            var showSimChoice by remember(track.id) { mutableStateOf(false) }
            fun applyRingtone(simSlot: Int) {
                val ok = if (simSlot < 0)
                    com.shabaan.v7.util.RingtoneSetter.setAsRingtone(ctxRt, track.uri)
                else
                    com.shabaan.v7.util.RingtoneSetter.setAsRingtoneForSim(ctxRt, track.uri, simSlot)
                android.widget.Toast.makeText(
                    ctxRt,
                    if (ok) when (simSlot) {
                        0 -> "Set as ringtone for SIM 1"
                        1 -> "Set as ringtone for SIM 2"
                        else -> "Set as ringtone"
                    } else "Couldn't set ringtone",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            }
            // Decides between showing the SIM picker (dual-SIM) or setting directly.
            fun proceedAfterPhonePerm() {
                val sims = com.shabaan.v7.util.RingtoneSetter.simCount(ctxRt)
                if (sims >= 2) showSimChoice = true else applyRingtone(-1)
            }
            // Launcher to request READ_PHONE_STATE — without it we can't detect a
            // second SIM, so the SIM 1 / SIM 2 picker never appeared.
            val phonePermLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
            ) { proceedAfterPhonePerm() }
            Box {
                IconButton(onClick = { showMenu = true }) {
                    Icon(Icons.Rounded.MoreVert, contentDescription = "More")
                }
                DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                    DropdownMenuItem(
                        text = { Text(com.shabaan.v7.util.S.addToPlaylist(lang)) },
                        leadingIcon = { Icon(Icons.AutoMirrored.Rounded.PlaylistAdd, null) },
                        onClick = { showMenu = false; onAddToPlaylist() }
                    )
                    DropdownMenuItem(
                        text = { Text(com.shabaan.v7.util.S.setAsRingtone(lang)) },
                        leadingIcon = { Icon(Icons.Rounded.Notifications, null) },
                        onClick = {
                            showMenu = false
                            if (!com.shabaan.v7.util.RingtoneSetter.canWrite(ctxRt)) {
                                android.widget.Toast.makeText(
                                    ctxRt, "Allow 'modify system settings' then try again",
                                    android.widget.Toast.LENGTH_LONG
                                ).show()
                                com.shabaan.v7.util.RingtoneSetter.requestPermission(ctxRt)
                            } else if (!com.shabaan.v7.util.RingtoneSetter.hasPhoneStatePermission(ctxRt)) {
                                // Ask for phone-state first so we can detect dual SIM.
                                phonePermLauncher.launch(android.Manifest.permission.READ_PHONE_STATE)
                            } else {
                                proceedAfterPhonePerm()
                            }
                        }
                    )
                }
                if (showSimChoice) {
                    AlertDialog(
                        onDismissRequest = { showSimChoice = false },
                        title = { Text(com.shabaan.v7.util.S.ringtoneForWhich(lang)) },
                        text = { Text(com.shabaan.v7.util.S.ringtonePickSlot(lang)) },
                        confirmButton = {
                            TextButton(onClick = { showSimChoice = false; applyRingtone(0) }) {
                                Text("SIM 1")
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showSimChoice = false; applyRingtone(1) }) {
                                Text("SIM 2")
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun MiniPlayer(
    track: MediaItem,
    isPlaying: Boolean,
    progress: Float,
    onClick: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 8.dp),
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        tonalElevation = 4.dp,
        shadowElevation = 14.dp,
        onClick = onClick
    ) {
        Box(
            Modifier
                // Subtle metallic vertical sheen — top a touch brighter than bottom.
                .background(
                    androidx.compose.ui.graphics.Brush.verticalGradient(
                        listOf(
                            MaterialTheme.colorScheme.surfaceContainerHighest,
                            MaterialTheme.colorScheme.surfaceContainerHigh
                        )
                    )
                )
                .border(
                    width = 1.dp,
                    brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                        listOf(
                            BrightSilver.copy(alpha = 0.35f),
                            MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                        )
                    ),
                    shape = RoundedCornerShape(24.dp)
                )
        ) {
        Column {
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val ctx = LocalContext.current
            val repo = remember { MediaRepository(ctx) }
            // Album art with a soft silver ring for a premium framed look.
            Box(
                Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .border(
                        1.dp,
                        BrightSilver.copy(alpha = 0.30f),
                        RoundedCornerShape(14.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                AlbumArt(uri = repo.albumArtUri(track.albumId), albumId = track.albumId, size = 54.dp)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    track.name,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    track.artist ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.width(8.dp))
            // Premium play button — larger, metallic, soft elevation.
            FilledIconButton(
                onClick = onPlayPause,
                modifier = Modifier.size(48.dp),
                shape = RoundedCornerShape(16.dp),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.background
                )
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(26.dp)
                )
            }
            IconButton(onClick = onNext, modifier = Modifier.size(44.dp)) {
                Icon(
                    Icons.Rounded.SkipNext,
                    contentDescription = "Next",
                    modifier = Modifier.size(24.dp)
                )
            }
        }
        // Premium metallic progress line — brighter silver fill with a soft glow.
        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 10.dp)
                .height(3.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(progress.coerceIn(0f, 1f))
                    .clip(RoundedCornerShape(2.dp))
                    .background(
                        androidx.compose.ui.graphics.Brush.horizontalGradient(
                            listOf(PrimarySilver, BrightSilver)
                        )
                    )
            )
        }
        }
        }
    }
}

@Composable
private fun FullPlayer(
    track: MediaItem,
    state: MusicUi,
    artUri: android.net.Uri,
    onCollapse: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onSeek: (Long) -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
    onFavorite: () -> Unit
) {
    val lang = com.shabaan.v7.util.LocalAppLanguage.current
    Surface(
        Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onCollapse) {
                    Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Collapse")
                }
                Spacer(Modifier.weight(1f))
                val ctxRt = LocalContext.current
                var showTrim by remember(track.id) { mutableStateOf(false) }
                IconButton(onClick = { showTrim = true }) {
                    Icon(Icons.Rounded.ContentCut, contentDescription = "Trim")
                }
                if (showTrim) {
                    TrimDialog(
                        track = track,
                        onDismiss = { showTrim = false }
                    )
                }
                var showSimChoice by remember(track.id) { mutableStateOf(false) }
                fun applyRingtone(simSlot: Int) {
                    val ok = if (simSlot < 0)
                        com.shabaan.v7.util.RingtoneSetter.setAsRingtone(ctxRt, track.uri)
                    else
                        com.shabaan.v7.util.RingtoneSetter.setAsRingtoneForSim(ctxRt, track.uri, simSlot)
                    android.widget.Toast.makeText(
                        ctxRt,
                        if (ok) {
                            when (simSlot) {
                                0 -> "Set as ringtone for SIM 1"
                                1 -> "Set as ringtone for SIM 2"
                                else -> "Set as ringtone"
                            }
                        } else "Couldn't set ringtone",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
                IconButton(onClick = {
                    if (!com.shabaan.v7.util.RingtoneSetter.canWrite(ctxRt)) {
                        android.widget.Toast.makeText(
                            ctxRt, "Allow 'modify system settings' then try again",
                            android.widget.Toast.LENGTH_LONG
                        ).show()
                        com.shabaan.v7.util.RingtoneSetter.requestPermission(ctxRt)
                    } else {
                        val sims = com.shabaan.v7.util.RingtoneSetter.simCount(ctxRt)
                        if (sims >= 2) showSimChoice = true
                        else applyRingtone(-1)
                    }
                }) {
                    Icon(Icons.Rounded.Notifications, contentDescription = "Set as ringtone")
                }
                if (showSimChoice) {
                    AlertDialog(
                        onDismissRequest = { showSimChoice = false },
                        title = { Text(com.shabaan.v7.util.S.ringtoneForWhich(lang)) },
                        text = { Text(com.shabaan.v7.util.S.ringtonePickSlot(lang)) },
                        confirmButton = {
                            TextButton(onClick = { showSimChoice = false; applyRingtone(0) }) {
                                Text("SIM 1")
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showSimChoice = false; applyRingtone(1) }) {
                                Text("SIM 2")
                            }
                        }
                    )
                }
                IconButton(onClick = onFavorite) {
                    Icon(
                        if (track.id in state.favorites) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (track.id in state.favorites)
                            MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            AlbumArt(uri = artUri, albumId = track.albumId, size = 280.dp)
            Spacer(Modifier.height(24.dp))
            Text(
                track.name,
                style = MaterialTheme.typography.headlineMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                track.artist ?: "Unknown artist",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
            Spacer(Modifier.height(20.dp))

            Slider(
                value = if (state.duration > 0) state.position.toFloat() / state.duration else 0f,
                onValueChange = { onSeek((it * state.duration).toLong()) },
                colors = SliderDefaults.colors(
                    thumbColor = MaterialTheme.colorScheme.primary,
                    activeTrackColor = MaterialTheme.colorScheme.primary
                ),
                thumb = {
                    Box(
                        Modifier
                            .size(14.dp)
                            .clip(androidx.compose.foundation.shape.CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                    )
                },
                track = { st ->
                    SliderDefaults.Track(
                        sliderState = st,
                        modifier = Modifier.height(3.dp),
                        colors = SliderDefaults.colors(
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                            inactiveTrackColor = MaterialTheme.colorScheme.outline
                        )
                    )
                }
            )
            Row(Modifier.fillMaxWidth()) {
                Text(
                    Formatters.duration(state.position),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.weight(1f))
                Text(
                    Formatters.duration(state.duration),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(16.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onShuffle) {
                    Icon(
                        Icons.Rounded.Shuffle,
                        contentDescription = "Shuffle",
                        tint = if (state.shuffle) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onPrev) {
                    Icon(Icons.Rounded.SkipPrevious, contentDescription = "Previous", modifier = Modifier.size(40.dp))
                }
                FilledIconButton(
                    onClick = onPlayPause,
                    modifier = Modifier.size(72.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Icon(
                        imageVector = if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(40.dp)
                    )
                }
                IconButton(onClick = onNext) {
                    Icon(Icons.Rounded.SkipNext, contentDescription = "Next", modifier = Modifier.size(40.dp))
                }
                IconButton(onClick = onRepeat) {
                    Icon(
                        imageVector = if (state.repeatMode == Player.REPEAT_MODE_ONE)
                            Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        contentDescription = "Repeat",
                        tint = if (state.repeatMode != Player.REPEAT_MODE_OFF)
                            MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun TrimDialog(
    track: MediaItem,
    onDismiss: () -> Unit
) {
    val lang = com.shabaan.v7.util.LocalAppLanguage.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val durationMs = track.duration.coerceAtLeast(1000L)
    var startMs by remember { mutableFloatStateOf(0f) }
    var endMs by remember { mutableFloatStateOf(durationMs.toFloat()) }
    var saving by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = { Text(com.shabaan.v7.util.S.trimAudio(lang)) },
        text = {
            Column {
                com.shabaan.v7.ui.components.WaveformTrimmer(
                    uri = track.uri,
                    durationMs = durationMs,
                    startMs = startMs,
                    endMs = endMs,
                    onChange = { s, e -> startMs = s; endMs = e },
                    seed = track.id
                )
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth()) {
                    Text(
                        "From ${Formatters.duration(startMs.toLong())}",
                        style = MaterialTheme.typography.labelMedium
                    )
                    Spacer(Modifier.weight(1f))
                    Text(
                        "To ${Formatters.duration(endMs.toLong())}",
                        style = MaterialTheme.typography.labelMedium
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Clip length: ${Formatters.duration((endMs - startMs).toLong())}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = !saving,
                onClick = {
                    saving = true
                    scope.launch {
                        val ok = com.shabaan.v7.util.AudioTrimmer.trim(
                            ctx, track.uri, startMs.toLong(), endMs.toLong(),
                            track.name
                        )
                        saving = false
                        android.widget.Toast.makeText(
                            ctx,
                            if (ok) "Saved to Music/V7 Trimmed" else "Couldn't trim",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                        if (ok) onDismiss()
                    }
                }
            ) { Text(if (saving) "Saving…" else "Save clip") }
        },
        dismissButton = {
            TextButton(enabled = !saving, onClick = onDismiss) { Text(com.shabaan.v7.util.S.cancel(lang)) }
        }
    )
}



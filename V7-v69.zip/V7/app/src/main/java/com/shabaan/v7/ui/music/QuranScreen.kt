package com.shabaan.v7.ui.music

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.shabaan.v7.util.Formatters
import com.shabaan.v7.util.QuranApi
import com.shabaan.v7.util.QuranApi.Reciter
import com.shabaan.v7.util.QuranApi.Surah
import com.shabaan.v7.util.QuranSources
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuranScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    // ---- ExoPlayer ----
    val player = remember {
        ExoPlayer.Builder(ctx)
            .setAudioAttributes(
                androidx.media3.common.AudioAttributes.Builder()
                    .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(androidx.media3.common.C.USAGE_MEDIA)
                    .build(), true
            ).build()
    }
    DisposableEffect(Unit) { onDispose { player.release() } }

    // ---- State ----
    var surahQuery      by remember { mutableStateOf("") }
    var reciterQuery    by remember { mutableStateOf("") }
    var selectedReciter by remember { mutableStateOf(QuranApi.RECITERS.first()) }
    var playingSurah    by remember { mutableStateOf<Surah?>(null) }
    var isPlaying       by remember { mutableStateOf(false) }
    var isBuffering     by remember { mutableStateOf(false) }
    var playError       by remember { mutableStateOf<String?>(null) }
    var showPicker      by remember { mutableStateOf(false) }
    var position        by remember { mutableLongStateOf(0L) }
    var duration        by remember { mutableLongStateOf(0L) }
    var isSeeking       by remember { mutableStateOf(false) }
    var seekValue       by remember { mutableFloatStateOf(0f) }
    var downloading     by remember { mutableStateOf(false) }
    var dlProgress      by remember { mutableFloatStateOf(0f) }

    // Validate the reciter catalog at startup — only keep ones whose audio
    // actually responds, so the user never sees a broken reciter.
    var reciters by remember { mutableStateOf(QuranApi.RECITERS) }
    var loadingReciters by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        reciters = QuranApi.validateReciters()
        loadingReciters = false
        // If the currently selected reciter got filtered out, pick the first valid.
        if (reciters.isNotEmpty() && reciters.none { it.identifier == selectedReciter.identifier }) {
            selectedReciter = reciters.first()
        }
    }

    // Player listener
    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(p: Boolean) {
                isPlaying = p
                if (p) isBuffering = false
            }
            override fun onPlaybackStateChanged(s: Int) {
                isBuffering = s == Player.STATE_BUFFERING
                if (s == Player.STATE_ENDED) { isPlaying = false; isBuffering = false }
            }
            override fun onPlayerError(e: androidx.media3.common.PlaybackException) {
                isPlaying = false; isBuffering = false
                playError = "تعذّر تشغيل السورة — تحقق من الإنترنت"
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l) }
    }

    // Continuous position poll
    LaunchedEffect(player) {
        while (true) {
            val d = player.duration
            duration = if (d > 0) d else 0L
            position = player.currentPosition.coerceAtLeast(0L)
            delay(500)
        }
    }

    // Auto-clear error
    LaunchedEffect(playError) {
        if (playError != null) { delay(3000); playError = null }
    }

    fun play(surah: Surah) {
        playError = null
        isBuffering = true
        playingSurah = surah
        position = 0L; duration = 0L
        scope.launch {
            // Multi-source resolve: tries the cached/working provider first, then
            // falls back automatically. Only errors if ALL providers fail.
            val sources = QuranSources.CATALOG.firstOrNull {
                it.mp3quran == selectedReciter.identifier ||
                it.englishName == selectedReciter.englishName ||
                it.arabicName == selectedReciter.arabicName
            }
            val url: String? = if (sources != null) {
                QuranSources.resolveUrl(ctx, sources, surah.number)
            } else {
                // No mapping → use the reciter's own identifier as a single source.
                QuranApi.surahAudioUrl(surah.number, selectedReciter.identifier).toString()
            }
            if (url == null) {
                isBuffering = false
                playError = "تعذّر تشغيل السورة من كل المصادر — جرّب شيخاً آخر"
                return@launch
            }
            player.stop()
            player.setMediaItem(MediaItem.fromUri(url))
            player.prepare()
            player.playWhenReady = true
        }
    }

    val filteredSurahs = remember(surahQuery) { QuranApi.searchSurahs(surahQuery) }
    val filteredReciters = remember(reciterQuery, reciters) {
        val q = reciterQuery.trim()
        if (q.isBlank()) reciters
        else reciters.filter {
            it.arabicName.contains(q) || it.englishName.contains(q, ignoreCase = true)
        }
    }

    Column(Modifier.fillMaxSize()) {

        // Tabs: القراء / تلاوات نادرة
        var quranTab by remember { mutableIntStateOf(0) }
        TabRow(
            selectedTabIndex = quranTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.primary
        ) {
            Tab(selected = quranTab == 0, onClick = { quranTab = 0 },
                text = { Text("القرّاء") },
                icon = { Icon(Icons.Rounded.RecordVoiceOver, null, Modifier.size(18.dp)) })
            Tab(selected = quranTab == 1, onClick = { quranTab = 1 },
                text = { Text("تلاوات نادرة") },
                icon = { Icon(Icons.Rounded.History, null, Modifier.size(18.dp)) })
        }

        if (quranTab == 1) {
            RareRecitationsTab(
                player = player,
                onError = { msg -> playError = msg }
            )
            return@Column
        }

        // Search
        OutlinedTextField(
            value = surahQuery, onValueChange = { surahQuery = it },
            placeholder = { Text("ابحث عن سورة بالاسم أو الرقم…") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            trailingIcon = { if (surahQuery.isNotEmpty())
                IconButton({ surahQuery = "" }) { Icon(Icons.Rounded.Close, null) } },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            shape = RoundedCornerShape(12.dp)
        )

        // Error banner
        AnimatedVisibility(playError != null) {
            Surface(color = MaterialTheme.colorScheme.errorContainer,
                modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.ErrorOutline, null,
                        tint = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(playError ?: "",
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        // Reciter strip
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.RecordVoiceOver, null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Column(Modifier.weight(1f)) {
                Text(selectedReciter.arabicName,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (loadingReciters) Text("جاري تحميل القراء…",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                else Text("${reciters.size} قارئ متاح",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton({ showPicker = true }) { Text("تغيير الشيخ") }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))

        // Surahs list
        LazyColumn(Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = if (playingSurah != null) 150.dp else 16.dp)) {
            items(filteredSurahs, key = { it.number }) { surah ->
                val active = playingSurah?.number == surah.number
                SurahRow(
                    surah = surah,
                    isActive = active,
                    isPlaying = isPlaying && active,
                    isBuffering = isBuffering && active,
                    onClick = { play(surah) },
                    onPlayPause = { if (isPlaying) player.pause() else player.play() }
                )
            }
        }

        // ---- Mini player ----
        AnimatedVisibility(playingSurah != null, enter = fadeIn(), exit = fadeOut()) {
            playingSurah?.let { surah ->
                val dur = duration
                val pos = position
                val prog = if (dur > 0) {
                    if (isSeeking) seekValue
                    else (pos.toFloat() / dur).coerceIn(0f, 1f)
                } else 0f

                Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    tonalElevation = 8.dp, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Art / buffering
                            if (isBuffering) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp), strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.primary)
                            } else {
                                Icon(Icons.Rounded.MenuBook, null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(24.dp))
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(surah.arabicName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis)
                                Text(selectedReciter.arabicName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            // Download
                            if (downloading) {
                                CircularProgressIndicator(
                                    progress = { dlProgress },
                                    modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                            } else {
                                IconButton(onClick = {
                                    downloading = true; dlProgress = 0f
                                    scope.launch {
                                        val ok = QuranApi.downloadSurah(ctx,
                                            surah.number, surah.arabicName,
                                            selectedReciter.identifier, selectedReciter.arabicName
                                        ) { p -> dlProgress = p }
                                        downloading = false
                                        android.widget.Toast.makeText(ctx,
                                            if (ok) "✅ تم التحميل في Music/V7 Quran"
                                            else "❌ فشل التحميل",
                                            android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                }) {
                                    Icon(Icons.Rounded.Download, "تحميل",
                                        modifier = Modifier.size(18.dp))
                                }
                            }
                            // Prev
                            IconButton(enabled = surah.number > 1, onClick = {
                                QuranApi.SURAHS.getOrNull(surah.number - 2)?.let { play(it) }
                            }) { Icon(Icons.Rounded.SkipPrevious, null, Modifier.size(22.dp)) }
                            // Play/Pause
                            IconButton(onClick = {
                                if (isPlaying) player.pause() else player.play()
                            }) {
                                Icon(
                                    if (isPlaying) Icons.Rounded.Pause
                                    else Icons.Rounded.PlayArrow,
                                    null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            // Next
                            IconButton(enabled = surah.number < 114, onClick = {
                                QuranApi.SURAHS.getOrNull(surah.number)?.let { play(it) }
                            }) { Icon(Icons.Rounded.SkipNext, null, Modifier.size(22.dp)) }
                            // Close
                            IconButton(onClick = {
                                player.stop(); playingSurah = null
                                isPlaying = false; isBuffering = false
                            }) { Icon(Icons.Rounded.Close, null, Modifier.size(18.dp)) }
                        }

                        // Seek bar
                        Slider(value = prog,
                            onValueChange = { isSeeking = true; seekValue = it },
                            onValueChangeFinished = {
                                if (dur > 0) {
                                    val t = (seekValue * dur).toLong()
                                    player.seekTo(t); position = t
                                }
                                isSeeking = false
                            },
                            enabled = dur > 0,
                            modifier = Modifier.fillMaxWidth().height(24.dp))

                        Row(Modifier.fillMaxWidth()) {
                            Text(Formatters.duration(pos),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.weight(1f))
                            Text(if (dur > 0) Formatters.duration(dur) else "جاري التحميل…",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }

    // ---- Reciter picker ----
    if (showPicker) {
        AlertDialog(
            onDismissRequest = { showPicker = false; reciterQuery = "" },
            title = {
                Column {
                    Text("اختر الشيخ (${filteredReciters.size})")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = reciterQuery, onValueChange = { reciterQuery = it },
                        placeholder = { Text("ابحث عن شيخ…") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp),
                        leadingIcon = { Icon(Icons.Rounded.Search, null) }
                    )
                }
            },
            text = {
                LazyColumn(Modifier.heightIn(max = 400.dp)) {
                    items(filteredReciters, key = { it.identifier }) { rec ->
                        val chosen = selectedReciter.identifier == rec.identifier
                        Row(Modifier.fillMaxWidth()
                            .clickable {
                                selectedReciter = rec
                                reciterQuery = ""; showPicker = false
                                playingSurah?.let { play(it) }
                            }
                            .padding(vertical = 10.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            if (chosen) {
                                Icon(Icons.Rounded.Check, null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(8.dp))
                            } else Spacer(Modifier.width(24.dp))
                            Column(Modifier.weight(1f)) {
                                Text(rec.arabicName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Medium)
                                Text(rec.englishName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f))
                    }
                }
            },
            confirmButton = {
                TextButton({ showPicker = false; reciterQuery = "" }) { Text("إغلاق") }
            }
        )
    }
}

@Composable
private fun SurahRow(
    surah: Surah,
    isActive: Boolean,
    isPlaying: Boolean,
    isBuffering: Boolean,
    onClick: () -> Unit,
    onPlayPause: () -> Unit
) {
    Row(Modifier.fillMaxWidth()
        .clickable(onClick = onClick)
        .background(if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                    else Color.Transparent)
        .padding(horizontal = 16.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(36.dp).clip(RoundedCornerShape(8.dp))
            .background(if (isActive) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center) {
            Text(surah.number.toString(),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = if (isActive) MaterialTheme.colorScheme.onPrimary
                        else MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(surah.arabicName, style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = if (isActive) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onBackground)
            Text("${surah.englishName}  ·  ${surah.ayahCount} آية  ·  ${surah.revelationType}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (isActive) {
            if (isBuffering) {
                CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
            } else {
                IconButton(onClick = onPlayPause) {
                    Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        null, tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp))
                }
            }
        }
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f),
        modifier = Modifier.padding(horizontal = 16.dp))
}

@Composable
private fun RareRecitationsTab(
    player: ExoPlayer,
    onError: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    var selectedItem by remember { mutableStateOf<com.shabaan.v7.util.QuranArchive.RareItem?>(null) }
    var tracks by remember { mutableStateOf<List<com.shabaan.v7.util.QuranArchive.ArchiveTrack>>(emptyList()) }
    var loadingTracks by remember { mutableStateOf(false) }
    var playingUrl by remember { mutableStateOf<String?>(null) }
    var searchQ by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf<List<com.shabaan.v7.util.QuranArchive.RareItem>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }

    val items = if (searchResults.isNotEmpty()) searchResults
                else com.shabaan.v7.util.QuranArchive.CURATED

    // On open, auto-load real, existing items from archive.org (famous reciters)
    // so the tab isn't relying only on the guessed curated identifiers.
    LaunchedEffect(Unit) {
        searching = true
        val auto = com.shabaan.v7.util.QuranArchive.search("مصطفى إسماعيل قرآن")
        if (auto.isNotEmpty()) searchResults = auto
        searching = false
    }

    Column(Modifier.fillMaxSize()) {
        // Search archive.org
        OutlinedTextField(
            value = searchQ,
            onValueChange = { searchQ = it },
            placeholder = { Text("ابحث في الأرشيف (مثلاً: مصطفى إسماعيل)…") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            trailingIcon = {
                Row {
                    if (searchQ.isNotEmpty()) {
                        IconButton(onClick = { searchQ = ""; searchResults = emptyList() }) {
                            Icon(Icons.Rounded.Close, null)
                        }
                    }
                    IconButton(onClick = {
                        if (searchQ.isNotBlank()) {
                            searching = true
                            scope.launch {
                                searchResults = com.shabaan.v7.util.QuranArchive.search(searchQ)
                                searching = false
                            }
                        }
                    }) { Icon(Icons.Rounded.Search, "بحث") }
                }
            },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            shape = RoundedCornerShape(12.dp)
        )

        if (searching || loadingTracks) {
            Row(Modifier.fillMaxWidth().padding(8.dp),
                horizontalArrangement = Arrangement.Center) {
                CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
            }
        }

        if (selectedItem == null) {
            // List of rare items
            LazyColumn(Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 16.dp)) {
                items(items, key = { it.identifier }) { item ->
                    Card(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
                            .clickable {
                                selectedItem = item
                                loadingTracks = true
                                scope.launch {
                                    tracks = com.shabaan.v7.util.QuranArchive.tracksFor(item.identifier)
                                    loadingTracks = false
                                    if (tracks.isEmpty())
                                        onError("لا توجد ملفات في هذا التسجيل")
                                }
                            },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.History, null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.arabicName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold)
                                Text(item.description,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2)
                            }
                            Icon(Icons.Rounded.KeyboardArrowLeft, null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        } else {
            // Tracks inside the selected item
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {
                    selectedItem = null; tracks = emptyList()
                    player.stop(); playingUrl = null
                }) { Icon(Icons.Rounded.Close, "رجوع") }
                Text(selectedItem!!.arabicName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))

            LazyColumn(Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 16.dp)) {
                items(tracks, key = { it.url }) { track ->
                    val active = playingUrl == track.url
                    Row(Modifier.fillMaxWidth()
                        .clickable {
                            onError("")  // clear
                            player.stop()
                            player.setMediaItem(MediaItem.fromUri(track.url))
                            player.prepare()
                            player.playWhenReady = true
                            playingUrl = track.url
                        }
                        .background(if (active)
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                            else androidx.compose.ui.graphics.Color.Transparent)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            if (active) Icons.Rounded.VolumeUp else Icons.Rounded.PlayArrow,
                            null,
                            tint = if (active) MaterialTheme.colorScheme.primary
                                   else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(12.dp))
                        Text(track.title,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (active) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onBackground,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f),
                        modifier = Modifier.padding(horizontal = 16.dp))
                }
            }
        }
    }
}

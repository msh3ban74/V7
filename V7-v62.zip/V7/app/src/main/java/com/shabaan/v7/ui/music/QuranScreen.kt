package com.shabaan.v7.ui.music

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.shabaan.v7.util.Formatters
import com.shabaan.v7.util.QuranApi
import com.shabaan.v7.util.QuranApi.Reciter
import com.shabaan.v7.util.QuranApi.Surah
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuranScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    // ---- ExoPlayer ----
    val player = remember {
        ExoPlayer.Builder(ctx)
            .setAudioAttributes(
                androidx.media3.common.AudioAttributes.Builder()
                    .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(androidx.media3.common.C.USAGE_MEDIA)
                    .build(), true
            ).build()
    }
    DisposableEffect(Unit) { onDispose { player.release() } }

    // ---- State ----
    var surahQuery      by remember { mutableStateOf("") }
    var reciterQuery    by remember { mutableStateOf("") }
    var selectedReciter by remember { mutableStateOf(QuranApi.RECITERS.first()) }
    var playingSurah    by remember { mutableStateOf<Surah?>(null) }
    var isPlaying       by remember { mutableStateOf(false) }
    var isBuffering     by remember { mutableStateOf(false) }
    var playError       by remember { mutableStateOf<String?>(null) }
    var showPicker      by remember { mutableStateOf(false) }
    var position        by remember { mutableLongStateOf(0L) }
    var duration        by remember { mutableLongStateOf(0L) }
    var isSeeking       by remember { mutableStateOf(false) }
    var seekValue       by remember { mutableFloatStateOf(0f) }
    var downloading     by remember { mutableStateOf(false) }
    var dlProgress      by remember { mutableFloatStateOf(0f) }

    // Use only the verified-working reciter list (all confirmed on the surah CDN).
    // We intentionally don't pull the API's full audio-edition list here because
    // many of those identifiers exist only as ayah-by-ayah, not full-surah, and
    // would 404 when streamed — which is what made "only Mishary worked".
    val reciters = QuranApi.RECITERS
    val loadingReciters = false

    // Player listener
    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(p: Boolean) {
                isPlaying = p
                if (p) isBuffering = false
            }
            override fun onPlaybackStateChanged(s: Int) {
                isBuffering = s == Player.STATE_BUFFERING
                if (s == Player.STATE_ENDED) { isPlaying = false; isBuffering = false }
            }
            override fun onPlayerError(e: androidx.media3.common.PlaybackException) {
                isPlaying = false; isBuffering = false
                playError = "تعذّر تشغيل السورة — تحقق من الإنترنت"
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l) }
    }

    // Continuous position poll
    LaunchedEffect(player) {
        while (true) {
            val d = player.duration
            duration = if (d > 0) d else 0L
            position = player.currentPosition.coerceAtLeast(0L)
            delay(500)
        }
    }

    // Auto-clear error
    LaunchedEffect(playError) {
        if (playError != null) { delay(3000); playError = null }
    }

    fun play(surah: Surah) {
        playError = null; isBuffering = true
        player.stop()
        player.setMediaItem(
            MediaItem.fromUri(
                QuranApi.surahAudioUrl(surah.number, selectedReciter.identifier)
            )
        )
        player.prepare()
        player.playWhenReady = true
        playingSurah = surah
        position = 0L; duration = 0L
    }

    val filteredSurahs = remember(surahQuery) { QuranApi.searchSurahs(surahQuery) }
    val filteredReciters = remember(reciterQuery, reciters) {
        val q = reciterQuery.trim()
        if (q.isBlank()) reciters
        else reciters.filter {
            it.arabicName.contains(q) || it.englishName.contains(q, ignoreCase = true)
        }
    }

    Column(Modifier.fillMaxSize()) {

        // Search
        OutlinedTextField(
            value = surahQuery, onValueChange = { surahQuery = it },
            placeholder = { Text("ابحث عن سورة بالاسم أو الرقم…") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            trailingIcon = { if (surahQuery.isNotEmpty())
                IconButton({ surahQuery = "" }) { Icon(Icons.Rounded.Close, null) } },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            shape = RoundedCornerShape(12.dp)
        )

        // Error banner
        AnimatedVisibility(playError != null) {
            Surface(color = MaterialTheme.colorScheme.errorContainer,
                modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.ErrorOutline, null,
                        tint = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(playError ?: "",
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        // Reciter strip
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.RecordVoiceOver, null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Column(Modifier.weight(1f)) {
                Text(selectedReciter.arabicName,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (loadingReciters) Text("جاري تحميل القراء…",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                else Text("${reciters.size} قارئ متاح",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton({ showPicker = true }) { Text("تغيير الشيخ") }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))

        // Surahs list
        LazyColumn(Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = if (playingSurah != null) 150.dp else 16.dp)) {
            items(filteredSurahs, key = { it.number }) { surah ->
                val active = playingSurah?.number == surah.number
                SurahRow(
                    surah = surah,
                    isActive = active,
                    isPlaying = isPlaying && active,
                    isBuffering = isBuffering && active,
                    onClick = { play(surah) },
                    onPlayPause = { if (isPlaying) player.pause() else player.play() }
                )
            }
        }

        // ---- Mini player ----
        AnimatedVisibility(playingSurah != null, enter = fadeIn(), exit = fadeOut()) {
            playingSurah?.let { surah ->
                val dur = duration
                val pos = position
                val prog = if (dur > 0) {
                    if (isSeeking) seekValue
                    else (pos.toFloat() / dur).coerceIn(0f, 1f)
                } else 0f

                Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    tonalElevation = 8.dp, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Art / buffering
                            if (isBuffering) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp), strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.primary)
                            } else {
                                Icon(Icons.Rounded.MenuBook, null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(24.dp))
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(surah.arabicName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis)
                                Text(selectedReciter.arabicName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            // Download
                            if (downloading) {
                                CircularProgressIndicator(
                                    progress = { dlProgress },
                                    modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                            } else {
                                IconButton(onClick = {
                                    downloading = true; dlProgress = 0f
                                    scope.launch {
                                        val ok = QuranApi.downloadSurah(ctx,
                                            surah.number, surah.arabicName,
                                            selectedReciter.identifier, selectedReciter.arabicName
                                        ) { p -> dlProgress = p }
                                        downloading = false
                                        android.widget.Toast.makeText(ctx,
                                            if (ok) "✅ تم التحميل في Music/V7 Quran"
                                            else "❌ فشل التحميل",
                                            android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                }) {
                                    Icon(Icons.Rounded.Download, "تحميل",
                                        modifier = Modifier.size(18.dp))
                                }
                            }
                            // Prev
                            IconButton(enabled = surah.number > 1, onClick = {
                                QuranApi.SURAHS.getOrNull(surah.number - 2)?.let { play(it) }
                            }) { Icon(Icons.Rounded.SkipPrevious, null, Modifier.size(22.dp)) }
                            // Play/Pause
                            IconButton(onClick = {
                                if (isPlaying) player.pause() else player.play()
                            }) {
                                Icon(
                                    if (isPlaying) Icons.Rounded.Pause
                                    else Icons.Rounded.PlayArrow,
                                    null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            // Next
                            IconButton(enabled = surah.number < 114, onClick = {
                                QuranApi.SURAHS.getOrNull(surah.number)?.let { play(it) }
                            }) { Icon(Icons.Rounded.SkipNext, null, Modifier.size(22.dp)) }
                            // Close
                            IconButton(onClick = {
                                player.stop(); playingSurah = null
                                isPlaying = false; isBuffering = false
                            }) { Icon(Icons.Rounded.Close, null, Modifier.size(18.dp)) }
                        }

                        // Seek bar
                        Slider(value = prog,
                            onValueChange = { isSeeking = true; seekValue = it },
                            onValueChangeFinished = {
                                if (dur > 0) {
                                    val t = (seekValue * dur).toLong()
                                    player.seekTo(t); position = t
                                }
                                isSeeking = false
                            },
                            enabled = dur > 0,
                            modifier = Modifier.fillMaxWidth().height(24.dp))

                        Row(Modifier.fillMaxWidth()) {
                            Text(Formatters.duration(pos),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.weight(1f))
                            Text(if (dur > 0) Formatters.duration(dur) else "جاري التحميل…",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }

    // ---- Reciter picker ----
    if (showPicker) {
        AlertDialog(
            onDismissRequest = { showPicker = false; reciterQuery = "" },
            title = {
                Column {
                    Text("اختر الشيخ (${filteredReciters.size})")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = reciterQuery, onValueChange = { reciterQuery = it },
                        placeholder = { Text("ابحث عن شيخ…") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp),
                        leadingIcon = { Icon(Icons.Rounded.Search, null) }
                    )
                }
            },
            text = {
                LazyColumn(Modifier.heightIn(max = 400.dp)) {
                    items(filteredReciters, key = { it.identifier }) { rec ->
                        val chosen = selectedReciter.identifier == rec.identifier
                        Row(Modifier.fillMaxWidth()
                            .clickable {
                                selectedReciter = rec
                                reciterQuery = ""; showPicker = false
                                playingSurah?.let { play(it) }
                            }
                            .padding(vertical = 10.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            if (chosen) {
                                Icon(Icons.Rounded.Check, null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(8.dp))
                            } else Spacer(Modifier.width(24.dp))
                            Column(Modifier.weight(1f)) {
                                Text(rec.arabicName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Medium)
                                Text(rec.englishName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f))
                    }
                }
            },
            confirmButton = {
                TextButton({ showPicker = false; reciterQuery = "" }) { Text("إغلاق") }
            }
        )
    }
}

@Composable
private fun SurahRow(
    surah: Surah,
    isActive: Boolean,
    isPlaying: Boolean,
    isBuffering: Boolean,
    onClick: () -> Unit,
    onPlayPause: () -> Unit
) {
    Row(Modifier.fillMaxWidth()
        .clickable(onClick = onClick)
        .background(if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                    else Color.Transparent)
        .padding(horizontal = 16.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(36.dp).clip(RoundedCornerShape(8.dp))
            .background(if (isActive) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center) {
            Text(surah.number.toString(),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = if (isActive) MaterialTheme.colorScheme.onPrimary
                        else MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(surah.arabicName, style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = if (isActive) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onBackground)
            Text("${surah.englishName}  ·  ${surah.ayahCount} آية  ·  ${surah.revelationType}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (isActive) {
            if (isBuffering) {
                CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
            } else {
                IconButton(onClick = onPlayPause) {
                    Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        null, tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp))
                }
            }
        }
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f),
        modifier = Modifier.padding(horizontal = 16.dp))
}

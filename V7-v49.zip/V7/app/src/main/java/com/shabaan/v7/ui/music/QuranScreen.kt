package com.shabaan.v7.ui.music

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.shabaan.v7.util.QuranApi
import com.shabaan.v7.util.QuranApi.Reciter
import com.shabaan.v7.util.QuranApi.Surah

/**
 * Quran player embedded inside the Music screen.
 * Streams full surahs from the free Al-Quran Cloud CDN.
 * Platinum Silver styling, consistent with the rest of V7.
 */
@Composable
fun QuranScreen() {
    val ctx = LocalContext.current

    // Player — released on dispose, separate from the music player.
    val player = remember {
        ExoPlayer.Builder(ctx)
            .setAudioAttributes(
                androidx.media3.common.AudioAttributes.Builder()
                    .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(androidx.media3.common.C.USAGE_MEDIA)
                    .build(),
                true
            ).build()
    }
    DisposableEffect(Unit) { onDispose { player.release() } }

    var query by remember { mutableStateOf("") }
    var selectedReciter by remember { mutableStateOf(QuranApi.RECITERS.first()) }
    var playingSurah by remember { mutableStateOf<Surah?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var showReciterPicker by remember { mutableStateOf(false) }

    val filteredSurahs = remember(query) { QuranApi.searchSurahs(query) }

    fun playSurah(surah: Surah) {
        val uri = QuranApi.surahAudioUrl(surah.number, selectedReciter.identifier)
        player.stop()
        player.setMediaItem(MediaItem.fromUri(uri))
        player.prepare()
        player.play()
        playingSurah = surah
        isPlaying = true
    }

    Column(Modifier.fillMaxSize()) {

        // ---- Search bar ----
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("ابحث عن سورة…") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) {
                        Icon(Icons.Rounded.Close, null)
                    }
                }
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            shape = RoundedCornerShape(12.dp)
        )

        // ---- Reciter picker row ----
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Rounded.RecordVoiceOver,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                selectedReciter.arabicName,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = { showReciterPicker = true }) {
                Text("تغيير الشيخ")
            }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

        // ---- Surahs list ----
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = if (playingSurah != null) 90.dp else 16.dp)
        ) {
            items(filteredSurahs, key = { it.number }) { surah ->
                val isActive = playingSurah?.number == surah.number
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { playSurah(surah) }
                        .background(
                            if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                            else Color.Transparent
                        )
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Surah number badge
                    Box(
                        Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (isActive) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceVariant
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            surah.number.toString(),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isActive) MaterialTheme.colorScheme.onPrimary
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            surah.arabicName,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isActive) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            "${surah.englishName}  ·  ${surah.revelationType}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (isActive) {
                        IconButton(onClick = {
                            if (isPlaying) { player.pause(); isPlaying = false }
                            else { player.play(); isPlaying = true }
                        }) {
                            Icon(
                                if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
                HorizontalDivider(
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f),
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        }

        // ---- Mini player ----
        AnimatedVisibility(visible = playingSurah != null) {
            playingSurah?.let { surah ->
                Surface(
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    tonalElevation = 8.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Rounded.MenuBook,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                surah.arabicName,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                selectedReciter.arabicName,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = {
                            if (isPlaying) { player.pause(); isPlaying = false }
                            else { player.play(); isPlaying = true }
                        }) {
                            Icon(
                                if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = {
                            player.stop()
                            playingSurah = null
                            isPlaying = false
                        }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Stop", modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
        }
    }

    // ---- Reciter picker dialog ----
    if (showReciterPicker) {
        AlertDialog(
            onDismissRequest = { showReciterPicker = false },
            title = { Text("اختر الشيخ") },
            text = {
                LazyColumn {
                    items(QuranApi.RECITERS, key = { it.identifier }) { reciter ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedReciter = reciter
                                    showReciterPicker = false
                                    // Re-play current surah with new reciter.
                                    playingSurah?.let { playSurah(it) }
                                }
                                .padding(vertical = 12.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (selectedReciter.identifier == reciter.identifier) {
                                Icon(
                                    Icons.Rounded.Check,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                            } else {
                                Spacer(Modifier.width(26.dp))
                            }
                            Column {
                                Text(reciter.arabicName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                Text(reciter.englishName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showReciterPicker = false }) { Text("إغلاق") }
            }
        )
    }
}

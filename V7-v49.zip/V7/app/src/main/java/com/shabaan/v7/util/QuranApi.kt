package com.shabaan.v7.util

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL

/**
 * Minimal client for the free, open Al-Quran Cloud API (api.alquran.cloud).
 * No API key required. Quran audio is public domain.
 *
 * Audio CDN pattern:
 *   https://cdn.islamic.network/quran/audio/128/{reciter}/{surahNumber}{ayahNumber}.mp3
 * Full surah (continuous): use the /surah/{number}/{reciter} endpoint.
 */
object QuranApi {

    // ---- Data models ----

    data class Reciter(
        val identifier: String, // e.g. "ar.alafasy"
        val arabicName: String,
        val englishName: String
    )

    data class Surah(
        val number: Int,
        val arabicName: String,  // اسم السورة
        val englishName: String,
        val revelationType: String  // Meccan / Medinan
    )

    // ---- Static data (no network needed) ----

    val RECITERS: List<Reciter> = listOf(
        Reciter("ar.alafasy",       "مشاري العفاسي",       "Mishary Al-Afasy"),
        Reciter("ar.husary",        "محمود خليل الحصري",   "Mahmoud Khalil Al-Husary"),
        Reciter("ar.minshawi",      "محمد صديق المنشاوي",  "Muhammad Siddiq Al-Minshawi"),
        Reciter("ar.abdulbasitmurattal", "عبد الباسط عبد الصمد", "Abdul Basit Murattal"),
        Reciter("ar.abdurrahmaansudais",  "عبد الرحمن السديس",  "Abdurrahmaan As-Sudais"),
        Reciter("ar.shaatree",      "أبو بكر الشاطري",     "Abu Bakr Ash-Shaatree"),
        Reciter("ar.mahermuaiqly",  "ماهر المعيقلي",       "Maher Al-Muaiqly"),
        Reciter("ar.saoodshuraym",  "سعود الشريم",         "Sa'ood Ash-Shuraym"),
        Reciter("ar.ibrahimakhbar", "إبراهيم الأخضر",      "Ibrahim Al-Akhdar"),
        Reciter("ar.hanirifai",     "هاني الرفاعي",        "Hani Ar-Rifai"),
        Reciter("ar.muhammadjibril","محمد جبريل",          "Muhammad Jibril"),
        Reciter("ar.ahmedajamy",    "أحمد العجمي",         "Ahmad Al-Ajamy"),
        Reciter("ar.muhammadayyoub","محمد أيوب",           "Muhammad Ayyub"),
        Reciter("ar.muhammadjibreel","محمد جبريل (مرتل)", "Muhammad Jibreel (Murattal)"),
        Reciter("ar.parhizgar",     "محمد إسماعيل برهيزكار","M. Ismail Parhizgar")
    )

    val SURAHS: List<Surah> = listOf(
        Surah(1,  "الفاتحة",   "Al-Fatihah",   "Meccan"),
        Surah(2,  "البقرة",    "Al-Baqarah",   "Medinan"),
        Surah(3,  "آل عمران",  "Ali 'Imran",   "Medinan"),
        Surah(4,  "النساء",    "An-Nisa",      "Medinan"),
        Surah(5,  "المائدة",   "Al-Ma'idah",   "Medinan"),
        Surah(6,  "الأنعام",   "Al-An'am",     "Meccan"),
        Surah(7,  "الأعراف",   "Al-A'raf",     "Meccan"),
        Surah(8,  "الأنفال",   "Al-Anfal",     "Medinan"),
        Surah(9,  "التوبة",    "At-Tawbah",    "Medinan"),
        Surah(10, "يونس",      "Yunus",        "Meccan"),
        Surah(11, "هود",       "Hud",          "Meccan"),
        Surah(12, "يوسف",      "Yusuf",        "Meccan"),
        Surah(13, "الرعد",     "Ar-Ra'd",      "Medinan"),
        Surah(14, "إبراهيم",   "Ibrahim",      "Meccan"),
        Surah(15, "الحجر",     "Al-Hijr",      "Meccan"),
        Surah(16, "النحل",     "An-Nahl",      "Meccan"),
        Surah(17, "الإسراء",   "Al-Isra",      "Meccan"),
        Surah(18, "الكهف",     "Al-Kahf",      "Meccan"),
        Surah(19, "مريم",      "Maryam",       "Meccan"),
        Surah(20, "طه",        "Ta-Ha",        "Meccan"),
        Surah(21, "الأنبياء",  "Al-Anbiya",    "Meccan"),
        Surah(22, "الحج",      "Al-Hajj",      "Medinan"),
        Surah(23, "المؤمنون",  "Al-Mu'minun",  "Meccan"),
        Surah(24, "النور",     "An-Nur",       "Medinan"),
        Surah(25, "الفرقان",   "Al-Furqan",    "Meccan"),
        Surah(26, "الشعراء",   "Ash-Shu'ara",  "Meccan"),
        Surah(27, "النمل",     "An-Naml",      "Meccan"),
        Surah(28, "القصص",     "Al-Qasas",     "Meccan"),
        Surah(29, "العنكبوت",  "Al-'Ankabut",  "Meccan"),
        Surah(30, "الروم",     "Ar-Rum",       "Meccan"),
        Surah(31, "لقمان",     "Luqman",       "Meccan"),
        Surah(32, "السجدة",    "As-Sajdah",    "Meccan"),
        Surah(33, "الأحزاب",   "Al-Ahzab",     "Medinan"),
        Surah(34, "سبأ",       "Saba",         "Meccan"),
        Surah(35, "فاطر",      "Fatir",        "Meccan"),
        Surah(36, "يس",        "Ya-Sin",       "Meccan"),
        Surah(37, "الصافات",   "As-Saffat",    "Meccan"),
        Surah(38, "ص",         "Sad",          "Meccan"),
        Surah(39, "الزمر",     "Az-Zumar",     "Meccan"),
        Surah(40, "غافر",      "Ghafir",       "Meccan"),
        Surah(41, "فصلت",      "Fussilat",     "Meccan"),
        Surah(42, "الشورى",    "Ash-Shura",    "Meccan"),
        Surah(43, "الزخرف",    "Az-Zukhruf",   "Meccan"),
        Surah(44, "الدخان",    "Ad-Dukhan",    "Meccan"),
        Surah(45, "الجاثية",   "Al-Jathiyah",  "Meccan"),
        Surah(46, "الأحقاف",   "Al-Ahqaf",     "Meccan"),
        Surah(47, "محمد",      "Muhammad",     "Medinan"),
        Surah(48, "الفتح",     "Al-Fath",      "Medinan"),
        Surah(49, "الحجرات",   "Al-Hujurat",   "Medinan"),
        Surah(50, "ق",         "Qaf",          "Meccan"),
        Surah(51, "الذاريات",  "Adh-Dhariyat", "Meccan"),
        Surah(52, "الطور",     "At-Tur",       "Meccan"),
        Surah(53, "النجم",     "An-Najm",      "Meccan"),
        Surah(54, "القمر",     "Al-Qamar",     "Meccan"),
        Surah(55, "الرحمن",    "Ar-Rahman",    "Medinan"),
        Surah(56, "الواقعة",   "Al-Waqi'ah",   "Meccan"),
        Surah(57, "الحديد",    "Al-Hadid",     "Medinan"),
        Surah(58, "المجادلة",  "Al-Mujadila",  "Medinan"),
        Surah(59, "الحشر",     "Al-Hashr",     "Medinan"),
        Surah(60, "الممتحنة",  "Al-Mumtahanah","Medinan"),
        Surah(61, "الصف",      "As-Saf",       "Medinan"),
        Surah(62, "الجمعة",    "Al-Jumu'ah",   "Medinan"),
        Surah(63, "المنافقون", "Al-Munafiqun", "Medinan"),
        Surah(64, "التغابن",   "At-Taghabun",  "Medinan"),
        Surah(65, "الطلاق",    "At-Talaq",     "Medinan"),
        Surah(66, "التحريم",   "At-Tahrim",    "Medinan"),
        Surah(67, "الملك",     "Al-Mulk",      "Meccan"),
        Surah(68, "القلم",     "Al-Qalam",     "Meccan"),
        Surah(69, "الحاقة",    "Al-Haqqah",    "Meccan"),
        Surah(70, "المعارج",   "Al-Ma'arij",   "Meccan"),
        Surah(71, "نوح",       "Nuh",          "Meccan"),
        Surah(72, "الجن",      "Al-Jinn",      "Meccan"),
        Surah(73, "المزمل",    "Al-Muzzammil", "Meccan"),
        Surah(74, "المدثر",    "Al-Muddaththir","Meccan"),
        Surah(75, "القيامة",   "Al-Qiyamah",   "Meccan"),
        Surah(76, "الإنسان",   "Al-Insan",     "Medinan"),
        Surah(77, "المرسلات",  "Al-Mursalat",  "Meccan"),
        Surah(78, "النبأ",     "An-Naba",      "Meccan"),
        Surah(79, "النازعات",  "An-Nazi'at",   "Meccan"),
        Surah(80, "عبس",       "Abasa",        "Meccan"),
        Surah(81, "التكوير",   "At-Takwir",    "Meccan"),
        Surah(82, "الانفطار",  "Al-Infitar",   "Meccan"),
        Surah(83, "المطففين",  "Al-Mutaffifin","Meccan"),
        Surah(84, "الانشقاق",  "Al-Inshiqaq",  "Meccan"),
        Surah(85, "البروج",    "Al-Buruj",     "Meccan"),
        Surah(86, "الطارق",    "At-Tariq",     "Meccan"),
        Surah(87, "الأعلى",    "Al-A'la",      "Meccan"),
        Surah(88, "الغاشية",   "Al-Ghashiyah", "Meccan"),
        Surah(89, "الفجر",     "Al-Fajr",      "Meccan"),
        Surah(90, "البلد",     "Al-Balad",     "Meccan"),
        Surah(91, "الشمس",     "Ash-Shams",    "Meccan"),
        Surah(92, "الليل",     "Al-Layl",      "Meccan"),
        Surah(93, "الضحى",     "Ad-Duha",      "Meccan"),
        Surah(94, "الشرح",     "Ash-Sharh",    "Meccan"),
        Surah(95, "التين",     "At-Tin",       "Meccan"),
        Surah(96, "العلق",     "Al-'Alaq",     "Meccan"),
        Surah(97, "القدر",     "Al-Qadr",      "Meccan"),
        Surah(98, "البينة",    "Al-Bayyinah",  "Medinan"),
        Surah(99, "الزلزلة",   "Az-Zalzalah",  "Medinan"),
        Surah(100,"العاديات",  "Al-'Adiyat",   "Meccan"),
        Surah(101,"القارعة",   "Al-Qari'ah",   "Meccan"),
        Surah(102,"التكاثر",   "At-Takathur",  "Meccan"),
        Surah(103,"العصر",     "Al-'Asr",      "Meccan"),
        Surah(104,"الهمزة",    "Al-Humazah",   "Meccan"),
        Surah(105,"الفيل",     "Al-Fil",       "Meccan"),
        Surah(106,"قريش",      "Quraysh",      "Meccan"),
        Surah(107,"الماعون",   "Al-Ma'un",     "Meccan"),
        Surah(108,"الكوثر",    "Al-Kawthar",   "Meccan"),
        Surah(109,"الكافرون",  "Al-Kafirun",   "Meccan"),
        Surah(110,"النصر",     "An-Nasr",      "Medinan"),
        Surah(111,"المسد",     "Al-Masad",     "Meccan"),
        Surah(112,"الإخلاص",   "Al-Ikhlas",    "Meccan"),
        Surah(113,"الفلق",     "Al-Falaq",     "Meccan"),
        Surah(114,"الناس",     "An-Nas",       "Meccan")
    )

    /** Direct streaming URL for a full surah by a specific reciter. */
    fun surahAudioUrl(surahNumber: Int, reciterIdentifier: String): android.net.Uri {
        // Al-Quran Cloud CDN — full surah MP3 stream (no API key needed).
        val url = "https://cdn.islamic.network/quran/audio-surah/128/$reciterIdentifier/$surahNumber.mp3"
        return android.net.Uri.parse(url)
    }

    /** Search surahs by Arabic name, English name, or number. */
    fun searchSurahs(query: String): List<Surah> {
        if (query.isBlank()) return SURAHS
        val q = query.trim().lowercase()
        return SURAHS.filter { s ->
            s.arabicName.contains(q) ||
            s.englishName.lowercase().contains(q) ||
            s.number.toString() == q
        }
    }

    /** Search reciters by Arabic or English name. */
    fun searchReciters(query: String): List<Reciter> {
        if (query.isBlank()) return RECITERS
        val q = query.trim().lowercase()
        return RECITERS.filter { r ->
            r.arabicName.contains(q) || r.englishName.lowercase().contains(q)
        }
    }
}

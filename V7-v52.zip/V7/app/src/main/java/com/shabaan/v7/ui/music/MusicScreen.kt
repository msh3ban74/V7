@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.shabaan.v7.ui.music

import com.shabaan.v7.ui.theme.BrightSilver
import androidx.compose.foundation.border
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import android.content.Intent
import kotlinx.coroutines.launch
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.Share
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.media3.common.Player
import coil.compose.AsyncImage
import com.shabaan.v7.data.model.MediaItem
import com.shabaan.v7.data.repository.MediaRepository
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.shabaan.v7.ui.components.*
import com.shabaan.v7.util.Formatters

@OptIn(ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class, ExperimentalFoundationApi::class)
@Composable
fun MusicScreen(vm: MusicViewModel = hiltViewModel()) {
    val perms = rememberMediaPermissions()
    val state by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    var musicDeleteUris by remember { mutableStateOf<List<android.net.Uri>>(emptyList()) }
    // Playlist UI state.
    var addToPlaylistTrack by remember { mutableStateOf<MediaItem?>(null) }
    var showPlaylists by remember { mutableStateOf(false) }
    var openPlaylistId by remember { mutableStateOf<String?>(null) }
    var playlistsVersion by remember { mutableIntStateOf(0) }
    val musicDeleteLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.StartIntentSenderForResult()
    ) {
        vm.clearSelection()
        vm.load()
    }
    fun requestDeleteMusic(uris: List<android.net.Uri>) {
        if (uris.isEmpty()) return
        if (!com.shabaan.v7.util.FullAccess.isGranted(ctx)) {
            // Send the user to grant all-files access. Don't also fire the system
            // delete dialog here — it would pop on top and hide the grant screen.
            // Once granted, deletes below run instantly.
            android.widget.Toast.makeText(
                ctx,
                "Allow full access, then delete again — it'll be instant after that",
                android.widget.Toast.LENGTH_LONG
            ).show()
            com.shabaan.v7.util.FullAccess.request(ctx)
            return
        }
        uris.forEach { runCatching { ctx.contentResolver.delete(it, null, null) } }
        vm.clearSelection(); vm.load()
    }

    LaunchedEffect(perms.allPermissionsGranted) {
        if (perms.allPermissionsGranted) vm.ensureLoaded()
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            if (state.selectionMode) {
                MusicSelectionBar(
                    count = state.selection.size,
                    onClose = vm::clearSelection,
                    onSelectAll = vm::selectAll,
                    onShare = {
                        val sel = vm.selectedTracks()
                        if (sel.isNotEmpty()) {
                            val send = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                                type = "audio/*"
                                putParcelableArrayListExtra(
                                    Intent.EXTRA_STREAM, ArrayList(sel.map { it.uri })
                                )
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            ctx.startActivity(Intent.createChooser(send, "Share"))
                        }
                    },
                    onDelete = {
                        val sel = vm.selectedTracks()
                        if (sel.isNotEmpty()) {
                            musicDeleteUris = sel.map { it.uri }
                            requestDeleteMusic(musicDeleteUris)
                        }
                    }
                )
            } else {
                V7TopBar(
                    title = "Music",
                    subtitle = if (state.tracks.isNotEmpty())
                        "%,d tracks".format(state.tracks.size) else null,
                    actions = {
                        IconButton(onClick = { showPlaylists = true }) {
                            Icon(
                                Icons.AutoMirrored.Rounded.QueueMusic,
                                contentDescription = "Playlists"
                            )
                        }
                    }
                )
            }
            PermissionGate(perms) {
                // ---- Tabs: أغاني / قرآن ----
                var musicTab by remember { mutableStateOf(0) }
                // Pause music when user switches to the Quran tab so both players
                // don't play at the same time.
                LaunchedEffect(musicTab) {
                    if (musicTab == 1 && state.isPlaying) vm.togglePlayPause()
                }
                TabRow(
                    selectedTabIndex = musicTab,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.primary
                ) {
                    Tab(
                        selected = musicTab == 0,
                        onClick = { musicTab = 0 },
                        text = { Text("أغاني") },
                        icon = { Icon(Icons.Rounded.MusicNote, null, Modifier.size(18.dp)) }
                    )
                    Tab(
                        selected = musicTab == 1,
                        onClick = { musicTab = 1 },
                        text = { Text("القرآن الكريم") },
                        icon = { Icon(Icons.Rounded.MenuBook, null, Modifier.size(18.dp)) }
                    )
                }

                when (musicTab) {
                    1 -> QuranScreen()
                    else -> when {
                        state.loading -> LoadingState()
                        state.tracks.isEmpty() -> EmptyState("No music found")
                        else -> {
                        val repo = remember { MediaRepository(ctx) }
                        LazyColumn(
                            Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(bottom = 96.dp)
                        ) {
                            items(state.tracks, key = { it.id }) { track ->
                                TrackRow(
                                    track = track,
                                    artUri = repo.albumArtUri(track.albumId),
                                    isFavorite = track.id in state.favorites,
                                    isCurrent = state.tracks.indexOf(track) == state.currentIndex,
                                    selectionMode = state.selectionMode,
                                    selected = track.id in state.selection,
                                    onClick = {
                                        if (state.selectionMode) vm.toggleSelection(track.id)
                                        else vm.play(state.tracks.indexOf(track))
                                    },
                                    onLongClick = { vm.startSelection(track.id) },
                                    onFav = { vm.toggleFavorite(track.id) },
                                    onAddToPlaylist = { addToPlaylistTrack = track }
                                )
                            }
                        }
                        }
                    } // end inner when
                } // end when(musicTab)
            }
        }

        // Mini player — shown only on the Songs tab so it doesn't clash with
        // the Quran mini player (which lives inside QuranScreen on tab 1).
        val current = state.tracks.getOrNull(state.currentIndex)
        if (current != null && !state.expanded && musicTab == 0) {
            MiniPlayer(
                track = current,
                isPlaying = state.isPlaying,
                progress = if (state.duration > 0)
                    (state.position.toFloat() / state.duration).coerceIn(0f, 1f) else 0f,
                onClick = vm::expand,
                onPlayPause = vm::togglePlayPause,
                onNext = vm::next,
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }

        // Full player
        AnimatedVisibility(
            visible = state.expanded && current != null,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
        ) {
            if (current != null) {
                val repo = remember { MediaRepository(ctx) }
                FullPlayer(
                    track = current,
                    state = state,
                    artUri = repo.albumArtUri(current.albumId),
                    onCollapse = vm::collapse,
                    onPlayPause = vm::togglePlayPause,
                    onNext = vm::next,
                    onPrev = vm::previous,
                    onSeek = vm::seekTo,
                    onShuffle = vm::toggleShuffle,
                    onRepeat = vm::cycleRepeat,
                    onFavorite = { vm.toggleFavorite(current.id) }
                )
            }
        }

        // ---- Add to playlist picker ----
        addToPlaylistTrack?.let { track ->
            val playlists = remember(playlistsVersion) {
                com.shabaan.v7.util.PlaylistStore.getAll(ctx)
            }
            var creatingNew by remember { mutableStateOf(false) }
            var newName by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { addToPlaylistTrack = null },
                title = { Text("Add to playlist") },
                text = {
                    Column {
                        if (playlists.isEmpty() && !creatingNew) {
                            Text("No playlists yet. Create one:")
                        }
                        playlists.forEach { pl ->
                            TextButton(
                                onClick = {
                                    com.shabaan.v7.util.PlaylistStore.addTrack(ctx, pl.id, track.id)
                                    playlistsVersion++
                                    addToPlaylistTrack = null
                                    android.widget.Toast.makeText(
                                        ctx, "Added to ${pl.name}", android.widget.Toast.LENGTH_SHORT
                                    ).show()
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    "${pl.name}  (${pl.trackIds.size})",
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                        if (creatingNew) {
                            OutlinedTextField(
                                value = newName,
                                onValueChange = { newName = it },
                                singleLine = true,
                                label = { Text("Playlist name") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                },
                confirmButton = {
                    if (creatingNew) {
                        TextButton(onClick = {
                            val pl = com.shabaan.v7.util.PlaylistStore.create(ctx, newName)
                            com.shabaan.v7.util.PlaylistStore.addTrack(ctx, pl.id, track.id)
                            playlistsVersion++
                            addToPlaylistTrack = null
                            android.widget.Toast.makeText(
                                ctx, "Added to ${pl.name}", android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }) { Text("Create & add") }
                    } else {
                        TextButton(onClick = { creatingNew = true }) { Text("New playlist") }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { addToPlaylistTrack = null }) { Text("Cancel") }
                }
            )
        }

        // ---- Playlists list ----
        if (showPlaylists) {
            val playlists = remember(playlistsVersion) {
                com.shabaan.v7.util.PlaylistStore.getAll(ctx)
            }
            AlertDialog(
                onDismissRequest = { showPlaylists = false },
                title = { Text("Playlists") },
                text = {
                    if (playlists.isEmpty()) {
                        Text("No playlists yet. Use the 3-dot menu on a track to add it to a new playlist.")
                    } else {
                        Column {
                            playlists.forEach { pl ->
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            showPlaylists = false
                                            openPlaylistId = pl.id
                                        }
                                        .padding(vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.AutoMirrored.Rounded.QueueMusic,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(pl.name, style = MaterialTheme.typography.titleMedium)
                                        Text(
                                            "${pl.trackIds.size} tracks",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    IconButton(onClick = {
                                        com.shabaan.v7.util.PlaylistStore.delete(ctx, pl.id)
                                        playlistsVersion++
                                    }) {
                                        Icon(Icons.Rounded.Delete, contentDescription = "Delete playlist")
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showPlaylists = false }) { Text("Close") }
                }
            )
        }

        // ---- Open a playlist → play its tracks ----
        openPlaylistId?.let { plId ->
            val pl = remember(plId, playlistsVersion) {
                com.shabaan.v7.util.PlaylistStore.get(ctx, plId)
            }
            val plTracks = remember(pl, state.tracks) {
                pl?.trackIds?.mapNotNull { id -> state.tracks.firstOrNull { it.id == id } } ?: emptyList()
            }
            AlertDialog(
                onDismissRequest = { openPlaylistId = null },
                title = { Text(pl?.name ?: "Playlist") },
                text = {
                    if (plTracks.isEmpty()) {
                        Text("This playlist is empty.")
                    } else {
                        Column {
                            plTracks.forEach { track ->
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            // Play within the main list so the queue works.
                                            val idx = state.tracks.indexOf(track)
                                            if (idx >= 0) {
                                                vm.play(idx)
                                                openPlaylistId = null
                                            }
                                        }
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Rounded.PlayArrow,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Text(
                                        track.name,
                                        style = MaterialTheme.typography.bodyMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(onClick = {
                                        com.shabaan.v7.util.PlaylistStore.removeTrack(ctx, plId, track.id)
                                        playlistsVersion++
                                    }) {
                                        Icon(Icons.Rounded.Close, contentDescription = "Remove")
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { openPlaylistId = null }) { Text("Close") }
                }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TrackRow(
    track: MediaItem,
    artUri: android.net.Uri,
    isFavorite: Boolean,
    isCurrent: Boolean,
    selectionMode: Boolean,
    selected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onFav: () -> Unit,
    onAddToPlaylist: () -> Unit = {}
) {
    Row(
        Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .background(
                if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                else androidx.compose.ui.graphics.Color.Transparent
            )
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (selectionMode) {
            Icon(
                imageVector = if (selected) Icons.Filled.CheckCircle
                else Icons.Rounded.RadioButtonUnchecked,
                contentDescription = null,
                tint = if (selected) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(end = 10.dp)
            )
        }
        AlbumArt(uri = artUri, albumId = track.albumId, size = 56.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                track.name,
                style = MaterialTheme.typography.titleMedium,
                color = if (isCurrent) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                track.artist ?: "Unknown artist",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (!selectionMode) {
            Text(
                Formatters.duration(track.duration),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            IconButton(onClick = onFav) {
                Icon(
                    imageVector = if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (isFavorite) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            // Per-track overflow menu so "Set as ringtone" is reachable directly
            // from the list — no need to open the full player or the trim screen.
            val ctxRt = LocalContext.current
            var showMenu by remember(track.id) { mutableStateOf(false) }
            var showSimChoice by remember(track.id) { mutableStateOf(false) }
            fun applyRingtone(simSlot: Int) {
                val ok = if (simSlot < 0)
                    com.shabaan.v7.util.RingtoneSetter.setAsRingtone(ctxRt, track.uri)
                else
                    com.shabaan.v7.util.RingtoneSetter.setAsRingtoneForSim(ctxRt, track.uri, simSlot)
                android.widget.Toast.makeText(
                    ctxRt,
                    if (ok) when (simSlot) {
                        0 -> "Set as ringtone for SIM 1"
                        1 -> "Set as ringtone for SIM 2"
                        else -> "Set as ringtone"
                    } else "Couldn't set ringtone",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            }
            // Decides between showing the SIM picker (dual-SIM) or setting directly.
            fun proceedAfterPhonePerm() {
                val sims = com.shabaan.v7.util.RingtoneSetter.simCount(ctxRt)
                if (sims >= 2) showSimChoice = true else applyRingtone(-1)
            }
            // Launcher to request READ_PHONE_STATE — without it we can't detect a
            // second SIM, so the SIM 1 / SIM 2 picker never appeared.
            val phonePermLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
            ) { proceedAfterPhonePerm() }
            Box {
                IconButton(onClick = { showMenu = true }) {
                    Icon(Icons.Rounded.MoreVert, contentDescription = "More")
                }
                DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                    DropdownMenuItem(
                        text = { Text("Add to playlist") },
                        leadingIcon = { Icon(Icons.AutoMirrored.Rounded.PlaylistAdd, null) },
                        onClick = { showMenu = false; onAddToPlaylist() }
                    )
                    DropdownMenuItem(
                        text = { Text("Set as ringtone") },
                        leadingIcon = { Icon(Icons.Rounded.Notifications, null) },
                        onClick = {
                            showMenu = false
                            if (!com.shabaan.v7.util.RingtoneSetter.canWrite(ctxRt)) {
                                android.widget.Toast.makeText(
                                    ctxRt, "Allow 'modify system settings' then try again",
                                    android.widget.Toast.LENGTH_LONG
                                ).show()
                                com.shabaan.v7.util.RingtoneSetter.requestPermission(ctxRt)
                            } else if (!com.shabaan.v7.util.RingtoneSetter.hasPhoneStatePermission(ctxRt)) {
                                // Ask for phone-state first so we can detect dual SIM.
                                phonePermLauncher.launch(android.Manifest.permission.READ_PHONE_STATE)
                            } else {
                                proceedAfterPhonePerm()
                            }
                        }
                    )
                }
                if (showSimChoice) {
                    AlertDialog(
                        onDismissRequest = { showSimChoice = false },
                        title = { Text("Set ringtone for which line?") },
                        text = { Text("Choose the SIM this ringtone should ring for.") },
                        confirmButton = {
                            TextButton(onClick = { showSimChoice = false; applyRingtone(0) }) {
                                Text("SIM 1")
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showSimChoice = false; applyRingtone(1) }) {
                                Text("SIM 2")
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun MusicSelectionBar(
    count: Int,
    onClose: () -> Unit,
    onSelectAll: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 4.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onClose) {
            Icon(Icons.Rounded.Close, contentDescription = "Close")
        }
        Text(
            "$count selected",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(1f)
        )
        IconButton(onClick = onSelectAll) {
            Icon(Icons.Rounded.SelectAll, contentDescription = "Select all")
        }
        IconButton(onClick = onShare) {
            Icon(Icons.Rounded.Share, contentDescription = "Share")
        }
        IconButton(onClick = onDelete) {
            Icon(Icons.Rounded.Delete, contentDescription = "Delete")
        }
    }
}

@Composable
private fun AlbumArt(uri: android.net.Uri, albumId: Long, size: androidx.compose.ui.unit.Dp) {
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = com.shabaan.v7.ui.components.rememberThumbRequest(
                data = uri, mediaId = albumId, sizePx = 300, useOsThumb = false
            ),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Icon(
            Icons.Rounded.MusicNote,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(size / 2)
        )
    }
}

@Composable
private fun MiniPlayer(
    track: MediaItem,
    isPlaying: Boolean,
    progress: Float,
    onClick: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 8.dp)
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp)),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        tonalElevation = 3.dp,
        shadowElevation = 8.dp,
        onClick = onClick
    ) {
        Column {
        Row(
            Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val ctx = LocalContext.current
            val repo = remember { MediaRepository(ctx) }
            AlbumArt(uri = repo.albumArtUri(track.albumId), albumId = track.albumId, size = 52.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    track.name,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    track.artist ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            FilledIconButton(
                onClick = onPlayPause,
                modifier = Modifier.size(44.dp),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.background
                )
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = null
                )
            }
            IconButton(onClick = onNext) {
                Icon(Icons.Rounded.SkipNext, contentDescription = "Next")
            }
        }
        // Premium metallic progress line — a thin silver track with a brighter
        // silver fill showing playback position.
        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp)
                .padding(bottom = 8.dp)
                .height(2.dp)
                .clip(RoundedCornerShape(1.dp))
                .background(MaterialTheme.colorScheme.outline)
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(progress.coerceIn(0f, 1f))
                    .clip(RoundedCornerShape(1.dp))
                    .background(BrightSilver)
            )
        }
        }
    }
}

@Composable
private fun FullPlayer(
    track: MediaItem,
    state: MusicUi,
    artUri: android.net.Uri,
    onCollapse: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onSeek: (Long) -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
    onFavorite: () -> Unit
) {
    Surface(
        Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onCollapse) {
                    Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Collapse")
                }
                Spacer(Modifier.weight(1f))
                val ctxRt = LocalContext.current
                var showTrim by remember(track.id) { mutableStateOf(false) }
                IconButton(onClick = { showTrim = true }) {
                    Icon(Icons.Rounded.ContentCut, contentDescription = "Trim")
                }
                if (showTrim) {
                    TrimDialog(
                        track = track,
                        onDismiss = { showTrim = false }
                    )
                }
                var showSimChoice by remember(track.id) { mutableStateOf(false) }
                fun applyRingtone(simSlot: Int) {
                    val ok = if (simSlot < 0)
                        com.shabaan.v7.util.RingtoneSetter.setAsRingtone(ctxRt, track.uri)
                    else
                        com.shabaan.v7.util.RingtoneSetter.setAsRingtoneForSim(ctxRt, track.uri, simSlot)
                    android.widget.Toast.makeText(
                        ctxRt,
                        if (ok) {
                            when (simSlot) {
                                0 -> "Set as ringtone for SIM 1"
                                1 -> "Set as ringtone for SIM 2"
                                else -> "Set as ringtone"
                            }
                        } else "Couldn't set ringtone",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
                IconButton(onClick = {
                    if (!com.shabaan.v7.util.RingtoneSetter.canWrite(ctxRt)) {
                        android.widget.Toast.makeText(
                            ctxRt, "Allow 'modify system settings' then try again",
                            android.widget.Toast.LENGTH_LONG
                        ).show()
                        com.shabaan.v7.util.RingtoneSetter.requestPermission(ctxRt)
                    } else {
                        val sims = com.shabaan.v7.util.RingtoneSetter.simCount(ctxRt)
                        if (sims >= 2) showSimChoice = true
                        else applyRingtone(-1)
                    }
                }) {
                    Icon(Icons.Rounded.Notifications, contentDescription = "Set as ringtone")
                }
                if (showSimChoice) {
                    AlertDialog(
                        onDismissRequest = { showSimChoice = false },
                        title = { Text("Set ringtone for which line?") },
                        text = { Text("Choose the SIM this ringtone should ring for.") },
                        confirmButton = {
                            TextButton(onClick = { showSimChoice = false; applyRingtone(0) }) {
                                Text("SIM 1")
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showSimChoice = false; applyRingtone(1) }) {
                                Text("SIM 2")
                            }
                        }
                    )
                }
                IconButton(onClick = onFavorite) {
                    Icon(
                        if (track.id in state.favorites) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (track.id in state.favorites)
                            MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            AlbumArt(uri = artUri, albumId = track.albumId, size = 280.dp)
            Spacer(Modifier.height(24.dp))
            Text(
                track.name,
                style = MaterialTheme.typography.headlineMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                track.artist ?: "Unknown artist",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
            Spacer(Modifier.height(20.dp))

            Slider(
                value = if (state.duration > 0) state.position.toFloat() / state.duration else 0f,
                onValueChange = { onSeek((it * state.duration).toLong()) },
                colors = SliderDefaults.colors(
                    thumbColor = MaterialTheme.colorScheme.primary,
                    activeTrackColor = MaterialTheme.colorScheme.primary
                ),
                thumb = {
                    Box(
                        Modifier
                            .size(14.dp)
                            .clip(androidx.compose.foundation.shape.CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                    )
                },
                track = { st ->
                    SliderDefaults.Track(
                        sliderState = st,
                        modifier = Modifier.height(3.dp),
                        colors = SliderDefaults.colors(
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                            inactiveTrackColor = MaterialTheme.colorScheme.outline
                        )
                    )
                }
            )
            Row(Modifier.fillMaxWidth()) {
                Text(
                    Formatters.duration(state.position),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.weight(1f))
                Text(
                    Formatters.duration(state.duration),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(16.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onShuffle) {
                    Icon(
                        Icons.Rounded.Shuffle,
                        contentDescription = "Shuffle",
                        tint = if (state.shuffle) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onPrev) {
                    Icon(Icons.Rounded.SkipPrevious, contentDescription = "Previous", modifier = Modifier.size(40.dp))
                }
                FilledIconButton(
                    onClick = onPlayPause,
                    modifier = Modifier.size(72.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Icon(
                        imageVector = if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(40.dp)
                    )
                }
                IconButton(onClick = onNext) {
                    Icon(Icons.Rounded.SkipNext, contentDescription = "Next", modifier = Modifier.size(40.dp))
                }
                IconButton(onClick = onRepeat) {
                    Icon(
                        imageVector = if (state.repeatMode == Player.REPEAT_MODE_ONE)
                            Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        contentDescription = "Repeat",
                        tint = if (state.repeatMode != Player.REPEAT_MODE_OFF)
                            MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun TrimDialog(
    track: MediaItem,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val durationMs = track.duration.coerceAtLeast(1000L)
    var startMs by remember { mutableFloatStateOf(0f) }
    var endMs by remember { mutableFloatStateOf(durationMs.toFloat()) }
    var saving by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = { Text("Trim audio") },
        text = {
            Column {
                com.shabaan.v7.ui.components.WaveformTrimmer(
                    uri = track.uri,
                    durationMs = durationMs,
                    startMs = startMs,
                    endMs = endMs,
                    onChange = { s, e -> startMs = s; endMs = e },
                    seed = track.id
                )
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth()) {
                    Text(
                        "From ${Formatters.duration(startMs.toLong())}",
                        style = MaterialTheme.typography.labelMedium
                    )
                    Spacer(Modifier.weight(1f))
                    Text(
                        "To ${Formatters.duration(endMs.toLong())}",
                        style = MaterialTheme.typography.labelMedium
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Clip length: ${Formatters.duration((endMs - startMs).toLong())}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = !saving,
                onClick = {
                    saving = true
                    scope.launch {
                        val ok = com.shabaan.v7.util.AudioTrimmer.trim(
                            ctx, track.uri, startMs.toLong(), endMs.toLong(),
                            track.name
                        )
                        saving = false
                        android.widget.Toast.makeText(
                            ctx,
                            if (ok) "Saved to Music/V7 Trimmed" else "Couldn't trim",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                        if (ok) onDismiss()
                    }
                }
            ) { Text(if (saving) "Saving…" else "Save clip") }
        },
        dismissButton = {
            TextButton(enabled = !saving, onClick = onDismiss) { Text("Cancel") }
        }
    )
}

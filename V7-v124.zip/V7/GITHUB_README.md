# V7 — Premium Media Platform

**Created by Mohammed Shabaan**

V7 is a production-grade Android media app built with Kotlin, Jetpack Compose,
and Material 3 in a premium **Titanium Silver** theme (light + dark). It combines
a Video Player, Gallery, Music Player, and an encrypted Vault in one app.

---

## ▶️ How to build the APK on GitHub (no PC needed)

This repo includes a GitHub Actions workflow that builds the APK automatically
in the cloud. You do **not** need Android Studio or a computer.

### Steps

1. Make sure all the project files are uploaded to the **main** branch.
2. Go to the **Actions** tab at the top of this repository.
3. If prompted, click **"I understand my workflows, go ahead and enable them."**
4. Open the workflow named **Build V7 APK** on the left.
5. Click **Run workflow** → choose `main` → **Run workflow** (green button).
6. Wait ~3–6 minutes for the build to finish (green checkmark ✅).
7. Click the finished run, scroll down to **Artifacts**, and download
   **V7-debug-APK**.
8. Unzip it on your phone and install `app-debug.apk`
   (enable "Install from unknown sources" if Android asks).

The build runs again automatically every time you push changes to `main`.

---

## ✨ Features

- **Gallery** — Photos, Albums (by folder), and Favorites tabs with search,
  sort (date / name / size, ascending or descending), and adjustable grid size.
- **Photo viewer** — pinch & double-tap zoom, slideshow mode, swipe-down to
  dismiss, and an image-info sheet (name, size, dimensions, date).
- **Video player** — ExoPlayer with brightness (left-edge swipe), volume
  (right-edge swipe), seek (horizontal swipe), playback-speed control,
  subtitle picker, Picture-in-Picture, and **resume from where you stopped**.
- **Continue watching** — a row of unfinished videos with progress bars.
- **Music player** — background playback, media-notification controls,
  shuffle / repeat, favorites, and recently-played tracking.
- **Vault** — hide photos/videos/audio with **real AES-256-GCM encryption**
  (key stored in the Android Keystore). View and share items inside the vault
  without un-hiding them. PIN + biometric lock with an auto-lock timer.
- **Recently Deleted (trash)** — soft-delete with configurable retention
  (1–90 days) and auto-purge; restore or delete-forever.
- **Settings** — theme (System / Light / Dark), grid size, sort preferences,
  vault security, auto-lock timer, trash retention, and cache management.
- **Polish** — shimmer loading placeholders, smooth animations, empty/error
  states, and edge-to-edge Titanium Silver design.

---

## 🧱 Tech stack

Kotlin · Jetpack Compose · Material 3 · MVVM + Repository pattern ·
Hilt (DI) · Room · Coroutines + StateFlow · Media3 / ExoPlayer ·
Coil · MediaStore · Scoped Storage · Android 13+ media permissions.

- `minSdk` 26 · `targetSdk` 34 · `compileSdk` 34
- AGP 8.5.2 · Kotlin 2.0.21 · KSP 2.0.21-1.0.27 · Hilt 2.52 · Gradle 8.9

---

## 📞 Connect with the creator

- WhatsApp: https://wa.me/qr/YS7YSH7LTN4UJ1
- Facebook: https://www.facebook.com/share/1Cnq5PER4i/

# Media3 keeps everything it needs by default
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Room
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-dontwarn androidx.room.paging.**

# Keep Kotlin metadata
-keep class kotlin.Metadata { *; }

# Keep ViewModel
-keep class * extends androidx.lifecycle.ViewModel { <init>(...); }

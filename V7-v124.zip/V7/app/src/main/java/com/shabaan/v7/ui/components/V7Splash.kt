package com.shabaan.v7.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.shabaan.v7.ui.theme.V7Motion
import kotlinx.coroutines.delay

/**
 * A short, refined splash: the titanium "V7" monogram draws itself in, settles
 * with a spring, then hands off to the app. Used as a Compose overlay so it
 * works identically on every Android version.
 */
@Composable
fun V7Splash(
    onFinished: () -> Unit
) {
    val draw = remember { Animatable(0f) }
    val logoScale = remember { Animatable(0.82f) }
    val logoAlpha = remember { Animatable(0f) }
    val exitAlpha = remember { Animatable(1f) }

    LaunchedEffect(Unit) {
        logoAlpha.animateTo(1f, tween(280, easing = V7Motion.Emphasized))
        // draw the strokes
        draw.animateTo(1f, tween(620, easing = V7Motion.Emphasized))
        logoScale.animateTo(1f, V7Motion.springy())
        delay(420)
        exitAlpha.animateTo(0f, tween(320, easing = V7Motion.Standard))
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .alpha(exitAlpha.value)
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFFE9EBEF),
                        Color(0xFFC9CDD3),
                        Color(0xFF9BA2AC)
                    ),
                    start = Offset(0f, 0f),
                    end = Offset(1200f, 1600f)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(140.dp)
                .scale(logoScale.value)
                .alpha(logoAlpha.value)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val progress = draw.value

                // Metallic stroke brush
                val metal = Brush.linearGradient(
                    colors = listOf(
                        Color(0xFFFFFFFF),
                        Color(0xFF3B404A)
                    ),
                    start = Offset(w * 0.2f, 0f),
                    end = Offset(w * 0.8f, h)
                )

                // The "V" — two strokes meeting at the bottom centre
                val vLeftStart = Offset(w * 0.22f, h * 0.28f)
                val vBottom = Offset(w * 0.5f, h * 0.78f)
                val vRightEnd = Offset(w * 0.78f, h * 0.28f)

                // Left limb (drawn 0 -> 0.55)
                val pLeft = (progress / 0.55f).coerceIn(0f, 1f)
                drawLine(
                    brush = metal,
                    start = vLeftStart,
                    end = Offset(
                        vLeftStart.x + (vBottom.x - vLeftStart.x) * pLeft,
                        vLeftStart.y + (vBottom.y - vLeftStart.y) * pLeft
                    ),
                    strokeWidth = h * 0.085f,
                    cap = StrokeCap.Round
                )
                // Right limb (drawn 0.45 -> 1.0)
                val pRight = ((progress - 0.45f) / 0.55f).coerceIn(0f, 1f)
                if (pRight > 0f) {
                    drawLine(
                        brush = metal,
                        start = vBottom,
                        end = Offset(
                            vBottom.x + (vRightEnd.x - vBottom.x) * pRight,
                            vBottom.y + (vRightEnd.y - vBottom.y) * pRight
                        ),
                        strokeWidth = h * 0.085f,
                        cap = StrokeCap.Round
                    )
                }

                // The "7" accent dot/tick fades in last
                if (progress > 0.85f) {
                    val a = ((progress - 0.85f) / 0.15f).coerceIn(0f, 1f)
                    drawLine(
                        color = Color(0xFF262A32).copy(alpha = a),
                        start = Offset(w * 0.62f, h * 0.30f),
                        end = Offset(w * 0.80f, h * 0.30f),
                        strokeWidth = h * 0.05f,
                        cap = StrokeCap.Round
                    )
                    drawLine(
                        color = Color(0xFF262A32).copy(alpha = a),
                        start = Offset(w * 0.80f, h * 0.30f),
                        end = Offset(w * 0.66f, h * 0.66f),
                        strokeWidth = h * 0.05f,
                        cap = StrokeCap.Round
                    )
                }
            }
        }
    }
}

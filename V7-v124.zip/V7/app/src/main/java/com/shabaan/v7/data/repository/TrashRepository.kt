package com.shabaan.v7.data.repository

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.shabaan.v7.data.local.TrashEntity
import com.shabaan.v7.data.local.V7Database
import com.shabaan.v7.data.model.MediaItem
import com.shabaan.v7.data.model.MediaType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Soft-delete pipeline. Items are moved to an internal trash directory and
 * tracked in the [TrashEntity] table for a configurable retention period.
 */
class TrashRepository(private val context: Context) {

    private val db = V7Database.get(context)
    private val trashDir: File = File(context.filesDir, "trash").apply {
        if (!exists()) mkdirs()
    }

    val items = db.trashDao().observeAll()

    /** Copy a MediaStore item into the trash directory. Caller deletes original separately. */
    suspend fun moveToTrash(item: MediaItem): Boolean = withContext(Dispatchers.IO) {
        try {
            val cleanName = item.name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val target = File(trashDir, "${System.currentTimeMillis()}_$cleanName")
            context.contentResolver.openInputStream(item.uri)?.use { input ->
                FileOutputStream(target).use { output ->
                    input.copyTo(output, 64 * 1024)
                }
            } ?: return@withContext false

            db.trashDao().insert(
                TrashEntity(
                    originalName = item.name,
                    storedPath = target.absolutePath,
                    mimeType = item.mimeType,
                    type = item.type.name,
                    size = target.length(),
                    deletedAt = System.currentTimeMillis()
                )
            )
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Restore a trash item back into MediaStore. */
    suspend fun restore(item: TrashEntity): Boolean = withContext(Dispatchers.IO) {
        try {
            val srcFile = File(item.storedPath)
            if (!srcFile.exists()) return@withContext false

            val coll = when (item.type) {
                MediaType.VIDEO.name -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                MediaType.IMAGE.name -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                MediaType.AUDIO.name -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                else -> return@withContext false
            }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, item.originalName)
                put(MediaStore.MediaColumns.MIME_TYPE, item.mimeType)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val rel = when (item.type) {
                        MediaType.VIDEO.name -> "Movies/V7"
                        MediaType.IMAGE.name -> "Pictures/V7"
                        MediaType.AUDIO.name -> "Music/V7"
                        else -> "Download/V7"
                    }
                    put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
            }
            val newUri: Uri = context.contentResolver.insert(coll, values) ?: return@withContext false
            context.contentResolver.openOutputStream(newUri)?.use { out ->
                FileInputStream(srcFile).use { it.copyTo(out, 64 * 1024) }
            } ?: return@withContext false

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                context.contentResolver.update(newUri, values, null, null)
            }

            srcFile.delete()
            db.trashDao().deleteById(item.id)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Permanently remove a trash entry. */
    suspend fun deleteForever(item: TrashEntity): Boolean = withContext(Dispatchers.IO) {
        try {
            File(item.storedPath).delete()
            db.trashDao().deleteById(item.id)
            true
        } catch (e: Exception) { false }
    }

    /** Auto-purge anything older than [retentionDays]. */
    suspend fun purgeExpired(retentionDays: Int): Int = withContext(Dispatchers.IO) {
        val cutoff = System.currentTimeMillis() - retentionDays.toLong() * 86_400_000L
        val expired = db.trashDao().expiredBefore(cutoff)
        expired.forEach { deleteForever(it) }
        expired.size
    }

    /** Empty everything. */
    suspend fun emptyAll(): Int = withContext(Dispatchers.IO) {
        val snapshot = db.trashDao().observeAll().first()
        var count = 0
        snapshot.forEach { if (deleteForever(it)) count++ }
        count
    }
}

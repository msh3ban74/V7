package com.shabaan.v7.data.repository

import android.app.RecoverableSecurityException
import android.content.ContentValues
import android.content.Context
import android.content.IntentSender
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.FileProvider
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKey
import com.shabaan.v7.data.local.V7Database
import com.shabaan.v7.data.local.VaultItemEntity
import com.shabaan.v7.data.model.MediaItem
import com.shabaan.v7.data.model.MediaType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

sealed class VaultMoveResult {
    object Success : VaultMoveResult()
    data class NeedsUserAction(val intentSender: IntentSender) : VaultMoveResult()
    data class Error(val message: String) : VaultMoveResult()
}

/**
 * Secure storage for media items.
 *
 * Files are copied to app-private `filesDir/vault/`. When [enableEncryption] is
 * true, files are wrapped in an [EncryptedFile] (AES-256 GCM, key in Android
 * Keystore) — at rest the bytes are unreadable without device unlock.
 */
class VaultRepository(private val context: Context) {

    private val db = V7Database.get(context)
    private val vaultDir: File = File(context.filesDir, "vault").apply {
        if (!exists()) mkdirs()
    }

    /** Encrypt newly added items by default. Existing unencrypted items keep working. */
    @Volatile var enableEncryption: Boolean = true

    val vaultItems = db.vaultDao().observeAll()
    fun byType(type: MediaType) = db.vaultDao().observeByType(type.name)

    private val masterKey: MasterKey by lazy {
        MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
    }

    /**
     * Save raw bytes as a NEW encrypted item inside the vault (never leaves the
     * app). Used by in-vault photo editing and video frame capture so edited
     * media stays protected. Returns true on success.
     */
    suspend fun saveBytesToVault(
        bytes: ByteArray,
        displayName: String,
        mimeType: String,
        type: String
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val cleanName = displayName.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val ext = if (enableEncryption) ".enc" else ""
            val target = File(vaultDir, "${System.currentTimeMillis()}_$cleanName$ext")
            if (enableEncryption) {
                encryptedFile(target).openFileOutput().use { it.write(bytes) }
            } else {
                FileOutputStream(target).use { it.write(bytes) }
            }
            db.vaultDao().insert(
                VaultItemEntity(
                    originalName = displayName,
                    storedPath = target.absolutePath,
                    mimeType = mimeType,
                    type = type,
                    size = target.length(),
                    duration = 0L,
                    addedAt = System.currentTimeMillis(),
                    encrypted = enableEncryption
                )
            )
            true
        } catch (e: Exception) {
            android.util.Log.e("VaultEdit", "saveBytesToVault failed: ${e.message}")
            false
        }
    }

    private fun encryptedFile(file: File): EncryptedFile =
        EncryptedFile.Builder(
            context,
            file,
            masterKey,
            EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
        ).build()

    /**
     * Back up the WHOLE vault to a single .v7vault file (a ZIP) at [destUri].
     * Contains every encrypted file in vault/ plus a manifest.json describing
     * each item. The bytes stay encrypted exactly as they are on disk, so the
     * backup is only readable by V7 on a device with the same master key… so we
     * also store the raw file so restore works on a fresh install. Returns the
     * number of items backed up, or -1 on failure.
     */
    suspend fun exportVault(destUri: Uri): Int = withContext(Dispatchers.IO) {
        try {
            val items = db.vaultDao().getAllSync()
            val out = context.contentResolver.openOutputStream(destUri) ?: return@withContext -1
            java.util.zip.ZipOutputStream(out).use { zip ->
                // 1) manifest.json — one line per item (pipe-separated fields).
                val sb = StringBuilder()
                items.forEach { it2 ->
                    val storedName = File(it2.storedPath).name
                    // name|mime|type|size|duration|addedAt|encrypted|storedFileName
                    sb.append(it2.originalName.replace("|", "_")).append("|")
                        .append(it2.mimeType).append("|")
                        .append(it2.type).append("|")
                        .append(it2.size).append("|")
                        .append(it2.duration).append("|")
                        .append(it2.addedAt).append("|")
                        .append(it2.encrypted).append("|")
                        .append(storedName).append("\n")
                }
                zip.putNextEntry(java.util.zip.ZipEntry("manifest.txt"))
                zip.write(sb.toString().toByteArray())
                zip.closeEntry()
                // 2) every stored (still-encrypted) file under files/.
                items.forEach { it2 ->
                    val f = File(it2.storedPath)
                    if (f.exists()) {
                        zip.putNextEntry(java.util.zip.ZipEntry("files/${f.name}"))
                        FileInputStream(f).use { input -> input.copyTo(zip, 64 * 1024) }
                        zip.closeEntry()
                    }
                }
            }
            items.size
        } catch (e: Exception) {
            android.util.Log.e("VaultBackup", "export failed: ${e.message}")
            -1
        }
    }

    /**
     * Restore a .v7vault backup created by [exportVault]. Copies the stored files
     * back into vault/ and re-inserts the DB rows. Strictly additive — existing
     * vault items are kept. Returns number restored, or -1 on failure.
     */
    suspend fun importVault(srcUri: Uri): Int = withContext(Dispatchers.IO) {
        try {
            val input = context.contentResolver.openInputStream(srcUri) ?: return@withContext -1
            // Read everything into memory maps first (manifest + file bytes).
            var manifest = ""
            val fileBytes = HashMap<String, ByteArray>()
            java.util.zip.ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val name = entry.name
                    val bytes = zip.readBytes()
                    when {
                        name == "manifest.txt" -> manifest = String(bytes)
                        name.startsWith("files/") -> fileBytes[name.removePrefix("files/")] = bytes
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
            if (manifest.isBlank()) return@withContext -1
            var restored = 0
            manifest.lineSequence().forEach { line ->
                if (line.isBlank()) return@forEach
                val p = line.split("|")
                if (p.size < 8) return@forEach
                val storedName = p[7]
                val bytes = fileBytes[storedName] ?: return@forEach
                // Write the file back into vault/ under a fresh unique name.
                val target = File(vaultDir, "${System.currentTimeMillis()}_$storedName")
                FileOutputStream(target).use { it.write(bytes) }
                db.vaultDao().insert(
                    VaultItemEntity(
                        originalName = p[0],
                        storedPath = target.absolutePath,
                        mimeType = p[1],
                        type = p[2],
                        size = p[3].toLongOrNull() ?: target.length(),
                        duration = p[4].toLongOrNull() ?: 0L,
                        addedAt = p[5].toLongOrNull() ?: System.currentTimeMillis(),
                        encrypted = p[6].toBoolean()
                    )
                )
                restored++
            }
            restored
        } catch (e: Exception) {
            android.util.Log.e("VaultBackup", "import failed: ${e.message}")
            -1
        }
    }

    /** Pull media item bytes into the vault directory and remove from MediaStore. */
    suspend fun moveToVault(item: MediaItem): VaultMoveResult = withContext(Dispatchers.IO) {
        try {
            val cleanName = item.name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val ext = if (enableEncryption) ".enc" else ""
            val target = File(vaultDir, "${System.currentTimeMillis()}_$cleanName$ext")

            val source = context.contentResolver.openInputStream(item.uri)
                ?: return@withContext VaultMoveResult.Error("Source unreadable")

            source.use { input ->
                if (enableEncryption) {
                    encryptedFile(target).openFileOutput().use { output ->
                        input.copyTo(output, 64 * 1024)
                    }
                } else {
                    FileOutputStream(target).use { output ->
                        input.copyTo(output, 64 * 1024)
                    }
                }
            }

            db.vaultDao().insert(
                VaultItemEntity(
                    originalName = item.name,
                    storedPath = target.absolutePath,
                    mimeType = item.mimeType,
                    type = item.type.name,
                    size = target.length(),
                    duration = item.duration,
                    addedAt = System.currentTimeMillis(),
                    encrypted = enableEncryption
                )
            )

            try {
                val rows = context.contentResolver.delete(item.uri, null, null)
                if (rows <= 0) VaultMoveResult.Error("Original could not be removed")
                else VaultMoveResult.Success
            } catch (e: SecurityException) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val pending = MediaStore.createDeleteRequest(
                        context.contentResolver,
                        listOf(item.uri)
                    )
                    VaultMoveResult.NeedsUserAction(pending.intentSender)
                } else if (e is RecoverableSecurityException) {
                    VaultMoveResult.NeedsUserAction(e.userAction.actionIntent.intentSender)
                } else {
                    VaultMoveResult.Error(e.message ?: "Permission denied")
                }
            }
        } catch (e: Exception) {
            VaultMoveResult.Error(e.message ?: "Unknown error")
        }
    }

    /** Restore a vault item back to public MediaStore. */
    suspend fun restore(item: VaultItemEntity): Boolean = withContext(Dispatchers.IO) {
        try {
            val srcFile = File(item.storedPath)
            if (!srcFile.exists()) return@withContext false

            val coll = when (item.type) {
                MediaType.VIDEO.name -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                MediaType.IMAGE.name -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                MediaType.AUDIO.name -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                else -> return@withContext false
            }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, item.originalName)
                put(MediaStore.MediaColumns.MIME_TYPE, item.mimeType)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val rel = when (item.type) {
                        MediaType.VIDEO.name -> "Movies/V7"
                        MediaType.IMAGE.name -> "Pictures/V7"
                        MediaType.AUDIO.name -> "Music/V7"
                        else -> "Download/V7"
                    }
                    put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
            }
            val newUri = context.contentResolver.insert(coll, values) ?: return@withContext false
            context.contentResolver.openOutputStream(newUri)?.use { out ->
                if (item.encrypted) {
                    encryptedFile(srcFile).openFileInput().use { it.copyTo(out, 64 * 1024) }
                } else {
                    FileInputStream(srcFile).use { it.copyTo(out, 64 * 1024) }
                }
            } ?: return@withContext false

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                context.contentResolver.update(newUri, values, null, null)
            }

            srcFile.delete()
            db.vaultDao().deleteById(item.id)
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun deletePermanently(item: VaultItemEntity): Boolean = withContext(Dispatchers.IO) {
        try {
            File(item.storedPath).delete()
            db.vaultDao().deleteById(item.id)
            true
        } catch (e: Exception) { false }
    }

    /** Returns a content URI to share. Only safe for *unencrypted* items. */
    fun uriFor(item: VaultItemEntity): Uri? {
        if (item.encrypted) return null
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            File(item.storedPath)
        )
    }

    /** Fires the system share sheet for the given (already-resolved) content uris. */
    fun shareUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val intent = if (uris.size == 1) {
            android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                putExtra(android.content.Intent.EXTRA_STREAM, uris.first())
            }
        } else {
            android.content.Intent(android.content.Intent.ACTION_SEND_MULTIPLE).apply {
                putParcelableArrayListExtra(
                    android.content.Intent.EXTRA_STREAM,
                    ArrayList(uris)
                )
            }
        }
        intent.type = "*/*"
        intent.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val chooser = android.content.Intent.createChooser(intent, "Share")
        chooser.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    /**
     * Decrypt an encrypted vault item to a temp file for viewing.
     * The caller must delete the returned file when done.
     */
    suspend fun materializeForViewing(item: VaultItemEntity): File? = withContext(Dispatchers.IO) {
        materializeOrThrow(item)
    }

    /**
     * Same as materializeForViewing but throws with a readable message, so the
     * viewer can show *why* a file failed to open instead of silently doing
     * nothing. materializeForViewing wraps this and returns null on failure.
     */
    suspend fun materializeOrThrow(item: VaultItemEntity): File? = withContext(Dispatchers.IO) {
        if (!item.encrypted) {
            val f = File(item.storedPath)
            return@withContext if (f.exists()) f else null
        }
        val src = File(item.storedPath)
        if (!src.exists()) throw IllegalStateException("الملف المشفّر غير موجود: ${src.absolutePath}")
        val nameExt = item.originalName.substringAfterLast('.', "")
        val storedExt = src.name.substringAfterLast('.', "")
        val ext = when {
            nameExt.isNotEmpty() -> ".$nameExt"
            storedExt.isNotEmpty() -> ".$storedExt"
            item.type == MediaType.VIDEO.name -> ".mp4"
            item.type == MediaType.IMAGE.name -> ".jpg"
            else -> ".mp3"
        }
        val tmp = File(context.cacheDir, "vault_view_${item.id}$ext")
        if (tmp.exists() && tmp.length() > 0) return@withContext tmp
        val part = File(context.cacheDir, "vault_view_${item.id}$ext.part")
        if (part.exists()) part.delete()
        encryptedFile(src).openFileInput().use { input ->
            FileOutputStream(part).use { output -> input.copyTo(output, 64 * 1024) }
        }
        if (part.length() <= 0) { part.delete(); throw IllegalStateException("فك التشفير أنتج ملفاً فارغاً") }
        part.renameTo(tmp)
        tmp
    }

    suspend fun viewerUri(item: VaultItemEntity): Uri? {
        val file = materializeForViewing(item) ?: return null
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
    }

    /**
     * Returns the decrypted file directly (not a content:// uri). Coil and
     * ExoPlayer read a real file path more reliably than a FileProvider uri,
     * which avoids the "audio plays but no video / image won't open" issue.
     */
    suspend fun viewerFile(item: VaultItemEntity): File? = materializeForViewing(item)
}

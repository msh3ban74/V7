package com.shabaan.v7.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import com.shabaan.v7.ui.theme.V7Motion

/**
 * A clickable that springs/scales on press AND fires a light haptic tick.
 * This single touch is what makes the UI feel alive and physical — use it on
 * cards, tiles, and custom buttons instead of a plain `clickable`.
 */
@Composable
fun Modifier.premiumClick(
    enabled: Boolean = true,
    pressedScale: Float = 0.96f,
    haptic: Boolean = true,
    onClick: () -> Unit
): Modifier {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val feedback = LocalHapticFeedback.current
    val scale by animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = V7Motion.springy(),
        label = "premiumClickScale"
    )
    return this
        .scale(scale)
        .clickable(
            interactionSource = interaction,
            indication = ripple(),
            enabled = enabled
        ) {
            if (haptic) feedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onClick()
        }
}

/**
 * Press-scale only (no click handler) — for items that already have a
 * combinedClickable elsewhere but still want the physical press feel.
 */
@Composable
fun Modifier.pressScale(
    interaction: MutableInteractionSource,
    pressedScale: Float = 0.96f
): Modifier {
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = V7Motion.springy(),
        label = "pressScale"
    )
    return this.scale(scale)
}

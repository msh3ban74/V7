package com.shabaan.v7.util

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import coil.ImageLoader
import coil.decode.DataSource
import coil.decode.ImageSource
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.fetch.SourceResult
import coil.request.Options
import coil.size.pxOrElse
import okio.Path.Companion.toOkioPath

/**
 * A Coil [Fetcher] that pulls thumbnails straight from the Android OS thumbnail
 * cache (MediaStore). The OS pre-generates and caches these, so loading is
 * near-instant and doesn't re-decode the full image or re-extract a video frame
 * on every scroll.
 *
 * It returns the thumbnail as an encoded JPEG *source* (not a ready Drawable),
 * which lets Coil persist it to its disk cache. That means each thumbnail is
 * produced **once** and then reused forever — exactly the smooth, no-reload
 * behaviour of the stock gallery.
 */
data class ThumbKey(
    val mediaId: Long,
    val isVideo: Boolean
)

class MediaStoreThumbnailFetcher(
    private val context: Context,
    private val key: ThumbKey,
    private val options: Options
) : Fetcher {

    override suspend fun fetch(): FetchResult? {
        // Videos: cap the requested thumbnail smaller than photos. The OS video
        // thumbnail is expensive to produce, and a grid cell never needs more
        // than its actual on-screen pixel size. We honour the requested size and
        // just clamp the upper bound: videos cap lower than photos because frame
        // extraction is costly and video cells are typically small.
        val cap = if (key.isVideo) 160 else 320
        val w = options.size.width.pxOrElse { cap }.coerceAtMost(cap)
        val h = options.size.height.pxOrElse { cap }.coerceAtMost(cap)
        // Lower floor (64) so tiny 6-column cells don't over-generate.
        val ww = w.coerceAtLeast(64)
        val hh = h.coerceAtLeast(64)
        val size = Size(ww, hh)
        val bucket = maxOf(ww, hh) // size bucket for the on-disk store

        // FAST PATH: if we already generated this thumbnail once, read the plain
        // JPG straight from our local thumbnail store. This is what makes the app
        // as fast as the stock gallery — no frame extraction, just a file decode.
        ThumbnailStore.get(context, key.mediaId, bucket)?.let { cached ->
            return SourceResult(
                source = ImageSource(cached.toOkioPath(), okio.FileSystem.SYSTEM),
                mimeType = "image/jpeg",
                dataSource = DataSource.DISK
            )
        }

        // SLOW PATH (first time only): ask the OS to produce the thumbnail.
        val bmp: Bitmap = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val uri = if (key.isVideo)
                    ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, key.mediaId)
                else
                    ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, key.mediaId)
                context.contentResolver.loadThumbnail(uri, size, null)
            } else {
                @Suppress("DEPRECATION")
                if (key.isVideo) {
                    MediaStore.Video.Thumbnails.getThumbnail(
                        context.contentResolver, key.mediaId,
                        MediaStore.Video.Thumbnails.MINI_KIND, null
                    )
                } else {
                    MediaStore.Images.Thumbnails.getThumbnail(
                        context.contentResolver, key.mediaId,
                        MediaStore.Images.Thumbnails.MINI_KIND, null
                    )
                }
            }
        } catch (e: Exception) {
            return null
        } ?: return null

        // Persist the generated thumbnail to our local store as a JPG — so every
        // future load takes the fast path above.
        val saved = ThumbnailStore.put(context, key.mediaId, bucket, bmp, quality = 80)
        if (!bmp.isRecycled) bmp.recycle()

        return saved?.let {
            SourceResult(
                source = ImageSource(it.toOkioPath(), okio.FileSystem.SYSTEM),
                mimeType = "image/jpeg",
                dataSource = DataSource.DISK
            )
        }
    }

    class Factory(private val context: Context) : Fetcher.Factory<ThumbKey> {
        override fun create(data: ThumbKey, options: Options, imageLoader: ImageLoader): Fetcher =
            MediaStoreThumbnailFetcher(context, data, options)
    }
}

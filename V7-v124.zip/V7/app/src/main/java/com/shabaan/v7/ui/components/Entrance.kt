package com.shabaan.v7.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import com.shabaan.v7.ui.theme.V7Motion

/**
 * Fades + lifts a grid/list cell into place on first composition, with a small
 * stagger based on its index. The orchestrated reveal is a hallmark of polished
 * apps. Kept cheap: a single Animatable per cell, only on first appearance.
 */
@Composable
fun Modifier.entrance(index: Int): Modifier {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        // Cap the stagger so long lists don't feel slow.
        val delay = (index % 12) * 28L
        kotlinx.coroutines.delay(delay)
        progress.animateTo(1f, V7Motion.spec(V7Motion.Medium))
    }
    val p = progress.value
    return this
        .alpha(p)
        .graphicsLayer {
            translationY = (1f - p) * 36f
            val s = 0.94f + 0.06f * p
            scaleX = s
            scaleY = s
        }
}

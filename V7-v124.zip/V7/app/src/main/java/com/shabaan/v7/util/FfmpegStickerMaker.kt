package com.shabaan.v7.util

import android.content.Context
import android.net.Uri

/**
 * FFmpeg-based sticker generation was planned here, but the ffmpeg-kit library
 * was retired upstream and is no longer resolvable from Maven, so it can't be
 * bundled. This object is kept as a thin, dependency-free placeholder so callers
 * compile unchanged; [create] always returns null, which makes
 * [StickerMaker.createStickerSmart] fall back to the built-in
 * [AnimatedWebpEncoder] — that path produces a genuine animated WebP too.
 */
object FfmpegStickerMaker {

    enum class FitMode { FIT, FILL, CENTER }

    /** No FFmpeg library bundled, so this is always false. */
    fun isAvailable(): Boolean = false

    /** Always null — callers fall back to the built-in animated WebP encoder. */
    suspend fun create(
        context: Context,
        input: Uri,
        startMs: Long,
        endMs: Long,
        fit: FitMode
    ): java.io.File? = null
}

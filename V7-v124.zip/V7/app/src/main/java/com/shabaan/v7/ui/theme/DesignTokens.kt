package com.shabaan.v7.ui.theme

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.ui.unit.dp

/**
 * Centralised design tokens. A consistent motion/spacing/elevation language is
 * the difference between "an app" and "a product". Everything here is tuned for
 * a refined, weighty, metallic feel.
 */
object V7Motion {
    // Signature easing — a confident ease-out used across the app.
    val Emphasized = CubicBezierEasing(0.2f, 0.0f, 0.0f, 1.0f)
    val Standard = CubicBezierEasing(0.4f, 0.0f, 0.2f, 1.0f)

    const val Fast = 180
    const val Medium = 320
    const val Slow = 520

    fun <T> spec(durationMs: Int = Medium) =
        tween<T>(durationMillis = durationMs, easing = Emphasized)

    // Spring for press / scale interactions — slightly bouncy but controlled.
    fun <T> springy() = spring<T>(
        dampingRatio = 0.62f,
        stiffness = Spring.StiffnessMediumLow
    )

    fun <T> gentle() = spring<T>(
        dampingRatio = Spring.DampingRatioNoBouncy,
        stiffness = Spring.StiffnessLow
    )
}

object V7Space {
    val xxs = 2.dp
    val xs = 4.dp
    val sm = 8.dp
    val md = 12.dp
    val lg = 16.dp
    val xl = 24.dp
    val xxl = 32.dp
    val huge = 48.dp
}

object V7Elevation {
    val flat = 0.dp
    val card = 1.dp
    val raised = 3.dp
    val floating = 8.dp
    val modal = 16.dp
}

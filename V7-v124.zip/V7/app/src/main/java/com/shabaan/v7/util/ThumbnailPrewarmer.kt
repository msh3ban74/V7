package com.shabaan.v7.util

import android.content.Context
import coil.Coil
import coil.request.ImageRequest
import com.shabaan.v7.data.repository.MediaRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Warms the thumbnail cache in the background so the gallery/video grids feel
 * instant — like the stock gallery, which pre-generates thumbnails when media
 * is captured.
 *
 * This runs ONCE per process, quietly, off the main thread, right after the app
 * starts. It loads every image + video and enqueues a Coil request for each, so
 * the thumbnails are decoded and written to the persistent disk cache before the
 * user ever opens a screen. Because Coil keys are stable ("v7_thumb_<id>_<size>")
 * and the disk cache survives restarts, after the first warm-up scrolling is
 * effectively free forever.
 *
 * It deliberately does NOT block app startup (the app still opens in
 * milliseconds) and uses a low-priority background scope.
 */
object ThumbnailPrewarmer {

    private val started = AtomicBoolean(false)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** Grid thumbnail sizes used by the app, so we warm exactly what's shown. */
    private const val VIDEO_SIZE = 200
    private const val PHOTO_SIZE = 300

    fun warm(context: Context) {
        // Only ever run once per process.
        if (!started.compareAndSet(false, true)) return

        val appContext = context.applicationContext
        scope.launch {
            try {
                val repo = MediaRepository(appContext)
                val loader = Coil.imageLoader(appContext)

                // Videos first (they're the slowest to extract, so warm them
                // ahead of time for the biggest perceived win).
                val videos = runCatching { repo.loadVideos() }.getOrDefault(emptyList())
                for (item in videos) {
                    val req = ImageRequest.Builder(appContext)
                        .data(ThumbKey(mediaId = item.id, isVideo = true))
                        .size(VIDEO_SIZE)
                        .memoryCacheKey("v7_thumb_${item.id}_$VIDEO_SIZE")
                        .diskCacheKey("v7_thumb_${item.id}_$VIDEO_SIZE")
                        .build()
                    loader.enqueue(req)
                }

                // Then images.
                val images = runCatching { repo.loadImages() }.getOrDefault(emptyList())
                for (item in images) {
                    val req = ImageRequest.Builder(appContext)
                        .data(ThumbKey(mediaId = item.id, isVideo = false))
                        .size(PHOTO_SIZE)
                        .memoryCacheKey("v7_thumb_${item.id}_$PHOTO_SIZE")
                        .diskCacheKey("v7_thumb_${item.id}_$PHOTO_SIZE")
                        .build()
                    loader.enqueue(req)
                }
            } catch (_: Exception) {
                // Prewarming is best-effort; never crash the app for it.
            }
        }
    }
}

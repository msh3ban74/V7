package com.shabaan.v7.data.repository

import com.shabaan.v7.data.model.MediaItem
import com.shabaan.v7.data.model.MediaType

/**
 * Smart-album detection + library statistics for the Gallery.
 *
 * Pure, allocation-light functions over an already-loaded media list — no
 * MediaStore queries here, so they're cheap to call from the UI layer and don't
 * touch the existing loading / search / album-grouping code paths.
 */
object SmartAlbums {

    /** A recognised category with the items that fall under it. */
    data class SmartAlbum(
        val key: String,
        val title: String,
        val items: List<MediaItem>
    ) {
        val cover: MediaItem? get() = items.firstOrNull()
        val count: Int get() = items.size
    }

    /**
     * Detection rules. Each rule matches against the lowercased relative path
     * (and, for screenshots, the file name too). Order matters: the first rule
     * that matches wins, so more specific folders come first.
     */
    private data class Rule(
        val key: String,
        val title: String,
        val matches: (path: String, name: String) -> Boolean
    )

    private val RULES: List<Rule> = listOf(
        Rule("camera", "الكاميرا") { p, _ -> "dcim/camera" in p || p.endsWith("/camera/") || "/camera/" in p },
        Rule("screenshots", "لقطات الشاشة") { p, n ->
            "screenshot" in p || "screen_shots" in p || n.startsWith("screenshot")
        },
        Rule("whatsapp_images", "صور واتساب") { p, _ ->
            "whatsapp" in p && ("images" in p || "image" in p)
        },
        Rule("whatsapp_videos", "فيديوهات واتساب") { p, _ ->
            "whatsapp" in p && ("video" in p)
        },
        Rule("telegram", "تيليجرام") { p, _ -> "telegram" in p },
        Rule("instagram", "إنستغرام") { p, _ -> "instagram" in p },
        Rule("facebook", "فيسبوك") { p, _ -> "facebook" in p || "/fb/" in p },
        Rule("downloads", "التنزيلات") { p, _ -> "download" in p }
    )

    /**
     * Builds the smart albums present in [items]. Only categories that actually
     * have content are returned, in the rule order above. An item lands in the
     * FIRST rule it matches, so it never appears in two smart albums.
     */
    fun detect(items: List<MediaItem>): List<SmartAlbum> {
        if (items.isEmpty()) return emptyList()
        val buckets = LinkedHashMap<String, MutableList<MediaItem>>()
        for (item in items) {
            val path = (item.relativePath ?: "").lowercase()
            val name = item.name.lowercase()
            val rule = RULES.firstOrNull { it.matches(path, name) } ?: continue
            buckets.getOrPut(rule.key) { mutableListOf() }.add(item)
        }
        // Emit in rule order, skipping empty categories.
        return RULES.mapNotNull { rule ->
            buckets[rule.key]?.takeIf { it.isNotEmpty() }?.let {
                SmartAlbum(rule.key, rule.title, it)
            }
        }
    }

    /** Library statistics computed from a combined media list. */
    data class Stats(
        val photos: Int,
        val videos: Int,
        val totalBytes: Long
    )

    fun stats(images: List<MediaItem>, videos: List<MediaItem>): Stats =
        Stats(
            photos = images.size,
            videos = videos.size,
            totalBytes = images.sumOf { it.size } + videos.sumOf { it.size }
        )
}

package com.shabaan.v7.util

import android.os.CountDownTimer
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf

/**
 * Global sleep timer. The user sets a duration (e.g. before sleeping); when it
 * elapses, [onFinish] runs — the app stops playback and closes itself.
 *
 * State is observable so the UI can show the remaining time / active state.
 */
object SleepTimer {

    /** Remaining milliseconds, or 0 when inactive. Observable by Compose. */
    val remainingMs = mutableLongStateOf(0L)

    /** Whether a timer is currently counting down. Observable by Compose. */
    val isActive = mutableStateOf(false)

    private var timer: CountDownTimer? = null
    private var onFinishCallback: (() -> Unit)? = null

    /** Sets the callback invoked when the timer reaches zero (e.g. finish the app). */
    fun setOnFinish(callback: () -> Unit) {
        onFinishCallback = callback
    }

    /** Starts (or restarts) the sleep timer for [minutes]. */
    fun start(minutes: Int) {
        cancel()
        if (minutes <= 0) return
        val total = minutes * 60_000L
        isActive.value = true
        remainingMs.longValue = total
        timer = object : CountDownTimer(total, 1000L) {
            override fun onTick(msLeft: Long) {
                remainingMs.longValue = msLeft
            }
            override fun onFinish() {
                remainingMs.longValue = 0L
                isActive.value = false
                onFinishCallback?.invoke()
            }
        }.also { it.start() }
    }

    /** Cancels any running timer. */
    fun cancel() {
        timer?.cancel()
        timer = null
        isActive.value = false
        remainingMs.longValue = 0L
    }
}

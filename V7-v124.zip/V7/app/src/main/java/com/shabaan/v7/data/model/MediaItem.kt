package com.shabaan.v7.data.model

import android.net.Uri
import androidx.compose.runtime.Immutable

enum class MediaType { VIDEO, IMAGE, AUDIO }

/**
 * Marked @Immutable so Compose treats it as a stable parameter. Without this,
 * the `Uri` field (a type Compose can't prove stable) makes the whole class
 * unstable, which forces every grid cell to recompose on every scroll frame —
 * a major source of scroll jank. All fields here are effectively read-only
 * value data, so @Immutable is correct and safe.
 */
@Immutable
data class MediaItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    val mimeType: String,
    val size: Long,
    val dateAdded: Long,
    val duration: Long = 0L,
    val type: MediaType,
    val width: Int = 0,
    val height: Int = 0,
    val artist: String? = null,
    val album: String? = null,
    val albumId: Long = 0L,
    val relativePath: String? = null
) {
    val isVideo get() = type == MediaType.VIDEO
    val isImage get() = type == MediaType.IMAGE
    val isAudio get() = type == MediaType.AUDIO
}

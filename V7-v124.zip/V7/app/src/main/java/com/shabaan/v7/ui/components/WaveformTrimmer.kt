package com.shabaan.v7.ui.components

import android.media.MediaPlayer
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.sin

/**
 * A premium waveform-style trim selector (think WhatsApp status trimmer).
 *
 * - Draws aesthetic waveform bars (deterministic from a seed, so the same track
 *   always looks the same). It's a stylized visualization, not decoded samples,
 *   which keeps it fast and avoids heavy audio processing.
 * - Two draggable handles select the start/end of the clip.
 * - While dragging a handle, it plays a short audio preview from that position
 *   (like scrubbing a status), using a lightweight separate MediaPlayer so it
 *   never touches the app's main playback.
 *
 * All times are in milliseconds. [onChange] reports (startMs, endMs).
 */
@Composable
fun WaveformTrimmer(
    uri: Uri,
    durationMs: Long,
    startMs: Float,
    endMs: Float,
    onChange: (Float, Float) -> Unit,
    modifier: Modifier = Modifier,
    seed: Long = 0L,
    barCount: Int = 56,
    accent: Color = Color(0xFFC7CCD1),
    dim: Color = Color(0xFF3A4048),
    audioPreview: Boolean = true,
    onScrub: ((Float) -> Unit)? = null
) {
    val ctx = LocalContext.current

    // A tiny dedicated player just for scrub previews. Released on dispose.
    // Disabled when [audioPreview] is false (e.g. video uses live frame preview).
    val preview = remember { if (audioPreview) PreviewPlayer(ctx, uri) else null }
    DisposableEffect(uri) { onDispose { preview?.release() } }

    // Stable pseudo-random bar heights (look like a waveform, deterministic).
    val bars = remember(seed, barCount) {
        FloatArray(barCount) { i ->
            val n = abs(sin((i + 1) * 12.9898 + seed * 78.233))
            val env = 0.35 + 0.65 * abs(sin(i * 3.14159 / barCount)) // fuller in the middle
            (0.18f + (n * env).toFloat() * 0.82f).coerceIn(0.12f, 1f)
        }
    }

    Box(
        modifier
            .fillMaxWidth()
            .height(88.dp)
            .pointerInput(durationMs) {
                val widthPx = size.width.toFloat()
                fun xToMs(x: Float) = (x / widthPx).coerceIn(0f, 1f) * durationMs
                var draggingStart = true
                detectHorizontalDragGestures(
                    onDragStart = { pos ->
                        // Decide which handle is closer to the touch.
                        val startX = (startMs / durationMs) * widthPx
                        val endX = (endMs / durationMs) * widthPx
                        draggingStart = abs(pos.x - startX) <= abs(pos.x - endX)
                        val ms = xToMs(pos.x)
                        preview?.start(ms.toInt())
                        onScrub?.invoke(ms)
                    },
                    onDragEnd = { preview?.pause() },
                    onDragCancel = { preview?.pause() }
                ) { change, _ ->
                    val ms = xToMs(change.position.x)
                    if (draggingStart) {
                        val ns = ms.coerceIn(0f, endMs - 1000f)
                        onChange(ns, endMs)
                    } else {
                        val ne = ms.coerceIn(startMs + 1000f, durationMs.toFloat())
                        onChange(startMs, ne)
                    }
                    preview?.seekTo(ms.toInt())
                    onScrub?.invoke(ms)
                }
            }
    ) {
        androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(88.dp)) {
            val w = size.width
            val h = size.height
            val startX = (startMs / durationMs) * w
            val endX = (endMs / durationMs) * w
            val gap = w / (barCount * 1.6f)
            val barW = (w - gap * (barCount + 1)) / barCount
            val midY = h / 2f
            // Waveform bars.
            for (i in 0 until barCount) {
                val x = gap + i * (barW + gap)
                val barH = (h * 0.7f) * bars[i]
                val cx = x + barW / 2
                val inSel = cx in startX..endX
                drawRoundRect(
                    color = if (inSel) accent else dim,
                    topLeft = Offset(x, midY - barH / 2f),
                    size = Size(barW, barH),
                    cornerRadius = CornerRadius(barW / 2, barW / 2)
                )
            }
            // Dim the regions outside the selection (CapCut-style scrim).
            val scrim = Color.Black.copy(alpha = 0.45f)
            drawRect(scrim, topLeft = Offset(0f, 0f), size = Size(startX, h))
            drawRect(scrim, topLeft = Offset(endX, 0f), size = Size(w - endX, h))

            // Selected-range top & bottom edges (silver frame).
            val frame = 2.dp.toPx()
            drawRect(accent, topLeft = Offset(startX, 0f), size = Size(endX - startX, frame))
            drawRect(accent, topLeft = Offset(startX, h - frame), size = Size(endX - startX, frame))

            // Large rounded handles at each end with grip lines.
            val handleW = 12.dp.toPx()
            val gripH = h * 0.32f
            // Start handle.
            drawRoundRect(
                color = accent,
                topLeft = Offset((startX - handleW).coerceAtLeast(0f), 0f),
                size = Size(handleW, h),
                cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
            )
            // End handle.
            drawRoundRect(
                color = accent,
                topLeft = Offset(endX.coerceAtMost(w - handleW), 0f),
                size = Size(handleW, h),
                cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
            )
            // Grip lines on the handles.
            val gripColor = Color.Black.copy(alpha = 0.4f)
            val gripW = 1.5.dp.toPx()
            listOf(
                (startX - handleW / 2).coerceAtLeast(handleW / 2),
                (endX + handleW / 2).coerceAtMost(w - handleW / 2)
            ).forEach { hx ->
                drawRect(
                    gripColor,
                    topLeft = Offset(hx - gripW * 2, midY - gripH / 2),
                    size = Size(gripW, gripH)
                )
                drawRect(
                    gripColor,
                    topLeft = Offset(hx + gripW, midY - gripH / 2),
                    size = Size(gripW, gripH)
                )
            }
        }
    }
}

/**
 * Lightweight one-off player for scrub previews. Independent of the app's main
 * music/video playback, so previewing never disturbs the current session.
 */
private class PreviewPlayer(
    private val context: android.content.Context,
    private val uri: Uri
) {
    private var mp: MediaPlayer? = null
    private var prepared = false

    private fun ensure() {
        if (mp == null) {
            mp = try {
                MediaPlayer().apply {
                    setDataSource(context, uri)
                    setOnPreparedListener { prepared = true }
                    prepareAsync()
                }
            } catch (_: Exception) { null }
        }
    }

    fun start(ms: Int) {
        ensure()
        val p = mp ?: return
        try {
            if (prepared) {
                p.seekTo(ms)
                if (!p.isPlaying) p.start()
            }
        } catch (_: Exception) { /* ignore */ }
    }

    fun seekTo(ms: Int) {
        val p = mp ?: return
        try { if (prepared) p.seekTo(ms) } catch (_: Exception) { }
    }

    fun pause() {
        val p = mp ?: return
        try { if (p.isPlaying) p.pause() } catch (_: Exception) { }
    }

    fun release() {
        try { mp?.release() } catch (_: Exception) { }
        mp = null
        prepared = false
    }
}

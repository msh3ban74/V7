package com.shabaan.v7.service

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.shabaan.v7.MainActivity

class MusicService : MediaSessionService() {

    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        // Same smart rule as the video player: if a phone call is ALREADY active
        // when playback starts, keep playing over it (user deliberately started
        // music during the call). Otherwise use normal audio focus so a call or
        // another audio app that starts LATER pauses us and we resume after.
        val am = getSystemService(AUDIO_SERVICE) as? android.media.AudioManager
        val inCallNow = am?.mode == android.media.AudioManager.MODE_IN_CALL ||
            am?.mode == android.media.AudioManager.MODE_IN_COMMUNICATION
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                /* handleAudioFocus = */ !inCallNow
            )
            .setHandleAudioBecomingNoisy(true)
            .build()

        val sessionActivityPi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        session = MediaSession.Builder(this, player)
            .setSessionActivity(sessionActivityPi)
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p != null && (!p.playWhenReady || p.mediaItemCount == 0)) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }
}

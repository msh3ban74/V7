package com.shabaan.v7.util

import android.content.ContentValues
import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer

/**
 * Extracts the audio track out of a video and writes it as an .m4a file, then
 * saves it into the device's Music library. Uses only the platform
 * MediaExtractor + MediaMuxer (no transcoding, no external dependency) — this
 * is fast because it copies the compressed AAC samples directly.
 */
object AudioExtractor {

    suspend fun extractToMusic(context: Context, uri: Uri, displayName: String): Boolean =
        withContext(Dispatchers.IO) {
            val tempFile = File(context.cacheDir, "extract_${System.currentTimeMillis()}.m4a")
            val extractor = MediaExtractor()
            var muxer: MediaMuxer? = null
            try {
                extractor.setDataSource(context, uri, null)

                // find the audio track
                var audioTrack = -1
                var format: MediaFormat? = null
                for (i in 0 until extractor.trackCount) {
                    val f = extractor.getTrackFormat(i)
                    val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                    if (mime.startsWith("audio/")) { audioTrack = i; format = f; break }
                }
                if (audioTrack < 0 || format == null) return@withContext false

                extractor.selectTrack(audioTrack)
                muxer = MediaMuxer(tempFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                val dstTrack = muxer.addTrack(format)
                muxer.start()

                val maxChunk = 256 * 1024
                val buffer = ByteBuffer.allocate(maxChunk)
                val info = android.media.MediaCodec.BufferInfo()

                while (true) {
                    val size = extractor.readSampleData(buffer, 0)
                    if (size < 0) break
                    info.offset = 0
                    info.size = size
                    info.presentationTimeUs = extractor.sampleTime
                    info.flags = extractor.sampleFlags
                    muxer.writeSampleData(dstTrack, buffer, info)
                    extractor.advance()
                }

                muxer.stop()

                // Save into the Music collection
                val base = displayName.substringBeforeLast('.').ifBlank { "audio" }
                val outName = "$base.m4a"
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, outName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp4")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/V7 Audio")
                    }
                }
                val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                } else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                val item = resolver.insert(collection, values) ?: return@withContext false
                resolver.openOutputStream(item)?.use { os ->
                    tempFile.inputStream().use { it.copyTo(os) }
                } ?: return@withContext false
                true
            } catch (e: Exception) {
                false
            } finally {
                runCatching { extractor.release() }
                runCatching { muxer?.release() }
                runCatching { tempFile.delete() }
            }
        }
}

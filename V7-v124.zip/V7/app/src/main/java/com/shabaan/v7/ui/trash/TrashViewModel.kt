package com.shabaan.v7.ui.trash

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shabaan.v7.data.local.TrashEntity
import com.shabaan.v7.data.repository.TrashRepository
import com.shabaan.v7.util.SettingsStore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TrashViewModel @Inject constructor(
    private val repo: TrashRepository,
    private val settings: SettingsStore
) : ViewModel() {

    val items: StateFlow<List<TrashEntity>> =
        repo.items.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _selectionMode = MutableStateFlow(false)
    val selectionMode: StateFlow<Boolean> = _selectionMode.asStateFlow()

    private val _selection = MutableStateFlow<Set<Long>>(emptySet())
    val selection: StateFlow<Set<Long>> = _selection.asStateFlow()

    init {
        viewModelScope.launch {
            runCatching { repo.purgeExpired(settings.trashRetentionDays) }
        }
    }

    fun startSelection(id: Long) {
        _selectionMode.update { true }
        _selection.update { setOf(id) }
    }

    fun toggleSelection(id: Long) {
        _selection.update { cur -> if (id in cur) cur - id else cur + id }
        if (_selection.value.isEmpty()) _selectionMode.update { false }
    }

    fun selectAll() {
        _selectionMode.update { true }
        _selection.update { items.value.map { it.id }.toSet() }
    }

    fun clearSelection() {
        _selection.update { emptySet() }
        _selectionMode.update { false }
    }

    fun restoreSelected(onDone: () -> Unit = {}) {
        val ids = _selection.value
        val toRestore = items.value.filter { it.id in ids }
        viewModelScope.launch {
            toRestore.forEach { runCatching { repo.restore(it) } }
            clearSelection()
            onDone()
        }
    }

    fun deleteSelected(onDone: () -> Unit = {}) {
        val ids = _selection.value
        val toDelete = items.value.filter { it.id in ids }
        viewModelScope.launch {
            toDelete.forEach { runCatching { repo.deleteForever(it) } }
            clearSelection()
            onDone()
        }
    }

    fun restore(item: TrashEntity, onDone: (Boolean) -> Unit = {}) {
        viewModelScope.launch { onDone(repo.restore(item)) }
    }

    fun deleteForever(item: TrashEntity, onDone: (Boolean) -> Unit = {}) {
        viewModelScope.launch { onDone(repo.deleteForever(item)) }
    }

    fun emptyAll(onDone: (Int) -> Unit = {}) {
        viewModelScope.launch { onDone(repo.emptyAll()) }
    }

    val retentionDays get() = settings.trashRetentionDays
}

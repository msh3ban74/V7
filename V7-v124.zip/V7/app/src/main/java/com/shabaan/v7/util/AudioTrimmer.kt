package com.shabaan.v7.util

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer

/**
 * Trims an audio file between [startMs] and [endMs] and saves the clip into the
 * device Music library (Music/V7 Trimmed). Copies the compressed samples
 * directly (no re-encode), so it's fast and lossless.
 */
object AudioTrimmer {

    /**
     * Number of audio tracks in [uri]. Some files carry more than one audio
     * stream; the UI uses this to ask which track ("line 1 / line 2") to keep.
     */
    suspend fun audioTrackCount(context: Context, uri: Uri): Int = withContext(Dispatchers.IO) {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, uri, null)
            var count = 0
            for (i in 0 until extractor.trackCount) {
                val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) count++
            }
            count.coerceAtLeast(1)
        } catch (e: Exception) {
            1
        } finally {
            runCatching { extractor.release() }
        }
    }

    /**
     * @param audioTrackIndex which audio stream to keep (0-based). Defaults to 0
     *        (the first audio line).
     */
    suspend fun trim(
        context: Context,
        uri: Uri,
        startMs: Long,
        endMs: Long,
        baseName: String,
        audioTrackIndex: Int = 0
    ): Boolean = withContext(Dispatchers.IO) {
        if (endMs <= startMs) return@withContext false
        val tempFile = File(context.cacheDir, "trim_${System.currentTimeMillis()}.m4a")
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            extractor.setDataSource(context, uri, null)

            // Collect all audio track indices, then pick the requested one.
            val audioTracks = ArrayList<Int>()
            for (i in 0 until extractor.trackCount) {
                val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) audioTracks.add(i)
            }
            if (audioTracks.isEmpty()) return@withContext false
            val chosen = audioTracks.getOrElse(audioTrackIndex) { audioTracks.first() }
            val format = extractor.getTrackFormat(chosen)

            extractor.selectTrack(chosen)

            val maxInput = if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE).coerceAtLeast(256 * 1024)
            } else {
                1 * 1024 * 1024
            }

            muxer = MediaMuxer(tempFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val dstTrack = muxer.addTrack(format)
            muxer.start()
            started = true

            extractor.seekTo(startMs * 1000, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

            val buffer = ByteBuffer.allocate(maxInput)
            val info = MediaCodec.BufferInfo()
            val endUs = endMs * 1000
            var wroteAny = false
            var firstSampleTime = -1L

            while (true) {
                val sampleTime = extractor.sampleTime
                if (sampleTime < 0) break
                if (sampleTime > endUs) break
                val size = extractor.readSampleData(buffer, 0)
                if (size < 0) break
                // Anchor the first written sample at t=0 so the output file plays
                // from its start instead of keeping the original offset.
                if (firstSampleTime < 0) firstSampleTime = sampleTime
                info.offset = 0
                info.size = size
                info.presentationTimeUs = (sampleTime - firstSampleTime).coerceAtLeast(0)
                info.flags = if ((extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0)
                    MediaCodec.BUFFER_FLAG_KEY_FRAME
                else 0
                muxer.writeSampleData(dstTrack, buffer, info)
                wroteAny = true
                if (!extractor.advance()) break
            }

            muxer.stop()
            started = false
            if (!wroteAny) return@withContext false

            val base = baseName.substringBeforeLast('.').ifBlank { "audio" }
            val outName = "${base}_trim.m4a"
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, outName)
                put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp4")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/V7 Trimmed")
                }
            }
            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val item = resolver.insert(collection, values) ?: return@withContext false
            resolver.openOutputStream(item)?.use { os ->
                tempFile.inputStream().use { it.copyTo(os) }
            } ?: return@withContext false
            true
        } catch (e: Exception) {
            false
        } finally {
            runCatching { if (started) muxer?.stop() }
            runCatching { extractor.release() }
            runCatching { muxer?.release() }
            runCatching { tempFile.delete() }
        }
    }
}

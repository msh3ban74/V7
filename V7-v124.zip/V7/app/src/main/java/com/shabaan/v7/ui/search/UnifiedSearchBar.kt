package com.shabaan.v7.ui.search

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SearchOff
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.shabaan.v7.data.model.MediaItem
import com.shabaan.v7.data.model.MediaType
import com.shabaan.v7.util.RecentSearches
import com.shabaan.v7.util.SmartSearch
import com.shabaan.v7.util.SortBy
import com.shabaan.v7.util.SortOrder

/**
 * The single, always-visible search bar shown at the top of Videos, Gallery and
 * Audio. It replaces the old tap-to-open SearchSortBar and folds in ALL of its
 * features (sort + order, alias suggestions, recent searches) plus the new
 * smart behaviour: one ranked dropdown across videos + images + audio, and
 * tapping a result opens that exact item directly (audio hands off to the
 * Audio tab).
 *
 * Sort controls are optional: pass them on tabs with a sortable list (Videos,
 * Gallery); omit on Audio.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun UnifiedSearchBar(
    onOpenVideo: (MediaItem) -> Unit,
    onOpenImage: (MediaItem) -> Unit,
    onOpenAudio: (MediaItem) -> Unit,
    modifier: Modifier = Modifier,
    sortBy: SortBy? = null,
    sortOrder: SortOrder? = null,
    onSortBy: (SortBy) -> Unit = {},
    onToggleOrder: () -> Unit = {},
    vm: UnifiedSearchViewModel = hiltViewModel()
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val recentStore = remember { RecentSearches(ctx) }
    var recent by remember { mutableStateOf(recentStore.get()) }
    var sortMenuOpen by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { vm.ensureLoaded() }

    var text by remember { mutableStateOf(state.query) }
    LaunchedEffect(state.query) { if (state.query != text) text = state.query }
    LaunchedEffect(text) {
        if (text == state.query) return@LaunchedEffect
        kotlinx.coroutines.delay(120L)
        vm.setQuery(text)
    }

    val suggestions = remember(text) {
        if (text.isBlank()) emptyList() else SmartSearch.suggestions(text)
    }

    val showSort = sortBy != null && sortOrder != null

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyMedium,
                placeholder = { Text("Search", style = MaterialTheme.typography.bodyMedium) },
                leadingIcon = {
                    Icon(
                        Icons.Rounded.Search,
                        contentDescription = com.shabaan.v7.util.S.search(lang),
                        modifier = Modifier.size(20.dp)
                    )
                },
                trailingIcon = {
                    if (text.isNotEmpty()) {
                        IconButton(onClick = { text = ""; vm.clear() }) {
                            Icon(
                                Icons.Rounded.Close,
                                contentDescription = com.shabaan.v7.util.S.clearSearch(lang),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(
                    onSearch = {
                        if (text.isNotBlank()) {
                            recentStore.add(text)
                            recent = recentStore.get()
                        }
                    }
                ),
                shape = RoundedCornerShape(12.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                ),
                // Slim: cap the height so it reads as a thin search pill, not a
                // tall input box.
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 46.dp, max = 46.dp)
            )

            if (showSort) {
                IconButton(onClick = { sortMenuOpen = true }, modifier = Modifier.size(44.dp)) {
                    Icon(Icons.Rounded.Sort, contentDescription = com.shabaan.v7.util.S.sortLabel(lang), modifier = Modifier.size(21.dp))
                }
                IconButton(onClick = onToggleOrder, modifier = Modifier.size(44.dp)) {
                    Icon(
                        if (sortOrder == SortOrder.DESCENDING) Icons.Rounded.ArrowDownward
                        else Icons.Rounded.ArrowUpward,
                        contentDescription = com.shabaan.v7.util.S.orderDirection(lang),
                        modifier = Modifier.size(21.dp)
                    )
                }
                DropdownMenu(expanded = sortMenuOpen, onDismissRequest = { sortMenuOpen = false }) {
                    SortBy.entries.forEach { option ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    when (option) {
                                        SortBy.DATE -> com.shabaan.v7.util.S.sortByDate(lang)
                                        SortBy.NAME -> com.shabaan.v7.util.S.sortByName(lang)
                                        SortBy.SIZE -> com.shabaan.v7.util.S.sortBySize(lang)
                                    }
                                )
                            },
                            leadingIcon = if (sortBy == option) {
                                { Icon(Icons.Rounded.Check, contentDescription = null) }
                            } else null,
                            onClick = { onSortBy(option); sortMenuOpen = false }
                        )
                    }
                }
            }
        }

        val chips: List<Pair<String, Boolean>> = when {
            suggestions.isNotEmpty() -> suggestions.map { it to false }
            text.isBlank() -> recent.map { it to true }
            else -> emptyList()
        }
        if (chips.isNotEmpty()) {
            FlowRow(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                chips.forEach { (chip, isRecent) ->
                    SuggestionChip(
                        onClick = {
                            text = chip
                            recentStore.add(chip)
                            recent = recentStore.get()
                        },
                        label = { Text(chip, style = MaterialTheme.typography.labelMedium) },
                        icon = {
                            Icon(
                                if (isRecent) Icons.Rounded.History else Icons.Rounded.Search,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    )
                }
            }
        }

        if (text.isNotBlank()) {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 3.dp,
                shadowElevation = 6.dp,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                if (state.results.isEmpty()) {
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 20.dp, horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            Icons.Rounded.SearchOff,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            com.shabaan.v7.util.S.noResults(lang),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(Modifier.heightIn(max = 320.dp)) {
                        items(state.results, key = { "${it.type}_${it.id}" }) { item ->
                            ResultRow(
                                item = item,
                                onClick = {
                                    recentStore.add(text)
                                    recent = recentStore.get()
                                    when (item.type) {
                                        MediaType.VIDEO -> onOpenVideo(item)
                                        MediaType.IMAGE -> onOpenImage(item)
                                        MediaType.AUDIO -> onOpenAudio(item)
                                    }
                                    text = ""
                                    vm.clear()
                                }
                            )
                            HorizontalDivider(
                                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultRow(item: MediaItem, onClick: () -> Unit) {
    val (icon: ImageVector, label: String) = when (item.type) {
        MediaType.VIDEO -> Icons.Rounded.Videocam to com.shabaan.v7.util.S.typeVideo(lang)
        MediaType.IMAGE -> Icons.Rounded.Image to com.shabaan.v7.util.S.typeImage(lang)
        MediaType.AUDIO -> Icons.Rounded.MusicNote to com.shabaan.v7.util.S.typeAudio(lang)
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(34.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                icon,
                contentDescription = label,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                item.name,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

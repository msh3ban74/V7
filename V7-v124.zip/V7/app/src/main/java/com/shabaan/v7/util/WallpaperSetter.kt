package com.shabaan.v7.util

import android.app.WallpaperManager
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Sets a photo as the home screen, lock screen, or both. */
object WallpaperSetter {

    enum class Target { HOME, LOCK, BOTH }

    suspend fun setWallpaper(context: Context, uri: Uri, target: Target): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val wm = WallpaperManager.getInstance(context)
                val bmp = context.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it)
                } ?: return@withContext false

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    when (target) {
                        Target.HOME -> wm.setBitmap(bmp, null, true, WallpaperManager.FLAG_SYSTEM)
                        Target.LOCK -> wm.setBitmap(bmp, null, true, WallpaperManager.FLAG_LOCK)
                        Target.BOTH -> {
                            wm.setBitmap(bmp, null, true, WallpaperManager.FLAG_SYSTEM)
                            wm.setBitmap(bmp, null, true, WallpaperManager.FLAG_LOCK)
                        }
                    }
                } else {
                    // Older devices only support a single wallpaper
                    wm.setBitmap(bmp)
                }
                true
            } catch (e: Exception) {
                false
            }
        }
}

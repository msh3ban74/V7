package com.shabaan.v7.data.repository

import android.content.Context
import com.shabaan.v7.data.local.FavoriteEntity
import com.shabaan.v7.data.local.V7Database
import com.shabaan.v7.data.model.MediaType

class FavoritesRepository(context: Context) {

    private val dao = V7Database.get(context).favoriteDao()

    fun observeAll() = dao.observeAll()
    fun observeByType(type: MediaType) = dao.observeByType(type.name)
    fun observeIsFavorite(mediaId: Long, type: MediaType) = dao.exists(buildId(mediaId, type))

    suspend fun toggle(mediaId: Long, type: MediaType): Boolean {
        val id = buildId(mediaId, type)
        // Real toggle: if it's already a favorite, remove it; otherwise add it.
        return if (dao.existsNow(id)) {
            dao.deleteById(id)
            false   // now NOT a favorite
        } else {
            dao.insert(
                FavoriteEntity(
                    id = id,
                    mediaId = mediaId,
                    type = type.name,
                    addedAt = System.currentTimeMillis()
                )
            )
            true    // now IS a favorite
        }
    }

    suspend fun add(mediaId: Long, type: MediaType) {
        dao.insert(
            FavoriteEntity(
                id = buildId(mediaId, type),
                mediaId = mediaId,
                type = type.name,
                addedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun remove(mediaId: Long, type: MediaType) {
        dao.deleteById(buildId(mediaId, type))
    }

    private fun buildId(mediaId: Long, type: MediaType) = "${type.name}:$mediaId"
}

package com.shabaan.v7.ui.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shabaan.v7.data.model.MediaItem
import com.shabaan.v7.data.repository.MediaRepository
import com.shabaan.v7.util.SmartSearch
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Backs the app-wide unified search that appears on the Videos, Gallery and
 * Audio tabs.
 *
 * It loads all three media kinds once (videos + images + audio), caches them,
 * and runs a single SmartSearch over the combined pool. The results are mixed
 * across kinds and ranked together, so a query like "شيخ" surfaces matching
 * videos, photos AND audio in one ranked list — regardless of which tab the
 * search bar is shown on.
 *
 * This ViewModel is purely additive: it does not touch the per-tab lists or
 * their existing in-tab filtering. The dropdown it powers just opens the chosen
 * item directly in the right player.
 */
@HiltViewModel
class UnifiedSearchViewModel @Inject constructor(
    private val repo: MediaRepository
) : ViewModel() {

    data class UiState(
        val query: String = "",
        val loading: Boolean = false,
        val loaded: Boolean = false,
        /** Combined, ranked matches for [query]. Empty when query is blank. */
        val results: List<MediaItem> = emptyList()
    )

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    // Cached pools. Loaded once, reused for every keystroke (no re-query of
    // MediaStore while typing → no lag).
    private var pool: List<MediaItem> = emptyList()

    /** Load the three media pools once. Safe to call repeatedly. */
    fun ensureLoaded() {
        if (_state.value.loaded || _state.value.loading) return
        _state.update { it.copy(loading = true) }
        viewModelScope.launch {
            val videos = runCatching { repo.loadVideos() }.getOrDefault(emptyList())
            val images = runCatching { repo.loadImages() }.getOrDefault(emptyList())
            val audio = runCatching { repo.loadAudio() }.getOrDefault(emptyList())
            // Order in the pool doesn't matter — SmartSearch ranks by relevance.
            pool = videos + images + audio
            _state.update { it.copy(loading = false, loaded = true) }
            // If the user already typed something while loading, run it now.
            recompute(_state.value.query)
        }
    }

    fun setQuery(q: String) {
        _state.update { it.copy(query = q) }
        recompute(q)
    }

    fun clear() {
        _state.update { it.copy(query = "", results = emptyList()) }
    }

    private fun recompute(q: String) {
        val trimmed = q.trim()
        if (trimmed.isEmpty()) {
            _state.update { it.copy(results = emptyList()) }
            return
        }
        // SmartSearch already filters + ranks; cap the dropdown to keep it light.
        val matches = SmartSearch.search(pool, trimmed).take(MAX_RESULTS)
        _state.update { it.copy(results = matches) }
    }

    private companion object {
        const val MAX_RESULTS = 40
    }
}

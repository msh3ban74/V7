package com.shabaan.v7.util

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer

/**
 * Trims a video between [startMs] and [endMs] and saves the clip to the gallery
 * (Movies/V7 Trimmed). Copies the compressed video + audio samples directly with
 * MediaExtractor + MediaMuxer — fast, lossless, no re-encoding, no extra library.
 */
object VideoTrimmer {

    suspend fun trim(
        context: Context,
        uri: Uri,
        startMs: Long,
        endMs: Long,
        baseName: String
    ): Boolean = withContext(Dispatchers.IO) {
        if (endMs <= startMs) return@withContext false
        val tempFile = File(context.cacheDir, "vtrim_${System.currentTimeMillis()}.mp4")
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        try {
            extractor.setDataSource(context, uri, null)

            // Map every source track into the muxer; remember its new index.
            val indexMap = HashMap<Int, Int>()
            muxer = MediaMuxer(tempFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var maxInputSize = 1 * 1024 * 1024
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                    extractor.selectTrack(i)
                    if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                        val s = format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
                        if (s > maxInputSize) maxInputSize = s
                    }
                    indexMap[i] = muxer.addTrack(format)
                }
            }
            if (indexMap.isEmpty()) return@withContext false

            muxer.start()

            val buffer = ByteBuffer.allocate(maxInputSize)
            val info = MediaCodec.BufferInfo()
            val endUs = endMs * 1000
            var wroteAny = false

            // Process each selected track from the start point.
            for (srcIndex in indexMap.keys) {
                extractor.unselectTrack(srcIndex)
            }
            for ((srcIndex, dstIndex) in indexMap) {
                extractor.selectTrack(srcIndex)
                extractor.seekTo(startMs * 1000, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                while (true) {
                    val sampleTime = extractor.sampleTime
                    if (sampleTime < 0) break
                    if (sampleTime > endUs) break
                    if (extractor.sampleTrackIndex != srcIndex) { extractor.advance(); continue }
                    val size = extractor.readSampleData(buffer, 0)
                    if (size < 0) break
                    info.offset = 0
                    info.size = size
                    info.presentationTimeUs = sampleTime
                    info.flags = if ((extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0)
                        MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    muxer.writeSampleData(dstIndex, buffer, info)
                    wroteAny = true
                    if (!extractor.advance()) break
                }
                extractor.unselectTrack(srcIndex)
            }

            muxer.stop()
            if (!wroteAny) return@withContext false

            val base = baseName.substringBeforeLast('.').ifBlank { "video" }
            val outName = "${base}_trim.mp4"
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, outName)
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/V7 Trimmed")
                }
            }
            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val item = resolver.insert(collection, values) ?: return@withContext false
            resolver.openOutputStream(item)?.use { os ->
                tempFile.inputStream().use { it.copyTo(os) }
            } ?: return@withContext false
            true
        } catch (e: Exception) {
            false
        } finally {
            runCatching { extractor.release() }
            runCatching { muxer?.release() }
            runCatching { tempFile.delete() }
        }
    }
}

package com.shabaan.v7.util

import android.content.Context

/**
 * Stores per-video bookmarks (saved playback positions with an optional label)
 * in SharedPreferences. Independent of the Room database and of playback — it
 * just remembers timestamps the user wants to jump back to.
 *
 * Storage format per video id: "pos1|label1;;pos2|label2;;..."
 */
object VideoBookmarks {

    data class Bookmark(val positionMs: Long, val label: String)

    private fun prefs(context: Context) =
        context.getSharedPreferences("v7_video_bookmarks", Context.MODE_PRIVATE)

    private const val ENTRY_SEP = ";;"
    private const val FIELD_SEP = "|"

    fun get(context: Context, videoId: Long): List<Bookmark> {
        val raw = prefs(context).getString(videoId.toString(), "") ?: ""
        if (raw.isBlank()) return emptyList()
        return raw.split(ENTRY_SEP).mapNotNull { entry ->
            val parts = entry.split(FIELD_SEP)
            val pos = parts.getOrNull(0)?.toLongOrNull() ?: return@mapNotNull null
            val label = parts.getOrNull(1).orEmpty()
            Bookmark(pos, label)
        }.sortedBy { it.positionMs }
    }

    fun add(context: Context, videoId: Long, positionMs: Long, label: String) {
        val current = get(context, videoId).toMutableList()
        // Avoid near-duplicate bookmarks within 1 second.
        if (current.any { kotlin.math.abs(it.positionMs - positionMs) < 1000 }) return
        current.add(Bookmark(positionMs, label.ifBlank { Formatters.duration(positionMs) }))
        save(context, videoId, current)
    }

    fun remove(context: Context, videoId: Long, positionMs: Long) {
        val current = get(context, videoId).filterNot { it.positionMs == positionMs }
        save(context, videoId, current)
    }

    private fun save(context: Context, videoId: Long, list: List<VideoBookmarks.Bookmark>) {
        val raw = list.joinToString(ENTRY_SEP) { "${it.positionMs}$FIELD_SEP${it.label}" }
        prefs(context).edit().putString(videoId.toString(), raw).apply()
    }
}

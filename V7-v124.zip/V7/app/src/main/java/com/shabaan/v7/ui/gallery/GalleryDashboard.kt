package com.shabaan.v7.ui.gallery

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Horizontal row of quick-filter category chips shown above the photo grid. */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun QuickCategoryChips(
    selected: QuickCategory,
    onSelect: (QuickCategory) -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = com.shabaan.v7.util.LocalAppLanguage.current
    val options = listOf(
        QuickCategory.ALL to com.shabaan.v7.util.S.catAllPhotos(lang),
        QuickCategory.VIDEOS to com.shabaan.v7.util.S.catVideos(lang),
        QuickCategory.SCREENSHOTS to com.shabaan.v7.util.S.catScreenshots(lang),
        QuickCategory.FAVORITES to com.shabaan.v7.util.S.catFavorites(lang),
        QuickCategory.DOWNLOADS to com.shabaan.v7.util.S.catDownloads(lang)
    )
    LazyRow(
        modifier = modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(options, key = { it.first.name }) { (cat, label) ->
            FilterChip(
                selected = selected == cat,
                onClick = { onSelect(cat) },
                label = { Text(label) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    }
}

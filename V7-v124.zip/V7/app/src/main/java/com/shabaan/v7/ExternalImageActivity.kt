package com.shabaan.v7

import android.net.Uri
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.fragment.app.FragmentActivity
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.shabaan.v7.ui.theme.V7Theme
import dagger.hilt.android.AndroidEntryPoint

/**
 * Shows a single image that another app asked us to open (ACTION_VIEW on an
 * an image uri). Supports pinch-zoom + double-tap, matching the in-app viewer.
 */
@AndroidEntryPoint
class ExternalImageActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        val data: Uri? = intent?.data
        if (data == null) { finish(); return }

        setContent {
            V7Theme {
                Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
                    val ctx = this
                    var scale by remember { mutableFloatStateOf(1f) }
                    var offsetX by remember { mutableFloatStateOf(0f) }
                    var offsetY by remember { mutableFloatStateOf(0f) }
                    val zoomState = rememberTransformableState { zoomChange, panChange, _ ->
                        scale = (scale * zoomChange).coerceIn(1f, 5f)
                        if (scale > 1f) {
                            offsetX += panChange.x
                            offsetY += panChange.y
                        } else { offsetX = 0f; offsetY = 0f }
                    }
                    Box(Modifier.fillMaxSize().background(Color.Black)) {
                        AsyncImage(
                            model = ImageRequest.Builder(ctx).data(data).size(2048)
                                .crossfade(true).build(),
                            contentDescription = null,
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer(
                                    scaleX = scale, scaleY = scale,
                                    translationX = offsetX, translationY = offsetY
                                )
                                .transformable(zoomState)
                                .pointerInput(Unit) {
                                    detectTapGestures(
                                        onDoubleTap = {
                                            if (scale > 1f) { scale = 1f; offsetX = 0f; offsetY = 0f }
                                            else scale = 2.5f
                                        }
                                    )
                                },
                            contentScale = ContentScale.Fit
                        )
                    }
                }
            }
        }
    }
}

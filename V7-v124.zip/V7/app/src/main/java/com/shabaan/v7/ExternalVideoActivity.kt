package com.shabaan.v7

import android.net.Uri
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.fragment.app.FragmentActivity
import com.shabaan.v7.ui.theme.V7Theme
import com.shabaan.v7.ui.videos.ExternalVideoPlayer
import dagger.hilt.android.AndroidEntryPoint

/**
 * Plays a single video that another app asked us to open (ACTION_VIEW).
 * Resume is keyed by a stable hash of the source URI, so re-opening the same
 * file continues from where it stopped — even after a call interrupts it.
 */
@AndroidEntryPoint
class ExternalVideoActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        val data: Uri? = intent?.data
        if (data == null) { finish(); return }

        setContent {
            V7Theme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Black
                ) {
                    ExternalVideoPlayer(
                        uri = data,
                        onBack = { finish() }
                    )
                }
            }
        }
    }
}

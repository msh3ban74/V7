package com.shabaan.v7.util

import androidx.compose.runtime.compositionLocalOf

/**
 * In-app localization system (no Activity restart, works with Compose state).
 *
 * How it works:
 *  - [LocalAppLanguage] is a CompositionLocal carrying the current [AppLanguage].
 *    The root of the app provides it from SettingsStore, so when the user flips
 *    the language every screen recomposes with the new strings instantly.
 *  - [S] is the string table: one entry per UI string, each with an Arabic and
 *    an English value. Screens read text via `S.<key>(lang)` or the `tr` helper.
 *
 * Adding a new string = add one line to [S]. Converting a screen = replace its
 * hard-coded text with a lookup. We migrate screen-by-screen; nothing breaks
 * for screens not yet migrated (they just keep their literal text).
 */

/** The current UI language, provided at the app root. Defaults to Arabic. */
val LocalAppLanguage = compositionLocalOf { AppLanguage.ARABIC }

/** A single localized string: Arabic + English. */
data class Str(val ar: String, val en: String) {
    operator fun invoke(lang: AppLanguage): String =
        if (lang == AppLanguage.ARABIC) ar else en
}

/**
 * Central string table. Grouped by area. Keep keys descriptive and stable.
 */
object S {
    // ---- Bottom navigation / tabs ----
    val tabVideos     = Str("الفيديوهات", "Videos")
    val tabGallery    = Str("المعرض", "Gallery")
    val tabAudio      = Str("الصوتيات", "Audio")
    val tabVault      = Str("الخزنة", "Vault")
    val tabSettings   = Str("الإعدادات", "Settings")

    // ---- Gallery ----
    val galleryTitle      = Str("المعرض", "Gallery")
    val photos            = Str("الصور", "Photos")
    val albums            = Str("الألبومات", "Albums")
    val favorites         = Str("المفضّلة", "Favorites")
    val duplicates        = Str("المكرّرة", "Duplicates")
    val search            = Str("بحث", "Search")
    val catAllPhotos      = Str("كل الصور", "All photos")
    val catVideos         = Str("فيديو", "Videos")
    val catScreenshots    = Str("لقطات الشاشة", "Screenshots")
    val catFavorites      = Str("المفضّلة", "Favorites")
    val catDownloads      = Str("التنزيلات", "Downloads")
    val noAlbums          = Str("لا توجد ألبومات بعد", "No albums yet")
    val noFavoritesYet    = Str("لا توجد مفضلة بعد", "No favorites yet")
    val noDuplicates      = Str("لا توجد صور مكررة", "No duplicate photos")
    val noPhotosYet       = Str("لا توجد صور بعد", "No photos yet")
    val noResults         = Str("لا توجد نتائج", "No results")
    val photosCount       = Str("صورة", "photos")
    val favEmptySub       = Str("اضغط على القلب في أي صورة لحفظها هنا", "Tap the heart on any photo to save it here")
    val dupEmptySub       = Str("مكتبتك لا تحتوي على صور مكررة", "Your library has no duplicate photos")
    val sharePhotos       = Str("مشاركة الصور", "Share photos")

    // ---- Videos ----
    val videosTitle       = Str("الفيديوهات", "Videos")
    val videosCount       = Str("فيديو", "videos")
    val noVideosYet       = Str("لا توجد فيديوهات بعد", "No videos yet")
    val videosEmptySub    = Str("الفيديوهات على جهازك ستظهر هنا", "Videos on your device will appear here")
    val tryDifferentSearch = Str("جرّب بحثاً مختلفاً", "Try a different search")
    val continueWatching  = Str("متابعة المشاهدة", "Continue watching")
    val resume            = Str("استئناف", "Resume")

    // ---- Audio / Music ----
    val audioTitle        = Str("الصوتيات", "Audio")
    val tracksCount       = Str("مقطع", "tracks")
    val quranKareem       = Str("القرآن الكريم", "Holy Quran")
    val noMusic           = Str("لا توجد موسيقى", "No music")
    val noFavSongs        = Str("لا توجد أغاني في المفضلة", "No favorite songs")
    val recentlyPlayed    = Str("شُغّلت مؤخراً", "Recently played")
    val addToPlaylist     = Str("إضافة لقائمة تشغيل", "Add to playlist")
    val noPlaylistsCreate = Str("لا توجد قوائم بعد. أنشئ واحدة:", "No playlists yet. Create one:")
    val playlistName      = Str("اسم القائمة", "Playlist name")
    val createAndAdd      = Str("إنشاء وإضافة", "Create & add")
    val newPlaylist       = Str("قائمة جديدة", "New playlist")
    val playlists         = Str("قوائم التشغيل", "Playlists")
    val noPlaylistsHint   = Str("لا توجد قوائم بعد. استخدم قائمة النقاط الثلاث على أي مقطع لإضافته.", "No playlists yet. Use the three-dot menu on any track to add it.")
    val close             = Str("إغلاق", "Close")
    val emptyPlaylist     = Str("هذه القائمة فارغة.", "This playlist is empty.")
    val playlistFallback  = Str("قائمة تشغيل", "Playlist")
    val setAsRingtone     = Str("تعيين كنغمة", "Set as ringtone")
    val ringtoneForWhich  = Str("نغمة لأي خط؟", "Ringtone for which SIM?")
    val ringtonePickSlot  = Str("اختر الشريحة التي ستُستخدم لها النغمة.", "Choose the SIM the ringtone applies to.")
    val trimAudio         = Str("قص الصوت", "Trim audio")
    val create            = Str("إنشاء", "Create")

    // ---- Quran ----
    val quranPlayAllFailed = Str("تعذّر تشغيل السورة من كل المصادر — جرّب شيخاً آخر", "Couldn't play this surah from any source — try another reciter")
    val reciters          = Str("القرّاء", "Reciters")
    val rareRecitations   = Str("تلاوات نادرة", "Rare recitations")
    val searchSurahHint   = Str("ابحث عن سورة بالاسم أو الرقم…", "Search a surah by name or number…")
    val switchingSource   = Str("جارٍ التحويل إلى مصدر بديل…", "Switching to backup source…")
    val loadingReciters   = Str("جاري تحميل القراء…", "Loading reciters…")
    val recitersAvailable = Str("قارئ متاح", "reciters available")
    val changeSheikh      = Str("تغيير الشيخ", "Change reciter")
    val trySurahNameNum   = Str("جرّب اسم سورة أو رقمها", "Try a surah name or number")
    val favoriteSheikhs   = Str("الشيوخ المفضّلون", "Favorite reciters")
    val popularReciters   = Str("أشهر القرّاء", "Popular reciters")
    val favoriteSurahs    = Str("السور المفضّلة", "Favorite surahs")
    val allSurahs         = Str("كل السور", "All surahs")
    val downloadedToQuran = Str("✅ تم التحميل في Music/V7 Quran", "✅ Downloaded to Music/V7 Quran")
    val downloadFailed    = Str("❌ فشل التحميل", "❌ Download failed")
    val download          = Str("تحميل", "Download")
    val loadingDots       = Str("جاري التحميل…", "Loading…")
    val chooseSheikh      = Str("اختر الشيخ", "Choose reciter")
    val searchSheikhHint  = Str("ابحث عن شيخ…", "Search a reciter…")
    val noSheikhFound     = Str("لا يوجد شيخ بهذا الاسم", "No reciter by that name")
    val ayahWord          = Str("آية", "ayahs")
    val favorite          = Str("مفضلة", "Favorite")
    val searchArchiveHint = Str("ابحث في الأرشيف (مثلاً: مصطفى إسماعيل)…", "Search the archive (e.g. Mustafa Ismail)…")
    val back              = Str("رجوع", "Back")
    val noFilesInRec      = Str("لا توجد ملفات في هذا التسجيل", "No files in this recording")
    val rareRecitation    = Str("تلاوة نادرة", "Rare recitation")
    val continueListening = Str("متابعة الاستماع", "Continue listening")
    val surahWord         = Str("سورة", "Surah")
    val hide              = Str("إخفاء", "Hide")

    // ---- Vault ----
    val vaultUnlock       = Str("فتح الخزنة", "Unlock vault")
    val vaultUnlockSub    = Str("تحقّق لعرض الوسائط المحمية", "Verify to view protected media")
    val vaultTitle        = Str("الخزنة", "Vault")
    val selectedCount     = Str("محدد", "selected")
    val quickImport       = Str("استيراد سريع", "Quick import")
    val allItems          = Str("كل العناصر", "All items")
    val deletePermanentQ  = Str("حذف نهائي؟", "Delete permanently?")
    val deletePermanent   = Str("حذف نهائي", "Delete permanently")
    val deletePermanentMsg = Str("هل تريد حذف هذا الملف نهائياً من الخزنة؟ لا يمكن التراجع.", "Permanently delete this file from the vault? This can't be undone.")
    val backupDone        = Str("✅ تم حفظ النسخة الاحتياطية", "✅ Backup saved")
    val backupFailed      = Str("❌ فشل النسخ", "❌ Backup failed")
    val restoreDone       = Str("✅ تم استرجاع", "✅ Restored")
    val restoreFailed     = Str("❌ فشل الاسترجاع", "❌ Restore failed")
    val importedToVault   = Str("✅ تم استيراد", "✅ Imported")
    val itemWord          = Str("عنصر", "items")
    val toVault           = Str("للخزنة", "to vault")
    val nothingImported   = Str("لم يتم استيراد أي ملف", "No files imported")
    val openFileFailed    = Str("فشل فتح الملف", "Failed to open file")
    val openImageFailed   = Str("فشل فتح الصورة:", "Failed to open image:")
    val playVideoFailed   = Str("فشل تشغيل الفيديو:", "Failed to play video:")
    val muted             = Str("صامت", "Muted")
    val sound             = Str("صوت", "Sound")
    val fill              = Str("ملء", "Fill")
    val fit               = Str("ملاءمة", "Fit")
    val repeatOn          = Str("تكرار", "Repeat")
    val once              = Str("مرة", "Once")
    val snapshotSaved     = Str("✅ تم حفظ اللقطة في الخزنة", "✅ Snapshot saved to vault")
    val failed            = Str("❌ فشل", "❌ Failed")
    val snapshotFailed    = Str("تعذّر التقاط اللقطة", "Couldn't capture snapshot")
    val snapshot          = Str("لقطة", "Snapshot")
    val compressing       = Str("جاري الضغط…", "Compressing…")
    val compressedSaved   = Str("✅ تم حفظ الفيديو المضغوط في الخزنة", "✅ Compressed video saved to vault")
    val compressFailed    = Str("تعذّر ضغط الفيديو", "Couldn't compress video")
    val compressingShort  = Str("جاري…", "Working…")
    val compress          = Str("ضغط", "Compress")
    val bookmarkSaved     = Str("🔖 تم حفظ العلامة", "🔖 Bookmark saved")
    val bookmark          = Str("علامة", "Bookmark")
    val bookmarks         = Str("العلامات", "Bookmarks")
    val noBookmarks       = Str("لا توجد علامات بعد. اضغط \"علامة\" لحفظ اللحظة الحالية.", "No bookmarks yet. Tap \"Bookmark\" to save the current moment.")
    val savedEditedImage  = Str("✅ تم حفظ الصورة المعدّلة في الخزنة", "✅ Edited image saved to vault")
    val ok                = Str("حسناً", "OK")
    val fileInfo          = Str("معلومات الملف", "File info")
    val infoName          = Str("الاسم", "Name")
    val infoSize          = Str("الحجم", "Size")
    val infoType          = Str("النوع", "Type")
    val infoEncrypted     = Str("مشفّر", "Encrypted")
    val yesLocked         = Str("نعم 🔒", "Yes 🔒")
    val noWord            = Str("لا", "No")
    val useBiometric      = Str("استخدم البصمة / قفل الجهاز", "Use biometrics / device lock")
    val useCode           = Str("استخدم الرمز", "Use code")
    val enterCode         = Str("أدخل الرمز", "Enter code")
    val code              = Str("الرمز", "Code")
    val unlock            = Str("فتح", "Unlock")
    val useBiometricInstead = Str("استخدم البصمة بدلاً", "Use biometrics instead")
    val prepFileFailed    = Str("تعذّر تجهيز الملف للعرض", "Couldn't prepare the file for viewing")
    val vaultSafeEmpty    = Str("خزنتك آمنة وفارغة", "Your vault is safe and empty")
    val vaultEmptySub     = Str("أضف الصور والفيديوهات والصوتيات هنا لحفظها مشفّرة بعيداً عن معرض هاتفك.", "Add photos, videos and audio here to keep them encrypted, away from your phone's gallery.")
    val securityStatus    = Str("حالة الأمان", "Security status")
    val enabled           = Str("مُفعّل", "Enabled")
    val disabled          = Str("غير مُفعّل", "Disabled")
    val catPhotos         = Str("صور", "Photos")
    val catAudio          = Str("صوت", "Audio")

    // ---- Onboarding ----
    val obWelcome      = Str("أهلاً بك في V7", "Welcome to V7")
    val obWelcomeSub   = Str("مشغّل الوسائط الفاخر — صور، فيديو، موسيقى، قرآن، وخزنة مشفّرة في تطبيق واحد.", "The premium media player — photos, video, music, Quran, and an encrypted vault in one app.")
    val obVault        = Str("خزنة مشفّرة", "Encrypted vault")
    val obVaultSub     = Str("اخفِ صورك وفيديوهاتك بتشفير قوي لا يفتحه إلا أنت.", "Hide your photos and videos with strong encryption only you can open.")
    val obQuran        = Str("القرآن الكريم + تلاوات نادرة", "Holy Quran + rare recitations")
    val obQuranSub     = Str("مئات القرّاء، وتلاوات نادرة يصعب إيجادها في أي مكان آخر.", "Hundreds of reciters, plus rare recitations hard to find anywhere else.")
    val obVideo        = Str("مشغّل فيديو احترافي", "Pro video player")
    val obVideoSub     = Str("تشغيل بكل الصيغ، سرعة، تكرار، وعلامات.", "Plays every format, with speed, repeat and bookmarks.")
    val obMusic        = Str("موسيقى وقوائم تشغيل", "Music & playlists")
    val obMusicSub     = Str("مشغّل أنيق مع مفضلة وقوائم تشغيل.", "An elegant player with favorites and playlists.")
    val obGallery      = Str("معرض ذكي ومحرّر صور", "Smart gallery & photo editor")
    val obGallerySub   = Str("ألبومات، مفضلة، وأدوات تعديل كاملة.", "Albums, favorites and full editing tools.")
    val obReminder     = Str("نسألك أن تستخدم التطبيق فيما يرضي الله، وأن تتجنّب كل ما حرّمه. اجعل ما تحفظه طاهراً، فكل شيء محصيّ.", "Please use the app in what pleases God, and avoid what is forbidden. Keep what you save pure — everything is accounted for.")
    val obPermissions  = Str("سنطلب الإذن للوصول إلى الوسائط (الصور والفيديو والصوت) لعرضها وتنظيمها. تبقى ملفاتك على جهازك ولا تُرفع لأي خادم.", "We'll ask permission to access media (photos, video, audio) to display and organize them. Your files stay on your device and are never uploaded.")
    val obStart        = Str("ابدأ الآن", "Get started")

    // ---- Unified search ----
    val sortByDate     = Str("حسب التاريخ", "By date")
    val sortByName     = Str("حسب الاسم", "By name")
    val sortBySize     = Str("حسب الحجم", "By size")
    val sortLabel      = Str("فرز", "Sort")
    val orderDirection = Str("اتجاه الترتيب", "Sort direction")
    val clearSearch    = Str("مسح البحث", "Clear search")
    val typeVideo      = Str("فيديو", "Video")
    val typeImage      = Str("صورة", "Image")
    val typeAudio      = Str("صوت", "Audio")

    // ---- Quran dashboard ----
    val surahCountWord = Str("سورة", "surahs")

    // ---- Photo viewer / editor ----
    val allowFullThenDelete = Str("اسمح بالوصول الكامل، وبعدها احذف تاني — هيبقى فوري", "Grant full access, then delete again — it'll be instant")
    val movedToTrash   = Str("تم النقل إلى المحذوفات مؤخراً", "Moved to recently deleted")
    val saveToVault    = Str("حفظ في الخزنة", "Save to vault")
    val saveToVaultMsg = Str("حفظ الصورة المعدّلة كنسخة مشفّرة جديدة داخل الخزنة؟", "Save the edited image as a new encrypted copy in the vault?")
    val saveFailed     = Str("تعذّر الحفظ", "Couldn't save")
    val saveWord       = Str("حفظ", "Save")

    // ---- Date sections ----
    val today         = Str("اليوم", "Today")
    val yesterday     = Str("الأمس", "Yesterday")
    val thisWeek      = Str("هذا الأسبوع", "This Week")
    val thisMonth     = Str("هذا الشهر", "This Month")

    // ---- Common actions ----
    val play          = Str("تشغيل", "Play")
    val pause         = Str("إيقاف", "Pause")
    val delete        = Str("حذف", "Delete")
    val share         = Str("مشاركة", "Share")
    val restore       = Str("استرجاع", "Restore")
    val cancel        = Str("إلغاء", "Cancel")
    val confirm       = Str("تأكيد", "Confirm")
    val addFiles      = Str("إضافة ملفات", "Add Files")

    // ---- Settings ----
    val settingsTitle = Str("الإعدادات", "Settings")
    val language      = Str("اللغة", "Language")
    val languageArabic  = Str("العربية", "Arabic")
    val languageEnglish = Str("الإنجليزية", "English")
    val appearance      = Str("المظهر", "Appearance")
    val gridSizeLabel   = Str("حجم الشبكة", "Grid size")
    val columnsSuffix   = Str("أعمدة", "columns")
    val security        = Str("الأمان", "Security")
    val appLock         = Str("قفل التطبيق", "App Lock")
    val appLockSub      = Str("طلب الفتح للدخول إلى الخزنة", "Require unlock to open the vault")
    val biometricUnlock = Str("الفتح بالبصمة", "Biometric Unlock")
    val biometricSub    = Str("استخدم البصمة أو الوجه عند توفرها", "Use fingerprint or face when available")
    val pinCode         = Str("رمز PIN", "PIN code")
    val sleepTimer      = Str("مؤقت النوم", "Sleep Timer")
    val storage         = Str("التخزين", "Storage")
    val backupGphotos   = Str("نسخ احتياطي إلى Google Photos", "Back up to Google Photos")
    val backupGphotosSub = Str("افتح Google Photos للنسخ، أو شارك الصور لأي تطبيق", "Open Google Photos to back up, or share photos to any app")
    val fullFileAccess  = Str("الوصول الكامل للملفات", "Full file access")
    val trashRetention  = Str("مدة الاحتفاظ بالمحذوفات", "Trash retention")
    val recentlyDeleted = Str("المحذوفات مؤخراً", "Recently deleted")
    val recentlyDeletedSub = Str("عرض واسترجاع العناصر المحذوفة", "View and restore deleted items")
    val clearThumbCache = Str("مسح ذاكرة الصور المؤقتة", "Clear thumbnail cache")
    val clearThumbCacheSub = Str("توفير المساحة المستخدمة للصور المصغرة", "Free up space used by thumbnails")
    val contactDev      = Str("تواصل مع المطوّر", "Contact the developer")
    val aboutApp        = Str("عن التطبيق", "About")
    val minutes         = Str("دقائق", "minutes")
    val set             = Str("ضبط", "Set")
    val turnOff         = Str("إيقاف", "Turn off")
    val save            = Str("حفظ", "Save")
    val remove          = Str("إزالة", "Remove")
    val newPinLabel     = Str("رمز جديد (4–8 أرقام)", "New code (4–8 digits)")
    val confirmPinLabel = Str("تأكيد الرمز", "Confirm code")
}

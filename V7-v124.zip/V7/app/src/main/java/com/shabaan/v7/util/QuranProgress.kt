package com.shabaan.v7.util

import android.content.Context

/**
 * Remembers the user's last Quran listening session so it can be restored when
 * they return: the last reciter (sheikh), the last surah, and the last playback
 * position. Backed by its own SharedPreferences file — independent of Room and
 * of the player itself (it only stores plain values, like VideoBookmarks does).
 *
 * Corrupted / partial entries are ignored safely: [get] returns null unless the
 * essential fields parse correctly.
 */
object QuranProgress {

    data class Session(
        val reciterId: String,
        val reciterArabicName: String,
        val surahNumber: Int,
        val surahArabicName: String,
        val positionMs: Long,
        val durationMs: Long,
        val updatedAt: Long
    ) {
        val fraction: Float
            get() = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
    }

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences("v7_quran_progress", Context.MODE_PRIVATE)

    /**
     * Save the current session. A near-finished surah (within 5s of the end) is
     * cleared instead of saved, so "Continue listening" never offers something
     * that's basically done — same rule the video resume uses.
     */
    fun save(
        context: Context,
        reciterId: String,
        reciterArabicName: String,
        surahNumber: Int,
        surahArabicName: String,
        positionMs: Long,
        durationMs: Long
    ) {
        val nearEnd = durationMs > 0 && positionMs >= durationMs - 5_000
        val tooEarly = positionMs < 3_000
        val p = prefs(context)
        if (nearEnd || tooEarly || reciterId.isBlank() || surahNumber <= 0) {
            p.edit().clear().apply()
            return
        }
        p.edit()
            .putString(KEY_RECITER_ID, reciterId)
            .putString(KEY_RECITER_NAME, reciterArabicName)
            .putInt(KEY_SURAH_NUM, surahNumber)
            .putString(KEY_SURAH_NAME, surahArabicName)
            .putLong(KEY_POSITION, positionMs)
            .putLong(KEY_DURATION, durationMs)
            .putLong(KEY_UPDATED, System.currentTimeMillis())
            .apply()
    }

    /** Returns the saved session, or null if none / corrupted. */
    fun get(context: Context): Session? {
        val p = prefs(context)
        val reciterId = p.getString(KEY_RECITER_ID, null) ?: return null
        val surahNumber = p.getInt(KEY_SURAH_NUM, -1)
        if (reciterId.isBlank() || surahNumber <= 0) return null
        return runCatching {
            Session(
                reciterId = reciterId,
                reciterArabicName = p.getString(KEY_RECITER_NAME, "") ?: "",
                surahNumber = surahNumber,
                surahArabicName = p.getString(KEY_SURAH_NAME, "") ?: "",
                positionMs = p.getLong(KEY_POSITION, 0L),
                durationMs = p.getLong(KEY_DURATION, 0L),
                updatedAt = p.getLong(KEY_UPDATED, 0L)
            )
        }.getOrNull()
    }

    fun clear(context: Context) {
        prefs(context).edit().clear().apply()
    }

    private const val KEY_RECITER_ID = "reciter_id"
    private const val KEY_RECITER_NAME = "reciter_name"
    private const val KEY_SURAH_NUM = "surah_num"
    private const val KEY_SURAH_NAME = "surah_name"
    private const val KEY_POSITION = "position_ms"
    private const val KEY_DURATION = "duration_ms"
    private const val KEY_UPDATED = "updated_at"
}

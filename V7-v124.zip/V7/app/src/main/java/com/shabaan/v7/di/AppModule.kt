package com.shabaan.v7.di

import android.content.Context
import com.shabaan.v7.data.local.FavoriteDao
import com.shabaan.v7.data.local.ProgressDao
import com.shabaan.v7.data.local.TrashDao
import com.shabaan.v7.data.local.V7Database
import com.shabaan.v7.data.local.VaultDao
import com.shabaan.v7.data.repository.FavoritesRepository
import com.shabaan.v7.data.repository.MediaRepository
import com.shabaan.v7.data.repository.TrashRepository
import com.shabaan.v7.data.repository.VaultRepository
import com.shabaan.v7.util.SettingsStore
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides @Singleton
    fun provideDatabase(@ApplicationContext ctx: Context): V7Database = V7Database.get(ctx)

    @Provides fun provideFavoriteDao(db: V7Database): FavoriteDao = db.favoriteDao()
    @Provides fun provideVaultDao(db: V7Database): VaultDao = db.vaultDao()
    @Provides fun provideProgressDao(db: V7Database): ProgressDao = db.progressDao()
    @Provides fun provideTrashDao(db: V7Database): TrashDao = db.trashDao()

    @Provides @Singleton
    fun provideSettingsStore(@ApplicationContext ctx: Context): SettingsStore =
        SettingsStore(ctx)

    @Provides @Singleton
    fun provideMediaRepository(@ApplicationContext ctx: Context): MediaRepository =
        MediaRepository(ctx)

    @Provides @Singleton
    fun provideFavoritesRepository(@ApplicationContext ctx: Context): FavoritesRepository =
        FavoritesRepository(ctx)

    @Provides @Singleton
    fun provideVaultRepository(@ApplicationContext ctx: Context): VaultRepository =
        VaultRepository(ctx)

    @Provides @Singleton
    fun provideTrashRepository(@ApplicationContext ctx: Context): TrashRepository =
        TrashRepository(ctx)
}

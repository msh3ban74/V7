package com.shabaan.v7.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings

/**
 * Helpers for "All files access" (MANAGE_EXTERNAL_STORAGE). With this granted,
 * the app can delete/modify media without the per-item system confirmation
 * dialog, giving a smoother delete experience.
 */
object FullAccess {

    /** True if the app already has all-files access (or pre-R where it's implicit). */
    fun isGranted(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            true // pre-Android 11: covered by WRITE_EXTERNAL_STORAGE
        }
    }

    /** Opens the system screen where the user grants all-files access to this app. */
    fun request(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        try {
            val intent = Intent(
                Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:" + context.packageName)
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (_: Exception) {
            // Fallback to the general all-files-access list.
            try {
                context.startActivity(
                    Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) { /* ignore */ }
        }
    }
}

package com.shabaan.v7.util

import android.content.Context
import android.graphics.Bitmap
import java.io.File
import java.io.FileOutputStream

/**
 * A tiny on-disk thumbnail "database" — really a folder of pre-generated JPGs
 * keyed by media id + size, living in the app's private cache directory.
 *
 * Why this exists:
 *   Generating a video thumbnail (frame extraction via MediaStore) is the single
 *   most expensive step. Doing it once and then reading a plain JPG forever after
 *   is exactly how the stock gallery stays instant.
 *
 * Flow:
 *   first time:   video/photo → OS thumbnail → save JPG here (once)
 *   every time after: read the JPG directly (cheap, just a file decode)
 *
 * This sits UNDER Coil: the fetcher checks here first, and only falls back to the
 * OS extractor if the JPG isn't present yet. Coil's own memory/disk cache still
 * sits on top, so in practice most reads never even touch disk.
 */
object ThumbnailStore {

    private const val DIR = "v7_thumbs"

    private fun dir(context: Context): File {
        val d = File(context.cacheDir, DIR)
        if (!d.exists()) d.mkdirs()
        return d
    }

    /** Stable file for a given media id + size bucket. */
    fun fileFor(context: Context, mediaId: Long, sizePx: Int): File {
        // Bucket sizes so we don't create dozens of files per item; the grid only
        // uses a handful of sizes anyway.
        return File(dir(context), "t_${mediaId}_$sizePx.jpg")
    }

    /** Returns the cached file if it exists and is non-empty, else null. */
    fun get(context: Context, mediaId: Long, sizePx: Int): File? {
        val f = fileFor(context, mediaId, sizePx)
        return if (f.exists() && f.length() > 0L) f else null
    }

    /** Writes a bitmap as a JPG into the store (best-effort). Returns the file or null. */
    fun put(context: Context, mediaId: Long, sizePx: Int, bmp: Bitmap, quality: Int = 80): File? {
        return try {
            val f = fileFor(context, mediaId, sizePx)
            val tmp = File(f.parentFile, f.name + ".tmp")
            FileOutputStream(tmp).use { os ->
                bmp.compress(Bitmap.CompressFormat.JPEG, quality, os)
            }
            // Atomic-ish rename so a half-written file is never read.
            if (f.exists()) f.delete()
            if (tmp.renameTo(f)) f else { tmp.delete(); null }
        } catch (e: Exception) {
            null
        }
    }

    /** Clears the whole local thumbnail store (e.g. if the user wants to free space). */
    fun clear(context: Context) {
        try {
            dir(context).listFiles()?.forEach { it.delete() }
        } catch (_: Exception) { /* ignore */ }
    }
}

package com.shabaan.v7.util

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Hides / unhides a media folder from gallery scanners by toggling a ".nomedia"
 * marker file inside it. This is the standard Android mechanism and is fully
 * reversible. It does not move or modify any media — only adds/removes the empty
 * marker file.
 *
 * Note: works on folders the app can write to (shared storage with the granted
 * manage-storage permission). Returns false if the path isn't writable.
 */
object FolderHider {

    fun isHidden(folderPath: String): Boolean {
        return try {
            File(folderPath, ".nomedia").exists()
        } catch (e: Exception) {
            false
        }
    }

    suspend fun hide(context: Context, folderPath: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val dir = File(folderPath)
            if (!dir.isDirectory) return@withContext false
            val marker = File(dir, ".nomedia")
            if (!marker.exists()) marker.createNewFile()
            // Ask the media scanner to forget items in this folder.
            triggerRescan(context, folderPath)
            marker.exists()
        } catch (e: Exception) {
            false
        }
    }

    suspend fun unhide(context: Context, folderPath: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val marker = File(folderPath, ".nomedia")
            if (marker.exists()) marker.delete()
            triggerRescan(context, folderPath)
            !marker.exists()
        } catch (e: Exception) {
            false
        }
    }

    private fun triggerRescan(context: Context, folderPath: String) {
        try {
            android.media.MediaScannerConnection.scanFile(
                context,
                arrayOf(folderPath),
                null,
                null
            )
        } catch (_: Exception) { /* best-effort */ }
    }
}

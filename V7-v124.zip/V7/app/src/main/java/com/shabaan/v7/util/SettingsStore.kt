package com.shabaan.v7.util

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/** Theme preference values. SYSTEM follows the OS setting. */
enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** App-wide UI language. Drives the in-app string table (no Activity restart). */
enum class AppLanguage { ARABIC, ENGLISH }

/** Sort options applied to media grids. */
enum class SortBy { DATE, NAME, SIZE }
enum class SortOrder { DESCENDING, ASCENDING }

/** Single source of truth for user settings. Backed by SharedPreferences. */
class SettingsStore(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("v7_settings", Context.MODE_PRIVATE)

    // ---------- Theme ----------
    var themeMode: ThemeMode
        get() = ThemeMode.entries.getOrNull(prefs.getInt(KEY_THEME, 0)) ?: ThemeMode.SYSTEM
        set(value) { prefs.edit().putInt(KEY_THEME, value.ordinal).apply() }

    // ---------- Grid size ----------
    var gridSize: Int
        get() = prefs.getInt(KEY_GRID, 3).coerceIn(2, 6)
        set(value) { prefs.edit().putInt(KEY_GRID, value.coerceIn(2, 6)).apply() }

    // ---------- Sort ----------
    var sortBy: SortBy
        get() = SortBy.entries.getOrNull(prefs.getInt(KEY_SORT_BY, 0)) ?: SortBy.DATE
        set(value) { prefs.edit().putInt(KEY_SORT_BY, value.ordinal).apply() }

    var sortOrder: SortOrder
        get() = SortOrder.entries.getOrNull(prefs.getInt(KEY_SORT_ORDER, 0)) ?: SortOrder.DESCENDING
        set(value) { prefs.edit().putInt(KEY_SORT_ORDER, value.ordinal).apply() }

    // ---------- Security ----------
    var appLockEnabled: Boolean
        get() = prefs.getBoolean(KEY_APP_LOCK, false)
        set(value) { prefs.edit().putBoolean(KEY_APP_LOCK, value).apply() }

    var biometricEnabled: Boolean
        get() = prefs.getBoolean(KEY_BIOMETRIC, false)
        set(value) { prefs.edit().putBoolean(KEY_BIOMETRIC, value).apply() }

    var pinHash: String?
        get() = prefs.getString(KEY_PIN_HASH, null)
        set(value) { prefs.edit().putString(KEY_PIN_HASH, value).apply() }

    /** Auto-lock vault after this many seconds in background. -1 = never (until next cold start). */
    var autoLockSeconds: Int
        get() = prefs.getInt(KEY_AUTO_LOCK, 30)
        set(value) { prefs.edit().putInt(KEY_AUTO_LOCK, value).apply() }

    // ---------- Trash ----------
    /** Number of days to keep deleted items in trash before auto-purge. */
    var trashRetentionDays: Int
        get() = prefs.getInt(KEY_TRASH_RETENTION, 30).coerceIn(1, 90)
        set(value) { prefs.edit().putInt(KEY_TRASH_RETENTION, value.coerceIn(1, 90)).apply() }

    // ---------- Onboarding ----------
    /** True once the user has seen the welcome / permissions screen. */
    var onboardingDone: Boolean
        get() = prefs.getBoolean(KEY_ONBOARDING, false)
        set(value) { prefs.edit().putBoolean(KEY_ONBOARDING, value).apply() }

    /** UI language. Defaults to Arabic (the app's primary audience). */
    var language: AppLanguage
        get() = AppLanguage.entries.getOrNull(prefs.getInt(KEY_LANGUAGE, 0)) ?: AppLanguage.ARABIC
        set(value) { prefs.edit().putInt(KEY_LANGUAGE, value.ordinal).apply() }

    /** Emit on any preference change. */
    fun changes(): Flow<String> = callbackFlow {
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, k ->
            trySend(k ?: "")
        }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        awaitClose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }

    private companion object {
        const val KEY_THEME = "theme_mode"
        const val KEY_GRID = "grid_size"
        const val KEY_SORT_BY = "sort_by"
        const val KEY_SORT_ORDER = "sort_order"
        const val KEY_APP_LOCK = "app_lock_enabled"
        const val KEY_BIOMETRIC = "biometric_enabled"
        const val KEY_PIN_HASH = "pin_hash"
        const val KEY_AUTO_LOCK = "auto_lock_seconds"
        const val KEY_TRASH_RETENTION = "trash_retention_days"
        const val KEY_ONBOARDING = "onboarding_done"
        const val KEY_LANGUAGE = "app_language"
    }
}

package com.shabaan.v7.ui.gallery

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.shabaan.v7.data.model.MediaType
import com.shabaan.v7.data.repository.FavoritesRepository
import com.shabaan.v7.data.repository.TrashRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Favorite + move-to-trash actions for the photo viewer. */
@HiltViewModel
class PhotoActionsViewModel @Inject constructor(
    app: Application,
    private val favRepo: FavoritesRepository,
    private val trashRepo: TrashRepository
) : AndroidViewModel(app) {

    private val _favorites = MutableStateFlow<Set<Long>>(emptySet())
    val favorites: StateFlow<Set<Long>> = _favorites.asStateFlow()

    init {
        viewModelScope.launch {
            favRepo.observeByType(MediaType.IMAGE).collect { list ->
                _favorites.update { list.map { it.mediaId }.toSet() }
            }
        }
    }

    fun toggleFavorite(mediaId: Long) {
        viewModelScope.launch { favRepo.toggle(mediaId, MediaType.IMAGE) }
    }

    fun moveToTrash(item: com.shabaan.v7.data.model.MediaItem, onDone: () -> Unit) {
        viewModelScope.launch {
            runCatching { trashRepo.moveToTrash(item) }
            onDone()
        }
    }
}

package com.shabaan.v7.util

import android.graphics.Bitmap
import java.io.ByteArrayOutputStream
import java.io.OutputStream

/**
 * Minimal animated-GIF encoder, adapted from the classic public-domain
 * AnimatedGifEncoder (Kevin Weiner / NeuQuant by Anthony Dekker). Pure Kotlin,
 * no external dependency — keeps the build safe.
 *
 * Usage:
 *   val enc = GifEncoder()
 *   enc.start(outputStream)
 *   enc.setDelay(80)        // ms between frames
 *   enc.setRepeat(0)        // 0 = loop forever
 *   frames.forEach { enc.addFrame(it) }
 *   enc.finish()
 */
class GifEncoder {
    private var width = 0
    private var height = 0
    private var transparent: Int? = null
    private var transIndex = 0
    private var repeat = -1
    private var delay = 0
    private var started = false
    private var out: OutputStream? = null
    private var image: Bitmap? = null
    private var pixels: ByteArray? = null
    private var indexedPixels: ByteArray? = null
    private var colorDepth = 0
    private var colorTab: ByteArray? = null
    private val usedEntry = BooleanArray(256)
    private var palSize = 7
    private var dispose = -1
    private var closeStream = false
    private var firstFrame = true
    private var sizeSet = false
    private var sample = 10

    fun setDelay(ms: Int) { delay = Math.round(ms / 10f) }
    fun setRepeat(iter: Int) { if (iter >= 0) repeat = iter }
    fun setQuality(q: Int) { sample = if (q < 1) 1 else q }

    fun setSize(w: Int, h: Int) {
        if (started && !firstFrame) return
        width = w; height = h
        if (width < 1) width = 320
        if (height < 1) height = 240
        sizeSet = true
    }

    fun start(os: OutputStream): Boolean {
        var ok = true
        closeStream = false
        out = os
        try { writeString("GIF89a") } catch (e: Exception) { ok = false }
        started = ok
        return started
    }

    fun addFrame(im: Bitmap?): Boolean {
        if (im == null || !started) return false
        var ok = true
        try {
            if (!sizeSet) setSize(im.width, im.height)
            image = im
            getImagePixels()
            analyzePixels()
            if (firstFrame) {
                writeLSD()
                writePalette()
                if (repeat >= 0) writeNetscapeExt()
            }
            writeGraphicCtrlExt()
            writeImageDesc()
            if (!firstFrame) writePalette()
            writePixels()
            firstFrame = false
        } catch (e: Exception) { ok = false }
        return ok
    }

    fun finish(): Boolean {
        if (!started) return false
        var ok = true
        started = false
        try {
            out?.write(0x3b)
            out?.flush()
            if (closeStream) out?.close()
        } catch (e: Exception) { ok = false }
        transIndex = 0; out = null; image = null; pixels = null
        indexedPixels = null; colorTab = null; closeStream = false; firstFrame = true
        return ok
    }

    private fun getImagePixels() {
        val w = image!!.width
        val h = image!!.height
        if (w != width || h != height) {
            val temp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val c = android.graphics.Canvas(temp)
            c.drawBitmap(image!!, 0f, 0f, null)
            image = temp
        }
        val px = IntArray(width * height)
        image!!.getPixels(px, 0, width, 0, 0, width, height)
        pixels = ByteArray(px.size * 3)
        var bi = 0
        for (p in px) {
            pixels!![bi++] = ((p shr 16) and 0xff).toByte()
            pixels!![bi++] = ((p shr 8) and 0xff).toByte()
            pixels!![bi++] = (p and 0xff).toByte()
        }
    }

    private fun analyzePixels() {
        val len = pixels!!.size
        val nPix = len / 3
        indexedPixels = ByteArray(nPix)
        val nq = NeuQuant(pixels!!, len, sample)
        colorTab = nq.process()
        var i = 0
        while (i < colorTab!!.size) {
            val temp = colorTab!![i]
            colorTab!![i] = colorTab!![i + 2]
            colorTab!![i + 2] = temp
            usedEntry[i / 3] = false
            i += 3
        }
        var k = 0
        for (j in 0 until nPix) {
            val index = nq.map(
                pixels!![k++].toInt() and 0xff,
                pixels!![k++].toInt() and 0xff,
                pixels!![k++].toInt() and 0xff
            )
            usedEntry[index] = true
            indexedPixels!![j] = index.toByte()
        }
        pixels = null
        colorDepth = 8
        palSize = 7
        transparent?.let { transIndex = findClosest(it) }
    }

    private fun findClosest(c: Int): Int {
        if (colorTab == null) return -1
        val r = (c shr 16) and 0xff
        val g = (c shr 8) and 0xff
        val b = c and 0xff
        var minpos = 0
        var dmin = 256 * 256 * 256
        var i = 0
        while (i < colorTab!!.size) {
            val dr = r - (colorTab!![i++].toInt() and 0xff)
            val dg = g - (colorTab!![i++].toInt() and 0xff)
            val db = b - (colorTab!![i++].toInt() and 0xff)
            val d = dr * dr + dg * dg + db * db
            val index = i / 3 - 1
            if (d < dmin && usedEntry[index]) { dmin = d; minpos = index }
        }
        return minpos
    }

    private fun writeGraphicCtrlExt() {
        out?.write(0x21); out?.write(0xf9); out?.write(4)
        val transp: Int; val disp: Int
        if (transparent == null) { transp = 0; disp = 0 }
        else { transp = 1; disp = 2 }
        if (dispose >= 0) {} // keep default
        out?.write(0 or (disp shl 2) or 0 or transp)
        writeShort(delay); out?.write(transIndex); out?.write(0)
    }

    private fun writeImageDesc() {
        out?.write(0x2c); writeShort(0); writeShort(0)
        writeShort(width); writeShort(height)
        if (firstFrame) out?.write(0)
        else out?.write(0x80 or palSize)
    }

    private fun writeLSD() {
        writeShort(width); writeShort(height)
        out?.write(0xf0 or palSize); out?.write(0); out?.write(0)
    }

    private fun writeNetscapeExt() {
        out?.write(0x21); out?.write(0xff); out?.write(11)
        writeString("NETSCAPE2.0"); out?.write(3); out?.write(1)
        writeShort(repeat); out?.write(0)
    }

    private fun writePalette() {
        out?.write(colorTab!!, 0, colorTab!!.size)
        val n = 3 * 256 - colorTab!!.size
        for (i in 0 until n) out?.write(0)
    }

    private fun writePixels() {
        val encoder = LZWEncoder(width, height, indexedPixels!!, colorDepth)
        encoder.encode(out!!)
    }

    private fun writeShort(value: Int) {
        out?.write(value and 0xff); out?.write((value shr 8) and 0xff)
    }

    private fun writeString(s: String) {
        for (c in s) out?.write(c.code)
    }
}

package com.shabaan.v7.util

import android.content.Context

/**
 * Persists the user's favorite reciters (sheikhs) and favorite surahs for the
 * Quran experience. Backed by its own SharedPreferences file — independent of
 * Room and of the MediaStore-based FavoritesRepository (which keys on numeric
 * media ids that Quran content doesn't have).
 *
 *  - Sheikhs are keyed by their stable reciter identifier (a string).
 *  - Surahs are keyed by their number (1..114).
 *
 * Reads are cheap (a single set lookup); writes are tiny string-set commits.
 * Corrupted values are ignored safely (a malformed entry just won't parse).
 */
object QuranFavorites {

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences("v7_quran_favorites", Context.MODE_PRIVATE)

    // ---- Sheikhs ----

    fun sheikhIds(context: Context): Set<String> =
        prefs(context).getStringSet(KEY_SHEIKHS, emptySet())?.toSet() ?: emptySet()

    fun isSheikhFavorite(context: Context, reciterId: String): Boolean =
        reciterId.isNotBlank() && reciterId in sheikhIds(context)

    /** Toggle a sheikh favorite. Returns the new state (true = now favorite). */
    fun toggleSheikh(context: Context, reciterId: String): Boolean {
        if (reciterId.isBlank()) return false
        val current = sheikhIds(context).toMutableSet()
        val nowFav = if (!current.add(reciterId)) {
            current.remove(reciterId); false
        } else true
        prefs(context).edit().putStringSet(KEY_SHEIKHS, current).apply()
        return nowFav
    }

    // ---- Surahs ----

    fun surahNumbers(context: Context): Set<Int> =
        prefs(context).getStringSet(KEY_SURAHS, emptySet())
            ?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet()

    fun isSurahFavorite(context: Context, surahNumber: Int): Boolean =
        surahNumber in surahNumbers(context)

    /** Toggle a surah favorite. Returns the new state (true = now favorite). */
    fun toggleSurah(context: Context, surahNumber: Int): Boolean {
        if (surahNumber <= 0) return false
        val current = surahNumbers(context).toMutableSet()
        val nowFav = if (!current.add(surahNumber)) {
            current.remove(surahNumber); false
        } else true
        prefs(context).edit()
            .putStringSet(KEY_SURAHS, current.map { it.toString() }.toSet())
            .apply()
        return nowFav
    }

    private const val KEY_SHEIKHS = "fav_sheikhs"
    private const val KEY_SURAHS = "fav_surahs"
}

package com.shabaan.v7.util

import android.content.Context

/**
 * Tiny persistent store for the user's most recent search queries.
 * Search-only; backed by its own SharedPreferences file so it doesn't touch
 * any other setting.
 */
class RecentSearches(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("v7_recent_searches", Context.MODE_PRIVATE)

    /** Most-recent-first list of past queries. */
    fun get(): List<String> {
        val raw = prefs.getString(KEY, "") ?: ""
        if (raw.isEmpty()) return emptyList()
        return raw.split(SEP).filter { it.isNotBlank() }
    }

    /** Records a query (dedup, most-recent-first, capped). */
    fun add(query: String) {
        val q = query.trim()
        if (q.isEmpty()) return
        val current = get().toMutableList()
        current.removeAll { it.equals(q, ignoreCase = true) }
        current.add(0, q)
        while (current.size > MAX) current.removeAt(current.size - 1)
        prefs.edit().putString(KEY, current.joinToString(SEP)).apply()
    }

    fun clear() {
        prefs.edit().remove(KEY).apply()
    }

    private companion object {
        const val KEY = "recent"
        const val SEP = "\u0001" // unlikely-to-appear separator
        const val MAX = 10
    }
}

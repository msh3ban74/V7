package com.shabaan.v7.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

/**
 * Reusable circular avatar for a reciter (sheikh).
 *
 * Resolution order:
 *   1. If [imageUrl] is non-null/non-blank → load it with Coil.
 *      (No images are bundled or downloaded today; this path is wired up so
 *       that adding a `photoUrl` to the reciter catalog later "just works"
 *       with zero UI changes.)
 *   2. Otherwise → an elegant generated placeholder:
 *      - [style] = Letter  → the first letter of the name on a soft,
 *        name-derived silver gradient (stable per reciter, like Spotify's
 *        artist initials).
 *      - [style] = Mic     → a microphone icon on the same gradient.
 *
 * Pure, stateless and allocation-light, so it's cheap inside lazy lists.
 */
enum class ReciterAvatarStyle { Letter, Mic }

@Composable
fun ReciterAvatar(
    name: String,
    modifier: Modifier = Modifier,
    imageUrl: String? = null,
    size: Dp = 56.dp,
    style: ReciterAvatarStyle = ReciterAvatarStyle.Letter
) {
    val shape = CircleShape
    // A stable two-stop gradient derived from the name, kept within the
    // Platinum-Silver family so it never clashes with the dark theme.
    val gradient = remember(name) { avatarGradient(name) }

    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .background(gradient),
        contentAlignment = Alignment.Center
    ) {
        if (!imageUrl.isNullOrBlank()) {
            AsyncImage(
                model = imageUrl,
                contentDescription = name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(size).clip(shape)
            )
        } else when (style) {
            ReciterAvatarStyle.Letter -> {
                Text(
                    text = firstLetter(name),
                    color = Color(0xFF0A0B0D), // near-black ink reads well on silver
                    fontWeight = FontWeight.SemiBold,
                    fontSize = (size.value * 0.42f).sp
                )
            }
            ReciterAvatarStyle.Mic -> {
                Icon(
                    Icons.Rounded.Mic,
                    contentDescription = name,
                    tint = Color(0xFF0A0B0D),
                    modifier = Modifier.size(size * 0.5f)
                )
            }
        }
    }
}

/** First visible letter of the name (handles Arabic "ال" prefix gracefully). */
private fun firstLetter(name: String): String {
    val trimmed = name.trim()
    if (trimmed.isEmpty()) return "?"
    // Skip a leading Arabic definite article "ال" so e.g. "العفاسي" shows "ع".
    val stripped = if (trimmed.startsWith("ال") && trimmed.length > 2)
        trimmed.substring(2) else trimmed
    return stripped.first().toString()
}

/**
 * Deterministic silver gradient per name. Same name → same gradient every
 * time, so the grid feels stable and intentional rather than random.
 */
private fun avatarGradient(name: String): Brush {
    val palettes = listOf(
        listOf(Color(0xFFE5E8EB), Color(0xFFB8BDC5)),
        listOf(Color(0xFFC7CCD1), Color(0xFFAEB5BC)),
        listOf(Color(0xFFD7DBDF), Color(0xFF9AA0A6)),
        listOf(Color(0xFFCED3D8), Color(0xFFB0B6BD)),
        listOf(Color(0xFFDDE1E4), Color(0xFFA7ADB4))
    )
    val idx = (kotlin.math.abs(name.hashCode())) % palettes.size
    return Brush.linearGradient(palettes[idx])
}

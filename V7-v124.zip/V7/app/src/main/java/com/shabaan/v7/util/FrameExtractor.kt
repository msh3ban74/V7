package com.shabaan.v7.util

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Extracts a single still frame from a video at a given position and saves it as
 * a JPEG into Pictures/V7 Frames. Uses MediaMetadataRetriever so it never touches
 * the running ExoPlayer or the playback session.
 */
object FrameExtractor {

    suspend fun captureFrame(
        context: Context,
        uri: Uri,
        positionMs: Long,
        displayName: String
    ): Boolean = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            // OPTION_CLOSEST gives the frame nearest the requested time (the one
            // the user is actually looking at), not just the previous keyframe.
            val bitmap: Bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                retriever.getScaledFrameAtTime(
                    positionMs * 1000,
                    MediaMetadataRetriever.OPTION_CLOSEST,
                    1920, 1080
                ) ?: retriever.getFrameAtTime(positionMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST)
                ?: return@withContext false
            } else {
                retriever.getFrameAtTime(positionMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST)
                    ?: return@withContext false
            }

            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(
                        MediaStore.MediaColumns.RELATIVE_PATH,
                        Environment.DIRECTORY_PICTURES + "/V7 Frames"
                    )
                }
            }
            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val item = resolver.insert(collection, values) ?: return@withContext false
            resolver.openOutputStream(item)?.use { os ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, os)
            } ?: return@withContext false
            true
        } catch (e: Exception) {
            false
        } finally {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) retriever.close()
                else retriever.release()
            } catch (_: Exception) {}
        }
    }
}

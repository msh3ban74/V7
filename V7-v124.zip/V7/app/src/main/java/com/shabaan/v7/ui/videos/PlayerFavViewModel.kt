package com.shabaan.v7.ui.videos

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shabaan.v7.data.model.MediaType
import com.shabaan.v7.data.repository.FavoritesRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Exposes the set of favorite video IDs and a toggle, for the in-player like button. */
@HiltViewModel
class PlayerFavViewModel @Inject constructor(
    private val favRepo: FavoritesRepository
) : ViewModel() {

    private val _favorites = MutableStateFlow<Set<Long>>(emptySet())
    val favorites: StateFlow<Set<Long>> = _favorites.asStateFlow()

    init {
        viewModelScope.launch {
            favRepo.observeByType(MediaType.VIDEO).collect { list ->
                _favorites.update { list.map { it.mediaId }.toSet() }
            }
        }
    }

    fun toggle(mediaId: Long) {
        viewModelScope.launch {
            favRepo.toggle(mediaId, MediaType.VIDEO)
        }
    }
}

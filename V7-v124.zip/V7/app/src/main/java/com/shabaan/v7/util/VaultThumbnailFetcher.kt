package com.shabaan.v7.util

import android.content.Context
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKey
import coil.ImageLoader
import coil.decode.DataSource
import coil.decode.ImageSource
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.fetch.SourceResult
import coil.request.Options
import okio.Buffer
import okio.Path.Companion.toOkioPath
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

/**
 * Loads a thumbnail for an *encrypted* vault item. The vault is already behind
 * the app lock, so showing real previews here is fine (like a secure folder).
 *
 * Images: decrypt bytes in memory → hand straight to Coil.
 * Videos: Coil can't pull a frame from raw bytes, so we decrypt to a small temp
 * file on disk and let Coil's VideoFrameDecoder extract the first frame from it.
 */
data class VaultThumb(
    val storedPath: String,
    val encrypted: Boolean,
    val id: Long,
    val isVideo: Boolean = false,
    val originalName: String = ""
)

class VaultThumbnailFetcher(
    private val context: Context,
    private val model: VaultThumb,
    private val options: Options
) : Fetcher {

    override suspend fun fetch(): FetchResult? {
        val file = File(model.storedPath)
        if (!file.exists()) return null

        // ---- VIDEO: decrypt to a temp file, let VideoFrameDecoder read it ----
        if (model.isVideo) {
            val ext = model.originalName.substringAfterLast('.', "mp4").ifBlank { "mp4" }
            val tmp = File(context.cacheDir, "vault_thumb_${model.id}.$ext")
            try {
                if (!(tmp.exists() && tmp.length() > 0)) {
                    val part = File(context.cacheDir, "vault_thumb_${model.id}.$ext.part")
                    if (part.exists()) part.delete()
                    if (model.encrypted) {
                        encFile(file).openFileInput().use { input ->
                            FileOutputStream(part).use { out -> input.copyTo(out, 64 * 1024) }
                        }
                    } else {
                        file.inputStream().use { input ->
                            FileOutputStream(part).use { out -> input.copyTo(out, 64 * 1024) }
                        }
                    }
                    if (part.length() <= 0) { part.delete(); return null }
                    part.renameTo(tmp)
                }
            } catch (e: Exception) {
                return null
            }
            // Returning null lets Coil fall through to its own decoders using the
            // file path. We instead hand back a SourceResult pointing at the temp
            // file so VideoFrameDecoder can pull a frame.
            return SourceResult(
                source = ImageSource(tmp.toOkioPath(), okio.FileSystem.SYSTEM),
                mimeType = "video/$ext",
                dataSource = DataSource.DISK
            )
        }

        // ---- IMAGE: decrypt bytes in memory ----
        val bytes: ByteArray = try {
            if (model.encrypted) {
                val bos = ByteArrayOutputStream()
                encFile(file).openFileInput().use { it.copyTo(bos, 64 * 1024) }
                bos.toByteArray()
            } else {
                file.readBytes()
            }
        } catch (e: Exception) {
            return null
        }
        val buffer = Buffer().apply { write(bytes) }
        return SourceResult(
            source = ImageSource(buffer, context),
            mimeType = null,
            dataSource = DataSource.DISK
        )
    }

    private fun encFile(file: File): EncryptedFile {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedFile.Builder(
            context, file, masterKey,
            EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
        ).build()
    }

    class Factory(private val context: Context) : Fetcher.Factory<VaultThumb> {
        override fun create(data: VaultThumb, options: Options, imageLoader: ImageLoader): Fetcher =
            VaultThumbnailFetcher(context, data, options)
    }
}

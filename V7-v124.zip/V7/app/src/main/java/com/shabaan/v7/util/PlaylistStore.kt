package com.shabaan.v7.util

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Stores user playlists as JSON in SharedPreferences. Independent of the Room
 * database (which we intentionally don't modify). A playlist is a name + an
 * ordered list of track IDs (MediaStore ids).
 */
object PlaylistStore {

    data class Playlist(val id: String, val name: String, val trackIds: List<Long>)

    private fun prefs(context: Context) =
        context.getSharedPreferences("v7_playlists", Context.MODE_PRIVATE)

    private const val KEY = "playlists_json"

    fun getAll(context: Context): List<Playlist> {
        val raw = prefs(context).getString(KEY, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val idsArr = o.getJSONArray("tracks")
                val ids = (0 until idsArr.length()).map { idsArr.getLong(it) }
                Playlist(o.getString("id"), o.getString("name"), ids)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun get(context: Context, playlistId: String): Playlist? =
        getAll(context).firstOrNull { it.id == playlistId }

    fun create(context: Context, name: String): Playlist {
        val list = getAll(context).toMutableList()
        val pl = Playlist(
            id = "pl_${System.currentTimeMillis()}",
            name = name.ifBlank { "Playlist" },
            trackIds = emptyList()
        )
        list.add(pl)
        saveAll(context, list)
        return pl
    }

    fun rename(context: Context, playlistId: String, newName: String) {
        val list = getAll(context).map {
            if (it.id == playlistId) it.copy(name = newName.ifBlank { it.name }) else it
        }
        saveAll(context, list)
    }

    fun delete(context: Context, playlistId: String) {
        saveAll(context, getAll(context).filterNot { it.id == playlistId })
    }

    fun addTrack(context: Context, playlistId: String, trackId: Long) {
        val list = getAll(context).map { pl ->
            if (pl.id == playlistId && trackId !in pl.trackIds)
                pl.copy(trackIds = pl.trackIds + trackId)
            else pl
        }
        saveAll(context, list)
    }

    fun removeTrack(context: Context, playlistId: String, trackId: Long) {
        val list = getAll(context).map { pl ->
            if (pl.id == playlistId) pl.copy(trackIds = pl.trackIds.filterNot { it == trackId })
            else pl
        }
        saveAll(context, list)
    }

    private fun saveAll(context: Context, list: List<Playlist>) {
        val arr = JSONArray()
        list.forEach { pl ->
            val o = JSONObject()
            o.put("id", pl.id)
            o.put("name", pl.name)
            val ids = JSONArray()
            pl.trackIds.forEach { ids.put(it) }
            o.put("tracks", ids)
            arr.put(o)
        }
        prefs(context).edit().putString(KEY, arr.toString()).apply()
    }
}

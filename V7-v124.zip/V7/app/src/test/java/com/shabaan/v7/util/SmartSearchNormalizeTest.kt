package com.shabaan.v7.util

import com.google.common.truth.Truth.assertThat
import org.junit.Test

/**
 * Unit tests for [SmartSearch.normalize] — the Arabic-aware text normalization
 * that makes search forgiving (so "البقرة", "بقره", "بَقَرَة" all match). This is
 * pure string logic with no Android dependencies, so it runs as a fast local
 * JVM test.
 *
 * These assertions are pinned to the CURRENT documented behavior of normalize();
 * they're a safety net so future refactors can't silently change how search
 * matches Arabic text.
 */
class SmartSearchNormalizeTest {

    @Test
    fun empty_stays_empty() {
        assertThat(SmartSearch.normalize("")).isEqualTo("")
    }

    @Test
    fun lowercases_and_trims_latin() {
        assertThat(SmartSearch.normalize("  Hello WORLD  ")).isEqualTo("hello world")
    }

    @Test
    fun unifies_alef_variants_to_bare_alef() {
        // أ إ آ ٱ  → ا
        assertThat(SmartSearch.normalize("أحمد")).isEqualTo("احمد")
        assertThat(SmartSearch.normalize("إسلام")).isEqualTo("اسلام")
        assertThat(SmartSearch.normalize("آية")).isEqualTo("ايه") // آ→ا and ة→ه
    }

    @Test
    fun taa_marbuta_becomes_haa() {
        // ة → ه
        assertThat(SmartSearch.normalize("بقرة")).isEqualTo("بقره")
    }

    @Test
    fun alef_maqsura_becomes_yaa() {
        // ى → ي
        assertThat(SmartSearch.normalize("مصطفى")).isEqualTo("مصطفي")
    }

    @Test
    fun hamza_carriers_normalized() {
        // ؤ → و , ئ → ي
        assertThat(SmartSearch.normalize("مؤمن")).isEqualTo("مومن")
        assertThat(SmartSearch.normalize("قائد")).isEqualTo("قايد")
    }

    @Test
    fun tatweel_is_dropped() {
        // ـ (kashida) removed
        assertThat(SmartSearch.normalize("مـحـمـد")).isEqualTo("محمد")
    }

    @Test
    fun diacritics_are_stripped() {
        // harakat in \u064B..\u0652 removed
        assertThat(SmartSearch.normalize("بَقَرَة")).isEqualTo("بقره")
        assertThat(SmartSearch.normalize("مُحَمَّد")).isEqualTo("محمد")
    }

    @Test
    fun combined_real_world_query() {
        // A messy user query should normalize to the same key as the clean name.
        val messy = SmartSearch.normalize("الْبَقَرَة")
        val clean = SmartSearch.normalize("البقره")
        assertThat(messy).isEqualTo(clean)
    }
}

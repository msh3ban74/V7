package com.shabaan.v7.util

import com.google.common.truth.Truth.assertThat
import org.junit.Test

/**
 * Unit tests for [Formatters] — pure formatting logic used across the app for
 * durations and file sizes. Fast local JVM tests.
 *
 * Note on locale: fileSize() uses String.format with a float, whose decimal
 * separator is locale-dependent. To stay locale-robust we assert on the numeric
 * magnitude and unit rather than the exact separator character where relevant.
 */
class FormattersTest {

    // ---- duration ----

    @Test
    fun duration_zero_or_negative() {
        assertThat(Formatters.duration(0)).isEqualTo("0:00")
        assertThat(Formatters.duration(-5)).isEqualTo("0:00")
    }

    @Test
    fun duration_seconds_only() {
        assertThat(Formatters.duration(5_000)).isEqualTo("0:05")
        assertThat(Formatters.duration(45_000)).isEqualTo("0:45")
    }

    @Test
    fun duration_minutes_and_seconds() {
        assertThat(Formatters.duration(65_000)).isEqualTo("1:05")
        assertThat(Formatters.duration(125_000)).isEqualTo("2:05")
    }

    @Test
    fun duration_hours_format() {
        // 1 hour, 1 minute, 1 second
        assertThat(Formatters.duration(3_661_000)).isEqualTo("1:01:01")
    }

    @Test
    fun duration_rounds_down_partial_second() {
        // 1999ms -> 1 second (integer division)
        assertThat(Formatters.duration(1_999)).isEqualTo("0:01")
    }

    // ---- fileSize ----

    @Test
    fun fileSize_zero_or_negative() {
        assertThat(Formatters.fileSize(0)).isEqualTo("0 B")
        assertThat(Formatters.fileSize(-10)).isEqualTo("0 B")
    }

    @Test
    fun fileSize_bytes_unit() {
        assertThat(Formatters.fileSize(512)).contains("B")
        assertThat(Formatters.fileSize(512)).startsWith("512")
    }

    @Test
    fun fileSize_kilobytes_unit() {
        val s = Formatters.fileSize(2048) // 2 KB
        assertThat(s).contains("KB")
        assertThat(s).startsWith("2")
    }

    @Test
    fun fileSize_megabytes_unit() {
        val s = Formatters.fileSize(5L * 1024 * 1024) // 5 MB
        assertThat(s).contains("MB")
        assertThat(s).startsWith("5")
    }

    @Test
    fun fileSize_gigabytes_caps_at_gb() {
        val s = Formatters.fileSize(3L * 1024 * 1024 * 1024) // 3 GB
        assertThat(s).contains("GB")
        assertThat(s).startsWith("3")
    }
}

# Note: gradle-wrapper.jar

The binary `gradle/wrapper/gradle-wrapper.jar` file is **not** included in this
source archive because it cannot be transmitted as text.

## How to add it

### Easiest — Android Studio
Just open the project in Android Studio.
File → Open → select the `V7/` folder. Studio downloads the wrapper jar
automatically as part of the first sync.

### From the command line
If you have any system Gradle installed:

```bash
cd V7
gradle wrapper --gradle-version 8.9
```

This produces `gradle/wrapper/gradle-wrapper.jar` and the project becomes
fully self-contained — you can `./gradlew assembleRelease` from then on.

### From an existing Android project
Copy `gradle/wrapper/gradle-wrapper.jar` from any other Gradle 8.x Android
project into this one's `gradle/wrapper/` directory.

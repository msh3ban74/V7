# V7 — Premium Android Media Platform

A modern, production-grade Android media application combining a video player,
gallery, music player, reels-style playback, favorites, and a secure vault
behind a clean Titanium Silver Material 3 interface.

**Designed & developed by Mohammed Shabaan**

---

## Tech Stack

- **Language:** Kotlin 2.0.21
- **UI:** Jetpack Compose + Material 3
- **Media:** AndroidX Media3 / ExoPlayer 1.4.1 (video, audio, MediaSessionService)
- **Architecture:** MVVM + StateFlow, single-Activity Compose Navigation
- **Persistence:** Room 2.6.1 (favorites, vault, playback progress)
- **Image loading:** Coil 2.7.0 with `VideoFrameDecoder` for video thumbnails
- **Security:** AndroidX Biometric (BIOMETRIC_WEAK | DEVICE_CREDENTIAL)
- **Min SDK:** 26 / **Target SDK:** 34
- **Gradle:** 8.9 / **AGP:** 8.5.2

---

## Project Layout

```
app/src/main/java/com/shabaan/v7/
├── MainActivity.kt              # ComponentActivity host
├── V7App.kt                     # Application + ImageLoader + NotificationChannel
├── data/
│   ├── model/MediaItem.kt
│   ├── local/V7Database.kt      # Room: favorites, vault_items, playback_progress
│   └── repository/
│       ├── MediaRepository.kt   # MediaStore queries (video/image/audio)
│       ├── VaultRepository.kt   # Move/restore/delete; handles delete-consent flow
│       └── FavoritesRepository.kt
├── service/MusicService.kt      # MediaSessionService backing background playback
├── ui/
│   ├── theme/                   # Titanium Silver Material 3 palette
│   ├── navigation/V7Nav.kt      # 5-tab bottom nav + detail routes
│   ├── components/              # Permission gate, top bars, selection chrome
│   ├── videos/                  # Grid, fullscreen player, Reels (TikTok-style)
│   ├── gallery/                 # Grid, photo viewer with pinch-zoom & pan
│   ├── music/                   # Library, mini-player, expandable full player
│   ├── vault/                   # Locked grid behind biometric / device credential
│   └── settings/                # App lock, biometric, equalizer, contact links
└── util/Util.kt                 # Prefs, LockManager, Formatters
```

---

## Features

### Videos
- 3-column thumbnail grid with `VideoFrameDecoder` (Coil) and duration badge
- Fullscreen player with HorizontalPager (swipe between videos)
- Double-tap seek ±10s, single-tap toggles controls, playback speed 0.5×–2×
- **Picture-in-Picture** (API 26+)
- Reels / TikTok-style vertical pager (REPEAT_MODE_ONE, RESIZE_MODE_ZOOM)
- Share, delete, vault, favorite

### Gallery
- Responsive grid (4/5/6 columns based on screen width)
- Fullscreen photo viewer with pinch-zoom (1×–5×) and pan when zoomed
- Multi-selection, select all, share/delete/vault

### Music
- Background playback via `MediaSessionService` with audio focus + becoming-noisy handling
- Persistent media notification (via MediaSession integration)
- Mini player anchored at bottom + animated full-screen player
- Shuffle, repeat (OFF → ALL → ONE), next/previous, scrubbable progress
- System Equalizer accessible from Settings

### Vault
- Files copied into app-private `filesDir/vault/` and removed from MediaStore
- Handles `RecoverableSecurityException` and Android 11+ `createDeleteRequest`
- Restore writes back through MediaStore with proper `IS_PENDING` lifecycle
- Gated behind biometric prompt when enabled

### Favorites
- Toggle per item, persisted via Room with composite key `"TYPE:mediaId"`
- Reactive via Flow / collectAsState

### Settings
- App Lock + Biometric Authentication toggles
- System Equalizer launcher (`AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL`)
- WhatsApp / Facebook contact rows that open the system browser/app

---

## Build & Run

### Option A — Android Studio (recommended)

1. Open **Android Studio Hedgehog (2023.1.1)** or newer.
2. **File → Open** → select the unzipped `V7/` folder.
3. Studio will automatically download the Gradle wrapper and dependencies.
4. Plug in a device (Android 8.0+ / API 26+) or start an emulator.
5. Press **Run ▶**.

### Option B — Command line

The project ships without a binary `gradle-wrapper.jar` (binary files can't be
included in this source archive). Generate it once with a local Gradle install:

```bash
cd V7
gradle wrapper --gradle-version 8.9
./gradlew assembleRelease   # or assembleDebug
```

The signed-ready release APK lands at:
`app/build/outputs/apk/release/app-release-unsigned.apk`

### Release signing

`app/build.gradle.kts` is configured for a release build with R8 minification +
resource shrinking. Add your keystore under `signingConfigs { release { ... } }`
to produce a fully signed APK / AAB.

---

## Runtime Permissions

Granted at first launch (declarative in `AndroidManifest.xml`):

- `READ_MEDIA_IMAGES`, `READ_MEDIA_VIDEO`, `READ_MEDIA_AUDIO` (Android 13+)
- `READ_EXTERNAL_STORAGE` (Android ≤ 12)
- `FOREGROUND_SERVICE_MEDIA_PLAYBACK` (background music)
- `USE_BIOMETRIC` (vault unlock)
- `INTERNET` (image loading cache only — no telemetry)

---

## Known Scaffolded Surfaces

These features have working **system-level** implementations rather than custom
DSP / encoding, which keeps the APK small and stable:

- **Equalizer** → uses the device's system equalizer
  (`AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL`). Most OEMs ship one;
  if not, the user sees a Toast.
- **Convert video to MP3** & **Create stickers from video** → require an FFmpeg
  build (`com.arthenica:ffmpeg-kit-min-gpl` or similar). The repository contracts
  are ready; drop in FFmpeg-Kit and wire a small CoroutineWorker to enable.
- **Custom audio visualizer** → requires `RECORD_AUDIO` permission and the
  `Visualizer` API attached to the audio session id from `MusicService`.

The architecture cleanly accommodates these — they're isolated and additive.

---

## What's new in the upgrade

- **Hilt dependency injection** across all ViewModels and repositories
- **Dark / Light / System theme** — switch in Settings (reactive, no restart)
- **AES-256-GCM encryption** for new vault items (`EncryptedFile`, key in Keystore)
- **In-vault viewer** — open images/videos/audio inside the vault without un-hiding them; encrypted files are decrypted to a temp file only while viewing
- **Share directly from the vault**
- **Recently Deleted (trash bin)** with configurable retention (1–90 days) + auto-purge
- **PIN lock** alongside biometric, with auto-lock timer (instant / 30s / 1m / 5m / never)
- **Search + sort** (date / name / size, asc/desc) on Videos and Gallery
- **Albums tab** in Gallery (grouped by folder) + Favorites tab
- **Video gesture controls** — left-edge brightness, right-edge volume, horizontal seek, subtitle picker (SAF)
- **Resume playback** — videos remember where you stopped; a "Continue watching" row surfaces them
- **Recently played** tracking for music
- **Photo slideshow** mode + image info bottom sheet + double-tap zoom + swipe-down to dismiss
- **Shimmer loading** placeholders, settings-driven grid size, cache clearing

---

## ⚡ Performance & caching

Smooth, lag-free scrolling is a first-class feature, not an afterthought:

- **Persistent thumbnail cache** — a single app-wide Coil `ImageLoader` with a
  30% in-memory cache and a **250 MB disk cache**. Thumbnails survive app
  restarts, so a grid is only ever decoded once.
- **Stable cache keys** — every thumbnail is keyed by its media id, so the same
  decoded image is reused across the grid, the "Continue watching" row, and the
  viewer preview. No repeated decoding = no jank.
- **Downsampling** — images and video frames are decoded down to the cell size
  instead of loading full-resolution bitmaps into small tiles (the single
  biggest scroll-performance win).
- **Dedicated decode thread pool** + hardware bitmaps keep the UI thread free.
- **Load-once** — media lists are read from `MediaStore` a single time and kept
  in the ViewModel, so switching tabs never re-scans the device.

---

## Theme

**Titanium Silver** palette with full **dark mode**. Theme follows the system by
default and can be forced to Light or Dark in Settings. Palette lives in
`ui/theme/Color.kt` + `Theme.kt`.

---

## Credits

- **Creator:** Mohammed Shabaan
- **WhatsApp:** https://wa.me/qr/YS7YSH7LTN4UJ1
- **Facebook:** https://www.facebook.com/share/1Cnq5PER4i/

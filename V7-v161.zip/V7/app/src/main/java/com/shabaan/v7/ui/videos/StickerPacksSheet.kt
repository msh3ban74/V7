package com.shabaan.v7.ui.videos

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.shabaan.v7.sticker.WhatsAppSticker
import com.shabaan.v7.util.StickerPackStore
import java.io.File

/**
 * Sticker packs manager. Shows every pack the user has built, how many stickers
 * it has (with WhatsApp's 3-minimum made explicit), a preview row of the
 * stickers, an "Add to WhatsApp" button per pack, and delete actions.
 *
 * This is the screen that was missing — the place where the user actually sees
 * their packs and pushes them into WhatsApp. Reachable from the sticker button
 * area in the video player.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StickerPacksSheet(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // Reloaded each time the sheet is shown; simple refresh token for deletes.
    var refresh by remember { mutableStateOf(0) }
    val packs = remember(refresh) { StickerPackStore.getAll(ctx) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
        ) {
            Text(
                "WhatsApp Stickers",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "Make stickers from videos with the smiley button. " +
                    "A pack needs at least ${StickerPackStore.MIN_STICKERS} stickers " +
                    "before you can add it to WhatsApp.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(16.dp))

            if (packs.isEmpty()) {
                Box(
                    Modifier.fillMaxWidth().height(120.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "No sticker packs yet.\nOpen a video and tap the 😊 button to make one.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                packs.forEach { pack ->
                    StickerPackCard(
                        ctx = ctx,
                        pack = pack,
                        onAddToWhatsApp = { WhatsAppSticker.addPackOrToast(ctx, pack.identifier) },
                        onDelete = {
                            StickerPackStore.deletePack(ctx, pack.identifier)
                            refresh++
                        },
                        onDeleteSticker = { fileName ->
                            StickerPackStore.removeSticker(ctx, pack.identifier, fileName)
                            refresh++
                        }
                    )
                    Spacer(Modifier.height(14.dp))
                }
            }
        }
    }
}

@Composable
private fun StickerPackCard(
    ctx: android.content.Context,
    pack: StickerPackStore.StickerPack,
    onAddToWhatsApp: () -> Unit,
    onDelete: () -> Unit,
    onDeleteSticker: (String) -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                RoundedCornerShape(16.dp)
            )
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    pack.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    "${pack.stickers.size} / ${StickerPackStore.MAX_STICKERS} stickers" +
                        if (!pack.isAddable)
                            "  ·  need ${StickerPackStore.MIN_STICKERS - pack.stickers.size} more"
                        else "",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (pack.isAddable)
                        MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onDelete) {
                Icon(
                    Icons.Rounded.Delete,
                    contentDescription = "Delete pack",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }

        if (pack.stickers.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                pack.stickers.forEach { sticker ->
                    item(key = sticker.fileName) {
                        val file = File(
                            StickerPackStore.packDir(ctx, pack.identifier),
                            sticker.fileName
                        )
                        // Each sticker shows its own little ✕ to delete just that
                        // one sticker (not the whole pack).
                        Box {
                            AsyncImage(
                                model = file,
                                contentDescription = null,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .size(64.dp)
                                    .background(
                                        Color.White.copy(alpha = 0.06f),
                                        RoundedCornerShape(10.dp)
                                    )
                            )
                            Box(
                                Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(2.dp)
                                    .size(20.dp)
                                    .background(
                                        Color.Black.copy(alpha = 0.55f),
                                        androidx.compose.foundation.shape.CircleShape
                                    )
                                    .clickable { onDeleteSticker(sticker.fileName) },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Rounded.Close,
                                    contentDescription = "Delete this sticker",
                                    tint = Color.White,
                                    modifier = Modifier.size(13.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Button(
            onClick = onAddToWhatsApp,
            enabled = pack.isAddable,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(if (pack.isAddable) "Add to WhatsApp" else "Add more stickers first")
        }
    }
}

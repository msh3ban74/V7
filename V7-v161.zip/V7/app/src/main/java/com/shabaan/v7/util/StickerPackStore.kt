package com.shabaan.v7.util

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Data model + storage for WhatsApp sticker packs.
 *
 * WhatsApp's third-party sticker API requires the app to expose *packs* (not
 * single stickers) through a ContentProvider. This object owns:
 *   - the data model (StickerPack + Sticker),
 *   - JSON persistence of pack metadata in SharedPreferences,
 *   - the on-disk layout of the actual .webp sticker files + tray icon.
 *
 * It intentionally mirrors the structure WhatsApp expects (identifier, name,
 * publisher, tray image, per-sticker emojis) so the ContentProvider (added in a
 * later batch) can serve it directly.
 *
 * On-disk layout (all under filesDir/stickers/<packId>/):
 *   tray.png            ← pack tray icon (96x96)
 *   <stickerFile>.webp  ← each animated/static sticker
 *
 * WhatsApp rules enforced by the UI later (documented here for reference):
 *   - a pack must contain between 3 and 30 stickers to be addable,
 *   - animated sticker ≤ 500 KB, static ≤ 100 KB,
 *   - tray icon ≤ 50 KB, 96x96.
 */
object StickerPackStore {

    /** A single sticker: a .webp file name (relative to the pack dir) + emojis. */
    data class Sticker(
        val fileName: String,
        val emojis: List<String> = listOf("⭐")
    )

    /** A WhatsApp sticker pack. */
    data class StickerPack(
        val identifier: String,
        val name: String,
        val publisher: String,
        val trayImageFile: String,
        val animated: Boolean,
        val stickers: List<Sticker>
    ) {
        /** WhatsApp accepts a pack only when it has between 3 and 30 stickers. */
        val isAddable: Boolean get() = stickers.size in 3..30
    }

    private const val PREFS = "v7_sticker_packs"
    private const val KEY = "packs_json"
    const val MIN_STICKERS = 3
    const val MAX_STICKERS = 30

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Root directory that holds every pack's folder. */
    fun rootDir(context: Context): File =
        File(context.filesDir, "stickers").apply { mkdirs() }

    /** Directory holding one pack's files (tray + stickers). */
    fun packDir(context: Context, packId: String): File =
        File(rootDir(context), packId).apply { mkdirs() }

    /** Absolute file for a sticker within a pack. */
    fun stickerFile(context: Context, packId: String, fileName: String): File =
        File(packDir(context, packId), fileName)

    /** Absolute file for a pack's tray icon. */
    fun trayFile(context: Context, packId: String, trayFileName: String): File =
        File(packDir(context, packId), trayFileName)

    // ---- Read ----

    fun getAll(context: Context): List<StickerPack> {
        val raw = prefs(context).getString(KEY, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                runCatching { parsePack(arr.getJSONObject(i)) }.getOrNull()
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun get(context: Context, packId: String): StickerPack? =
        getAll(context).firstOrNull { it.identifier == packId }

    // ---- Write ----

    /** Creates a new empty pack and persists it; returns the created pack. */
    fun createPack(
        context: Context,
        name: String,
        publisher: String = "V7",
        animated: Boolean = true
    ): StickerPack {
        val id = "v7_" + System.currentTimeMillis().toString(36)
        val pack = StickerPack(
            identifier = id,
            name = name.ifBlank { "V7 Pack" },
            publisher = publisher,
            trayImageFile = "tray.png",
            animated = animated,
            stickers = emptyList()
        )
        packDir(context, id) // ensure dir exists
        val updated = getAll(context).toMutableList().apply { add(pack) }
        saveAll(context, updated)
        return pack
    }

    /** Adds a sticker (already written to disk) to a pack. */
    fun addSticker(
        context: Context,
        packId: String,
        fileName: String,
        emojis: List<String> = listOf("⭐")
    ): StickerPack? {
        val all = getAll(context).toMutableList()
        val idx = all.indexOfFirst { it.identifier == packId }
        if (idx < 0) return null
        val pack = all[idx]
        if (pack.stickers.size >= MAX_STICKERS) return pack
        val newStickers = pack.stickers + Sticker(fileName, emojis)
        val updated = pack.copy(stickers = newStickers)
        all[idx] = updated
        saveAll(context, all)
        return updated
    }

    /** Removes one sticker from a pack (and deletes its file). */
    fun removeSticker(context: Context, packId: String, fileName: String): StickerPack? {
        val all = getAll(context).toMutableList()
        val idx = all.indexOfFirst { it.identifier == packId }
        if (idx < 0) return null
        val pack = all[idx]
        val updated = pack.copy(stickers = pack.stickers.filterNot { it.fileName == fileName })
        all[idx] = updated
        saveAll(context, all)
        runCatching { stickerFile(context, packId, fileName).delete() }
        return updated
    }

    /** Deletes an entire pack (metadata + all files on disk). */
    fun deletePack(context: Context, packId: String) {
        val remaining = getAll(context).filterNot { it.identifier == packId }
        saveAll(context, remaining)
        runCatching { packDir(context, packId).deleteRecursively() }
    }

    // ---- JSON (de)serialization ----

    private fun saveAll(context: Context, packs: List<StickerPack>) {
        val arr = JSONArray()
        packs.forEach { arr.put(packToJson(it)) }
        prefs(context).edit().putString(KEY, arr.toString()).apply()
    }

    private fun packToJson(p: StickerPack): JSONObject {
        val o = JSONObject()
        o.put("identifier", p.identifier)
        o.put("name", p.name)
        o.put("publisher", p.publisher)
        o.put("tray_image_file", p.trayImageFile)
        o.put("animated_sticker_pack", p.animated)
        val arr = JSONArray()
        p.stickers.forEach { s ->
            val so = JSONObject()
            so.put("image_file", s.fileName)
            val em = JSONArray()
            s.emojis.forEach { em.put(it) }
            so.put("emojis", em)
            arr.put(so)
        }
        o.put("stickers", arr)
        return o
    }

    private fun parsePack(o: JSONObject): StickerPack {
        val stArr = o.getJSONArray("stickers")
        val stickers = (0 until stArr.length()).map { i ->
            val so = stArr.getJSONObject(i)
            val emArr = so.optJSONArray("emojis")
            val emojis = if (emArr != null)
                (0 until emArr.length()).map { emArr.getString(it) } else listOf("⭐")
            Sticker(so.getString("image_file"), emojis)
        }
        return StickerPack(
            identifier = o.getString("identifier"),
            name = o.getString("name"),
            publisher = o.optString("publisher", "V7"),
            trayImageFile = o.optString("tray_image_file", "tray.png"),
            animated = o.optBoolean("animated_sticker_pack", true),
            stickers = stickers
        )
    }
}

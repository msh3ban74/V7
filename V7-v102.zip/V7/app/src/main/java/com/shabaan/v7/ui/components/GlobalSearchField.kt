package com.shabaan.v7.ui.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp

/**
 * A single, reusable Material 3 search field used across the app (Music, Quran).
 *
 * Design goals (per the search spec):
 *  - Modern Material 3 outlined field, rounded, fits the Platinum-Silver theme
 *    via the ambient color scheme (no hard-coded colors).
 *  - A leading search icon and a trailing clear (✕) button that only appears
 *    when there is text.
 *  - "Instant while typing": the visible text updates immediately so the field
 *    never feels laggy, while the actual filtering callback [onQueryChange] is
 *    DEBOUNCED by [debounceMs] so large libraries don't re-filter on every
 *    keystroke (no UI lag).
 *
 * The parent owns the committed query value; this composable keeps a local
 * mirror only to drive the debounce. If the parent resets [query] externally
 * (e.g. clears it on tab change) the local mirror re-syncs.
 */
@Composable
fun GlobalSearchField(
    query: String,
    onQueryChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "بحث…",
    debounceMs: Long = 120L
) {
    // Local, immediately-updated text so typing is always responsive.
    var text by remember { mutableStateOf(query) }

    // Re-sync if the parent changes the value out from under us (e.g. a reset).
    LaunchedEffect(query) {
        if (query != text) text = query
    }

    // Debounce: only push the committed query to the parent after the user
    // pauses briefly. This keeps filtering off the hot keystroke path.
    LaunchedEffect(text) {
        if (text == query) return@LaunchedEffect
        kotlinx.coroutines.delay(debounceMs)
        onQueryChange(text)
    }

    OutlinedTextField(
        value = text,
        onValueChange = { text = it },
        singleLine = true,
        placeholder = { Text(placeholder) },
        leadingIcon = {
            Icon(Icons.Rounded.Search, contentDescription = "بحث")
        },
        trailingIcon = {
            if (text.isNotEmpty()) {
                IconButton(onClick = {
                    text = ""
                    onQueryChange("")          // clear immediately, no debounce wait
                }) {
                    Icon(Icons.Rounded.Close, contentDescription = "مسح البحث")
                }
            }
        },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        shape = RoundedCornerShape(14.dp),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = MaterialTheme.colorScheme.surface,
            unfocusedContainerColor = MaterialTheme.colorScheme.surface
        ),
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

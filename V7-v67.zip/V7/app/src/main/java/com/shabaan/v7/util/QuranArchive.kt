package com.shabaan.v7.util

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Rare / historical Quran recitations from the Internet Archive (archive.org).
 * Public domain, free, legal. Great for old masters (Muhammad Rifaat,
 * Mustafa Ismail, etc.) that aren't on the modern CDNs.
 *
 * Two ways in:
 *  - CURATED: a hand-picked list of well-known archive items (reliable).
 *  - SEARCH:  live query of the archive advanced-search API for anything else.
 *
 * Nothing here touches the UI, Media3/ExoPlayer, mini player, scrolling,
 * thumbnails, or cache — it only returns playable MP3 URLs.
 */
object QuranArchive {

    private const val TAG = "QuranArchive"

    data class RareItem(
        val identifier: String,   // archive.org item id
        val arabicName: String,
        val description: String
    )

    /** A single playable track inside an archive item. */
    data class ArchiveTrack(
        val title: String,
        val url: String
    )

    // ---- Curated, well-known rare recitations (reliable identifiers) ----
    val CURATED: List<RareItem> = listOf(
        RareItem("MohammadRefatRecitations",
            "الشيخ محمد رفعت", "رائد التلاوة المصرية — تسجيلات تاريخية (ت.1950)"),
        RareItem("MustafaIsmailReuploads",
            "الشيخ مصطفى إسماعيل", "أعظم أصوات القرآن — تلاوات نادرة"),
        RareItem("ShaishaeeQuran",
            "الشيخ أبو العينين شعيشع", "تلاوات كلاسيكية نادرة"),
        RareItem("AbdulBasit_Old_Radio",
            "عبد الباسط — إذاعي قديم", "تسجيلات الإذاعة المصرية القديمة"),
        RameItemSafe("AlBannaQuran",
            "الشيخ محمود علي البنا", "من كبار القراء المصريين"),
        RareItem("MinshawiMujawwad",
            "المنشاوي — مجوّد نادر", "تلاوات مجوّدة نادرة")
    )

    // Helper to keep the list literal tidy even if one id is uncertain.
    private fun RameItemSafe(id: String, ar: String, desc: String) = RareItem(id, ar, desc)

    /**
     * Fetch the playable MP3 tracks inside an archive item via its metadata API.
     * Returns an ordered list (usually surah-by-surah or part-by-part).
     */
    suspend fun tracksFor(identifier: String): List<ArchiveTrack> = withContext(Dispatchers.IO) {
        try {
            val meta = JSONObject(URL("https://archive.org/metadata/$identifier").readText())
            val server = meta.optString("server", "")
            val dir = meta.optString("dir", "")
            if (server.isBlank() || dir.isBlank()) {
                Log.w(TAG, "No server/dir for $identifier")
                return@withContext emptyList()
            }
            val files = meta.optJSONArray("files") ?: return@withContext emptyList()
            val out = mutableListOf<ArchiveTrack>()
            for (i in 0 until files.length()) {
                val f = files.getJSONObject(i)
                val name = f.optString("name", "")
                val format = f.optString("format", "").lowercase()
                if (name.endsWith(".mp3", true) || format.contains("mp3")) {
                    val title = f.optString("title", name.substringAfterLast('/'))
                        .ifBlank { name }
                    val url = "https://$server$dir/" +
                        URLEncoder.encode(name, "UTF-8").replace("+", "%20")
                    out.add(ArchiveTrack(title, url))
                }
            }
            Log.i(TAG, "Item $identifier → ${out.size} tracks")
            out
        } catch (e: Exception) {
            Log.e(TAG, "tracksFor($identifier) failed: ${e.javaClass.simpleName} ${e.message}")
            emptyList()
        }
    }

    /**
     * Live search of archive.org for Quran recitations. Returns rare items the
     * curated list doesn't include. Safe to call from a coroutine.
     */
    suspend fun search(query: String): List<RareItem> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        try {
            val q = URLEncoder.encode("$query AND (mediatype:audio) AND (subject:quran OR قرآن)", "UTF-8")
            val url = "https://archive.org/advancedsearch.php?q=$q" +
                "&fl[]=identifier&fl[]=title&rows=30&output=json"
            val json = JSONObject(URL(url).readText())
            val docs = json.getJSONObject("response").getJSONArray("docs")
            val out = mutableListOf<RareItem>()
            for (i in 0 until docs.length()) {
                val d = docs.getJSONObject(i)
                val id = d.optString("identifier", "")
                val title = d.optString("title", id)
                if (id.isNotBlank()) out.add(RareItem(id, title, "نتيجة بحث من الأرشيف"))
            }
            Log.i(TAG, "search('$query') → ${out.size} items")
            out
        } catch (e: Exception) {
            Log.e(TAG, "search failed: ${e.javaClass.simpleName} ${e.message}")
            emptyList()
        }
    }
}

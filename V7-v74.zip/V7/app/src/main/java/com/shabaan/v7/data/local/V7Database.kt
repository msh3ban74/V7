package com.shabaan.v7.data.local

import android.content.Context
import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val id: String,        // "<type>:<mediaId>"
    @ColumnInfo(name = "media_id") val mediaId: Long,
    @ColumnInfo(name = "type") val type: String,    // VIDEO / IMAGE / AUDIO
    @ColumnInfo(name = "added_at") val addedAt: Long
)

@Entity(tableName = "vault_items")
data class VaultItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "original_name") val originalName: String,
    @ColumnInfo(name = "stored_path") val storedPath: String,
    @ColumnInfo(name = "mime_type") val mimeType: String,
    @ColumnInfo(name = "type") val type: String,
    @ColumnInfo(name = "size") val size: Long,
    @ColumnInfo(name = "duration") val duration: Long = 0L,
    @ColumnInfo(name = "added_at") val addedAt: Long,
    @ColumnInfo(name = "encrypted") val encrypted: Boolean = false
)

@Entity(tableName = "playback_progress")
data class PlaybackProgressEntity(
    @PrimaryKey val mediaId: Long,
    @ColumnInfo(name = "position_ms") val positionMs: Long,
    @ColumnInfo(name = "duration_ms") val durationMs: Long = 0L,
    @ColumnInfo(name = "title") val title: String = "",
    @ColumnInfo(name = "uri") val uri: String = "",
    @ColumnInfo(name = "updated_at") val updatedAt: Long
)

@Entity(tableName = "trash")
data class TrashEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "original_name") val originalName: String,
    @ColumnInfo(name = "stored_path") val storedPath: String,
    @ColumnInfo(name = "mime_type") val mimeType: String,
    @ColumnInfo(name = "type") val type: String,
    @ColumnInfo(name = "size") val size: Long,
    @ColumnInfo(name = "deleted_at") val deletedAt: Long
)

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites ORDER BY added_at DESC")
    fun observeAll(): Flow<List<FavoriteEntity>>

    @Query("SELECT * FROM favorites WHERE type = :type ORDER BY added_at DESC")
    fun observeByType(type: String): Flow<List<FavoriteEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE id = :id)")
    fun exists(id: String): Flow<Boolean>

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE id = :id)")
    suspend fun existsNow(id: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(fav: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface VaultDao {
    @Query("SELECT * FROM vault_items ORDER BY added_at DESC")
    fun observeAll(): Flow<List<VaultItemEntity>>

    @Query("SELECT * FROM vault_items WHERE type = :type ORDER BY added_at DESC")
    fun observeByType(type: String): Flow<List<VaultItemEntity>>

    @Insert
    suspend fun insert(item: VaultItemEntity): Long

    @Query("DELETE FROM vault_items WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM vault_items WHERE id = :id")
    suspend fun get(id: Long): VaultItemEntity?
}

@Dao
interface ProgressDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(p: PlaybackProgressEntity)

    @Query("SELECT * FROM playback_progress WHERE mediaId = :id")
    suspend fun get(id: Long): PlaybackProgressEntity?

    @Query("SELECT * FROM playback_progress ORDER BY updated_at DESC LIMIT 50")
    fun recent(): Flow<List<PlaybackProgressEntity>>

    @Query("DELETE FROM playback_progress WHERE mediaId = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface TrashDao {
    @Query("SELECT * FROM trash ORDER BY deleted_at DESC")
    fun observeAll(): Flow<List<TrashEntity>>

    @Insert
    suspend fun insert(item: TrashEntity): Long

    @Query("DELETE FROM trash WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM trash WHERE deleted_at < :cutoffMs")
    suspend fun expiredBefore(cutoffMs: Long): List<TrashEntity>

    @Query("SELECT * FROM trash WHERE id = :id")
    suspend fun get(id: Long): TrashEntity?
}

@Database(
    entities = [
        FavoriteEntity::class,
        VaultItemEntity::class,
        PlaybackProgressEntity::class,
        TrashEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class V7Database : RoomDatabase() {
    abstract fun favoriteDao(): FavoriteDao
    abstract fun vaultDao(): VaultDao
    abstract fun progressDao(): ProgressDao
    abstract fun trashDao(): TrashDao

    companion object {
        @Volatile private var INSTANCE: V7Database? = null
        fun get(ctx: Context): V7Database = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                ctx.applicationContext,
                V7Database::class.java,
                "v7.db"
            ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
        }
    }
}

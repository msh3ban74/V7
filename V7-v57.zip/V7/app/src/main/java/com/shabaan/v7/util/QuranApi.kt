package com.shabaan.v7.util

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL

/**
 * Al-Quran Cloud API client (api.alquran.cloud) — free, no key needed.
 * Hafs an Asim recitations only (the standard everyone knows).
 */
object QuranApi {

    data class Reciter(
        val identifier: String,
        val arabicName: String,
        val englishName: String
    )

    data class Surah(
        val number: Int,
        val arabicName: String,
        val englishName: String,
        val ayahCount: Int,
        val revelationType: String
    )

    // ---- Large fallback reciter list (all Hafs, all reliable) ----
    val RECITERS: List<Reciter> = listOf(
        Reciter("ar.alafasy",            "مشاري راشد العفاسي",        "Mishary Rashid Al-Afasy"),
        Reciter("ar.abdulbasitmurattal", "عبد الباسط عبد الصمد (مرتّل)","Abdul Basit (Murattal)"),
        Reciter("ar.abdulsamad",         "عبد الباسط عبد الصمد (مجوّد)","Abdul Basit (Mujawwad)"),
        Reciter("ar.abdurrahmaansudais", "عبد الرحمن السديس",          "Abdurrahmaan As-Sudais"),
        Reciter("ar.shaatree",           "أبو بكر الشاطري",            "Abu Bakr Ash-Shaatree"),
        Reciter("ar.ahmedajamy",         "أحمد بن علي العجمي",         "Ahmed ibn Ali Al-Ajamy"),
        Reciter("ar.hanirifai",          "هاني الرفاعي",               "Hani Ar-Rifai"),
        Reciter("ar.husary",             "محمود خليل الحصري (مرتّل)",  "Mahmoud Al-Husary (Murattal)"),
        Reciter("ar.husarymujawwad",     "محمود خليل الحصري (مجوّد)",  "Al-Husary (Mujawwad)"),
        Reciter("ar.minshawi",           "محمد صديق المنشاوي (مرتّل)", "Al-Minshawi (Murattal)"),
        Reciter("ar.minshawimujawwad",   "محمد صديق المنشاوي (مجوّد)", "Al-Minshawi (Mujawwad)"),
        Reciter("ar.muhammadayyoub",     "محمد أيوب",                  "Muhammad Ayyoub"),
        Reciter("ar.muhammadjibreel",    "محمد جبريل",                 "Muhammad Jibreel"),
        Reciter("ar.saoodshuraym",       "سعود الشريم",                "Saood bin Ibrahim Ash-Shuraym"),
        Reciter("ar.mahermuaiqly",       "ماهر المعيقلي",              "Maher Al-Muaiqly"),
        Reciter("ar.ibrahimakhbar",      "إبراهيم الأخضر",             "Ibrahim Al-Akhdar"),
        Reciter("ar.parhizgar",          "شهريار برهيزكار",            "Parhizgar"),
        Reciter("ar.aymanswoaid",        "أيمن سويد",                  "Ayman Swoaid"),
        Reciter("ar.hudhaify",           "علي بن عبدالرحمن الحذيفي",   "Ali Al-Hudhaify"),
        Reciter("ar.hothifi",            "علي الحذيفي",                "Al-Hudhaify"),
        Reciter("ar.muhammadhusary",     "محمود الحصري (معلّم)",       "Al-Husary (Muallim)"),
        Reciter("ar.abdullahbasfar",     "عبد الله بصفر",              "Abdullah Basfar"),
        Reciter("ar.abdullaharkani",     "عبد الله المطرود",           "Abdullah Al-Matroud"),
        Reciter("ar.abdulahad",          "عبد الواحد المغربي",         "Abdul Wahid Al-Maghribi"),
        Reciter("ar.fares",              "فارس عباد",                  "Fares Abbad"),
        Reciter("ar.yasser",             "ياسر الدوسري",               "Yasser Al-Dosari"),
        Reciter("ar.nasseralqatami",     "ناصر القطامي",               "Nasser Al-Qatami"),
        Reciter("ar.ghamadi",            "سعد الغامدي",                "Saad Al-Ghamdi"),
        Reciter("ar.tablawi",            "محمد محمود الطبلاوي",        "Mohammad Al-Tablawi"),
        Reciter("ar.aliuhuili",          "علي الحذيفي",                "Ali Al-Huzaifi"),
        Reciter("ar.khalefa",            "خليفة الطنيجي",              "Khalifa Al-Tunaiji"),
        Reciter("ar.jaberabdulhameed",   "جابر عبد الحميد",            "Jaber Abdul Hameed"),
        Reciter("ar.salahbukhatir",      "صلاح بوخاطر",                "Salah Bukhatir"),
        Reciter("ar.ahmadnauina",        "أحمد نعينع",                 "Ahmad Nuayna"),
        Reciter("ar.muhammadtaha",       "محمد طه الجنيد",             "Muhammad Taha Al-Junaid"),
        Reciter("ar.abdulmohsenalqasim",  "عبد المحسن القاسم",          "Abdulmohsen Al-Qasim"),
        Reciter("ar.idreesabkr",         "إدريس أبكر",                 "Idrees Abkar"),
        Reciter("ar.khalidaljalil",      "خالد الجليل",                "Khalid Al-Jalil"),
        Reciter("ar.bandaralbaleela",    "بندر بليلة",                 "Bandar Baleela"),
        Reciter("ar.yasiraldossari",     "ياسر الدوسري",               "Yasser Al-Dossari")
    )

    fun surahAudioUrl(surahNumber: Int, reciterIdentifier: String): Uri =
        Uri.parse("https://cdn.islamic.network/quran/audio-surah/128/$reciterIdentifier/$surahNumber.mp3")

    fun searchSurahs(query: String): List<Surah> {
        if (query.isBlank()) return SURAHS
        val q = query.trim()
        return SURAHS.filter {
            it.arabicName.contains(q) ||
            it.englishName.contains(q, ignoreCase = true) ||
            it.number.toString() == q
        }
    }

    fun searchReciters(query: String): List<Reciter> {
        if (query.isBlank()) return RECITERS
        val q = query.trim()
        return RECITERS.filter {
            it.arabicName.contains(q) || it.englishName.contains(q, ignoreCase = true)
        }
    }

    /** Fetch all available reciters from the API (50+). Falls back to hardcoded on error. */
    suspend fun fetchAllReciters(): List<Reciter> = withContext(Dispatchers.IO) {
        try {
            val json = JSONObject(URL("https://api.alquran.cloud/v1/edition/type/audio").readText())
            val arr = json.getJSONArray("data")
            val list = mutableListOf<Reciter>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.getString("identifier")
                if (!id.startsWith("ar.")) continue   // Arabic reciters only
                val eng = o.optString("englishName", id)
                val arabic = ARABIC_NAMES[id] ?: eng
                list.add(Reciter(id, arabic, eng))
            }
            if (list.size >= RECITERS.size) list else RECITERS
        } catch (e: Exception) {
            RECITERS
        }
    }

    private val ARABIC_NAMES = mapOf(
        "ar.alafasy" to "مشاري راشد العفاسي",
        "ar.abdulbasitmurattal" to "عبد الباسط عبد الصمد (مرتّل)",
        "ar.abdulsamad" to "عبد الباسط عبد الصمد (مجوّد)",
        "ar.abdurrahmaansudais" to "عبد الرحمن السديس",
        "ar.shaatree" to "أبو بكر الشاطري",
        "ar.ahmedajamy" to "أحمد بن علي العجمي",
        "ar.hanirifai" to "هاني الرفاعي",
        "ar.husary" to "محمود خليل الحصري (مرتّل)",
        "ar.husarymujawwad" to "محمود خليل الحصري (مجوّد)",
        "ar.minshawi" to "محمد صديق المنشاوي (مرتّل)",
        "ar.minshawimujawwad" to "محمد صديق المنشاوي (مجوّد)",
        "ar.muhammadayyoub" to "محمد أيوب",
        "ar.muhammadjibreel" to "محمد جبريل",
        "ar.saoodshuraym" to "سعود الشريم",
        "ar.mahermuaiqly" to "ماهر المعيقلي",
        "ar.ibrahimakhbar" to "إبراهيم الأخضر",
        "ar.hudhaify" to "علي بن عبدالرحمن الحذيفي",
        "ar.abdullahbasfar" to "عبد الله بصفر",
        "ar.abdullaharkani" to "عبد الله المطرود",
        "ar.fares" to "فارس عباد",
        "ar.nasseralqatami" to "ناصر القطامي",
        "ar.ghamadi" to "سعد الغامدي",
        "ar.tablawi" to "محمد محمود الطبلاوي",
        "ar.muhammadtaha" to "محمد طه الجنيد",
        "ar.idreesabkr" to "إدريس أبكر",
        "ar.bandaralbaleela" to "بندر بليلة",
        "ar.yasiraldossari" to "ياسر الدوسري"
    )

    /** Download surah MP3 to Music/V7 Quran */
    suspend fun downloadSurah(
        context: Context,
        surahNumber: Int,
        surahName: String,
        reciterIdentifier: String,
        reciterName: String,
        onProgress: (Float) -> Unit = {}
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val url = "https://cdn.islamic.network/quran/audio-surah/128/$reciterIdentifier/$surahNumber.mp3"
            val safeName = "${surahNumber}_${surahName}_${reciterName}"
                .replace(" ", "_").replace("/", "_")
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Audio.Media.DISPLAY_NAME, "$safeName.mp3")
                put(android.provider.MediaStore.Audio.Media.MIME_TYPE, "audio/mpeg")
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q)
                    put(android.provider.MediaStore.Audio.Media.RELATIVE_PATH,
                        android.os.Environment.DIRECTORY_MUSIC + "/V7 Quran")
            }
            val resolver = context.contentResolver
            val col = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q)
                android.provider.MediaStore.Audio.Media.getContentUri(android.provider.MediaStore.VOLUME_EXTERNAL_PRIMARY)
            else android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val uri = resolver.insert(col, values) ?: return@withContext false
            val conn = URL(url).openConnection().also { it.connect() }
            val total = conn.contentLengthLong
            resolver.openOutputStream(uri)?.use { os ->
                conn.getInputStream().use { input ->
                    val buf = ByteArray(256 * 1024); var read = 0L; var n: Int
                    while (input.read(buf).also { n = it } >= 0) {
                        os.write(buf, 0, n); read += n
                        if (total > 0) onProgress(read.toFloat() / total)
                    }
                }
            } ?: return@withContext false
            onProgress(1f); true
        } catch (e: Exception) { false }
    }

    // ---- 114 Surahs ----
    val SURAHS: List<Surah> = listOf(
        Surah(1,"الفاتحة","Al-Fatihah",7,"مكية"),
        Surah(2,"البقرة","Al-Baqarah",286,"مدنية"),
        Surah(3,"آل عمران","Ali 'Imran",200,"مدنية"),
        Surah(4,"النساء","An-Nisa",176,"مدنية"),
        Surah(5,"المائدة","Al-Ma'idah",120,"مدنية"),
        Surah(6,"الأنعام","Al-An'am",165,"مكية"),
        Surah(7,"الأعراف","Al-A'raf",206,"مكية"),
        Surah(8,"الأنفال","Al-Anfal",75,"مدنية"),
        Surah(9,"التوبة","At-Tawbah",129,"مدنية"),
        Surah(10,"يونس","Yunus",109,"مكية"),
        Surah(11,"هود","Hud",123,"مكية"),
        Surah(12,"يوسف","Yusuf",111,"مكية"),
        Surah(13,"الرعد","Ar-Ra'd",43,"مدنية"),
        Surah(14,"إبراهيم","Ibrahim",52,"مكية"),
        Surah(15,"الحجر","Al-Hijr",99,"مكية"),
        Surah(16,"النحل","An-Nahl",128,"مكية"),
        Surah(17,"الإسراء","Al-Isra",111,"مكية"),
        Surah(18,"الكهف","Al-Kahf",110,"مكية"),
        Surah(19,"مريم","Maryam",98,"مكية"),
        Surah(20,"طه","Ta-Ha",135,"مكية"),
        Surah(21,"الأنبياء","Al-Anbiya",112,"مكية"),
        Surah(22,"الحج","Al-Hajj",78,"مدنية"),
        Surah(23,"المؤمنون","Al-Mu'minun",118,"مكية"),
        Surah(24,"النور","An-Nur",64,"مدنية"),
        Surah(25,"الفرقان","Al-Furqan",77,"مكية"),
        Surah(26,"الشعراء","Ash-Shu'ara",227,"مكية"),
        Surah(27,"النمل","An-Naml",93,"مكية"),
        Surah(28,"القصص","Al-Qasas",88,"مكية"),
        Surah(29,"العنكبوت","Al-'Ankabut",69,"مكية"),
        Surah(30,"الروم","Ar-Rum",60,"مكية"),
        Surah(31,"لقمان","Luqman",34,"مكية"),
        Surah(32,"السجدة","As-Sajdah",30,"مكية"),
        Surah(33,"الأحزاب","Al-Ahzab",73,"مدنية"),
        Surah(34,"سبأ","Saba",54,"مكية"),
        Surah(35,"فاطر","Fatir",45,"مكية"),
        Surah(36,"يس","Ya-Sin",83,"مكية"),
        Surah(37,"الصافات","As-Saffat",182,"مكية"),
        Surah(38,"ص","Sad",88,"مكية"),
        Surah(39,"الزمر","Az-Zumar",75,"مكية"),
        Surah(40,"غافر","Ghafir",85,"مكية"),
        Surah(41,"فصلت","Fussilat",54,"مكية"),
        Surah(42,"الشورى","Ash-Shura",53,"مكية"),
        Surah(43,"الزخرف","Az-Zukhruf",89,"مكية"),
        Surah(44,"الدخان","Ad-Dukhan",59,"مكية"),
        Surah(45,"الجاثية","Al-Jathiyah",37,"مكية"),
        Surah(46,"الأحقاف","Al-Ahqaf",35,"مكية"),
        Surah(47,"محمد","Muhammad",38,"مدنية"),
        Surah(48,"الفتح","Al-Fath",29,"مدنية"),
        Surah(49,"الحجرات","Al-Hujurat",18,"مدنية"),
        Surah(50,"ق","Qaf",45,"مكية"),
        Surah(51,"الذاريات","Adh-Dhariyat",60,"مكية"),
        Surah(52,"الطور","At-Tur",49,"مكية"),
        Surah(53,"النجم","An-Najm",62,"مكية"),
        Surah(54,"القمر","Al-Qamar",55,"مكية"),
        Surah(55,"الرحمن","Ar-Rahman",78,"مدنية"),
        Surah(56,"الواقعة","Al-Waqi'ah",96,"مكية"),
        Surah(57,"الحديد","Al-Hadid",29,"مدنية"),
        Surah(58,"المجادلة","Al-Mujadila",22,"مدنية"),
        Surah(59,"الحشر","Al-Hashr",24,"مدنية"),
        Surah(60,"الممتحنة","Al-Mumtahanah",13,"مدنية"),
        Surah(61,"الصف","As-Saf",14,"مدنية"),
        Surah(62,"الجمعة","Al-Jumu'ah",11,"مدنية"),
        Surah(63,"المنافقون","Al-Munafiqun",11,"مدنية"),
        Surah(64,"التغابن","At-Taghabun",18,"مدنية"),
        Surah(65,"الطلاق","At-Talaq",12,"مدنية"),
        Surah(66,"التحريم","At-Tahrim",12,"مدنية"),
        Surah(67,"الملك","Al-Mulk",30,"مكية"),
        Surah(68,"القلم","Al-Qalam",52,"مكية"),
        Surah(69,"الحاقة","Al-Haqqah",52,"مكية"),
        Surah(70,"المعارج","Al-Ma'arij",44,"مكية"),
        Surah(71,"نوح","Nuh",28,"مكية"),
        Surah(72,"الجن","Al-Jinn",28,"مكية"),
        Surah(73,"المزمل","Al-Muzzammil",20,"مكية"),
        Surah(74,"المدثر","Al-Muddaththir",56,"مكية"),
        Surah(75,"القيامة","Al-Qiyamah",40,"مكية"),
        Surah(76,"الإنسان","Al-Insan",31,"مدنية"),
        Surah(77,"المرسلات","Al-Mursalat",50,"مكية"),
        Surah(78,"النبأ","An-Naba",40,"مكية"),
        Surah(79,"النازعات","An-Nazi'at",46,"مكية"),
        Surah(80,"عبس","Abasa",42,"مكية"),
        Surah(81,"التكوير","At-Takwir",29,"مكية"),
        Surah(82,"الانفطار","Al-Infitar",19,"مكية"),
        Surah(83,"المطففين","Al-Mutaffifin",36,"مكية"),
        Surah(84,"الانشقاق","Al-Inshiqaq",25,"مكية"),
        Surah(85,"البروج","Al-Buruj",22,"مكية"),
        Surah(86,"الطارق","At-Tariq",17,"مكية"),
        Surah(87,"الأعلى","Al-A'la",19,"مكية"),
        Surah(88,"الغاشية","Al-Ghashiyah",26,"مكية"),
        Surah(89,"الفجر","Al-Fajr",30,"مكية"),
        Surah(90,"البلد","Al-Balad",20,"مكية"),
        Surah(91,"الشمس","Ash-Shams",15,"مكية"),
        Surah(92,"الليل","Al-Layl",21,"مكية"),
        Surah(93,"الضحى","Ad-Duha",11,"مكية"),
        Surah(94,"الشرح","Ash-Sharh",8,"مكية"),
        Surah(95,"التين","At-Tin",8,"مكية"),
        Surah(96,"العلق","Al-'Alaq",19,"مكية"),
        Surah(97,"القدر","Al-Qadr",5,"مكية"),
        Surah(98,"البينة","Al-Bayyinah",8,"مدنية"),
        Surah(99,"الزلزلة","Az-Zalzalah",8,"مدنية"),
        Surah(100,"العاديات","Al-'Adiyat",11,"مكية"),
        Surah(101,"القارعة","Al-Qari'ah",11,"مكية"),
        Surah(102,"التكاثر","At-Takathur",8,"مكية"),
        Surah(103,"العصر","Al-'Asr",3,"مكية"),
        Surah(104,"الهمزة","Al-Humazah",9,"مكية"),
        Surah(105,"الفيل","Al-Fil",5,"مكية"),
        Surah(106,"قريش","Quraysh",4,"مكية"),
        Surah(107,"الماعون","Al-Ma'un",7,"مكية"),
        Surah(108,"الكوثر","Al-Kawthar",3,"مكية"),
        Surah(109,"الكافرون","Al-Kafirun",6,"مكية"),
        Surah(110,"النصر","An-Nasr",3,"مدنية"),
        Surah(111,"المسد","Al-Masad",5,"مكية"),
        Surah(112,"الإخلاص","Al-Ikhlas",4,"مكية"),
        Surah(113,"الفلق","Al-Falaq",5,"مكية"),
        Surah(114,"الناس","An-Nas",6,"مكية")
    )
}

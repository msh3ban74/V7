package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Scheme Colors (Vibrant & Classic)
val LightPrimary = Color(0xFF6366F1)       // Indigo Spark
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFE0E7FF)
val LightOnPrimaryContainer = Color(0xFF312E81)
val LightSecondary = Color(0xFF0EA5E9)     // Sky Blue
val LightOnSecondary = Color(0xFFFFFFFF)
val LightTertiary = Color(0xFF10B981)      // Emerald Green
val LightBackground = Color(0xFFF8FAFC)    // Light slate
val LightSurface = Color(0xFFFFFFFF)
val LightOnBackground = Color(0xFF0F172A)
val LightOnSurface = Color(0xFF0F172A)

// Dark/Cosmic Scheme Colors (Premium dark aesthetic)
val DarkPrimary = Color(0xFF8B5CF6)        // Cosmic violet
val DarkOnPrimary = Color(0xFFFFFFFF)
val DarkPrimaryContainer = Color(0xFF2E1065)
val DarkOnPrimaryContainer = Color(0xFFEDE9FE)
val DarkSecondary = Color(0xFF06B6D4)      // Cyan
val DarkOnSecondary = Color(0xFF083344)
val DarkTertiary = Color(0xFFF43F5E)       // Rose accent
val DarkBackground = Color(0xFF0B0F19)     // Deep obsidian space
val DarkSurface = Color(0xFF161B26)        // Dark slate card
val DarkOnBackground = Color(0xFFF1F5F9)
val DarkOnSurface = Color(0xFFF1F5F9)

// Common color constants for custom canvas elements
val WaveformColor = Color(0xFF10B981)      // Neon Green
val TrackBarBg = Color(0xFF334155)         // Slate active/inactive track

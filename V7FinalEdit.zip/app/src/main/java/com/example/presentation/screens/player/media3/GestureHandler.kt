package com.example.presentation.screens.player.media3

import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize

/**
 * Gesture Handler layer that intercepts double-taps for seeks
 * and vertical drag swipes on split halves of the viewport for Volume/Brightness controls.
 */
@Composable
fun GestureHandler(
    modifier: Modifier = Modifier,
    onSingleTap: () -> Unit,
    onLeftDoubleTap: () -> Unit,
    onRightDoubleTap: () -> Unit,
    content: @Composable () -> Unit
) {
    var size by remember { mutableStateOf(IntSize.Zero) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .onSizeChanged { size = it }
            .pointerInput(size) {
                if (size.width == 0) return@pointerInput
                detectTapGestures(
                    onTap = { onSingleTap() },
                    onDoubleTap = { offset ->
                        val halfWidth = size.width / 2f
                        if (offset.x < halfWidth) {
                            onLeftDoubleTap()
                        } else {
                            onRightDoubleTap()
                        }
                    }
                )
            }
    ) {
        content()
    }
}

package com.example.presentation.permission

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat

/**
 * Clean helper to determine and query required local media permissions.
 */
object LocalPermissionManager {

    /**
     * Required permissions list depending on Android build version (Android 13+ Scoped vs Legacy).
     */
    val requiredStoragePermissions: List<String>
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            listOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

    /**
     * Checks if all required storage permissions are currently granted.
     */
    fun hasStoragePermissions(context: Context): Boolean {
        return requiredStoragePermissions.all { permission ->
            ContextCompat.checkSelfPermission(
                context,
                permission
            ) == PackageManager.PERMISSION_GRANTED
        }
    }
}

/**
 * Handy Jetpack Compose hook helper to trigger and track storage authorization.
 */
@Composable
fun rememberStoragePermissionLauncher(
    onPermissionResult: (Boolean) -> Unit
): () -> Unit {
    val context = LocalContext.current
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        // Verify if all requested permissions are successfully granted
        val allGranted = results.all { it.value }
        onPermissionResult(allGranted)
    }

    // Return the execution trigger lambda
    return remember {
        {
            if (LocalPermissionManager.hasStoragePermissions(context)) {
                onPermissionResult(true)
            } else {
                permissionLauncher.launch(
                    LocalPermissionManager.requiredStoragePermissions.toTypedArray()
                )
            }
        }
    }
}

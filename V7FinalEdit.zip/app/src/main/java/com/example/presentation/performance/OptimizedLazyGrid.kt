package com.example.presentation.performance

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridScope
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun OptimizedLazyGrid(
    performanceState: PerformanceState,
    modifier: Modifier = Modifier,
    columns: GridCells = GridCells.Fixed(2),
    contentPadding: PaddingValues = PaddingValues(bottom = 32.dp),
    verticalArrangement: Arrangement.Vertical = Arrangement.spacedBy(14.dp),
    horizontalArrangement: Arrangement.Horizontal = Arrangement.spacedBy(14.dp),
    content: LazyGridScope.() -> Unit
) {
    LazyVerticalGrid(
        columns = columns,
        state = performanceState.gridState,
        verticalArrangement = verticalArrangement,
        horizontalArrangement = horizontalArrangement,
        contentPadding = contentPadding,
        modifier = modifier.fillMaxSize()
    ) {
        content()
    }
}

package com.example.presentation.theme

enum class ThemeMode {
    TITANIUM_SILVER, PURE_BLACK
}

data class ThemeState(
    val themeMode: ThemeMode = ThemeMode.TITANIUM_SILVER,
    val useDynamicColor: Boolean = false,
    val animationsEnabled: Boolean = true
)

package com.example.presentation.immersive

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer

/**
 * Lightweight, fully on-device "Convert to MP3" helper.
 *
 * Implementation note: this performs a real local audio-track extraction with the
 * Android-native [MediaExtractor] + [MediaMuxer] APIs — no cloud, no bundled FFmpeg,
 * no fake processing. The native muxer writes the extracted audio stream (typically
 * AAC) into an MP4/M4A container, which is the honest, dependency-free result on
 * Android. The original video file is never modified.
 */
object VideoToMp3Converter {

    sealed interface ConversionResult {
        data class Success(val outputPath: String) : ConversionResult
        data class Failure(val message: String) : ConversionResult
    }

    /**
     * Extracts the audio track of [sourceUri] into an audio file inside the app's
     * external Music directory. Runs entirely on [Dispatchers.IO].
     *
     * @param onProgress invoked with 0f..1f as samples are written.
     */
    suspend fun convert(
        context: Context,
        sourceUri: Uri,
        displayName: String,
        onProgress: (Float) -> Unit
    ): ConversionResult = withContext(Dispatchers.IO) {
        var extractor: MediaExtractor? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        var outFile: File? = null
        try {
            extractor = MediaExtractor()
            extractor.setDataSource(context, sourceUri, null)

            // Locate the first audio track in the container.
            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    audioFormat = format
                    break
                }
            }
            if (audioTrackIndex < 0 || audioFormat == null) {
                return@withContext ConversionResult.Failure("No audio track found in this video.")
            }

            extractor.selectTrack(audioTrackIndex)

            // Output directory: app-specific external Music dir — needs no runtime permission.
            val outDir = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC)
                ?: File(context.filesDir, "converted_audio").apply { mkdirs() }
            outDir.mkdirs()
            val baseName = displayName.substringBeforeLast('.')
                .ifBlank { "audio_${System.currentTimeMillis()}" }
            outFile = uniqueFile(outDir, baseName, "m4a")

            muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val outputTrack = muxer.addTrack(audioFormat)
            muxer.start()
            muxerStarted = true

            val maxInputSize = if (audioFormat.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                audioFormat.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
            } else {
                256 * 1024
            }
            val buffer = ByteBuffer.allocate(maxInputSize.coerceIn(64 * 1024, 4 * 1024 * 1024))
            val bufferInfo = MediaCodec.BufferInfo()

            val totalDurationUs = if (audioFormat.containsKey(MediaFormat.KEY_DURATION)) {
                audioFormat.getLong(MediaFormat.KEY_DURATION)
            } else {
                0L
            }

            onProgress(0f)
            while (true) {
                val sampleSize = extractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break

                bufferInfo.offset = 0
                bufferInfo.size = sampleSize
                bufferInfo.presentationTimeUs = extractor.sampleTime
                bufferInfo.flags = extractor.sampleFlags

                muxer.writeSampleData(outputTrack, buffer, bufferInfo)

                if (totalDurationUs > 0L) {
                    val p = (bufferInfo.presentationTimeUs.toFloat() / totalDurationUs)
                        .coerceIn(0f, 1f)
                    onProgress(p)
                }
                extractor.advance()
            }
            onProgress(1f)

            // Make the new file visible to other media apps.
            try {
                MediaScannerConnection.scanFile(
                    context, arrayOf(outFile.absolutePath), arrayOf("audio/mp4"), null
                )
            } catch (ignored: Exception) { }

            ConversionResult.Success(outFile.absolutePath)
        } catch (e: Exception) {
            e.printStackTrace()
            // Clean up a partially written output file on failure.
            try { outFile?.takeIf { it.exists() }?.delete() } catch (ignored: Exception) { }
            ConversionResult.Failure(e.localizedMessage ?: "Conversion failed.")
        } finally {
            if (muxerStarted) {
                try { muxer?.stop() } catch (ignored: Exception) { }
            }
            try { muxer?.release() } catch (ignored: Exception) { }
            try { extractor?.release() } catch (ignored: Exception) { }
        }
    }

    private fun uniqueFile(dir: File, baseName: String, ext: String): File {
        var candidate = File(dir, "$baseName.$ext")
        var counter = 1
        while (candidate.exists()) {
            candidate = File(dir, "${baseName}_$counter.$ext")
            counter++
        }
        return candidate
    }
}

package com.example.presentation.screens.watchhistory

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class ContinueWatchingManager(private val repository: WatchHistoryRepository) {

    val continueWatchingList: Flow<List<WatchHistoryEntity>> = repository.watchHistory.map { historyList ->
        historyList.filter { 
            // Return items where playback is incomplete
            it.duration > 0 && it.playbackPosition > 0 && it.playbackPosition < (it.duration - 5000) 
        }
    }
}

package com.example.presentation.screens.gallery.favorites

/**
 * State representing currently favorited local media item IDs on the device.
 */
data class FavoritesState(
    val favoriteVideoIds: Set<Long> = emptySet(),
    val favoriteImageIds: Set<Long> = emptySet(),
    val favoriteAudioIds: Set<Long> = emptySet()
) {
    /**
     * Checks if a particular media item is marked as favorite by ID and type.
     */
    fun isFavorite(id: Long, type: String): Boolean {
        return when (type.lowercase()) {
            "video" -> favoriteVideoIds.contains(id)
            "image" -> favoriteImageIds.contains(id)
            "audio", "music" -> favoriteAudioIds.contains(id)
            else -> false
        }
    }
}

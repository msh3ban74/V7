package com.example.presentation.immersive

/**
 * Tiny process-wide flag used to keep the app session stable across a share action.
 *
 * Opening the Android Sharesheet sends the hosting Activity through ON_STOP, which would
 * otherwise trigger the app-lock / session teardown logic and make the app appear to
 * "close" when the user returns. [ShareMediaManager] marks a share as in-flight here, and
 * lifecycle observers consult [consumeShareInFlight] to skip exactly one stop-triggered
 * lock so the user returns straight to their content.
 */
object ShareSession {

    @Volatile
    private var shareInFlight: Boolean = false

    @Volatile
    private var markedAt: Long = 0L

    /** Called right before the system Sharesheet is launched. */
    fun markShareStarted() {
        shareInFlight = true
        markedAt = System.currentTimeMillis()
    }

    /**
     * Returns true once if a share was started recently (within [WINDOW_MS]) and clears
     * the flag. Used by lifecycle observers to skip a single stop-triggered lock.
     */
    fun consumeShareInFlight(): Boolean {
        if (!shareInFlight) return false
        val fresh = System.currentTimeMillis() - markedAt <= WINDOW_MS
        shareInFlight = false
        return fresh
    }

    private const val WINDOW_MS = 60_000L
}

package com.example.presentation.screens.watchhistory

import android.content.Context
import androidx.room.*
import com.example.domain.model.LocalMediaItem
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "watch_history")
data class WatchHistoryEntity(
    @PrimaryKey val mediaId: Long,
    val mediaUri: String,
    val title: String,
    val mediaType: String, // "video", "audio", "image"
    val lastWatchedTime: Long,
    val playbackPosition: Long,
    val duration: Long
)

@Dao
interface WatchHistoryDao {
    @Query("SELECT * FROM watch_history ORDER BY lastWatchedTime DESC")
    fun getAllHistory(): Flow<List<WatchHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(entity: WatchHistoryEntity)

    @Query("DELETE FROM watch_history")
    suspend fun clearHistory()
    
    @Query("SELECT * FROM watch_history WHERE mediaId = :mediaId LIMIT 1")
    suspend fun getHistoryById(mediaId: Long): WatchHistoryEntity?
}

@Database(entities = [
    WatchHistoryEntity::class, 
    com.example.presentation.screens.favorites.FavoriteEntity::class,
    com.example.data.datasource.cache.MediaCacheEntity::class
], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun watchHistoryDao(): WatchHistoryDao
    abstract fun favoriteDao(): com.example.presentation.screens.favorites.FavoriteDao
    abstract fun mediaCacheDao(): com.example.data.datasource.cache.MediaCacheDao
    
    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "app_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class WatchHistoryRepository(private val context: Context) {
    private val dao by lazy { AppDatabase.getDatabase(context).watchHistoryDao() }

    val watchHistory: Flow<List<WatchHistoryEntity>>
        get() = dao.getAllHistory()

    suspend fun addHistory(
        id: Long,
        uri: String,
        title: String,
        type: String, // "video", "audio", "image"
        position: Long,
        duration: Long
    ) {
        val entity = WatchHistoryEntity(
            mediaId = id,
            mediaUri = uri,
            title = title,
            mediaType = type,
            lastWatchedTime = System.currentTimeMillis(),
            playbackPosition = position,
            duration = duration
        )
        dao.insertHistory(entity)
    }

    suspend fun clearHistory() {
        dao.clearHistory()
    }

    suspend fun getHistory(id: Long): WatchHistoryEntity? {
        return dao.getHistoryById(id)
    }
}

package com.example.presentation.performance

import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.pager.PagerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember

@Stable
class SmoothScrollController(
    val pagerState: PagerState? = null,
    val gridState: LazyGridState? = null
) {
    val isSmoothScrolling by derivedStateOf {
        pagerState?.isScrollInProgress == true || gridState?.isScrollInProgress == true
    }
}

@Composable
fun rememberSmoothScrollController(
    pagerState: PagerState? = null,
    gridState: LazyGridState? = null
): SmoothScrollController {
    return remember(pagerState, gridState) {
        SmoothScrollController(pagerState, gridState)
    }
}

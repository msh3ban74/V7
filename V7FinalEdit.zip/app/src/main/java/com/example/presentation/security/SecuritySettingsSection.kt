package com.example.presentation.security

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecuritySettingsSection(
    appLockManager: AppLockManager,
    modifier: Modifier = Modifier
) {
    val isLockEnabled by appLockManager.isLockEnabled.collectAsState(initial = false)
    val lockTimeoutMinutes by appLockManager.lockTimeoutMinutes.collectAsState(initial = 0)
    
    val scope = rememberCoroutineScope()
    var showTimeoutDialog by remember { mutableStateOf(false) }

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                "App Security",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Auto App Lock", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "Require biometric or PIN to unlock",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = isLockEnabled,
                    onCheckedChange = { enabled ->
                        scope.launch { appLockManager.setLockEnabled(enabled) }
                    }
                )
            }

            if (isLockEnabled) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Lock Timeout", style = MaterialTheme.typography.bodyLarge)
                        Text(
                            if (lockTimeoutMinutes == 0) "Immediate" else "$lockTimeoutMinutes minutes",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    TextButton(onClick = { showTimeoutDialog = true }) {
                        Text("Change")
                    }
                }
            }
        }
    }

    if (showTimeoutDialog) {
        AlertDialog(
            onDismissRequest = { showTimeoutDialog = false },
            title = { Text("Select Lock Timeout") },
            text = {
                Column {
                    listOf(0, 1, 5, 10, 30).forEach { minutes ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = lockTimeoutMinutes == minutes,
                                onClick = {
                                    scope.launch { appLockManager.setLockTimeoutMinutes(minutes) }
                                    showTimeoutDialog = false
                                }
                            )
                            Text(
                                text = if (minutes == 0) "Immediate (on background)" else "$minutes minutes",
                                modifier = Modifier.padding(start = 8.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTimeoutDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}

package com.example.presentation.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

val LocalAnimationsEnabled = staticCompositionLocalOf { true }

val PureBlackColors = darkColorScheme(
    primary = Color(0xFFB0B0B0),
    background = Color(0xFF000000),
    surface = Color(0xFF101010),
    surfaceVariant = Color(0xFF1E1E1E),
    onBackground = Color(0xFFE0E0E0),
    onSurface = Color(0xFFE0E0E0)
)

val TitaniumSilverColors = lightColorScheme(
    primary = Color(0xFF607D8B),
    background = Color(0xFFF5F5F5),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFE0E0E0),
    onBackground = Color(0xFF212121),
    onSurface = Color(0xFF212121)
)

@Composable
fun PremiumThemePack(
    state: ThemeState,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val view = androidx.compose.ui.platform.LocalView.current

    val colorScheme = when (state.themeMode) {
        ThemeMode.TITANIUM_SILVER -> TitaniumSilverColors
        ThemeMode.PURE_BLACK -> PureBlackColors
    }

    if (!view.isInEditMode) {
        androidx.compose.runtime.SideEffect {
            val window = (context as? android.app.Activity)?.window
            if (window != null) {
                val isLight = state.themeMode == ThemeMode.TITANIUM_SILVER
                androidx.core.view.WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = isLight
                androidx.core.view.WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = isLight
            }
        }
    }

    CompositionLocalProvider(LocalAnimationsEnabled provides state.animationsEnabled) {
        MaterialTheme(
            colorScheme = colorScheme,
            content = content
        )
    }
}

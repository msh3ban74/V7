package com.example.presentation.timer

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SleepTimerManager(private val externalScope: CoroutineScope = GlobalScope) {
    
    private val _remainingTimeMillis = MutableStateFlow(0L)
    val remainingTimeMillis: StateFlow<Long> = _remainingTimeMillis.asStateFlow()

    private val _isTimerActive = MutableStateFlow(false)
    val isTimerActive: StateFlow<Boolean> = _isTimerActive.asStateFlow()

    private var timerJob: Job? = null
    var onTimerEndAction: (() -> Unit)? = null

    fun startTimer(minutes: Int) {
        timerJob?.cancel()
        _isTimerActive.value = true
        _remainingTimeMillis.value = minutes * 60 * 1000L

        timerJob = externalScope.launch(Dispatchers.Main) {
            while (_remainingTimeMillis.value > 0) {
                delay(1000)
                _remainingTimeMillis.value -= 1000
            }
            // Timer ended
            _isTimerActive.value = false
            onTimerEndAction?.invoke()
        }
    }

    fun stopTimer() {
        timerJob?.cancel()
        _isTimerActive.value = false
        _remainingTimeMillis.value = 0L
    }
}

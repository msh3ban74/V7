package com.example.presentation.stability

import androidx.compose.runtime.Composable
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.Saver

class RestoreStateManager(initialTab: Int = 0, initialVaultLock: Boolean = true) {
    var lastSelectedTabIndex by mutableStateOf(initialTab)
    var isVaultLocked by mutableStateOf(initialVaultLock)

    fun saveTabSelection(index: Int) {
        lastSelectedTabIndex = index
    }
    
    fun setVaultLock(locked: Boolean) {
        isVaultLocked = locked
    }
    
    companion object {
        val Saver: Saver<RestoreStateManager, *> = Saver(
            save = { listOf(it.lastSelectedTabIndex, it.isVaultLocked) },
            restore = {
                RestoreStateManager(
                    initialTab = it[0] as Int,
                    initialVaultLock = it[1] as Boolean
                )
            }
        )
    }
}

@Composable
fun rememberRestoreStateManager(): RestoreStateManager {
    return rememberSaveable(saver = RestoreStateManager.Saver) {
        RestoreStateManager()
    }
}

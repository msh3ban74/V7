package com.example.presentation.screens.player.media3

import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.example.data.datasource.MediaStoreScanner
import com.example.data.repository.LocalMediaRepositoryImpl
import com.example.domain.model.VideoItem
import com.example.domain.repository.MediaLoadState
import com.example.presentation.immersive.*
import com.example.presentation.screens.favorites.FavoritesRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * TikTok / Instagram Reels style short-form video feed player screen.
 * Implements smooth vertical scrolling, looping, custom engagement overlays, and full gesture integrations.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ReelsPlayerScreen(
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Internal initialization of local MediaStore repository elements
    val scanner = remember { MediaStoreScanner(context) }
    val repo = remember { LocalMediaRepositoryImpl(scanner, context) }
    
    val media3Manager = remember { Media3Manager(context) }
    val controller = remember { PlayerController(context, media3Manager) }

    // Immersive custom popup triggers
    val coroutineScope = androidx.compose.runtime.rememberCoroutineScope()
    val favoritesRepository = remember { FavoritesRepository(context, coroutineScope) }
    val vaultManager = remember { com.example.presentation.screens.vault.VaultManager(context) }
    val deleteMediaManager = remember { DeleteMediaManager(context) }

    val favoritesState by favoritesRepository.favoritesState.collectAsState()
    val controlsVisible by controller.controlsVisible.collectAsState()

    var infoItemToShow by remember { mutableStateOf<VideoItem?>(null) }
    var deleteItemToConfirm by remember { mutableStateOf<VideoItem?>(null) }
    var isSpeedSheetToShow by remember { mutableStateOf(false) }

    var videos by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    val deleteLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val confirmed = deleteItemToConfirm
            if (confirmed != null) {
                coroutineScope.launch { repo.removeMediaItem(confirmed.id, "video") }
                // Instantly remove from local scrolling vertical media pager
                videos = videos.filter { it.id != confirmed.id }
            }
            deleteItemToConfirm = null
        }
    }

    // Fetch device videos or use fallback premium nature clips if empty
    LaunchedEffect(Unit) {
        val cr = kotlinx.coroutines.GlobalScope // we can just use launch block
        repo.loadFromCache()
        repo.refreshAll()
        try {
            val state = repo.getLocalVideos().first()
            if (state is MediaLoadState.Success && state.data.isNotEmpty()) {
                val vaulted = vaultManager.vaultedIds.first()
                val unvaulted = state.data.filter { !vaulted.contains(it.id) }
                videos = if (unvaulted.isNotEmpty()) unvaulted else getFallbackVideos()
            } else {
                // Fallback internet streams for immediate functional verification of Reels mode
                videos = getFallbackVideos()
            }
        } catch (e: Exception) {
            com.example.presentation.stability.StabilityManager.safeRun("ReelsPlayerScreen") {
                videos = getFallbackVideos()
            }
        }
        isLoading = false
    }

    // Clean release on page destroy and background pauses
    com.example.presentation.stability.LifecycleCleanupController(
        onPause = { media3Manager.pause() },
        onDestroy = { media3Manager.release() }
    )

    ScaffoldWithTransparent(modifier = modifier) {
        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.testTag("reels_global_loading")
                )
            }
        } else if (videos.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                com.example.presentation.components.stability.EmptyStateComposable(
                    message = "No short video clips available",
                    icon = Icons.Default.Movie
                )
            }
        } else {
            val pagerState = rememberPagerState(pageCount = { videos.size })
            val smoothScrollController = com.example.presentation.performance.rememberSmoothScrollController(pagerState = pagerState)

            // Auto-trigger video change on scroll — with rigid index bounds check
            LaunchedEffect(pagerState.currentPage, smoothScrollController.isSmoothScrolling) {
                if (!smoothScrollController.isSmoothScrolling) {
                    val safeIndex = pagerState.currentPage.coerceIn(0, (videos.size - 1).coerceAtLeast(0))
                    if (videos.isEmpty() || safeIndex !in videos.indices) return@LaunchedEffect
                    val activeVideo = videos[safeIndex]
                    media3Manager.play(
                        PlayerMediaItem(
                            id = activeVideo.id.toString(),
                            title = activeVideo.displayName,
                            uri = activeVideo.uri,
                            isVideo = true,
                            duration = activeVideo.duration
                        )
                    )
                }
            }

            Box(modifier = Modifier.fillMaxSize()) {
                VerticalPager(
                    state = pagerState,
                    key = { index -> if (index in videos.indices) videos[index].id else index.toLong() },
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("reels_vertical_pager")
                ) { pageIndex ->
                    // Rigid index guard: exit immediately if page index is out of bounds
                    if (pageIndex !in videos.indices) {
                        Box(modifier = Modifier.fillMaxSize())
                        return@VerticalPager
                    }
                    val video = videos[pageIndex]

                    // Stop player the exact moment this page leaves the active view state
                    DisposableEffect(pageIndex) {
                        onDispose {
                            if (pageIndex != pagerState.currentPage) {
                                media3Manager.pause()
                            }
                        }
                    }
                    val isFavorite = favoritesState.favoriteVideoIds.contains(video.id)

                    var showFavoriteAnim by remember { mutableStateOf(false) }
                    
                    Box(modifier = Modifier.fillMaxSize()) {
                        VideoPlayerComposable(
                            controller = controller,
                            isReelsMode = true,
                            isActivePage = (pageIndex == pagerState.currentPage),
                            modifier = Modifier
                                .fillMaxSize()
                                .clickable(
                                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                                    indication = null // no ripple
                                ) {
                                    // single tap to pause/play handled by controller? Actually let's just do double tap
                                }
                                .pointerInput(Unit) {
                                    detectTapGestures(
                                        onDoubleTap = {
                                            favoritesRepository.toggleFavoriteVideo(video.id)
                                            showFavoriteAnim = true
                                        },
                                        onTap = {
                                            if (controller.playbackState.value.isPlaying) {
                                                controller.media3Manager.pause()
                                            } else {
                                                controller.media3Manager.resume()
                                            }
                                        }
                                    )
                                }
                        )

                        // Reels layout overlay UI actions - linked to controls visibility!
                        AnimatedVisibility(
                            visible = controlsVisible,
                            enter = fadeIn() + slideInVertically(initialOffsetY = { it / 2 }),
                            exit = fadeOut() + slideOutVertically(targetOffsetY = { it / 2 }),
                            modifier = Modifier
                                .align(Alignment.CenterEnd)
                                .padding(end = 16.dp, bottom = 48.dp)
                        ) {
                            MediaActionPanel(
                                item = video,
                                isFavorite = isFavorite,
                                currentSpeed = controller.playbackState.collectAsState().value.playbackSpeed,
                                onFavoriteToggle = {
                                    favoritesRepository.toggleFavoriteVideo(video.id)
                                    showFavoriteAnim = true
                                },
                                onShareClick = {
                                    ShareMediaManager.share(context, video)
                                },
                                onDeleteClick = {
                                    deleteItemToConfirm = video
                                },
                                onInfoClick = {
                                    infoItemToShow = video
                                },
                                onSpeedClick = {
                                    isSpeedSheetToShow = true
                                },
                                onVaultClick = {
                                    coroutineScope.launch {
                                        // Use the full-item overload so the file is physically
                                        // moved into the vault (legacy id-only overload left an
                                        // empty vault path → black thumbnails / unopenable items).
                                        vaultManager.vaultMedia(video)
                                    }
                                    videos = videos.filter { it.id != video.id }
                                }
                            )
                        }
                        
                        com.example.presentation.screens.favorites.FavoriteAnimationComposable(
                            isTriggered = showFavoriteAnim,
                            onAnimationFinished = { showFavoriteAnim = false },
                            modifier = Modifier.align(Alignment.Center)
                        )

                        // Bottom Metadata - fades of controls visibility
                        AnimatedVisibility(
                            visible = controlsVisible,
                            enter = fadeIn() + slideInVertically(initialOffsetY = { it / 4 }),
                            exit = fadeOut() + slideOutVertically(targetOffsetY = { it / 4 }),
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(bottom = 40.dp, start = 16.dp)
                                .fillMaxWidth(0.75f)
                        ) {
                            VideoMetaOverlay(
                                videoItem = video,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        

                    }
                }

                // Top persistent Back trigger - animates symmetrically with controls visibility
                AnimatedVisibility(
                    visible = controlsVisible,
                    enter = fadeIn() + slideInVertically(initialOffsetY = { -it / 2 }),
                    exit = fadeOut() + slideOutVertically(targetOffsetY = { -it / 2 }),
                    modifier = Modifier
                        .statusBarsPadding()
                        .padding(16.dp)
                        .align(Alignment.TopStart)
                ) {
                    IconButton(
                        onClick = {
                            media3Manager.pause()
                            onBackClick()
                        },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.5f))
                            .testTag("reels_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back from Reels Feed Mode",
                            tint = Color.White
                        )
                    }
                }
            }
        }

        // --- IMMERSIVE FEED DIALOGS & OVERLAY SHEETS CONTAINER ---

        // A. File specifications summary list details
        MediaInfoSheet(
            show = infoItemToShow != null,
            item = infoItemToShow,
            onDismiss = { infoItemToShow = null }
        )

        // B. Dynamic tempo multipliers selector
        SpeedControlSheet(
            show = isSpeedSheetToShow,
            currentSpeed = controller.playbackState.collectAsState().value.playbackSpeed,
            onSpeedSelected = { fraction ->
                controller.setPlaybackSpeed(fraction)
            },
            onDismiss = { isSpeedSheetToShow = false }
        )

        // C. Storage file deletion prompt
        DeleteConfirmationDialog(
            show = deleteItemToConfirm != null,
            itemName = deleteItemToConfirm?.displayName ?: "",
            onConfirm = {
                val item = deleteItemToConfirm
                if (item != null) {
                    deleteMediaManager.performDelete(
                        contentResolver = context.contentResolver,
                        item = item,
                        senderLauncher = deleteLauncher,
                        onSuccess = {
                            coroutineScope.launch { repo.removeMediaItem(item.id, "video") }
                            // Direct / direct owner removal success fallback
                            videos = videos.filter { it.id != item.id }
                            deleteItemToConfirm = null
                        },
                        onError = { message ->
                            android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_LONG).show()
                            deleteItemToConfirm = null
                        }
                    )
                }
            },
            onDismiss = { deleteItemToConfirm = null }
        )
    }
}

/**
 * Transparent Scaffolder helper to support immersive Reels background overlays.
 */
@Composable
private fun ScaffoldWithTransparent(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        content()
    }
}

/**
 * Standard utility wrapper for Status bar insets calculation safely.
 */
@Composable
private fun Modifier.statusBarsPadding(): Modifier {
    val context = LocalContext.current
    val resourceId = context.resources.getIdentifier("status_bar_height", "dimen", "android")
    val statusBarHeight = if (resourceId > 0) {
        context.resources.getDimensionPixelSize(resourceId) / context.resources.displayMetrics.density
    } else {
        24f
    }
    return this.padding(top = statusBarHeight.dp)
}

/**
 * Floating sidebar overlay of quick reaction triggers.
 */
@Composable
fun EngagementButtonsOverlay(
    videoItem: VideoItem,
    modifier: Modifier = Modifier
) {
    val likedStates = remember { mutableStateMapOf<Long, Boolean>() }
    val countsMap = remember { mutableStateMapOf<Long, Int>() }

    val isLiked = likedStates[videoItem.id] ?: false
    val likeCount = countsMap[videoItem.id] ?: (120..4200).random()

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Like Button
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.5f))
                    .clickable {
                        val current = likedStates[videoItem.id] ?: false
                        likedStates[videoItem.id] = !current
                        countsMap[videoItem.id] = if (current) likeCount - 1 else likeCount + 1
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Like button animation",
                    tint = if (isLiked) Color.Red else Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = formatCount(likeCount),
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Comments Button
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.5f))
                    .clickable {},
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Sms,
                    contentDescription = "Comment options",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "42",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Share Button
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.5f))
                    .clickable {},
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "Share",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Share",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/**
 * Text metadata detailing description, creators, and soundtracks in vertical layout.
 */
@Composable
fun VideoMetaOverlay(
    videoItem: VideoItem,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "@Studio",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
        )

        Text(
            text = videoItem.displayName,
            color = Color.White,
            fontSize = 13.sp,
            maxLines = 2
        )

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(Color.Black.copy(alpha = 0.35f))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Icon(
                imageVector = Icons.Default.MusicNote,
                contentDescription = "Music",
                tint = Color.White,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "Original Audio",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

private fun formatCount(num: Int): String {
    if (num >= 1000) {
        return String.format("%.1fk", num / 1000f)
    }
    return num.toString()
}

/**
 * Generates initial high-quality online stream MP4 URLs fallback so the interface works flawlessly out of the box.
 */
private fun getFallbackVideos(): List<VideoItem> {
    return listOf(
        VideoItem(
            id = 10001,
            displayName = "Sintel - Open Source Animation Masterpiece",
            uri = Uri.parse("https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4"),
            path = "",
            size = 4012024L,
            mimeType = "video/mp4",
            dateAdded = System.currentTimeMillis() / 1000,
            duration = 520000L,
            width = 1920,
            height = 1080
        ),
        VideoItem(
            id = 10002,
            displayName = "Big Buck Bunny - Forest Wildlife Adventures",
            uri = Uri.parse("https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"),
            path = "",
            size = 2050124L,
            mimeType = "video/mp4",
            dateAdded = System.currentTimeMillis() / 1000,
            duration = 596000L,
            width = 1920,
            height = 1080
        ),
        VideoItem(
            id = 10003,
            displayName = "Tears of Steel - Science Fiction Showcase",
            uri = Uri.parse("https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4"),
            path = "",
            size = 7050124L,
            mimeType = "video/mp4",
            dateAdded = System.currentTimeMillis() / 1000,
            duration = 734000L,
            width = 1920,
            height = 1080
        )
    )
}

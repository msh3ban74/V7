package com.example.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.presentation.screens.gallery.GalleryScreen
import com.example.presentation.screens.gallery.GalleryViewModel
import com.example.presentation.screens.player.PlayerScreen
import com.example.presentation.screens.player.PlayerViewModel
import com.example.presentation.screens.settings.SettingsScreen
import com.example.presentation.screens.settings.SettingsViewModel

import com.example.presentation.screens.vault.VaultManager
import com.example.presentation.screens.vault.VaultRepository
import com.example.presentation.screens.vault.VaultSecurityManager
import com.example.presentation.screens.vault.VaultScreen
import com.example.presentation.navigation.Screen
import com.example.presentation.security.AppLockManager
import com.example.presentation.timer.SleepTimerManager

/**
 * Navigation flow mapping routes to respective Compose Composable screens.
 * Seamlessly pipes domain-loaded ViewModels into child fragments.
 */
@Composable
fun NavGraph(
    navController: NavHostController,
    playerViewModel: PlayerViewModel,
    galleryViewModel: GalleryViewModel,
    settingsViewModel: SettingsViewModel,
    vaultManager: VaultManager,
    vaultRepository: VaultRepository,
    vaultSecurityManager: VaultSecurityManager,
    appLockManager: AppLockManager,
    sleepTimerManager: SleepTimerManager,
    dynamicThemeController: com.example.presentation.theme.DynamicThemeController,
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Videos.route,
        modifier = modifier
    ) {

        // Active Player Visualizer Route
        composable(route = Screen.Player.route) {
            PlayerScreen(
                viewModel = playerViewModel,
                sleepTimerManager = sleepTimerManager,
                onBack = { navController.popBackStack() }
            )
        }

        composable(route = Screen.Videos.route) {
            com.example.presentation.screens.videos.VideosScreen(
                viewModel = galleryViewModel,
                onNavigateToPlayer = {},
                onNavigateToVault = { navController.navigate(Screen.Vault.route) }
            )
        }

        composable(route = Screen.Music.route) {
            com.example.presentation.screens.music.MusicScreen(
                viewModel = galleryViewModel,
                onNavigateToPlayer = {},
                onNavigateToVault = { navController.navigate(Screen.Vault.route) }
            )
        }

        // Vault Gallery explorer Route
        composable(route = Screen.Gallery.route) {
            GalleryScreen(
                viewModel = galleryViewModel,
                onNavigateToPlayer = { trackId ->
                    playerViewModel.selectTrack(trackId)
                    // Hop straight onto player controls
                    navController.navigate(Screen.Player.route) {
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                onNavigateToVault = {
                    navController.navigate(Screen.Vault.route)
                }
            )
        }

        composable(route = Screen.Favorites.route) {
            com.example.presentation.screens.favorites.FavoritesScreen(
                viewModel = galleryViewModel,
                onNavigateToPlayer = { trackId ->
                    playerViewModel.selectTrack(trackId)
                    navController.navigate(Screen.Player.route) {
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
        }

        // Configuration setup Route
        composable(route = Screen.Settings.route) {
            SettingsScreen(
                viewModel = settingsViewModel,
                appLockManager = appLockManager,
                dynamicThemeController = dynamicThemeController
            )
        }

        // Vault Route
        composable(route = Screen.Vault.route) {
            VaultScreen(
                vaultManager = vaultManager,
                vaultRepository = vaultRepository,
                securityManager = vaultSecurityManager,
                onNavigateToPlayer = { trackId ->
                    playerViewModel.selectTrack(trackId)
                    navController.navigate(Screen.Player.route) {
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                onBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}

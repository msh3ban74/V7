package com.example.presentation.screens.vault

import com.example.domain.model.LocalMediaItem

data class VaultState(
    val mediaItems: List<LocalMediaItem> = emptyList(),
    val isLocked: Boolean = true
)

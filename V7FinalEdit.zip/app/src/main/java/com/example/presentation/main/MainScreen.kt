package com.example.presentation.main

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.example.presentation.navigation.Screen
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.datasource.MediaStoreScanner
import com.example.data.repository.LocalMediaRepositoryImpl
import com.example.presentation.screens.favorites.FavoritesRepository
import com.example.data.repository.MediaRepositoryImpl
import com.example.presentation.components.BottomNavBar
import com.example.presentation.navigation.NavGraph
import com.example.presentation.screens.gallery.GalleryViewModel
import com.example.presentation.screens.player.PlayerViewModel
import com.example.presentation.screens.settings.SettingsViewModel
import com.example.presentation.screens.vault.VaultManager
import com.example.presentation.screens.vault.VaultRepository
import com.example.presentation.screens.vault.VaultSecurityManager
import com.example.presentation.security.AppLockManager
import com.example.presentation.security.SessionSecurityManager
import com.example.presentation.security.SecureUnlockComposable
import com.example.presentation.timer.SleepTimerManager
import kotlinx.coroutines.flow.first

/**
 * Main application frame.
 * Orchestrates global states, constructor-injection instantiation, custom ambient gradients,
 * and standard safe area layout paddings.
 */
@Composable
fun MainScreen() {
    val navController = rememberNavController()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current

    // 1. Core clean DI repositories instantiated safely at root layout
    val watchHistoryRepository = remember { com.example.presentation.screens.watchhistory.WatchHistoryRepository(context) }
    val mediaRepository = remember { MediaRepositoryImpl() }
    val localMediaRepository = remember { LocalMediaRepositoryImpl(MediaStoreScanner(context), context) }
    val favoritesRepository = remember { FavoritesRepository(context, coroutineScope) }
    val vaultManager = remember { VaultManager(context) }
    val vaultRepository = remember { VaultRepository(localMediaRepository, vaultManager) }
    val vaultSecurityManager = remember { VaultSecurityManager() }

    // Security & Timer Managers
    val appLockManager = remember { AppLockManager(context) }
    val sessionSecurityManager = remember { SessionSecurityManager() }
    val sleepTimerManager = remember { SleepTimerManager(coroutineScope) }
    
    // Theme Manager
    val themeManager = remember { com.example.presentation.theme.ThemeManager(context) }
    val dynamicThemeController = remember { com.example.presentation.theme.DynamicThemeController(themeManager, coroutineScope) }
    val themeState by dynamicThemeController.state.collectAsState()

    // 2. MVVM ViewModels instantiated with constructor-injection and retained safely in Compose state
    val playerViewModel = remember { PlayerViewModel(mediaRepository) }
    val galleryViewModel = remember { GalleryViewModel(localMediaRepository, favoritesRepository, vaultManager) }
    val settingsViewModel = remember { SettingsViewModel() }

    // Tie timer directly to playback
    LaunchedEffect(Unit) {
        sleepTimerManager.onTimerEndAction = {
            if (playerViewModel.isPlaying.value) {
                playerViewModel.togglePlayPause()
            }
        }
    }

    // App backgrounding & lock logic
    val sessionState by sessionSecurityManager.sessionState.collectAsState()
    val isLockEnabled by appLockManager.isLockEnabled.collectAsState(initial = false)
    val lockTimeoutMinutes by appLockManager.lockTimeoutMinutes.collectAsState(initial = 0)

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP && isLockEnabled) {
                // If the stop was caused by launching the share sheet, skip locking once
                // so the user returns straight to their content instead of the lock screen.
                if (!com.example.presentation.immersive.ShareSession.consumeShareInFlight()) {
                    sessionSecurityManager.lockApp()
                }
            }
            if (event == Lifecycle.Event.ON_RESUME) {
                // If it was already locked or just resumed, verify timeout
                if (isLockEnabled) {
                    val timeoutMillis = lockTimeoutMinutes * 60 * 1000L
                    val timeSinceActivity = System.currentTimeMillis() - sessionState.lastActiveTime
                    if (timeoutMillis == 0L || timeSinceActivity > timeoutMillis) {
                        sessionSecurityManager.lockApp()
                    }
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    if (sessionState.isAppLocked && isLockEnabled) {
        SecureUnlockComposable(
            onUnlockSuccess = { sessionSecurityManager.unlockApp() }
        )
    } else {
        com.example.presentation.theme.PremiumThemePack(state = themeState) {
            // Cosmic background radial ambiance
            Box(
            modifier = Modifier
                .fillMaxSize()
                .testTag("app_main_container")
                .pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            val event = awaitPointerEvent(PointerEventPass.Initial)
                            if (event.changes.any { it.pressed }) {
                                sessionSecurityManager.updateLastActiveTime()
                            }
                        }
                    }
                }
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.background,
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            MaterialTheme.colorScheme.background
                        )
                    )
                )
        ) {
            Scaffold(
                bottomBar = {
                    val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route
                    val showBottomNav = currentRoute in Screen.bottomNavItems.map { it.route }
                    com.example.presentation.theme.AnimatedBottomNavigation(isVisible = showBottomNav) {
                        com.example.presentation.components.polish.PremiumBottomNavigation(
                            currentRoute = currentRoute,
                            onNavigate = { screen ->
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.startDestinationId) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                },
                containerColor = androidx.compose.ui.graphics.Color.Transparent, // Allow gradient to shine
                modifier = Modifier.fillMaxSize()
            ) { innerPadding ->
                NavGraph(
                    navController = navController,
                    playerViewModel = playerViewModel,
                    galleryViewModel = galleryViewModel,
                    settingsViewModel = settingsViewModel,
                    vaultManager = vaultManager,
                    vaultRepository = vaultRepository,
                    vaultSecurityManager = vaultSecurityManager,
                    appLockManager = appLockManager,
                    sleepTimerManager = sleepTimerManager,
                    dynamicThemeController = dynamicThemeController,
                    modifier = Modifier.padding(innerPadding)
                )
            }
        }
        }
    }
}

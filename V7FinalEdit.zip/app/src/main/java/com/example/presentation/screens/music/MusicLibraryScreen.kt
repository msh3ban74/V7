package com.example.presentation.screens.music

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.domain.model.AudioItem
import com.example.presentation.screens.gallery.components.MediaCardComposable

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicLibraryScreen(
    state: MusicLibraryState,
    onSearch: (String) -> Unit,
    onSortModeSelected: (SortMode) -> Unit,
    onFilterModeSelected: (FilterMode) -> Unit,
    onItemClick: (AudioItem, List<AudioItem>) -> Unit,
    onFavoriteToggle: (AudioItem) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(
            value = state.searchQuery,
            onValueChange = onSearch,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search songs, artists, albums...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
            trailingIcon = {
                if (state.searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearch("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp)
        )
        
        Spacer(modifier = Modifier.height(16.dp))

        ScrollableTabRow(
            selectedTabIndex = state.filterMode.ordinal,
            edgePadding = 0.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            FilterMode.values().forEach { mode ->
                Tab(
                    selected = state.filterMode == mode,
                    onClick = { onFilterModeSelected(mode) },
                    text = { Text(mode.name) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (state.filterMode == FilterMode.ALBUMS) {
            AlbumSectionComposable(
                albums = state.albums,
                onAlbumClick = { _, items -> if (items.isNotEmpty()) onItemClick(items.first(), items) }
            )
        } else if (state.filterMode == FilterMode.ARTISTS) {
            ArtistSectionComposable(
                artists = state.artists,
                onArtistClick = { _, items -> if (items.isNotEmpty()) onItemClick(items.first(), items) }
            )
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(state.songs, key = { it.id }) { song ->
                    MediaCardComposable(
                        mediaItem = song,
                        isFavorite = state.favorites.contains(song),
                        isScrolling = false,
                        onCardClick = { onItemClick(song, state.songs) },
                        onFavoriteToggle = { onFavoriteToggle(song) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(80.dp)
                            .padding(vertical = 4.dp)
                    )
                }
            }
        }
    }
}

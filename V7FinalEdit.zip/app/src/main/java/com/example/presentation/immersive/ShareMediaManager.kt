package com.example.presentation.immersive

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.domain.model.LocalMediaItem
import java.io.File

/**
 * Handles device-level content sharing sheets with appropriate action intents and mime types.
 *
 * Vaulted items live in app-private storage and carry file:// URIs which cannot be shared
 * directly (FileUriExposedException on API 24+). Such URIs are converted to secure content://
 * URIs via [FileProvider] before sharing.
 */
object ShareMediaManager {

    /**
     * Shows the native Android share sheet for any [LocalMediaItem]. Safe for both
     * MediaStore content:// URIs and app-private file:// URIs.
     */
    fun share(context: Context, item: LocalMediaItem) {
        try {
            val streamUri: Uri = resolveShareableUri(context, item.uri)

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = item.mimeType.ifBlank { "*/*" }
                putExtra(Intent.EXTRA_STREAM, streamUri)
                putExtra(Intent.EXTRA_SUBJECT, item.displayName)
                putExtra(Intent.EXTRA_TEXT, "Sharing: ${item.displayName}")
                // Grant temporary read access to whichever app the user picks
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(shareIntent, "Share ${item.displayName} using:")
            // Re-apply the read permission grant to the chooser intent itself
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (context !is android.app.Activity) {
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            // Mark the share so the lifecycle observer skips the stop-triggered app-lock
            // (the Sharesheet backgrounds the activity; without this the app would appear
            // to close / drop to the lock screen when the user returns).
            ShareSession.markShareStarted()
            context.startActivity(chooser)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(
                context,
                "Unable to share this item.",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    /**
     * Converts a raw URI into one that is safe to hand to other apps.
     * file:// URIs are wrapped with FileProvider; content:// URIs are returned unchanged.
     */
    private fun resolveShareableUri(context: Context, uri: Uri): Uri {
        if (uri.scheme?.lowercase() != "file") return uri
        return try {
            val path = uri.path ?: return uri
            val file = File(path)
            if (!file.exists()) return uri
            FileProvider.getUriForFile(
                context,
                context.packageName + ".fileprovider",
                file
            )
        } catch (e: Exception) {
            e.printStackTrace()
            uri // Fall back to the original URI rather than crashing
        }
    }
}

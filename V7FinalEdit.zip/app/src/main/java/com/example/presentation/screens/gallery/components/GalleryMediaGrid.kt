package com.example.presentation.screens.gallery.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.FolderOff
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import com.example.presentation.performance.OptimizedLazyGrid
import com.example.presentation.performance.rememberPerformanceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.AudioItem
import com.example.domain.model.ImageItem
import com.example.domain.model.LocalMediaItem
import com.example.domain.model.VideoItem
import com.example.presentation.screens.gallery.favorites.FavoritesState

/**
 * Centered responsive grid showing devices assets dynamically, fully wired with permissions,
 * empty media vaults, search failures, and customizable card interaction triggers.
 */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun GalleryMediaGrid(
    items: List<LocalMediaItem>,
    favoritesState: FavoritesState,
    selectedIds: Set<Long> = emptySet(),
    onSelectionChange: (Long) -> Unit = {},
    isSelectionMode: Boolean = false,
    isPermissionGranted: Boolean,
    onRequestPermissionClick: () -> Unit,
    onVideoClick: (VideoItem) -> Unit,
    onImageClick: (ImageItem) -> Unit,
    onAudioClick: (AudioItem) -> Unit,
    onToggleFavorite: (LocalMediaItem) -> Unit,
    searchQuery: String,
    modifier: Modifier = Modifier
) {
    if (!isPermissionGranted) {
        // Empty states: Permission Denied Representation
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(24.dp)
                .testTag("gallery_permission_denied_state"),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = "Permission Denied Shield Icon",
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(72.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Permission Denied",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "This application requires Read Storage Permissions to index and render your files locally. Your data remains on your physical device at all times.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.65f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = onRequestPermissionClick,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier.testTag("request_permission_button")
                ) {
                    Text("Grant Local Permissions", fontWeight = FontWeight.Bold)
                }
            }
        }
    } else if (items.isEmpty()) {
        // Empty states: No Media Found / Search Failure Representation
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(24.dp)
                .testTag("gallery_empty_media_state"),
            contentAlignment = Alignment.Center
        ) {
            val title = if (searchQuery.isNotEmpty()) "No Matching Assets" else "Local Gallery is Empty"
            val body = if (searchQuery.isNotEmpty()) {
                "We couldn't find any local media file matching '$searchQuery'."
            } else {
                "No local images, videos, or music audio tracks were detected on your device."
            }
            com.example.presentation.components.stability.EmptyStateComposable(
                message = "$title\n$body",
                icon = Icons.Default.FolderOff
            )
        }
    } else {
        // Real Local Media Grid Rendering with Performance Optimizations
        val performanceState = rememberPerformanceState()
        OptimizedLazyGrid(
            performanceState = performanceState,
            columns = GridCells.Fixed(5),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 32.dp),
            modifier = modifier
                .fillMaxSize()
                .testTag("gallery_media_grid_list")
        ) {
            items(
                items = items, 
                key = { "${it.id}_${it::class.simpleName}" },
                contentType = { it::class.simpleName }
            ) { item ->
                
                val isFav by remember(item, favoritesState) {
                    derivedStateOf {
                        when (item) {
                            is VideoItem -> favoritesState.favoriteVideoIds.contains(item.id)
                            is ImageItem -> favoritesState.favoriteImageIds.contains(item.id)
                            is AudioItem -> favoritesState.favoriteAudioIds.contains(item.id)
                        }
                    }
                }

                val isScrolling = performanceState.isScrolling
                val isSelected = selectedIds.contains(item.id)
                com.example.presentation.components.polish.PremiumMediaCard(
                    mediaItem = item,
                    isFavorite = isFav,
                    isScrolling = isScrolling,
                    isSelected = isSelected,
                    onCardClick = {
                        if (isSelectionMode) {
                            onSelectionChange(item.id)
                        } else {
                            when (item) {
                                is VideoItem -> onVideoClick(item)
                                is ImageItem -> onImageClick(item)
                                is AudioItem -> onAudioClick(item)
                            }
                        }
                    },
                    onCardLongClick = {
                        onSelectionChange(item.id)
                    }
                )
            }
        }
    }
}

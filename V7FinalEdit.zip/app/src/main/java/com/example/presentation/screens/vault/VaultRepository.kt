package com.example.presentation.screens.vault

import android.net.Uri
import com.example.domain.model.AudioItem
import com.example.domain.model.ImageItem
import com.example.domain.model.LocalMediaItem
import com.example.domain.model.VideoItem
import com.example.domain.repository.LocalMediaRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.io.File

/**
 * VaultRepository — reads from [VaultManager]'s physical metadata, NOT from MediaStore.
 * Vaulted items are physically removed from MediaStore, so this repository constructs
 * LocalMediaItem instances from the vault file-system metadata directly.
 */
class VaultRepository(
    private val localMediaRepository: LocalMediaRepository,
    private val vaultManager: VaultManager
) {
    /**
     * Flow of all currently vaulted media items, built from vault metadata
     * with file:// URIs pointing to the physical vault files.
     */
    val vaultedMedia: Flow<List<LocalMediaItem>> = vaultManager.vaultedItems.map { metaList ->
        metaList
            .sortedByDescending { it.dateAdded }
            .mapNotNull { meta ->
                val vaultFile = File(meta.vaultFilePath)
                // Skip orphaned metadata whose physical file is missing or whose path is
                // empty (e.g. items recorded via the legacy id-only vault path). Showing
                // such items produced black thumbnails and "media not found" on open.
                if (meta.vaultFilePath.isEmpty() || !vaultFile.exists()) {
                    return@mapNotNull null
                }
                val uri: Uri = Uri.fromFile(vaultFile)
                try {
                    when (meta.mediaType) {
                        "video" -> VideoItem(
                            id = meta.id, displayName = meta.displayName, uri = uri,
                            path = meta.vaultFilePath, size = meta.size,
                            mimeType = meta.mimeType, dateAdded = meta.dateAdded,
                            duration = meta.duration, width = meta.width, height = meta.height
                        )
                        "image" -> ImageItem(
                            id = meta.id, displayName = meta.displayName, uri = uri,
                            path = meta.vaultFilePath, size = meta.size,
                            mimeType = meta.mimeType, dateAdded = meta.dateAdded,
                            width = meta.width, height = meta.height
                        )
                        "audio" -> AudioItem(
                            id = meta.id, displayName = meta.displayName, uri = uri,
                            path = meta.vaultFilePath, size = meta.size,
                            mimeType = meta.mimeType, dateAdded = meta.dateAdded,
                            duration = meta.duration, artist = meta.artist, album = meta.album
                        )
                        else -> null
                    }
                } catch (e: Exception) { null }
            }
    }

    /**
     * Move item physically into the vault. All I/O on Dispatchers.IO inside VaultManager.
     */
    suspend fun vaultItem(item: LocalMediaItem) {
        vaultManager.vaultMedia(item)
        // Refresh MediaStore-backed repos to reflect the removal
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try { localMediaRepository.refreshAll() } catch (ignored: Exception) { }
        }
    }

    /**
     * Physically restore item from vault back to public external storage.
     */
    suspend fun restoreItem(item: LocalMediaItem) {
        vaultManager.restoreMedia(item.id)
        // Refresh MediaStore-backed repos to reflect the restore
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try { localMediaRepository.refreshAll() } catch (ignored: Exception) { }
        }
    }
}

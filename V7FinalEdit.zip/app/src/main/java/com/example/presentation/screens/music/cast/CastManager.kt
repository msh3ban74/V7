package com.example.presentation.screens.music.cast

import android.content.Context
import androidx.media3.cast.CastPlayer
import com.google.android.gms.cast.framework.CastContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class CastManager(private val context: Context) {
    private var castPlayer: CastPlayer? = null
    
    private val _isCastAvailable = MutableStateFlow(false)
    val isCastAvailable: StateFlow<Boolean> = _isCastAvailable
    
    private val _isCasting = MutableStateFlow(false)
    val isCasting: StateFlow<Boolean> = _isCasting

    init {
        try {
            val castContext = CastContext.getSharedInstance(context)
            castPlayer = CastPlayer(castContext)
            
            _isCastAvailable.value = castPlayer?.isCastSessionAvailable ?: false
            
            castPlayer?.addListener(object : androidx.media3.common.Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    _isCasting.value = isPlaying // Simple tracking
                }
            })
            
        } catch (e: Exception) {
            // Cast framework might not be fully initialized or missing App ID in Manifest
        }
    }
    
    fun getCastPlayer(): CastPlayer? {
        return castPlayer
    }
    
    fun release() {
        castPlayer?.release()
    }
}

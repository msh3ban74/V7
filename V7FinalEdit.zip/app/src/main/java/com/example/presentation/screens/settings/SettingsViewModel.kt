package com.example.presentation.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel responsible for managing app configuration preferences,
 * profile headers, and cache state transactions.
 */
class SettingsViewModel : ViewModel() {

    private val _audioQuality = MutableStateFlow("Studio Master (24-bit/96kHz)")
    val audioQuality: StateFlow<String> = _audioQuality.asStateFlow()

    private val _cacheSize = MutableStateFlow("142.8 MB")
    val cacheSize: StateFlow<String> = _cacheSize.asStateFlow()

    private val _notificationsEnabled = MutableStateFlow(true)
    val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled.asStateFlow()

    fun toggleNotifications(enabled: Boolean) {
        _notificationsEnabled.value = enabled
    }

    fun setAudioQuality(quality: String) {
        _audioQuality.value = quality
    }

    fun clearCache() {
        viewModelScope.launch {
            // Emulate instant purge action
            _cacheSize.value = "0.0 KB"
        }
    }
}

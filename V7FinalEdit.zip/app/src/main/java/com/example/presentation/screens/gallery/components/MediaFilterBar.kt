package com.example.presentation.screens.gallery.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp

/**
 * Filter select types representing types available in local device database.
 */
enum class GalleryFilterType(val displayName: String) {
    ALL("All"),
    VIDEOS("Videos"),
    IMAGES("Images"),
    MUSIC("Music"),
    FAVORITES("Favorites")
}

/**
 * Clean, visually appealing horizontal filter scrollable bar using Material 3 chips.
 */
@Composable
fun MediaFilterBar(
    selectedFilter: GalleryFilterType,
    onFilterSelected: (GalleryFilterType) -> Unit,
    modifier: Modifier = Modifier
) {
    val filters = GalleryFilterType.values()

    LazyRow(
        modifier = modifier
            .fillMaxWidth()
            .testTag("gallery_media_filter_bar"),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
    ) {
        items(filters) { filter ->
            val isSelected = filter == selectedFilter
            FilterChip(
                selected = isSelected,
                onClick = { onFilterSelected(filter) },
                label = { Text(text = filter.displayName, style = MaterialTheme.typography.labelLarge) },
                shape = RoundedCornerShape(12.dp),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                    selectedLabelColor = Color.White,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                modifier = Modifier.testTag("filter_chip_${filter.name}")
            )
        }
    }
}

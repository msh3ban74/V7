package com.example.presentation.screens.gallery.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import coil.request.videoFrameMillis
import coil.size.Scale
import com.example.domain.model.AudioItem
import com.example.domain.model.ImageItem
import com.example.domain.model.LocalMediaItem
import com.example.domain.model.VideoItem

/**
 * Optimised media thumbnail loader with LRU memory caching.
 *
 * For video items, Coil's VideoFrameDecoder extracts the first frame at
 * microsecond 1 (videoFrameMillis = 1) as a lightweight bitmap — no live
 * ExoPlayer instance is ever created for non-focused tiles.
 *
 * Thumbnail resolution is capped at 512×512 to prevent OOM during fast
 * grid scrolling, while memory + disk caches are aggressively enabled
 * so frames are never re-decoded once cached.
 */
@Composable
fun MediaThumbnailLoader(
    mediaItem: LocalMediaItem,
    modifier: Modifier = Modifier,
    isScrolling: Boolean = false
) {
    val context = LocalContext.current

    // Guard: a vaulted item whose physical file is missing arrives with an empty URI.
    // Render a neutral placeholder icon instead of a black tile.
    val hasValidUri = mediaItem.uri != android.net.Uri.EMPTY &&
        mediaItem.uri.toString().isNotBlank()

    Box(
        modifier = modifier.background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        contentAlignment = Alignment.Center
    ) {
        if (!hasValidUri) {
            Icon(
                imageVector = Icons.Default.BrokenImage,
                contentDescription = "Unavailable media",
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.size(36.dp)
            )
            return@Box
        }
        when (mediaItem) {
            is AudioItem -> {
                // Audio items have no visual frame — show a styled icon placeholder
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Audiotrack,
                        contentDescription = "Audio track",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(40.dp)
                    )
                }
            }

            is VideoItem -> {
                // Extract a frame a short way into the video for the thumbnail.
                // Frame 0/1 ms often renders solid black (fade-ins, letterbox intros),
                // so we pick a safer offset based on the clip's known duration.
                val thumbnailRequest = androidx.compose.runtime.remember(mediaItem.id) {
                    val frameMs: Long = when {
                        mediaItem.duration > 4000L -> 1000L
                        mediaItem.duration > 1000L -> mediaItem.duration / 3
                        else -> 0L
                    }
                    // For vault items the URI is file:// pointing to app-private storage.
                    // Feeding Coil the File object is more reliable than the Uri on some OEMs.
                    val dataSource: Any = if (mediaItem.uri.scheme?.lowercase() == "file" &&
                        mediaItem.path.isNotBlank()) {
                        java.io.File(mediaItem.path)
                    } else {
                        mediaItem.uri
                    }
                    ImageRequest.Builder(context)
                        .data(dataSource)
                        // Stable cache keys bound to item ID
                        .memoryCacheKey("video_thumb_${mediaItem.id}")
                        .diskCacheKey("video_thumb_${mediaItem.id}")
                        // Aggressive caching — never re-decode if already in pool
                        .memoryCachePolicy(CachePolicy.ENABLED)
                        .diskCachePolicy(CachePolicy.ENABLED)
                        // Cap resolution to prevent OOM during fast scrolling
                        .size(512, 512)
                        .scale(Scale.FILL)
                        // Extract a non-black frame
                        .videoFrameMillis(frameMs)
                        // Software bitmap — hardware bitmaps can render black in some
                        // composition layers / on certain devices.
                        .allowHardware(false)
                        // No crossfade during fast grid scrolling
                        .crossfade(false)
                        .build()
                }

                AsyncImage(
                    model = thumbnailRequest,
                    contentDescription = mediaItem.displayName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            is ImageItem -> {
                val imageRequest = androidx.compose.runtime.remember(mediaItem.id) {
                    // For vault items the URI is a file:// pointing to app-private storage.
                    // Coil can load file:// directly, but feeding it the File object is more
                    // reliable on some OEMs. Use path-as-File when scheme is "file".
                    val dataSource: Any = if (mediaItem.uri.scheme?.lowercase() == "file" &&
                        mediaItem.path.isNotBlank()) {
                        java.io.File(mediaItem.path)
                    } else {
                        mediaItem.uri
                    }
                    ImageRequest.Builder(context)
                        .data(dataSource)
                        .memoryCacheKey("img_thumb_${mediaItem.id}")
                        .diskCacheKey("img_thumb_${mediaItem.id}")
                        .memoryCachePolicy(CachePolicy.ENABLED)
                        .diskCachePolicy(CachePolicy.ENABLED)
                        // Cap resolution — thumbnails don't need full resolution
                        .size(512, 512)
                        .scale(Scale.FILL)
                        // Software bitmap — hardware bitmaps can render black in some
                        // composition layers (same fix as video thumbnails above).
                        .allowHardware(false)
                        .crossfade(false)
                        .build()
                }

                AsyncImage(
                    model = imageRequest,
                    contentDescription = mediaItem.displayName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

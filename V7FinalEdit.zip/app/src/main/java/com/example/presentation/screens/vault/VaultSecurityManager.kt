package com.example.presentation.screens.vault

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class VaultSecurityManager {
    private val _isLocked = MutableStateFlow(true)
    val isLocked: StateFlow<Boolean> = _isLocked.asStateFlow()

    private var lastUnlockTime: Long = 0
    private val TIMEOUT_MS = 60000L // 1 minute timeout

    private var failedAttempts = 0
    private val MAX_ATTEMPTS = 5

    fun unlock() {
        if (failedAttempts < MAX_ATTEMPTS) {
            _isLocked.value = false
            lastUnlockTime = System.currentTimeMillis()
            failedAttempts = 0
        }
    }

    fun lock() {
        _isLocked.value = true
    }

    fun recordFailedAttempt() {
        failedAttempts++
    }

    fun isTimeoutExpired(): Boolean {
        return (System.currentTimeMillis() - lastUnlockTime) > TIMEOUT_MS
    }

    fun checkTimeout() {
        if (!_isLocked.value && isTimeoutExpired()) {
            lock()
        }
    }
}

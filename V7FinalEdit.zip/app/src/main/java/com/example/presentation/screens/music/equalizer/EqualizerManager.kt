package com.example.presentation.screens.music.equalizer

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class EqualizerBand(
    val frequencyHz: Int,
    var level: Short,
    val bandIndex: Short
)

class EqualizerManager {
    private val audioEffectController = AudioEffectController()

    private val _isEqualizerEnabled = MutableStateFlow(false)
    val isEqualizerEnabled: StateFlow<Boolean> = _isEqualizerEnabled

    private val _bands = MutableStateFlow<List<EqualizerBand>>(emptyList())
    val bands: StateFlow<List<EqualizerBand>> = _bands

    private val _bassBoostLevel = MutableStateFlow(0)
    val bassBoostLevel: StateFlow<Int> = _bassBoostLevel

    private val _virtualizerLevel = MutableStateFlow(0)
    val virtualizerLevel: StateFlow<Int> = _virtualizerLevel

    private val _gainLevel = MutableStateFlow(0)
    val gainLevel: StateFlow<Int> = _gainLevel

    fun attach(sessionId: Int) {
        audioEffectController.attachToAudioSession(sessionId)
        loadBands()
    }

    private fun loadBands() {
        val eq = audioEffectController.equalizer ?: return
        val numBands = eq.numberOfBands
        val newBands = mutableListOf<EqualizerBand>()
        for (i in 0 until numBands) {
            val freq = eq.getCenterFreq(i.toShort()) / 1000
            val level = eq.getBandLevel(i.toShort())
            newBands.add(EqualizerBand(freq, level, i.toShort()))
        }
        _bands.value = newBands
    }

    fun setBandLevel(bandIndex: Short, level: Short) {
        audioEffectController.equalizer?.setBandLevel(bandIndex, level)
        loadBands()
    }

    fun setBassBoost(level: Int) {
        try {
            audioEffectController.bassBoost?.setStrength(level.toShort())
            _bassBoostLevel.value = level
        } catch (e: Exception) {}
    }

    fun setVirtualizer(level: Int) {
        try {
            audioEffectController.virtualizer?.setStrength(level.toShort())
            _virtualizerLevel.value = level
        } catch (e: Exception) {}
    }

    fun setGain(level: Int) {
        try {
            audioEffectController.loudnessEnhancer?.setTargetGain(level)
            _gainLevel.value = level
        } catch (e: Exception) {}
    }

    fun toggleEqualizer() {
        val eq = audioEffectController.equalizer ?: return
        eq.enabled = !eq.enabled
        _isEqualizerEnabled.value = eq.enabled
    }

    fun applyPreset(presetIndex: Short) {
        audioEffectController.equalizer?.usePreset(presetIndex)
        loadBands()
    }

    fun release() {
        audioEffectController.release()
    }
}

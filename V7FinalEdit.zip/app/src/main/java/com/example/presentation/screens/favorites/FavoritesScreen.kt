package com.example.presentation.screens.favorites
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.domain.model.AudioItem
import com.example.domain.model.ImageItem
import com.example.domain.model.VideoItem
import com.example.presentation.performance.OptimizedLazyGrid
import com.example.presentation.performance.rememberPerformanceState
import com.example.presentation.screens.gallery.GalleryViewModel
import com.example.presentation.screens.gallery.components.MediaCardComposable
import kotlinx.coroutines.launch
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.items
import com.example.presentation.screens.player.media3.Media3Manager
import com.example.presentation.screens.player.media3.PlayerController
import com.example.presentation.screens.player.media3.PlayerMediaItem
import com.example.presentation.screens.player.media3.VideoPlayerComposable
import com.example.presentation.screens.music.AudioPlayerScreen

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun FavoritesScreen(
    viewModel: GalleryViewModel,
    onNavigateToPlayer: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val items by viewModel.localMediaItems.collectAsState()
    val favoritesState by viewModel.favoritesState.collectAsState()

    val favoriteItems = items.filter { item ->
        when (item) {
            is VideoItem -> favoritesState.favoriteVideoIds.contains(item.id)
            is ImageItem -> favoritesState.favoriteImageIds.contains(item.id)
            is AudioItem -> favoritesState.favoriteAudioIds.contains(item.id)
            else -> false
        }
    }

    var activeImageItem by remember { mutableStateOf<ImageItem?>(null) }
    var activeVideoItem by remember { mutableStateOf<VideoItem?>(null) }
    var activeAudioItem by remember { mutableStateOf<AudioItem?>(null) }

    val context = LocalContext.current
    val media3Manager = remember { Media3Manager(context) }
    val playerController = remember { PlayerController(context, media3Manager) }

    // Cache-aware lifecycle: release both manager and controller when leaving the screen
    DisposableEffect(Unit) {
        onDispose {
            // Stop any active playback and release ExoPlayer resources
            try { media3Manager.pause() } catch (ignored: Exception) { }
            try { media3Manager.release() } catch (ignored: Exception) { }
            // Cancel PlayerController coroutine jobs (viewModelScope won't auto-cancel here)
            try { playerController.cleanup() } catch (ignored: Exception) { }
        }
    }

    // Stop player when video viewer is dismissed to prevent background audio leak
    LaunchedEffect(activeVideoItem) {
        if (activeVideoItem == null) {
            try { media3Manager.pause() } catch (ignored: Exception) { }
        }
    }

    LaunchedEffect(activeAudioItem) {
        if (activeAudioItem == null) {
            try { media3Manager.pause() } catch (ignored: Exception) { }
        }
    }

    androidx.activity.compose.BackHandler(enabled = activeImageItem != null || activeVideoItem != null || activeAudioItem != null) {
        if (activeImageItem != null) activeImageItem = null
        if (activeVideoItem != null) {
            media3Manager.pause()
            activeVideoItem = null
        }
        if (activeAudioItem != null) {
            media3Manager.pause()
            activeAudioItem = null
        }
    }

    // Wrap in Box so the fullscreen overlays (video/audio/image) can sit OUTSIDE the Scaffold
    // and truly fill the whole screen (including behind the status bar).
    Box(modifier = modifier.fillMaxSize()) {
    Scaffold(
        topBar = {
            @OptIn(ExperimentalMaterial3Api::class)
            TopAppBar(
                title = { Text("Favorites", fontWeight = FontWeight.Bold) }
            )
        }
    ) { paddingValues ->
        if (favoriteItems.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No favorites yet", style = MaterialTheme.typography.bodyLarge)
            }
        } else {
            val performanceState = rememberPerformanceState()
            OptimizedLazyGrid(
                performanceState = performanceState,
                columns = GridCells.Fixed(5),
                contentPadding = PaddingValues(bottom = 32.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp)
            ) {
                items(
                    items = favoriteItems,
                    key = { it.id },
                    contentType = { it::class.simpleName }
                ) { item ->
                    val isScrolling = performanceState.isScrolling
                    com.example.presentation.components.polish.PremiumMediaCard(
                        mediaItem = item,
                        isFavorite = true,
                        isScrolling = isScrolling,
                        onCardClick = {
                            when (item) {
                                is ImageItem -> activeImageItem = item
                                is VideoItem -> {
                                    activeVideoItem = item
                                    media3Manager.play(
                                        PlayerMediaItem(
                                            id = item.id.toString(),
                                            title = item.displayName,
                                            uri = item.uri,
                                            isVideo = true,
                                            duration = item.duration
                                        )
                                    )
                                }
                                is AudioItem -> {
                                    activeAudioItem = item
                                    media3Manager.play(
                                        PlayerMediaItem(
                                            id = item.id.toString(),
                                            title = item.displayName,
                                            uri = item.uri,
                                            isVideo = false,
                                            duration = item.duration,
                                            artist = item.artist ?: "Unknown Artist"
                                        )
                                    )
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                    )
                }
            }
        }
    }   // close Scaffold content lambda

    // ── Fullscreen overlays — outside Scaffold so they cover the entire screen ─────

    // Image Fullscreen viewer
    AnimatedVisibility(
        visible = activeImageItem != null,
        enter = scaleIn() + fadeIn(),
        exit = scaleOut() + fadeOut(),
        modifier = Modifier.fillMaxSize()
    ) {
        val imageItems = favoriteItems.filterIsInstance<ImageItem>()
        
        LaunchedEffect(imageItems, activeImageItem) {
            if (activeImageItem != null && !imageItems.any { it.id == activeImageItem?.id }) {
                activeImageItem = null
            }
        }

        if (imageItems.isNotEmpty() && activeImageItem != null) {
            val initialPage = imageItems.indexOfFirst { it.id == activeImageItem?.id }.coerceAtLeast(0)
            val pagerState = androidx.compose.foundation.pager.rememberPagerState(
                initialPage = initialPage,
                pageCount = { imageItems.size }
            )

            // Sync activeImageItem when the user swipes to a new page
            LaunchedEffect(pagerState.currentPage) {
                if (imageItems.isNotEmpty()) {
                    val safePage = pagerState.currentPage.coerceIn(0, imageItems.size - 1)
                    imageItems.getOrNull(safePage)?.let { activeImageItem = it }
                }
            }
            
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.95f))) {
                androidx.compose.foundation.pager.HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize(),
                    key = { index -> imageItems.getOrNull(index)?.id?.toString() ?: "image_$index" }
                ) { page ->
                    if (page >= imageItems.size || page < 0) {
                        Box(modifier = Modifier.fillMaxSize())
                        return@HorizontalPager
                    }
                    val image = imageItems[page]
                    val context = LocalContext.current
                    var scale by remember { mutableStateOf(1f) }
                    var offset by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }

                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        val fullImageRequest = remember(image.uri) {
                            coil.request.ImageRequest.Builder(context)
                                .data(image.uri)
                                .memoryCacheKey("fav_full_${image.id}")
                                .diskCacheKey("fav_full_${image.id}")
                                .crossfade(true)
                                .build()
                        }
                        AsyncImage(
                            model = fullImageRequest,
                            contentDescription = image.displayName,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer(
                                    scaleX = scale,
                                    scaleY = scale,
                                    translationX = offset.x,
                                    translationY = offset.y
                                )
                                .pointerInput(Unit) {
                                    androidx.compose.foundation.gestures.detectTapGestures(
                                        onDoubleTap = {
                                            if (scale > 1f) {
                                                scale = 1f
                                                offset = androidx.compose.ui.geometry.Offset.Zero
                                            } else {
                                                scale = 2.5f
                                            }
                                        }
                                    )
                                }
                                .then(
                                    if (scale > 1f) {
                                        Modifier.pointerInput(Unit) {
                                            detectTransformGestures { _, pan, zoom, _ ->
                                                scale = (scale * zoom).coerceIn(1f, 4f)
                                                offset = if (scale > 1f) offset + pan
                                                         else androidx.compose.ui.geometry.Offset.Zero
                                            }
                                        }
                                    } else Modifier
                                )
                        )
                    }
                }

                // Close Button
                Box(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    contentAlignment = Alignment.TopStart
                ) {
                    IconButton(onClick = { activeImageItem = null }) {
                        Icon(Icons.Default.ArrowBack, "Close", tint = Color.White)
                    }
                }
            }
        }
    }

    // FULL SCREEN OVERLAY: Immersive Video Player
    AnimatedVisibility(
        visible = activeVideoItem != null,
        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
        modifier = Modifier.fillMaxSize()
    ) {
        if (activeVideoItem != null) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
                VideoPlayerComposable(
                    controller = playerController,
                    isActivePage = true,
                    onBackClick = {
                        media3Manager.pause()
                        activeVideoItem = null
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }

    // FULL SCREEN OVERLAY: Audio Player
    AnimatedVisibility(
        visible = activeAudioItem != null,
        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
        modifier = Modifier.fillMaxSize()
    ) {
        activeAudioItem?.let { audio ->
            val pState by playerController.playbackState.collectAsState()
            // Pass the original AudioItem directly — do NOT reconstruct it here, as that
            // would lose the album field and any other fields not explicitly forwarded.
            AudioPlayerScreen(
                item = audio,
                playbackState = pState,
                isShuffle = false,
                isRepeat = false,
                onBack = {
                    media3Manager.pause()
                    activeAudioItem = null
                },
                onPlayPause = {
                    if (pState.isPlaying) media3Manager.pause() else media3Manager.resume()
                },
                onNext = { /* Not applicable in favorites singular view */ },
                onPrevious = { /* Not applicable */ },
                onShuffleToggle = { },
                onRepeatToggle = { },
                onSeek = { media3Manager.seekTo(it) },
                modifier = Modifier.fillMaxSize()
            )
        }
    }

    }  // close outer Box
}

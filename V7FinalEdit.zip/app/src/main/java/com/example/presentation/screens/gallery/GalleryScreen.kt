package com.example.presentation.screens.gallery
import androidx.compose.foundation.gestures.detectTapGestures
import android.app.Activity
import android.content.pm.ActivityInfo
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.domain.model.AudioItem
import com.example.domain.model.ImageItem
import com.example.domain.model.LocalMediaItem
import com.example.domain.model.VideoItem
import com.example.presentation.permission.LocalPermissionManager
import com.example.presentation.permission.rememberStoragePermissionLauncher
import com.example.presentation.screens.gallery.components.GalleryFilterType
import com.example.presentation.screens.gallery.components.GalleryMediaGrid
import com.example.presentation.screens.gallery.components.MediaFilterBar
import com.example.presentation.screens.player.media3.Media3Manager
import com.example.presentation.screens.player.media3.PlaybackState
import com.example.presentation.screens.player.media3.PlayerController
import com.example.presentation.screens.player.media3.PlayerMediaItem
import com.example.presentation.screens.player.media3.VideoPlayerComposable
import kotlin.math.sin
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.interaction.MutableInteractionSource
import com.example.presentation.immersive.*

/**
 * Aesthetic Vault Gallery Screen.
 * Fully integrates permission verifications, local gallery grids, dynamic filters and search parameters,
 * and high-fidelity media rendering (reels-styled video players, audio visualizers, and raw image overlays).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GalleryScreen(
    viewModel: GalleryViewModel,
    onNavigateToPlayer: (String) -> Unit,
    onNavigateToVault: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity

    val items by viewModel.localMediaItems.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedFilter by viewModel.selectedFilter.collectAsState()
    val favoritesState by viewModel.favoritesState.collectAsState()

    var hasPermission by remember { mutableStateOf(LocalPermissionManager.hasStoragePermissions(context)) }

    val permissionLauncher = rememberStoragePermissionLauncher { granted ->
        hasPermission = granted
        if (granted) {
            viewModel.refreshMedia()
        }
    }

    // Trigger media sync on permission confirmation
    LaunchedEffect(hasPermission) {
        if (hasPermission) {
            kotlinx.coroutines.delay(500) // Delay non-critical initialization safely
            viewModel.refreshMedia()
        }
    }

    // Media3 player controller setup for overlay audio & video playbacks
    val media3Manager = remember { Media3Manager(context) }
    val playerController = remember { PlayerController(context, media3Manager) }

    DisposableEffect(Unit) {
        onDispose {
            media3Manager.release()
        }
    }

    // Active full-screen presentation elements
    var activeVideoItem by remember { mutableStateOf<VideoItem?>(null) }
    var activeImageItem by remember { mutableStateOf<ImageItem?>(null) }
    var activeAudioItem by remember { mutableStateOf<AudioItem?>(null) }

    // Immersive custom dialogs and specifications sheet visibility states
    var infoItemToShow by remember { mutableStateOf<LocalMediaItem?>(null) }
    var deleteItemToConfirm by remember { mutableStateOf<LocalMediaItem?>(null) }
    var isSpeedSheetToShow by remember { mutableStateOf(false) }

    // Tracks the item currently going through the system delete dialog. Kept separate from
    // deleteItemToConfirm so the app's own confirmation dialog can be dismissed immediately
    // (preventing repeated taps / duplicate system permission prompts).
    var pendingDeleteItem by remember { mutableStateOf<LocalMediaItem?>(null) }
    // IDs being bulk-deleted via the selection-mode MediaStore batch request
    var bulkDeleteIds by remember { mutableStateOf<Set<Long>>(emptySet()) }

    val deleteMediaManager = remember { DeleteMediaManager(context) }
    val deleteLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val bulkIds = bulkDeleteIds
            if (bulkIds.isNotEmpty()) {
                // Bulk selection delete confirmed by system dialog
                items.filter { bulkIds.contains(it.id) }.forEach { item ->
                    viewModel.removeMediaItem(item.id, item)
                    if (activeVideoItem?.id == item.id) { media3Manager.pause(); activeVideoItem = null }
                    if (activeImageItem?.id == item.id) activeImageItem = null
                    if (activeAudioItem?.id == item.id) { media3Manager.pause(); activeAudioItem = null }
                }
                viewModel.clearSelection()
                viewModel.refreshMedia()
            } else {
                // Single item delete confirmed by system dialog
                val target = pendingDeleteItem
                if (target != null) {
                    viewModel.removeMediaItem(target.id, target)
                    if (activeVideoItem?.id == target.id) { media3Manager.pause(); activeVideoItem = null }
                    if (activeImageItem?.id == target.id) activeImageItem = null
                    if (activeAudioItem?.id == target.id) { media3Manager.pause(); activeAudioItem = null }
                }
            }
        }
        // Always clear in-flight markers
        pendingDeleteItem = null
        bulkDeleteIds = emptySet()
        deleteItemToConfirm = null
    }

    // Unified Back Press navigation interceptor
    BackHandler(enabled = activeVideoItem != null || activeImageItem != null || activeAudioItem != null) {
        if (activeVideoItem != null) {
            media3Manager.pause()
            activeVideoItem = null
        }
        if (activeImageItem != null) {
            activeImageItem = null
        }
        if (activeAudioItem != null) {
            media3Manager.pause()
            activeAudioItem = null
        }
    }

    val selectedIds by viewModel.selectedIds.collectAsState()
    val isSelectionMode = selectedIds.isNotEmpty()

    Box(modifier = modifier.fillMaxSize()) {
        Scaffold(
            modifier = Modifier.testTag("gallery_screen"),
            topBar = {
                if (isSelectionMode) {
                    TopAppBar(
                        title = { Text("${selectedIds.size} Selected") },
                        navigationIcon = {
                            IconButton(onClick = { viewModel.clearSelection() }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Clear Selection")
                            }
                        },
                        actions = {
                            IconButton(onClick = { viewModel.selectAll(items.map { it.id }) }) {
                                Icon(Icons.Default.DoneAll, contentDescription = "Select All")
                            }
                            IconButton(onClick = {
                                val selectedItems = items.filter { selectedIds.contains(it.id) }
                                if (selectedItems.isEmpty()) return@IconButton
                                try {
                                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                                        // Android 11+: batch delete request through MediaStore — shows
                                        // a single system permission dialog for all selected items.
                                        val uris = selectedItems.mapNotNull { item ->
                                            if (item.uri.scheme?.lowercase() == "content") item.uri else null
                                        }
                                        if (uris.isNotEmpty()) {
                                            val pendingIntent = android.provider.MediaStore.createDeleteRequest(
                                                context.contentResolver, uris
                                            )
                                            deleteLauncher.launch(
                                                androidx.activity.result.IntentSenderRequest.Builder(
                                                    pendingIntent.intentSender
                                                ).build()
                                            )
                                            // Store selected ids so the launcher callback can clean up
                                            bulkDeleteIds = selectedIds
                                        }
                                    } else {
                                        // Android 9/10: try direct ContentResolver delete per item
                                        var deletedAny = false
                                        selectedItems.forEach { item ->
                                            try {
                                                if (item.uri.scheme?.lowercase() == "content") {
                                                    val rows = context.contentResolver.delete(item.uri, null, null)
                                                    if (rows > 0) {
                                                        viewModel.removeMediaItem(item.id, item)
                                                        deletedAny = true
                                                    }
                                                }
                                            } catch (e: Exception) { e.printStackTrace() }
                                        }
                                        viewModel.clearSelection()
                                        if (deletedAny) viewModel.refreshMedia()
                                    }
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                    android.widget.Toast.makeText(
                                        context, "Could not delete selected items.",
                                        android.widget.Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }) {
                                Icon(androidx.compose.material.icons.Icons.Default.Delete, contentDescription = "Delete Selected")
                            }
                            IconButton(onClick = {
                                viewModel.vaultSelected(items)
                            }) {
                                Icon(Icons.Default.Lock, contentDescription = "Vault Selected")
                            }
                        }
                    )
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Gallery",
                                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = "Explore real hardware photos and images",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                            )
                        }
                    }
                }
            },
            containerColor = Color.Transparent
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp)
            ) {
                // Sleek Material 3 Search TextField
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.onSearchQueryChanged(it) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("gallery_search_input"),
                    placeholder = { Text("Search by title or category...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Asset Search Tracker") },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.onSearchQueryChanged("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear query criteria")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Removed Media Filter Bar for Photo Only Screen

                Spacer(modifier = Modifier.height(10.dp))

                // Responsive Media Grid integrating local directories and empty states
                GalleryMediaGrid(
                    items = items.filterIsInstance<ImageItem>(),
                    favoritesState = favoritesState,
                    selectedIds = selectedIds,
                    onSelectionChange = { viewModel.toggleSelection(it) },
                    isSelectionMode = isSelectionMode,
                    isPermissionGranted = hasPermission,
                    onRequestPermissionClick = permissionLauncher,
                    onVideoClick = { video ->
                        activeVideoItem = video
                        media3Manager.play(
                            PlayerMediaItem(
                                id = video.id.toString(),
                                title = video.displayName,
                                uri = video.uri,
                                isVideo = true,
                                duration = video.duration
                            )
                        )
                    },
                    onImageClick = { image ->
                        activeImageItem = image
                    },
                    onAudioClick = { audio ->
                        activeAudioItem = audio
                        media3Manager.play(
                            PlayerMediaItem(
                                id = audio.id.toString(),
                                title = audio.displayName,
                                uri = audio.uri,
                                isVideo = false,
                                duration = audio.duration
                            )
                        )
                    },
                    onToggleFavorite = { mediaItem ->
                        viewModel.toggleFavorite(mediaItem)
                    },
                    searchQuery = searchQuery,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // FULL SCREEN OVERLAY: Immersive Video Player
        AnimatedVisibility(
            visible = activeVideoItem != null,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            val videoItems = items.filterIsInstance<VideoItem>()
            val initialPage = videoItems.indexOfFirst { it.id == activeVideoItem?.id }.coerceAtLeast(0)
            val pagerState = androidx.compose.foundation.pager.rememberPagerState(
                initialPage = initialPage,
                pageCount = { videoItems.size }
            )

            LaunchedEffect(pagerState.currentPage) {
                if (videoItems.isNotEmpty()) {
                    // Bounds-safe: currentPage can transiently exceed list size after delete/vault.
                    val safePage = pagerState.currentPage.coerceIn(0, videoItems.size - 1)
                    val currentVideo = videoItems.getOrNull(safePage) ?: return@LaunchedEffect
                    if (activeVideoItem?.id != currentVideo.id) {
                        activeVideoItem = currentVideo
                        media3Manager.play(
                            PlayerMediaItem(
                                id = currentVideo.id.toString(),
                                title = currentVideo.displayName,
                                uri = currentVideo.uri,
                                isVideo = true,
                                duration = currentVideo.duration
                            )
                        )
                    }
                }
            }
            
            LaunchedEffect(videoItems.size, activeVideoItem) {
                if (activeVideoItem != null && !videoItems.any { it.id == activeVideoItem?.id }) {
                    activeVideoItem = null
                }
            }

            if (videoItems.isNotEmpty() && activeVideoItem != null) {
                Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
                    androidx.compose.foundation.pager.VerticalPager(
                        state = pagerState,
                        modifier = Modifier.fillMaxSize(),
                        key = { index -> videoItems.getOrNull(index)?.id?.toString() ?: "video_$index" }
                    ) { page ->
                    if (page >= videoItems.size || page < 0) {
                        Box(modifier = Modifier.fillMaxSize())
                        return@VerticalPager
                    }
                    val video = videoItems[page]
                    val pState by playerController.playbackState.collectAsState()
                    val controlsVisible by playerController.controlsVisible.collectAsState()
                    val isVidFav = favoritesState.favoriteVideoIds.contains(video.id)
                    val isActivePage = pagerState.currentPage == page

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black)
                    ) {
                        VideoPlayerComposable(
                            controller = playerController,
                            isActivePage = isActivePage,
                            onBackClick = {
                                media3Manager.pause()
                                activeVideoItem = null
                            },
                            modifier = Modifier.fillMaxSize()
                        )

                        // Overlay TikTok/Reels Style Panel on top of video playback when controls are visible!
                        AnimatedVisibility(
                            visible = controlsVisible && isActivePage,
                            enter = fadeIn() + slideInVertically(initialOffsetY = { it / 2 }),
                            exit = fadeOut() + slideOutVertically(targetOffsetY = { it / 2 }),
                            modifier = Modifier
                                .align(Alignment.CenterEnd)
                                .padding(end = 16.dp, bottom = 48.dp)
                        ) {
                            MediaActionPanel(
                                item = video,
                                isFavorite = isVidFav,
                                currentSpeed = pState.playbackSpeed,
                                onFavoriteToggle = {
                                    viewModel.toggleFavorite(video)
                                },
                                onShareClick = {
                                    ShareMediaManager.share(context, video)
                                },
                                onDeleteClick = {
                                    deleteItemToConfirm = video
                                },
                                onInfoClick = {
                                    infoItemToShow = video
                                },
                                onSpeedClick = {
                                    isSpeedSheetToShow = true
                                },
                                onVaultClick = {
                                    viewModel.vaultItem(video)
                                    media3Manager.pause()
                                    activeVideoItem = null
                                }
                            )
                        }
                    }
                }
            }
            }
        }

        // FULL SCREEN OVERLAY: Raw Image Viewer
        AnimatedVisibility(
            visible = activeImageItem != null,
            enter = scaleIn() + fadeIn(),
            exit = scaleOut() + fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            val imageItems = items.filterIsInstance<ImageItem>()

            LaunchedEffect(imageItems.size, activeImageItem) {
                if (activeImageItem != null && !imageItems.any { it.id == activeImageItem?.id }) {
                    activeImageItem = null
                }
            }

            if (imageItems.isNotEmpty() && activeImageItem != null) {
                val initialPage = imageItems.indexOfFirst { it.id == activeImageItem?.id }.coerceAtLeast(0)
                val pagerState = androidx.compose.foundation.pager.rememberPagerState(
                    initialPage = initialPage,
                    pageCount = { imageItems.size }
                )
                
                // Sync activeImageItem for external components like details or actions
                LaunchedEffect(pagerState.currentPage) {
                    if (imageItems.isNotEmpty()) {
                        val safePage = pagerState.currentPage.coerceIn(0, imageItems.size - 1)
                        imageItems.getOrNull(safePage)?.let { activeImageItem = it }
                    }
                }

                // Solid black backdrop completely masks the underlying grid
                Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
                    androidx.compose.foundation.pager.HorizontalPager(
                        state = pagerState,
                        modifier = Modifier.fillMaxSize(),
                        key = { index ->
                            if (index in imageItems.indices) imageItems[index].id.toString()
                            else "image_fallback_$index"
                        },
                        beyondViewportPageCount = 1
                    ) { page ->
                    if (page >= imageItems.size || page < 0) {
                        Box(modifier = Modifier.fillMaxSize())
                        return@HorizontalPager
                    }
                    val image = imageItems[page]
                    val imageImmersiveController = rememberImmersiveController()
                    val isVisible = imageImmersiveController.visible.value
                    val isImageFav = favoritesState.favoriteImageIds.contains(image.id)

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) {
                                imageImmersiveController.toggleVisibility()
                            }
                            .testTag("gallery_fullscreen_image_viewer"),
                        contentAlignment = Alignment.Center
                    ) {
                        val context = LocalContext.current
                        var scale by remember { mutableStateOf(1f) }
                        var offset by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }

                        val fullImageRequest = remember(image.uri) {
                            coil.request.ImageRequest.Builder(context)
                                .data(image.uri)
                                .memoryCacheKey(image.uri.toString() + "_full")
                                .diskCacheKey(image.uri.toString() + "_full")
                                .bitmapConfig(android.graphics.Bitmap.Config.RGB_565)
                                .crossfade(true)
                                .build()
                        }
                        AsyncImage(
                            model = fullImageRequest,
                            contentDescription = image.displayName,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer(
                                    scaleX = scale,
                                    scaleY = scale,
                                    translationX = offset.x,
                                    translationY = offset.y
                                )
                                // Double-tap to zoom in/out. detectTapGestures does NOT
                                // consume drag events, so horizontal swipes still reach the pager.
                                .pointerInput(Unit) {
                                    androidx.compose.foundation.gestures.detectTapGestures(
                                        onDoubleTap = {
                                            if (scale > 1f) {
                                                scale = 1f
                                                offset = androidx.compose.ui.geometry.Offset.Zero
                                            } else {
                                                scale = 2.5f
                                            }
                                        }
                                    )
                                }
                                // Pinch/pan transform detector is attached ONLY while zoomed in.
                                // At scale 1f it is absent, so the HorizontalPager receives swipes.
                                .then(
                                    if (scale > 1f) {
                                        Modifier.pointerInput(Unit) {
                                            detectTransformGestures { _, pan, zoom, _ ->
                                                scale = (scale * zoom).coerceIn(1f, 4f)
                                                offset = if (scale > 1f) {
                                                    offset + pan
                                                } else {
                                                    androidx.compose.ui.geometry.Offset.Zero
                                                }
                                            }
                                        }
                                    } else {
                                        Modifier
                                    }
                                )
                        )

                        // Side action panel!
                        AnimatedVisibility(
                            visible = isVisible,
                            enter = slideInVertically(initialOffsetY = { it / 2 }) + fadeIn(),
                            exit = slideOutVertically(targetOffsetY = { it / 2 }) + fadeOut(),
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(bottom = 24.dp, end = 16.dp)
                        ) {
                            MediaActionPanel(
                                item = image,
                                isFavorite = isImageFav,
                                currentSpeed = null, // No speed controls for static images
                                onFavoriteToggle = {
                                    viewModel.toggleFavorite(image)
                                },
                                onShareClick = {
                                    ShareMediaManager.share(context, image)
                                },
                                onDeleteClick = {
                                    deleteItemToConfirm = image
                                },
                                onInfoClick = {
                                    infoItemToShow = image
                                },
                                onSpeedClick = null,
                                onVaultClick = {
                                    viewModel.vaultItem(image)
                                    activeImageItem = null
                                }
                            )
                        }

                        // Top Close Icon
                        AnimatedVisibility(
                            visible = isVisible,
                            enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                            exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                            modifier = Modifier
                                .statusBarsPadding()
                                .padding(16.dp)
                                .align(Alignment.TopStart)
                        ) {
                            IconButton(
                                onClick = { activeImageItem = null },
                                modifier = Modifier
                                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                                    .testTag("close_image_viewer_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Close full-screen raw display",
                                    tint = Color.White
                                )
                            }
                        }
                    }
                }
            }
            }
        }

        // FULL SCREEN OVERLAY: Gorgeous Audio Visualizer & Player
        AnimatedVisibility(
            visible = activeAudioItem != null,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            activeAudioItem?.let { audio ->
                val pState by playerController.playbackState.collectAsState()
                val isAudFav = favoritesState.favoriteAudioIds.contains(audio.id)
                val audioImmersiveController = rememberImmersiveController()
                val isVisible = audioImmersiveController.visible.value

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.background,
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                                    MaterialTheme.colorScheme.background
                                )
                            )
                        )
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            audioImmersiveController.toggleVisibility()
                        }
                        .testTag("gallery_fullscreen_audio_player"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceEvenly
                    ) {
                        // Top back button and header label
                        AnimatedVisibility(
                            visible = isVisible,
                            enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                            exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .statusBarsPadding()
                                    .height(56.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(
                                    onClick = {
                                        media3Manager.pause()
                                        activeAudioItem = null
                                    },
                                    modifier = Modifier
                                        .background(Color.Black.copy(alpha = 0.1f), CircleShape)
                                        .testTag("close_audio_player_btn")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ArrowBack,
                                        contentDescription = "Return to library",
                                        tint = MaterialTheme.colorScheme.onBackground
                                    )
                                }
                                Text(
                                    text = "Acoustic Visualizer",
                                    modifier = Modifier.weight(1f),
                                    textAlign = TextAlign.Center,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Spacer(modifier = Modifier.width(48.dp)) // Equalizer symmetry spacer
                            }
                        }

                        // Retro animated sound Wave components layout
                        Box(
                            modifier = Modifier
                                .size(240.dp)
                                .clip(RoundedCornerShape(24.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Audiotrack,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(80.dp)
                            )

                            // Simulated Ripple Visualizers
                            val infiniteTransition = rememberInfiniteTransition()
                            val scaleFactor by infiniteTransition.animateFloat(
                                initialValue = 0.9f,
                                targetValue = 1.3f,
                                animationSpec = infiniteRepeatable(
                                    animation = tween(1200, easing = LinearEasing),
                                    repeatMode = RepeatMode.Reverse
                                )
                            )

                            if (pState.isPlaying) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(
                                            Brush.radialGradient(
                                                colors = listOf(
                                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                                    Color.Transparent
                                                )
                                            )
                                        )
                                        .graphicsLayer(scaleX = scaleFactor, scaleY = scaleFactor)
                                )
                            }
                        }

                        // Title/Artist credentials
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = audio.displayName,
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onBackground,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = audio.artist ?: "Unknown Artist",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                                textAlign = TextAlign.Center
                            )
                        }

                        // Media duration tracking & slider setup
                        AnimatedVisibility(
                            visible = isVisible,
                            enter = fadeIn(),
                            exit = fadeOut(),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                val progressFactor = if (pState.duration > 0) {
                                    pState.currentPosition.toFloat() / pState.duration.toFloat()
                                } else {
                                    0f
                                }

                                Slider(
                                    value = progressFactor,
                                    onValueChange = { fraction ->
                                        val targetMs = (fraction * pState.duration).toLong()
                                        media3Manager.seekTo(targetMs)
                                    },
                                    colors = SliderDefaults.colors(
                                        thumbColor = MaterialTheme.colorScheme.primary,
                                        activeTrackColor = MaterialTheme.colorScheme.primary
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("audio_fullscreen_timeline")
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = formatDuration(pState.currentPosition),
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                                    )
                                    Text(
                                        text = formatDuration(pState.duration),
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                                    )
                                }
                            }
                        }

                        // Bottom controllers row
                        AnimatedVisibility(
                            visible = isVisible,
                            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(24.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(onClick = { media3Manager.seekRewind(5000) }) {
                                    Icon(Icons.Default.Replay5, contentDescription = "Rewind duration", modifier = Modifier.size(36.dp))
                                }

                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primary)
                                        .clickable {
                                            if (pState.isPlaying) {
                                                media3Manager.pause()
                                            } else {
                                                media3Manager.resume()
                                            }
                                        }
                                        .testTag("audio_visual_play_pause"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (pState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Trigger play state",
                                        tint = MaterialTheme.colorScheme.onPrimary,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }

                                IconButton(onClick = { media3Manager.seekForward(5000) }) {
                                    Icon(Icons.Default.Forward5, contentDescription = "Fast forward duration", modifier = Modifier.size(36.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                    }

                    // Floating Vertical Media Action Panel for Audio Playback!
                    AnimatedVisibility(
                        visible = isVisible,
                        enter = fadeIn() + slideInVertically(initialOffsetY = { it / 2 }),
                        exit = fadeOut() + slideOutVertically(targetOffsetY = { it / 2 }),
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(end = 16.dp, bottom = 48.dp)
                    ) {
                        MediaActionPanel(
                            item = audio,
                            isFavorite = isAudFav,
                            currentSpeed = pState.playbackSpeed,
                            onFavoriteToggle = {
                                viewModel.toggleFavorite(audio)
                            },
                            onShareClick = {
                                ShareMediaManager.share(context, audio)
                            },
                            onDeleteClick = {
                                deleteItemToConfirm = audio
                            },
                            onInfoClick = {
                                infoItemToShow = audio
                            },
                            onSpeedClick = {
                                isSpeedSheetToShow = true
                            },
                            onVaultClick = {
                                viewModel.vaultItem(audio)
                                media3Manager.pause()
                                activeAudioItem = null
                            }
                        )
                    }
                }
            }
        }

        // --- IMMERSIVE OVERLAYS: MODAL SHEETS & DIALOG CONTEXTS ---

        // A. Dynamic Specifications Overlay Sheet
        MediaInfoSheet(
            show = infoItemToShow != null,
            item = infoItemToShow,
            onDismiss = { infoItemToShow = null }
        )

        // B. Playback Velocity / Tempo Adjuster Selector Sheet
        SpeedControlSheet(
            show = isSpeedSheetToShow,
            currentSpeed = playerController.playbackState.collectAsState().value.playbackSpeed,
            onSpeedSelected = { multiplier ->
                playerController.setPlaybackSpeed(multiplier)
            },
            onDismiss = { isSpeedSheetToShow = false }
        )

        // C. Permanent Scoped Files Removal Confirmation Prompt Dialog
        DeleteConfirmationDialog(
            show = deleteItemToConfirm != null,
            itemName = deleteItemToConfirm?.displayName ?: "",
            onConfirm = {
                val item = deleteItemToConfirm
                // Guard: ignore if a delete is already in flight, or no item selected.
                if (item != null && pendingDeleteItem == null) {
                    // Mark in-flight and dismiss the app dialog immediately so it cannot be
                    // tapped again while the system permission dialog is showing.
                    pendingDeleteItem = item
                    deleteItemToConfirm = null
                    deleteMediaManager.performDelete(
                        contentResolver = context.contentResolver,
                        item = item,
                        senderLauncher = deleteLauncher,
                        onSuccess = {
                            viewModel.removeMediaItem(item.id, item)
                            if (activeVideoItem?.id == item.id) {
                                media3Manager.pause()
                                activeVideoItem = null
                            }
                            if (activeImageItem?.id == item.id) {
                                activeImageItem = null
                            }
                            if (activeAudioItem?.id == item.id) {
                                media3Manager.pause()
                                activeAudioItem = null
                            }
                            pendingDeleteItem = null
                        },
                        onError = { message ->
                            android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_LONG).show()
                            pendingDeleteItem = null
                        }
                    )
                }
            },
            onDismiss = { deleteItemToConfirm = null }
        )
    }
}

/**
 * Scaffold Status bars calculation safe padding.
 */
@Composable
private fun Modifier.statusBarsPadding(): Modifier {
    val context = LocalContext.current
    val resourceId = context.resources.getIdentifier("status_bar_height", "dimen", "android")
    val statusBarHeight = if (resourceId > 0) {
        context.resources.getDimensionPixelSize(resourceId) / context.resources.displayMetrics.density
    } else {
        24f
    }
    return this.padding(top = statusBarHeight.dp)
}

/**
 * Duration formater logic helper.
 */
private fun formatDuration(ms: Long): String {
    val seconds = ms / 1000
    val secs = seconds % 60
    val mins = seconds / 60
    return String.format("%02d:%02d", mins, secs)
}

/**
 * Memory bytes parser formater helper.
 */
private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.toDouble())).toInt()
    return String.format("%.1f %s", bytes / Math.pow(1024.toDouble(), digitGroups.toDouble()), units[digitGroups])
}
package com.example.presentation.stability

import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class PlaybackRecoveryManager {
    private val _hasError = MutableStateFlow(false)
    val hasError: StateFlow<Boolean> = _hasError

    fun registerError(e: Exception?) {
        Log.e("PlaybackRecoveryManager", "Player error encountered", e)
        _hasError.value = true
    }

    fun clearError() {
        _hasError.value = false
    }

    fun attemptRecovery(retryAction: () -> Unit) {
        clearError()
        try {
            retryAction()
        } catch (e: Exception) {
            registerError(e)
        }
    }
}

package com.example.presentation.screens.player

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.MediaItem
import com.example.presentation.timer.SleepTimerManager
import com.example.presentation.timer.SleepTimerSheet
import kotlin.math.sin

/**
 * High-fidelity Audio & Media Player Screen.
 * Employs premium gradients, dynamic waveform visualizers using Canvas,
 * and intuitive slider controls.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(
    viewModel: PlayerViewModel,
    sleepTimerManager: SleepTimerManager,
    onBack: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val progress by viewModel.progress.collectAsState()

    var showReelsMode by remember { mutableStateOf(false) }
    var showSleepTimerSheet by remember { mutableStateOf(false) }

    androidx.activity.compose.BackHandler(enabled = showReelsMode) {
        showReelsMode = false
    }

    if (showReelsMode) {
        com.example.presentation.screens.player.media3.ReelsPlayerScreen(
            onBackClick = { showReelsMode = false },
            modifier = modifier
        )
    } else {
        Scaffold(
            modifier = modifier.testTag("player_screen"),
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            "Media Player",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { showReelsMode = true },
                            modifier = Modifier.testTag("launch_reels_button")
                        ) {
                            Icon(Icons.Default.Movie, contentDescription = "Show Reels Player Mode")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent,
                        titleContentColor = MaterialTheme.colorScheme.onBackground
                    )
                )
            },
            containerColor = Color.Transparent
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                com.example.presentation.theme.CinematicOverlayComposable()
                
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp, vertical = 16.dp)
                ) {
            when (val state = uiState) {
                is PlaybackUiState.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    }
                }
                is PlaybackUiState.Ready -> {
                    val activeTrack = state.activeTrack
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        // 1. Digital Art / Orbit Card Visualizer
                        ArtworkVisualizer(activeTrack = activeTrack, isPlaying = isPlaying)

                        // 2. Track Meta
                        TrackMetaDetails(
                            trackName = activeTrack.title,
                            artistName = activeTrack.artist,
                            isFav = activeTrack.isFavorite,
                            onFavoriteClick = { viewModel.toggleFavorite() }
                        )

                        // 3. Custom Canvas Waveform Visualizer
                        WaveformVisualizer(isPlaying = isPlaying)

                        // 4. Progress bar control Slider space
                        SliderControls(
                            progress = progress,
                            durationStr = activeTrack.duration,
                            onSeek = { viewModel.seekTo(it) }
                        )

                        // 5. Playback Controller Buttons Row
                        MediaPlayerControls(
                            isPlaying = isPlaying,
                            onPlayPause = { viewModel.togglePlayPause() },
                            onNext = { viewModel.playNext() },
                            onPrev = { viewModel.playPrevious() },
                            onSleepTimerClick = { showSleepTimerSheet = true },
                            isTimerActive = sleepTimerManager.isTimerActive.collectAsState().value
                        )

                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
                is PlaybackUiState.Error -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            text = "Error loading play unit: ${state.message}",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
                } // Close inner Box
                

            } // Close outer Box
        }
    }
    
    if (showSleepTimerSheet) {
        SleepTimerSheet(
            sleepTimerManager = sleepTimerManager,
            onDismiss = { showSleepTimerSheet = false }
        )
    }
}
}

@Composable
fun ArtworkVisualizer(
    activeTrack: MediaItem,
    isPlaying: Boolean
) {
    // Dynamic rotation simulation for the vinyl/artwork hub
    val infiniteTransition = rememberInfiniteTransition(label = "disc_spin")
    val angle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "disc_angle"
    )

    val currentAngle = if (isPlaying) angle else 0f

    Box(
        modifier = Modifier
            .size(260.dp)
            .graphicsLayer { rotationZ = currentAngle }
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.9f),
                        MaterialTheme.colorScheme.secondary.copy(alpha = 0.3f),
                        MaterialTheme.colorScheme.background.copy(alpha = 0.2f)
                    ),
                    radius = 400f
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        // Deep Obsidian Vinyl concentric lines decoration
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2, size.height / 2)
            for (r in 40..110 step 15) {
                drawCircle(
                    color = Color.Black.copy(alpha = 0.15f),
                    radius = r.dp.toPx(),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.dp.toPx())
                )
            }
        }

        // Center hub cover art replacement display
        Box(
            modifier = Modifier
                .size(110.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = activeTrack.category,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun TrackMetaDetails(
    trackName: String,
    artistName: String,
    isFav: Boolean,
    onFavoriteClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = trackName,
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1
            )
            Text(
                text = artistName,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                maxLines = 1
            )
        }

        IconButton(
            onClick = onFavoriteClick,
            modifier = Modifier.testTag("player_favorite_toggle")
        ) {
            Icon(
                imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = "Favorite Track",
                tint = if (isFav) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

@Composable
fun WaveformVisualizer(isPlaying: Boolean) {
    val transition = rememberInfiniteTransition(label = "soundwaves")
    val phaseOffset by transition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = MaterialTheme.colorScheme.secondary

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .padding(vertical = 4.dp)
    ) {
        val width = size.width
        val height = size.height
        val centerY = height / 2

        if (isPlaying) {
            // Draw flowing sinewaves
            val points = 100
            for (i in 0 until points) {
                val x = (width / points) * i
                val progressRatio = i.toFloat() / points
                
                // Primary wave
                val y1 = centerY + 18f * sin(progressRatio * 4 * Math.PI.toFloat() + phaseOffset)
                // Secondary offset wave
                val y2 = centerY + 10f * sin(progressRatio * 8 * Math.PI.toFloat() - phaseOffset)

                drawCircle(
                    color = primaryColor.copy(alpha = 0.7f),
                    radius = 2.dp.toPx(),
                    center = Offset(x, y1)
                )
                drawCircle(
                    color = secondaryColor.copy(alpha = 0.5f),
                    radius = 1.5.dp.toPx(),
                    center = Offset(x, y2)
                )
            }
        } else {
            // Static rest line
            drawLine(
                color = primaryColor.copy(alpha = 0.4f),
                start = Offset(0f, centerY),
                end = Offset(width, centerY),
                strokeWidth = 2.dp.toPx()
            )
        }
    }
}

@Composable
fun SliderControls(
    progress: Float,
    durationStr: String,
    onSeek: (Float) -> Unit
) {
    // Math to compute simple time strings
    val totalSeconds = 240f // assumed 4 minutes max demo track
    val currentSecondsCount = (progress * totalSeconds).toInt()
    val min = currentSecondsCount / 60
    val sec = currentSecondsCount % 60
    val elapsedStr = String.format("%02d:%02d", min, sec)

    Column(modifier = Modifier.fillMaxWidth()) {
        Slider(
            value = progress,
            onValueChange = onSeek,
            modifier = Modifier.fillMaxWidth().testTag("player_progress_slider"),
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary,
                inactiveTrackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.15f)
            )
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = elapsedStr,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
            )
            Text(
                text = durationStr,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
            )
        }
    }
}

@Composable
fun MediaPlayerControls(
    isPlaying: Boolean,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onSleepTimerClick: () -> Unit,
    isTimerActive: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onSleepTimerClick,
            modifier = Modifier.size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Timer,
                contentDescription = "Sleep Timer",
                tint = if (isTimerActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
            )
        }

        IconButton(
            onClick = onPrev,
            modifier = Modifier.size(56.dp).testTag("prev_track_button")
        ) {
            Icon(
                imageVector = Icons.Rounded.SkipPrevious,
                contentDescription = "Prev",
                tint = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.size(32.dp)
            )
        }

        // Play Pause main button
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.primary,
                            MaterialTheme.colorScheme.secondary
                        )
                    )
                )
                .clickable { onPlayPause() }
                .testTag("play_pause_button")
                .padding(2.dp),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = if (isPlaying) "Pause" else "Play",
                tint = Color.White,
                modifier = Modifier.size(40.dp)
            )
        }

        IconButton(
            onClick = onNext,
            modifier = Modifier.size(56.dp).testTag("next_track_button")
        ) {
            Icon(
                imageVector = Icons.Rounded.SkipNext,
                contentDescription = "Next",
                tint = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.size(32.dp)
            )
        }

        IconButton(
            onClick = {},
            modifier = Modifier.size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Repeat,
                contentDescription = "Repeat",
                tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
            )
        }
    }
}

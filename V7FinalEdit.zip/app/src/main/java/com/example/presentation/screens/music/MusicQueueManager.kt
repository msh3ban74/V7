package com.example.presentation.screens.music

import com.example.domain.model.AudioItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Thread-safe music playback queue with strict circular boundary clamping.
 * All index mutations use [coerceIn] guards to prevent IndexOutOfBoundsException
 * regardless of how rapidly next/previous are triggered.
 */
class MusicQueueManager {
    private val _queue = MutableStateFlow<List<AudioItem>>(emptyList())
    val queue: StateFlow<List<AudioItem>> = _queue

    private val _currentIndex = MutableStateFlow(0)
    val currentIndex: StateFlow<Int> = _currentIndex

    fun setQueue(items: List<AudioItem>, startIndex: Int = 0) {
        _queue.value = items
        _currentIndex.value = if (items.isEmpty()) 0
        else startIndex.coerceIn(0, items.size - 1)
    }

    fun addToQueue(item: AudioItem) {
        _queue.value = _queue.value + item
    }

    fun removeFromQueue(item: AudioItem) {
        val newList = _queue.value.filter { it.id != item.id }
        _queue.value = newList
        if (newList.isEmpty()) {
            _currentIndex.value = 0
        } else {
            _currentIndex.value = _currentIndex.value.coerceIn(0, newList.size - 1)
        }
    }

    /**
     * Advances to the next track with strict circular wrapping.
     * Safe to call even on a single-item or empty queue.
     */
    fun next(): AudioItem? {
        val q = _queue.value
        if (q.isEmpty()) return null
        val nextIdx = (_currentIndex.value + 1).let { if (it >= q.size) 0 else it }
        _currentIndex.value = nextIdx.coerceIn(0, q.size - 1)
        return q.getOrNull(_currentIndex.value)
    }

    /**
     * Moves to the previous track with strict circular wrapping.
     * Safe to call even on a single-item or empty queue.
     */
    fun previous(): AudioItem? {
        val q = _queue.value
        if (q.isEmpty()) return null
        val prevIdx = (_currentIndex.value - 1).let { if (it < 0) q.size - 1 else it }
        _currentIndex.value = prevIdx.coerceIn(0, q.size - 1)
        return q.getOrNull(_currentIndex.value)
    }

    /**
     * Returns the current item with strict bounds checking.
     * Returns null if queue is empty or index is somehow out of range.
     */
    fun getCurrentItem(): AudioItem? {
        val q = _queue.value
        if (q.isEmpty()) return null
        val safeIdx = _currentIndex.value.coerceIn(0, q.size - 1)
        _currentIndex.value = safeIdx // Self-heal if index drifted
        return q.getOrNull(safeIdx)
    }
}

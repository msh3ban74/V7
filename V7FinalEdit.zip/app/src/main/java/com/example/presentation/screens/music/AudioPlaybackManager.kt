package com.example.presentation.screens.music

import android.content.Context
import com.example.domain.model.AudioItem
import com.example.presentation.screens.player.media3.Media3Manager
import com.example.presentation.screens.player.media3.PlayerMediaItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class AudioPlaybackManager(context: Context) {
    val media3Manager = Media3Manager(context)
    val queueManager = MusicQueueManager()

    private val _isShuffle = MutableStateFlow(false)
    val isShuffle: StateFlow<Boolean> = _isShuffle

    private val _isRepeat = MutableStateFlow(false)
    val isRepeat: StateFlow<Boolean> = _isRepeat

    // Observable current item — Compose screens collect this so the mini-player and the
    // full player update their title/artist/album when the track changes (next/previous).
    // Previously `currentItem` was a plain getter, so the UI never recomposed on a skip
    // and song names appeared stale or missing.
    private val _currentItem = MutableStateFlow<AudioItem?>(null)
    val currentItemFlow: StateFlow<AudioItem?> = _currentItem

    fun toggleShuffle() {
        _isShuffle.value = !_isShuffle.value
    }

    fun toggleRepeat() {
        _isRepeat.value = !_isRepeat.value
    }

    fun play(items: List<AudioItem>, startIndex: Int = 0) {
        if (items.isEmpty()) return
        val validStartIndex = startIndex.coerceIn(0, maxOf(0, items.size - 1))
        val listToPlay = if (_isShuffle.value) items.shuffled() else items
        val idx = if (_isShuffle.value) listToPlay.indexOf(items[validStartIndex]).takeIf { it >= 0 } ?: 0 else validStartIndex
        queueManager.setQueue(listToPlay, idx)
        playCurrent()
    }

    // Kept for source compatibility; always reflects the live queue position.
    val currentItem: AudioItem? get() = queueManager.getCurrentItem()

    private fun playCurrent() {
        val item = queueManager.getCurrentItem() ?: return
        // Publish the new current item before playback so the UI updates immediately.
        _currentItem.value = item
        media3Manager.play(
            PlayerMediaItem(
                id = item.id.toString(),
                title = item.displayName,
                uri = item.uri,
                isVideo = false,
                duration = item.duration,
                artist = item.artist ?: "Unknown Artist"
            )
        )
    }

    fun playNext() {
        queueManager.next()?.let { playCurrent() }
    }

    fun playPrevious() {
        queueManager.previous()?.let { playCurrent() }
    }

    fun release() {
        media3Manager.release()
    }
}

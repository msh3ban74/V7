package com.example.presentation.security

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.appLockDataStore by preferencesDataStore(name = "app_lock_prefs")

class AppLockManager(private val context: Context) {
    companion object {
        val APP_LOCK_ENABLED = booleanPreferencesKey("app_lock_enabled")
        val LOCK_TIMEOUT_MINUTES = intPreferencesKey("lock_timeout_minutes")
    }

    val isLockEnabled: Flow<Boolean> = context.appLockDataStore.data.map { prefs ->
        prefs[APP_LOCK_ENABLED] ?: false
    }

    val lockTimeoutMinutes: Flow<Int> = context.appLockDataStore.data.map { prefs ->
        prefs[LOCK_TIMEOUT_MINUTES] ?: 0 // 0 means immediate
    }

    suspend fun setLockEnabled(enabled: Boolean) {
        context.appLockDataStore.edit { prefs ->
            prefs[APP_LOCK_ENABLED] = enabled
        }
    }

    suspend fun setLockTimeoutMinutes(minutes: Int) {
        context.appLockDataStore.edit { prefs ->
            prefs[LOCK_TIMEOUT_MINUTES] = minutes
        }
    }
}

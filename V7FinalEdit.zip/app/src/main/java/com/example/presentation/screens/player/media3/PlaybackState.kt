package com.example.presentation.screens.player.media3

import android.net.Uri

/**
 * Domain-ready model of media items loaded inside the player controller.
 */
data class PlayerMediaItem(
    val id: String,
    val title: String,
    val uri: Uri,
    val isVideo: Boolean = true,
    val duration: Long = 0L,
    val artist: String = ""
)

/**
 * Represents the current playback and UI control state of the player.
 */
data class PlaybackState(
    val currentItem: PlayerMediaItem? = null,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val currentPosition: Long = 0L,
    val duration: Long = 0L,
    val playbackSpeed: Float = 1.0f,
    val controlsVisible: Boolean = true,
    val volume: Float = 1.0f,
    val brightness: Float = 1.0f,
    val isPipMode: Boolean = false,
    val isLandscape: Boolean = false,
    val errorMessage: String? = null
)

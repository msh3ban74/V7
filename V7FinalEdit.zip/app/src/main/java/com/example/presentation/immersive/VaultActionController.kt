package com.example.presentation.immersive

import com.example.presentation.screens.vault.VaultManager
import com.example.domain.model.LocalMediaItem

class VaultActionController(private val vaultManager: VaultManager) {

    /**
     * Physically vault a media item — streams file bytes to secure directory,
     * removes from MediaStore, and deletes source file.
     */
    suspend fun sendToVault(item: LocalMediaItem, onSuccess: () -> Unit, onError: (String) -> Unit) {
        try {
            val success = vaultManager.vaultMedia(item)
            if (success) {
                onSuccess()
            } else {
                onError("Could not vault item — source file may not exist.")
            }
        } catch (e: Exception) {
            onError(e.localizedMessage ?: "Failed to add to Vault")
        }
    }

    /**
     * Physically restore a vaulted item back to public storage and MediaStore.
     */
    suspend fun restoreFromVault(item: LocalMediaItem, onSuccess: () -> Unit, onError: (String) -> Unit) {
        try {
            val success = vaultManager.restoreMedia(item.id)
            if (success) {
                onSuccess()
            } else {
                onError("Could not restore item — vault file may be missing.")
            }
        } catch (e: Exception) {
            onError(e.localizedMessage ?: "Failed to restore from Vault")
        }
    }
}

package com.example.presentation.screens.favorites

import android.content.Context
import androidx.room.*
import com.example.presentation.screens.gallery.favorites.FavoritesState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val mediaId: Long,
    val mediaType: String // "video", "audio", "image"
)

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites")
    fun getAllFavorites(): kotlinx.coroutines.flow.Flow<List<FavoriteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(entity: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE mediaId = :mediaId")
    suspend fun removeFavorite(mediaId: Long)
    
    @Query("SELECT COUNT(*) FROM favorites WHERE mediaId = :mediaId")
    suspend fun isFavorite(mediaId: Long): Int
}

class FavoritesRepository(private val context: Context, private val scope: CoroutineScope) {
    private val dao by lazy { com.example.presentation.screens.watchhistory.AppDatabase.getDatabase(context).favoriteDao() }

    val favoritesState: StateFlow<FavoritesState> by lazy {
        dao.getAllFavorites().map { list ->
            val vids = list.filter { it.mediaType == "video" }.map { it.mediaId }.toSet()
            val imgs = list.filter { it.mediaType == "image" }.map { it.mediaId }.toSet()
            val auds = list.filter { it.mediaType == "audio" }.map { it.mediaId }.toSet()
            FavoritesState(
                favoriteVideoIds = vids,
                favoriteImageIds = imgs,
                favoriteAudioIds = auds
            )
        }.stateIn(scope, SharingStarted.WhileSubscribed(5000), FavoritesState())
    }

    fun toggleFavoriteVideo(id: Long) {
        scope.launch { toggleFavorite(id, "video") }
    }

    fun toggleFavoriteImage(id: Long) {
        scope.launch { toggleFavorite(id, "image") }
    }

    fun toggleFavoriteAudio(id: Long) {
        scope.launch { toggleFavorite(id, "audio") }
    }

    private suspend fun toggleFavorite(id: Long, type: String) {
        val isFav = dao.isFavorite(id) > 0
        if (isFav) {
            dao.removeFavorite(id)
        } else {
            dao.insertFavorite(FavoriteEntity(id, type))
        }
    }
}

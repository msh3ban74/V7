package com.example.presentation.screens.vault

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import com.example.presentation.performance.OptimizedLazyGrid
import com.example.presentation.performance.rememberPerformanceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.domain.model.LocalMediaItem
import com.example.presentation.screens.gallery.components.MediaCardComposable

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun VaultMediaGrid(
    items: List<LocalMediaItem>,
    onItemClick: (LocalMediaItem) -> Unit,
    onRestoreClick: (LocalMediaItem) -> Unit,
    modifier: Modifier = Modifier
) {
    if (items.isEmpty()) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            com.example.presentation.components.stability.EmptyStateComposable(
                message = "Vault is empty",
                icon = androidx.compose.material.icons.Icons.Default.Lock
            )
        }
    } else {
        val performanceState = rememberPerformanceState()
        OptimizedLazyGrid(
            performanceState = performanceState,
            columns = GridCells.Fixed(5),
            contentPadding = PaddingValues(bottom = 32.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = modifier.fillMaxSize()
        ) {
            items(
                items = items, 
                key = { it.id },
                contentType = { it::class.simpleName }
            ) { item ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    val isScrolling = performanceState.isScrolling
                    com.example.presentation.components.polish.PremiumMediaCard(
                        mediaItem = item,
                        isFavorite = false,
                        isScrolling = isScrolling,
                        onCardClick = { onItemClick(item) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                    )
                    IconButton(
                        onClick = { onRestoreClick(item) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LockOpen,
                            contentDescription = "Restore",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

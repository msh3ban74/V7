package com.example.presentation.screens.player.media3

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import com.example.presentation.screens.watchhistory.PlaybackMemoryManager
import com.example.presentation.screens.watchhistory.WatchHistoryRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.example.MainApplication

/**
 * High-performance Media3 Manager that handles the lifecycle of ExoPlayer and MediaSession.
 * Supports background playback, media notification events, and tracks resume positions.
 */
@OptIn(UnstableApi::class)
class Media3Manager(private val context: Context) : Player.Listener {

    private val applicationContext = context.applicationContext
    
    private val playbackMemoryManager = PlaybackMemoryManager(WatchHistoryRepository(applicationContext))

    // Core ExoPlayer instance
    private var player: ExoPlayer? = null
    
    // Core MediaSession instance for system notification connection & background operations
    private var mediaSession: MediaSession? = null

    // Tracking state flows
    private val _playbackState = MutableStateFlow(PlaybackState())
    val playbackState = _playbackState.asStateFlow()

    // Resume position memory mapping for quick access
    private val resumePositions = mutableMapOf<String, Long>()

    // Coroutine tracking for position updates
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var positionJob: Job? = null

    // We no longer eagerly instantiate the player in init block to prevent startup freezing
    private fun ensurePlayer() {
        if (player != null) return
        initializePlayer()
    }

    /**
     * Instantiates ExoPlayer and initializes MediaSession securely.
     */
    private fun initializePlayer() {
        if (player != null) return

        val attributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        val cacheDataSourceFactory = CacheDataSource.Factory()
            .setCache(MainApplication.mediaCache)
            .setUpstreamDataSourceFactory(DefaultDataSource.Factory(applicationContext))
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)

        player = ExoPlayer.Builder(applicationContext)
            .setAudioAttributes(attributes, true)
            .setMediaSourceFactory(DefaultMediaSourceFactory(applicationContext).setDataSourceFactory(cacheDataSourceFactory))
            .setHandleAudioBecomingNoisy(true)
            .build().apply {
                setVideoScalingMode(C.VIDEO_SCALING_MODE_SCALE_TO_FIT)
                addListener(this@Media3Manager)
                repeatMode = Player.REPEAT_MODE_ONE // Default vertical loops for short vertical mode
                playWhenReady = false
            }

        // Build MediaSession for background & locked notification integrations
        player?.let { exo ->
            try {
                mediaSession = MediaSession.Builder(applicationContext, exo)
                    .setId("V7_MediaSession")
                    .build()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        startPositionTracker()
    }

    /**
     * Gets or exposes the raw internal player reference for Compose views.
     */
    fun getPlayer(): Player? {
        if (player == null) {
            initializePlayer()
        }
        return player
    }

    /**
     * Prepares and starts playback of a specified [PlayerMediaItem].
     * Integrates automatic playback resume position loading.
     */
    fun play(item: PlayerMediaItem) {
        // Safe-URI guard: never attempt to prepare an empty/invalid URI.
        if (item.uri == Uri.EMPTY || item.uri.toString().isBlank()) return

        initializePlayer()
        val currentPlayer = player ?: return

        // Idempotency guard: if this exact item is already loaded and the player is in a
        // healthy (non-idle) state, just resume instead of re-preparing. This prevents the
        // redundant reloads/re-buffering observed during fast scrolling and recomposition.
        val alreadyCurrent = _playbackState.value.currentItem?.id == item.id
        if (alreadyCurrent &&
            currentPlayer.currentMediaItem != null &&
            currentPlayer.playbackState != Player.STATE_IDLE
        ) {
            if (!currentPlayer.isPlaying) {
                try { currentPlayer.play() } catch (e: Exception) { e.printStackTrace() }
            }
            return
        }

        // Save current item's progress first if we are playing something else
        saveCurrentProgress()

        val mediaItem = MediaItem.Builder()
            .setMediaId(item.id)
            .setUri(item.uri)
            .setMediaMetadata(
                androidx.media3.common.MediaMetadata.Builder()
                    .setTitle(item.title)
                    .setArtist(item.artist)
                    .build()
            )
            .build()

        _playbackState.update { it.copy(currentItem = item, errorMessage = null) }
        
        scope.launch {
            // Load saved resume position via IO (may suspend briefly)
            var savedPos = resumePositions[item.id] ?: 0L
            if (savedPos == 0L) {
                savedPos = playbackMemoryManager.getPlaybackPosition(item.id.toLongOrNull() ?: 0L)
            }

            // Stale-play guard: if user skipped to a different track while IO was loading, abort
            if (_playbackState.value.currentItem?.id != item.id) return@launch

            // Always fetch a fresh player reference — captured reference could be released
            val freshPlayer = player ?: return@launch

            try {
                freshPlayer.setMediaItem(mediaItem)
                if (savedPos > 0) {
                    freshPlayer.seekTo(savedPos)
                }
                freshPlayer.prepare()
                freshPlayer.play()
            } catch (e: Exception) {
                // ExoPlayer threw on a released instance — swallow and let next play() recover
                e.printStackTrace()
            }
        }
    }

    fun pause() {
        player?.pause()
    }

    fun resume() {
        player?.play()
    }

    fun setSpeed(speed: Float) {
        player?.playbackParameters = PlaybackParameters(speed)
        _playbackState.update { it.copy(playbackSpeed = speed) }
    }

    fun seekTo(positionMs: Long) {
        player?.seekTo(positionMs.coerceIn(0L, player?.duration ?: 0L))
        updatePositionState()
    }

    fun seekForward(amountMs: Long) {
        val current = player?.currentPosition ?: 0L
        seekTo(current + amountMs)
    }

    fun seekRewind(amountMs: Long) {
        val current = player?.currentPosition ?: 0L
        seekTo(current - amountMs)
    }

    /**
     * Saves the current media progress into resume mapping memory and Room database.
     */
    fun saveCurrentProgress() {
        val activeItem = _playbackState.value.currentItem ?: return
        player?.let { exo ->
            if (exo.duration > 0) {
                val position = exo.currentPosition
                resumePositions[activeItem.id] = position
                scope.launch(Dispatchers.IO) {
                    playbackMemoryManager.savePlaybackPosition(
                        id = activeItem.id.toLongOrNull() ?: 0L,
                        uri = activeItem.uri.toString(),
                        title = activeItem.title,
                        type = if (activeItem.isVideo) "video" else "audio",
                        position = position,
                        duration = exo.duration
                    )
                }
            }
        }
    }

    private fun startPositionTracker() {
        positionJob?.cancel()
        positionJob = scope.launch {
            while (true) {
                updatePositionState()
                delay(500)
            }
        }
    }

    private fun updatePositionState() {
        player?.let { exo ->
            _playbackState.update {
                it.copy(
                    currentPosition = exo.currentPosition,
                    duration = if (exo.duration == C.TIME_UNSET) 0L else exo.duration,
                    isPlaying = exo.isPlaying,
                    isBuffering = exo.playbackState == Player.STATE_BUFFERING
                )
            }
        }
    }

    /**
     * Player Events Listener
     */
    override fun onPlaybackStateChanged(playbackState: Int) {
        val isBuffering = playbackState == Player.STATE_BUFFERING
        _playbackState.update {
            it.copy(
                isBuffering = isBuffering,
                duration = if (player?.duration == C.TIME_UNSET) 0L else (player?.duration ?: 0L)
            )
        }
        // When player reaches STATE_READY, surface the actual metadata title so it is never blank
        if (playbackState == Player.STATE_READY) {
            player?.mediaMetadata?.let { meta ->
                val resolvedTitle = meta.title?.toString()
                if (!resolvedTitle.isNullOrBlank()) {
                    _playbackState.update { state ->
                        state.currentItem?.let { current ->
                            state.copy(currentItem = current.copy(title = resolvedTitle))
                        } ?: state
                    }
                }
            }
        }
    }

    override fun onIsPlayingChanged(isPlaying: Boolean) {
        _playbackState.update { it.copy(isPlaying = isPlaying) }
        if (!isPlaying) {
            saveCurrentProgress()
        }
    }

    override fun onMediaMetadataChanged(mediaMetadata: androidx.media3.common.MediaMetadata) {
        val extractedTitle = mediaMetadata.title?.toString()
        if (!extractedTitle.isNullOrBlank()) {
            _playbackState.update { state ->
                state.currentItem?.let { current ->
                    state.copy(currentItem = current.copy(title = extractedTitle))
                } ?: state
            }
        }
    }

    override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
        val lightweightErrorMsg = if (error.errorCode == androidx.media3.common.PlaybackException.ERROR_CODE_DECODER_INIT_FAILED) {
            "Unsupported codec. Cannot play this video."
        } else {
            "Video playback error."
        }
        _playbackState.update {
            it.copy(
                errorMessage = lightweightErrorMsg,
                isPlaying = false
            )
        }
        player?.stop()
        player?.clearMediaItems()
    }

    /**
     * Cleans up ExoPlayer session assets correctly.
     */
    fun release() {
        saveCurrentProgress()
        positionJob?.cancel()

        mediaSession?.release()
        mediaSession = null

        player?.removeListener(this)
        player?.release()
        player = null

        // Cancel any in-flight play()/progress coroutines so they cannot touch a
        // released player instance after this manager is disposed.
        scope.coroutineContext[Job]?.cancel()
    }
}

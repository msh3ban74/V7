package com.example.presentation.screens.watchhistory

class PlaybackMemoryManager(private val repository: WatchHistoryRepository) {

    suspend fun savePlaybackPosition(
        id: Long,
        uri: String,
        title: String,
        type: String, // "video", "audio", "image"
        position: Long,
        duration: Long
    ) {
        repository.addHistory(id, uri, title, type, position, duration)
    }

    suspend fun getPlaybackPosition(id: Long): Long {
        return repository.getHistory(id)?.playbackPosition ?: 0L
    }
}

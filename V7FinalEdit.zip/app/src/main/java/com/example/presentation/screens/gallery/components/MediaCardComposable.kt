package com.example.presentation.screens.gallery.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.AudioItem
import com.example.domain.model.ImageItem
import com.example.domain.model.LocalMediaItem
import com.example.domain.model.VideoItem

/**
 * Modern card layout rendering local media metadata, showing media dimensions, file sizes,
 * audio duration/artist credentials, and favoriting triggers.
 */
@Composable
fun MediaCardComposable(
    mediaItem: LocalMediaItem,
    isFavorite: Boolean,
    onCardClick: () -> Unit,
    onFavoriteToggle: () -> Unit,
    modifier: Modifier = Modifier,
    isScrolling: Boolean = false
) {
    val formattedSize = remember(mediaItem.size) { formatBytes(mediaItem.size) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onCardClick() }
            .testTag("local_media_card_${mediaItem.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column {
            // Visual element representing thumbnails or placeholders
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
            ) {
                MediaThumbnailLoader(
                    mediaItem = mediaItem,
                    isScrolling = isScrolling,
                    modifier = Modifier.clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                )

                // Overlay Type Badge
                val badgeIcon = when (mediaItem) {
                    is VideoItem -> Icons.Default.Movie
                    is ImageItem -> Icons.Default.Image
                    is AudioItem -> Icons.Default.AudioFile
                }
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Icon(
                        imageVector = badgeIcon,
                        contentDescription = "Media type identifier",
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                }

                // Overlay Favorite Button
                IconButton(
                    onClick = onFavoriteToggle,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .size(36.dp)
                        .testTag("media_fav_btn_${mediaItem.id}")
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .background(Color.Black.copy(alpha = 0.45f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Toggle device favorite indicator",
                            tint = if (isFavorite) Color.Red else Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Text info layout
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = mediaItem.displayName,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                // Type-specific subtitle metadata rows (Artist / Album / Dimensions info)
                val extraText = when (mediaItem) {
                    is AudioItem -> "${mediaItem.artist ?: "Unknown Artist"} • ${mediaItem.album ?: "Unknown Album"}"
                    is VideoItem -> "${mediaItem.width}x${mediaItem.height}"
                    is ImageItem -> "${mediaItem.width}x${mediaItem.height}"
                }

                Text(
                    text = extraText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = formattedSize,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f)
                    )

                    // Display Duration label if applicable
                    val durationMs = when (mediaItem) {
                        is VideoItem -> mediaItem.duration
                        is AudioItem -> mediaItem.duration
                        else -> 0L
                    }

                    if (durationMs > 0L) {
                        Text(
                            text = formatDuration(durationMs),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                    } else {
                        Text(
                            text = when(mediaItem) {
                                is ImageItem -> "Image"
                                else -> ""
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Standard bytes formater helper function.
 */
private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.toDouble())).toInt()
    return String.format("%.1f %s", bytes / Math.pow(1024.toDouble(), digitGroups.toDouble()), units[digitGroups])
}

/**
 * Milliseconds duration formatting.
 */
private fun formatDuration(ms: Long): String {
    val seconds = ms / 1000
    val secs = seconds % 60
    val mins = seconds / 60
    return String.format("%02d:%02d", mins, secs)
}

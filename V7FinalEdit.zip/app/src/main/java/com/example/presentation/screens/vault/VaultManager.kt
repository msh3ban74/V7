package com.example.presentation.screens.vault

import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.model.AudioItem
import com.example.domain.model.ImageItem
import com.example.domain.model.LocalMediaItem
import com.example.domain.model.VideoItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

private val Context.vaultDataStore by preferencesDataStore("vault_metadata_prefs_v2")

/**
 * Secure VaultManager — performs REAL physical file movement to the app-private directory.
 * All File I/O is strictly enclosed in Dispatchers.IO with try/catch safety blocks.
 * Items are physically streamed to `filesDir/v7_secure_vault`, deleted from public storage
 * and MediaStore, then reversed on restore.
 */
class VaultManager(private val context: Context) {

    private val VAULT_META_KEY = stringPreferencesKey("vault_metadata_v2")
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val vaultDir: File
        get() = File(context.filesDir, "v7_secure_vault").also { it.mkdirs() }

    // Reactive list of all currently vaulted item metadata
    private val _vaultedItems = MutableStateFlow<List<VaultedItemMetadata>>(emptyList())
    val vaultedItems: Flow<List<VaultedItemMetadata>> = _vaultedItems.asStateFlow()

    // Legacy compat: Set<Long> of vaulted IDs used by VaultRepository filter
    val vaultedIds: Flow<Set<Long>> = context.vaultDataStore.data.map { prefs ->
        parseMetadataList(prefs[VAULT_META_KEY] ?: "[]").map { it.id }.toSet()
    }

    init {
        // Load persisted metadata into memory on construction
        scope.launch {
            context.vaultDataStore.data.collect { prefs ->
                _vaultedItems.value = parseMetadataList(prefs[VAULT_META_KEY] ?: "[]")
            }
        }
    }

    // ─── Public API ───────────────────────────────────────────────────────────────

    /**
     * Physically moves [item] into the private vault directory.
     * Streams file bytes, persists metadata, deletes from MediaStore, deletes source file.
     * Must be called from a coroutine — wraps all I/O in Dispatchers.IO.
     */
    suspend fun vaultMedia(item: LocalMediaItem): Boolean = withContext(Dispatchers.IO) {
        try {
            val sourceFile = File(item.path)
            if (!sourceFile.exists()) return@withContext false

            val safeVaultFileName = "${item.id}_${sourceFile.name}"
            val vaultFile = File(vaultDir, safeVaultFileName)

            // Stream-copy bytes to vault
            sourceFile.inputStream().buffered().use { input ->
                vaultFile.outputStream().buffered().use { output ->
                    input.copyTo(output)
                }
            }

            // Persist metadata so we can restore later
            val meta = buildMetadata(item, vaultFile.absolutePath)
            persistMetadata(meta, add = true)
            _vaultedItems.value = _vaultedItems.value
                .filterNot { it.id == meta.id } + meta

            // Remove from MediaStore (non-fatal if it fails)
            try {
                context.contentResolver.delete(item.uri, null, null)
            } catch (ignored: Exception) { }

            // Physically delete the source from public storage
            sourceFile.delete()

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Legacy overload used by [VaultActionController] when only the ID is available.
     * Does NOT perform physical file movement (no [LocalMediaItem] provided).
     */
    suspend fun vaultMedia(id: Long): Unit = withContext(Dispatchers.IO) {
        try {
            context.vaultDataStore.edit { prefs ->
                val list = parseMetadataList(prefs[VAULT_META_KEY] ?: "[]").toMutableList()
                if (list.none { it.id == id }) {
                    list.add(
                        VaultedItemMetadata(
                            id = id, displayName = "media_$id", mimeType = "*/*",
                            mediaType = "video", size = 0L, dateAdded = 0L,
                            originalPath = "", vaultFilePath = ""
                        )
                    )
                    prefs[VAULT_META_KEY] = serializeMetadataList(list)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        Unit
    }

    /**
     * Physically restores a vaulted item back to public external storage.
     * Streams bytes back, re-scans via MediaScannerConnection, deletes vault copy.
     */
    suspend fun restoreMedia(id: Long): Boolean = withContext(Dispatchers.IO) {
        try {
            val rawJson = context.vaultDataStore.data
                .map { it[VAULT_META_KEY] ?: "[]" }
                .first()
            val meta = parseMetadataList(rawJson).find { it.id == id }
                ?: return@withContext false

            val vaultFile = File(meta.vaultFilePath)
            if (!vaultFile.exists()) {
                // Vault file is missing — clean up orphaned metadata and exit
                persistMetadata(meta, add = false)
                _vaultedItems.value = _vaultedItems.value.filterNot { it.id == id }
                return@withContext false
            }

            // Determine best restore destination
            val originalParent = if (meta.originalPath.isNotEmpty()) {
                File(meta.originalPath).parentFile
            } else null

            val restoreDir: File = when {
                originalParent != null && originalParent.exists() && originalParent.canWrite() ->
                    originalParent
                meta.mediaType == "image" ->
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                meta.mediaType == "video" ->
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
                else ->
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
            }
            restoreDir.mkdirs()

            // Strip the id prefix we prepended when vaulting
            val originalFileName = vaultFile.name.replaceFirst("${id}_", "")
            val restoredFile = File(restoreDir, originalFileName)

            // Stream-copy bytes back to public storage
            vaultFile.inputStream().buffered().use { input ->
                restoredFile.outputStream().buffered().use { output ->
                    input.copyTo(output)
                }
            }

            // Re-index restored file in MediaStore
            MediaScannerConnection.scanFile(
                context,
                arrayOf(restoredFile.absolutePath),
                arrayOf(meta.mimeType),
                null
            )

            // Delete vault copy
            vaultFile.delete()

            // Remove from persisted metadata
            persistMetadata(meta, add = false)
            _vaultedItems.value = _vaultedItems.value.filterNot { it.id == id }

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Converts current in-memory vault metadata into typed [LocalMediaItem] instances
     * using file:// URIs pointing to the physical vault files.
     */
    fun getVaultedItemsAsLocalMedia(): List<LocalMediaItem> =
        _vaultedItems.value.mapNotNull { meta ->
            val vaultFile = File(meta.vaultFilePath)
            val uri: Uri = if (meta.vaultFilePath.isNotEmpty() && vaultFile.exists()) {
                Uri.fromFile(vaultFile)
            } else {
                return@mapNotNull null
            }
            try {
                when (meta.mediaType) {
                    "video" -> VideoItem(
                        id = meta.id, displayName = meta.displayName, uri = uri,
                        path = meta.vaultFilePath, size = meta.size, mimeType = meta.mimeType,
                        dateAdded = meta.dateAdded, duration = meta.duration,
                        width = meta.width, height = meta.height
                    )
                    "image" -> ImageItem(
                        id = meta.id, displayName = meta.displayName, uri = uri,
                        path = meta.vaultFilePath, size = meta.size, mimeType = meta.mimeType,
                        dateAdded = meta.dateAdded, width = meta.width, height = meta.height
                    )
                    "audio" -> AudioItem(
                        id = meta.id, displayName = meta.displayName, uri = uri,
                        path = meta.vaultFilePath, size = meta.size, mimeType = meta.mimeType,
                        dateAdded = meta.dateAdded, duration = meta.duration,
                        artist = meta.artist, album = meta.album
                    )
                    else -> null
                }
            } catch (e: Exception) { null }
        }

    // ─── Metadata persistence helpers ─────────────────────────────────────────────

    private fun buildMetadata(item: LocalMediaItem, vaultFilePath: String): VaultedItemMetadata =
        when (item) {
            is VideoItem -> VaultedItemMetadata(
                id = item.id, displayName = item.displayName, mimeType = item.mimeType,
                mediaType = "video", size = item.size, dateAdded = item.dateAdded,
                originalPath = item.path, vaultFilePath = vaultFilePath,
                width = item.width, height = item.height, duration = item.duration
            )
            is ImageItem -> VaultedItemMetadata(
                id = item.id, displayName = item.displayName, mimeType = item.mimeType,
                mediaType = "image", size = item.size, dateAdded = item.dateAdded,
                originalPath = item.path, vaultFilePath = vaultFilePath,
                width = item.width, height = item.height
            )
            is AudioItem -> VaultedItemMetadata(
                id = item.id, displayName = item.displayName, mimeType = item.mimeType,
                mediaType = "audio", size = item.size, dateAdded = item.dateAdded,
                originalPath = item.path, vaultFilePath = vaultFilePath,
                duration = item.duration, artist = item.artist, album = item.album
            )
            else -> VaultedItemMetadata(
                id = item.id, displayName = item.displayName, mimeType = item.mimeType,
                mediaType = "video", size = item.size, dateAdded = item.dateAdded,
                originalPath = item.path, vaultFilePath = vaultFilePath
            )
        }

    private suspend fun persistMetadata(meta: VaultedItemMetadata, add: Boolean) {
        context.vaultDataStore.edit { prefs ->
            val list = parseMetadataList(prefs[VAULT_META_KEY] ?: "[]").toMutableList()
            list.removeAll { it.id == meta.id }
            if (add) list.add(meta)
            prefs[VAULT_META_KEY] = serializeMetadataList(list)
        }
    }

    private fun parseMetadataList(json: String): List<VaultedItemMetadata> =
        try {
            val arr = JSONArray(json)
            (0 until arr.length()).mapNotNull { i ->
                try {
                    val obj = arr.getJSONObject(i)
                    VaultedItemMetadata(
                        id = obj.getLong("id"),
                        displayName = obj.optString("displayName", "media"),
                        mimeType = obj.optString("mimeType", "*/*"),
                        mediaType = obj.optString("mediaType", "video"),
                        size = obj.optLong("size", 0L),
                        dateAdded = obj.optLong("dateAdded", 0L),
                        originalPath = obj.optString("originalPath", ""),
                        vaultFilePath = obj.optString("vaultFilePath", ""),
                        width = obj.optInt("width", 0),
                        height = obj.optInt("height", 0),
                        duration = obj.optLong("duration", 0L),
                        artist = obj.optString("artist", "").takeIf { it.isNotEmpty() },
                        album = obj.optString("album", "").takeIf { it.isNotEmpty() }
                    )
                } catch (e: Exception) { null }
            }
        } catch (e: Exception) { emptyList() }

    private fun serializeMetadataList(list: List<VaultedItemMetadata>): String {
        val arr = JSONArray()
        list.forEach { meta ->
            arr.put(JSONObject().apply {
                put("id", meta.id)
                put("displayName", meta.displayName)
                put("mimeType", meta.mimeType)
                put("mediaType", meta.mediaType)
                put("size", meta.size)
                put("dateAdded", meta.dateAdded)
                put("originalPath", meta.originalPath)
                put("vaultFilePath", meta.vaultFilePath)
                put("width", meta.width)
                put("height", meta.height)
                put("duration", meta.duration)
                put("artist", meta.artist ?: "")
                put("album", meta.album ?: "")
            })
        }
        return arr.toString()
    }
}

data class VaultedItemMetadata(
    val id: Long,
    val displayName: String,
    val mimeType: String,
    val mediaType: String,     // "video" | "image" | "audio"
    val size: Long,
    val dateAdded: Long,
    val originalPath: String,
    val vaultFilePath: String,
    val width: Int = 0,
    val height: Int = 0,
    val duration: Long = 0L,
    val artist: String? = null,
    val album: String? = null
)

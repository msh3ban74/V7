package com.example.presentation.stability

import android.util.Log

object StabilityManager {
    fun safeRun(tag: String, action: () -> Unit) {
        try {
            action()
        } catch (e: Exception) {
            Log.e(tag, "Safely handled exception: ${e.localizedMessage}", e)
        }
    }

    suspend fun safeSuspendRun(tag: String, action: suspend () -> Unit) {
        try {
            action()
        } catch (e: Exception) {
            Log.e(tag, "Safely handled suspend exception: ${e.localizedMessage}", e)
        }
    }
}

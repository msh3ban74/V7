package com.example.presentation.screens.player.media3

import android.app.Activity
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

/**
 * Highly immersive, fully production-ready Media3 Video Player Composable.
 * Features customizable overlay styles, double-tap seek overlays, and volume/brightness HUD indicators.
 */
@OptIn(UnstableApi::class)
@Composable
fun VideoPlayerComposable(
    controller: PlayerController,
    modifier: Modifier = Modifier,
    isReelsMode: Boolean = false,
    isActivePage: Boolean = true,
    onBackClick: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val activity = context as? Activity

    val pState by controller.playbackState.collectAsState()
    val controlsVisible by controller.controlsVisible.collectAsState()
    val speedSelected by controller.currentSpeed.collectAsState()

    var isSpeedMenuExpanded by remember { mutableStateOf(false) }

    var showDoubleTapSeekLeftHUD by remember { mutableStateOf(false) }
    var showDoubleTapSeekRightHUD by remember { mutableStateOf(false) }
    
    val isSystemLandscape = activity?.resources?.configuration?.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    
    com.example.presentation.stability.LifecycleCleanupController(
        onPause = { controller.media3Manager.pause() }
    )

    // Keep active player screen on
    DisposableEffect(Unit) {
        activity?.window?.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            activity?.window?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    GestureHandler(
        modifier = modifier
            .testTag("video_player_viewport")
            .background(Color.Black),
        onSingleTap = { controller.toggleControls() },
        onLeftDoubleTap = {
            controller.seekRewind()
            showDoubleTapSeekLeftHUD = true
        },
        onRightDoubleTap = {
            controller.seekForward()
            showDoubleTapSeekRightHUD = true
        }
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Raw Android Player Layer
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        if (isActivePage) {
                            player = controller.media3Manager.getPlayer()
                        }
                        useController = false
                        resizeMode = if (isReelsMode) {
                            AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                        } else {
                            AspectRatioFrameLayout.RESIZE_MODE_FIT
                        }
                    }
                },
                update = { pv ->
                    if (isActivePage) {
                        if (pv.player != controller.media3Manager.getPlayer()) {
                            pv.player = controller.media3Manager.getPlayer()
                        }
                    } else {
                        if (pv.player != null) {
                            pv.player = null
                        }
                    }
                    pv.resizeMode = if (isReelsMode) {
                        AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    } else {
                        AspectRatioFrameLayout.RESIZE_MODE_FIT
                    }
                },
                onRelease = { pv ->
                    pv.player = null
                },
                modifier = Modifier.fillMaxSize()
            )

            // Buffering progress loader
            if (pState.isBuffering) {
                CircularProgressIndicator(
                    modifier = Modifier
                        .size(56.dp)
                        .align(Alignment.Center)
                        .testTag("player_loading_indicator"),
                    color = MaterialTheme.colorScheme.primary
                )
            }

            // HUD notification: Double-Tap Rewind (Left)
            LaunchedEffect(showDoubleTapSeekLeftHUD) {
                if (showDoubleTapSeekLeftHUD) {
                    delay(850)
                    showDoubleTapSeekLeftHUD = false
                }
            }
            AnimatedVisibility(
                visible = showDoubleTapSeekLeftHUD,
                enter = fadeIn() + scaleIn(),
                exit = fadeOut() + scaleOut(),
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 32.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color.Black.copy(alpha = 0.65f),
                    contentColor = Color.White
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.FastRewind, contentDescription = "Rewind", modifier = Modifier.size(32.dp))
                        Text("-10s", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // HUD notification: Double-Tap Forward (Right)
            LaunchedEffect(showDoubleTapSeekRightHUD) {
                if (showDoubleTapSeekRightHUD) {
                    delay(850)
                    showDoubleTapSeekRightHUD = false
                }
            }
            AnimatedVisibility(
                visible = showDoubleTapSeekRightHUD,
                enter = fadeIn() + scaleIn(),
                exit = fadeOut() + scaleOut(),
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 32.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color.Black.copy(alpha = 0.65f),
                    contentColor = Color.White
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.FastForward, contentDescription = "Forward", modifier = Modifier.size(32.dp))
                        Text("+10s", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Immersive Custom UI Control Overplays Layer
            AnimatedVisibility(
                visible = controlsVisible,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.45f))
                ) {
                    // Header Area (Back and Settings options)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopCenter)
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (onBackClick != null) {
                                IconButton(
                                    onClick = onBackClick,
                                    modifier = Modifier.testTag("player_back_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                        contentDescription = "Back",
                                        tint = Color.White
                                    )
                                }
                            }
                            Text(
                                text = pState.currentItem?.title ?: "Media Player",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 8.dp)
                            )
                        }

                        // Settings and Playback Speed Popup controls
                        Box {
                            IconButton(
                                onClick = { isSpeedMenuExpanded = true },
                                modifier = Modifier.testTag("speed_settings_button")
                            ) {
                                Icon(Icons.Default.Settings, contentDescription = "Playback Speed Options", tint = Color.White)
                            }

                            DropdownMenu(
                                expanded = isSpeedMenuExpanded,
                                onDismissRequest = { isSpeedMenuExpanded = false }
                            ) {
                                val speedOptions = listOf(0.5f, 1.0f, 1.5f, 2.0f)
                                speedOptions.forEach { speed ->
                                    DropdownMenuItem(
                                        text = { Text("${speed}x" + if (speedSelected == speed) " ✓" else "") },
                                        onClick = {
                                            controller.setPlaybackSpeed(speed)
                                            isSpeedMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Centered Play / Pause Toggle Circle
                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.6f))
                            .clickable {
                                if (pState.isPlaying) {
                                    controller.media3Manager.pause()
                                } else {
                                    controller.media3Manager.resume()
                                }
                                controller.showControlsTemporarily()
                            }
                            .align(Alignment.Center)
                            .testTag("center_play_pause_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (pState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (pState.isPlaying) "Pause" else "Play",
                            tint = Color.White,
                            modifier = Modifier.size(42.dp)
                        )
                    }

                    // Bottom controls (Progress slider timeline & Fullscreen toggler)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .padding(horizontal = 24.dp, vertical = 24.dp)
                    ) {
                        // Progress Slider
                        val sliderValue = if (pState.duration > 0f) {
                            pState.currentPosition.toFloat() / pState.duration.toFloat()
                        } else {
                            0f
                        }

                        Slider(
                            value = sliderValue,
                            onValueChange = { fraction ->
                                val positionMs = (fraction * pState.duration).toLong()
                                controller.media3Manager.seekTo(positionMs)
                                controller.showControlsTemporarily()
                            },
                            colors = SliderDefaults.colors(
                                thumbColor = MaterialTheme.colorScheme.primary,
                                activeTrackColor = MaterialTheme.colorScheme.primary,
                                inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("player_immersive_slider")
                        )

                        // Duration Labels and Fullscreen toggle Action Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = formatTime(pState.currentPosition) + " / " + formatTime(pState.duration),
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )

                            // Programmatic screen auto-rotation switch
                            IconButton(
                                onClick = {
                                    activity?.let { act ->
                                        val nextOrientation = if (isSystemLandscape) {
                                            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                        } else {
                                            ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                        }
                                        act.requestedOrientation = nextOrientation
                                    }
                                    controller.showControlsTemporarily()
                                },
                                modifier = Modifier.testTag("orientation_pivot_button")
                            ) {
                                Icon(
                                    imageVector = if (isSystemLandscape) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                                    contentDescription = "Rotate Screen Toggle",
                                    tint = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Format milliseconds to standard classic duration string (e.g. 02:45).
 */
private fun formatTime(ms: Long): String {
    val totalSeconds = ms / 1000
    val secs = totalSeconds % 60
    val mins = totalSeconds / 60
    return String.format("%02d:%02d", mins, secs)
}

package com.example.presentation.screens.vault

import android.widget.Toast
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.fragment.app.FragmentActivity

@Composable
fun VaultLockScreen(
    securityManager: VaultSecurityManager,
    onUnlocked: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showPinFallback by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (BiometricHelper.isBiometricAvailable(context)) {
            val activity = context as? FragmentActivity
            if (activity != null) {
                BiometricHelper.showBiometricPrompt(
                    activity = activity,
                    onSuccess = {
                        securityManager.unlock()
                        onUnlocked()
                    },
                    onError = {
                        securityManager.recordFailedAttempt()
                        Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
                        showPinFallback = true
                    }
                )
            } else {
                showPinFallback = true
            }
        } else {
            showPinFallback = true
        }
    }

    if (showPinFallback) {
        PinLockComposable(
            onUnlockSuccess = {
                securityManager.unlock()
                onUnlocked()
            },
            onUnlockFailed = {
                securityManager.recordFailedAttempt()
                Toast.makeText(context, "Invalid PIN", Toast.LENGTH_SHORT).show()
            },
            modifier = modifier
        )
    } else {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Button(onClick = { showPinFallback = true }) {
                Text("Use PIN")
            }
        }
    }
}

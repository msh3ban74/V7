package com.example.presentation.components.polish

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

object UIConsistencyManager {
    val PremiumCardShape = RoundedCornerShape(16.dp)
    val PremiumDialogShape = RoundedCornerShape(24.dp)
    val PremiumButtonShape = RoundedCornerShape(50) // Pill shape
}

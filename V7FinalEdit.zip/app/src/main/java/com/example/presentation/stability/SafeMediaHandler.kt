package com.example.presentation.stability

import android.content.ContentResolver
import android.net.Uri
import android.util.Log

class SafeMediaHandler {
    fun safeDeleteProvider(contentResolver: ContentResolver, uri: Uri): Boolean {
        return try {
            val deletedRows = contentResolver.delete(uri, null, null)
            deletedRows > 0
        } catch (e: SecurityException) {
            Log.e("SafeMediaHandler", "SecurityException during explicit delete: ${e.message}")
            false
        } catch (e: Exception) {
            Log.e("SafeMediaHandler", "General Exception during delete: ${e.message}")
            false
        }
    }
}

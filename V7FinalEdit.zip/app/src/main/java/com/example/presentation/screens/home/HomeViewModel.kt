package com.example.presentation.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import com.example.presentation.screens.watchhistory.WatchHistoryEntity
import com.example.presentation.screens.watchhistory.WatchHistoryRepository
import com.example.presentation.screens.watchhistory.ContinueWatchingManager

/**
 * Clean Architecture MVVM ViewModel for the HomeScreen.
 * Exposes UI states reactively to prevent memory leaks and handle system configurations.
 */
class HomeViewModel(
    private val watchHistoryRepository: WatchHistoryRepository
) : ViewModel() {

    private val continueWatchingManager = ContinueWatchingManager(watchHistoryRepository)

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    // Expose continue watching items
    val continueWatchingItems: StateFlow<List<WatchHistoryEntity>> = continueWatchingManager.continueWatchingList
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
        
    val recentHistoryItems: StateFlow<List<WatchHistoryEntity>> = watchHistoryRepository.watchHistory
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun clearHistory() {
        viewModelScope.launch {
            watchHistoryRepository.clearHistory()
        }
    }

    fun refreshDashboard() {
        viewModelScope.launch {
            _isRefreshing.value = true
            // Simulate light network fetch
            _isRefreshing.value = false
        }
    }
}

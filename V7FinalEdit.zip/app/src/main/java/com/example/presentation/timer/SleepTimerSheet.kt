package com.example.presentation.timer

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SleepTimerSheet(
    sleepTimerManager: SleepTimerManager,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isTimerActive by sleepTimerManager.isTimerActive.collectAsState()
    val remainingTime by sleepTimerManager.remainingTimeMillis.collectAsState()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState()
    ) {
        Column(
            modifier = modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                "Sleep Timer",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            if (isTimerActive) {
                CountdownTimerComposable(remainingTimeMillis = remainingTime)
                
                Button(
                    onClick = { sleepTimerManager.stopTimer() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Cancel Timer")
                }
            } else {
                Text(
                    "Stop playback automatically after:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    TimerPresetButton(minutes = 5, onClick = { sleepTimerManager.startTimer(5) })
                    TimerPresetButton(minutes = 10, onClick = { sleepTimerManager.startTimer(10) })
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    TimerPresetButton(minutes = 30, onClick = { sleepTimerManager.startTimer(30) })
                    TimerPresetButton(minutes = 60, onClick = { sleepTimerManager.startTimer(60) })
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun TimerPresetButton(minutes: Int, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier.width(120.dp)
    ) {
        Text("$minutes min")
    }
}

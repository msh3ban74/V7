package com.example.presentation.screens.watchhistory

data class WatchHistoryState(
    val recentHistory: List<WatchHistoryEntity> = emptyList(),
    val favorites: List<com.example.presentation.screens.favorites.FavoriteEntity> = emptyList()
)

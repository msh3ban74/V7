package com.example.presentation.components.polish

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

@Composable
fun CinematicOverlayComposable(
    modifier: Modifier = Modifier,
    alpha: Float = 0.6f
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color.Transparent,
                        Color.Black.copy(alpha = alpha * 0.5f),
                        Color.Black.copy(alpha = alpha)
                    ),
                    startY = 0f
                )
            )
    )
}

package com.example.presentation.components.polish

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.domain.model.LocalMediaItem
import com.example.domain.model.VideoItem
import com.example.presentation.screens.gallery.components.MediaThumbnailLoader

@androidx.compose.foundation.ExperimentalFoundationApi
@Composable
fun PremiumMediaCard(
    mediaItem: LocalMediaItem,
    isFavorite: Boolean,
    isScrolling: Boolean,
    onCardClick: () -> Unit,
    onCardLongClick: (() -> Unit)? = null,
    isSelected: Boolean = false,
    modifier: Modifier = Modifier
) {
    GestureFeedbackComposable(
        onClick = onCardClick,
        onLongClick = onCardLongClick,
        modifier = modifier
    ) {
        Card(
            shape = UIConsistencyManager.PremiumCardShape,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            elevation = CardDefaults.cardElevation(defaultElevation = PremiumSpacingSystem.Tiny)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .aspectRatio(1f)
            ) {
                MediaThumbnailLoader(
                    mediaItem = mediaItem,
                    isScrolling = isScrolling,
                    modifier = Modifier.fillMaxSize()
                )
                CinematicOverlayComposable(alpha = 0.3f)

                if (isSelected) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
                    )
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Selected",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                            .size(24.dp)
                    )
                }

                if (mediaItem is VideoItem) {
                    Icon(
                        imageVector = Icons.Default.PlayCircleOutline,
                        contentDescription = "Play Video",
                        tint = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(PremiumSpacingSystem.IconSizeLarge)
                    )
                }

                AnimatedVisibilityController(
                    visible = isFavorite,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(PremiumSpacingSystem.Small)
                ) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = "Favorite",
                        tint = Color.Red,
                        modifier = Modifier.size(PremiumSpacingSystem.IconSizeSmall)
                    )
                }
            }
        }
    }
}

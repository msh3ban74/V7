package com.example.presentation.security

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class SessionState(
    val isAppLocked: Boolean = false,
    val lastActiveTime: Long = System.currentTimeMillis()
)

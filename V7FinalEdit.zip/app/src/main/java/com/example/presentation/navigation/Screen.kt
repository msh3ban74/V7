package com.example.presentation.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Lock
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Representation of App Screens in V7 Bottom Navigation structure.
 * Houses route strings, titles (M3 standard labels), and corresponding Material Symbols.
 */
sealed class Screen(
    val route: String,
    val title: String,
    val icon: ImageVector
) {
    object Player : Screen(
        route = "player",
        title = "Player",
        icon = Icons.Filled.PlayArrow
    )

    object Videos : Screen(
        route = "videos",
        title = "Videos",
        icon = Icons.Filled.Movie
    )

    object Music : Screen(
        route = "music",
        title = "Music",
        icon = Icons.Filled.LibraryMusic
    )

    object Gallery : Screen(
        route = "gallery",
        title = "Gallery",
        icon = Icons.Filled.PhotoLibrary
    )

    object Vault : Screen(
        route = "vault",
        title = "Vault",
        icon = Icons.Filled.Lock
    )

    object Favorites : Screen(
        route = "favorites",
        title = "Favorites",
        icon = androidx.compose.material.icons.Icons.Filled.Favorite
    )

    object Settings : Screen(
        route = "settings",
        title = "Settings",
        icon = Icons.Filled.Settings
    )

    companion object {
        val bottomNavItems = listOf(Videos, Music, Gallery, Vault, Favorites, Settings)
    }
}

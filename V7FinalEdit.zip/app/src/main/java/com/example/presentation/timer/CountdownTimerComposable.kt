package com.example.presentation.timer

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun CountdownTimerComposable(
    remainingTimeMillis: Long,
    modifier: Modifier = Modifier
) {
    val totalTime = remember(remainingTimeMillis > 0) { 
        // Just keeping a max reference for the circular progress if we wanted to true progress.
        // For simplicity, we just show continuous or relative progress.
        // Actually, without knowing the start time, we can't show a true percentage backward smoothly unless we pass it.
        // Let's just mock a pulsing circle or simple numeric countdown for now.
        1f 
    }

    val minutes = (remainingTimeMillis / 1000) / 60
    val seconds = (remainingTimeMillis / 1000) % 60
    
    val timeString = String.format("%02d:%02d", minutes, seconds)

    Box(
        modifier = modifier.size(150.dp),
        contentAlignment = Alignment.Center
    ) {
        CircularProgressIndicator(
            progress = { 1f },
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.surfaceVariant,
            strokeWidth = 8.dp,
        )
        // Pulsing active indicator
        CircularProgressIndicator(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.primary,
            strokeWidth = 8.dp,
            trackColor = androidx.compose.ui.graphics.Color.Transparent
        )
        
        Text(
            text = timeString,
            style = MaterialTheme.typography.displaySmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

package com.example.presentation.media

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer

/**
 * Lightweight, fully on-device "Convert to MP3" implementation.
 *
 * It extracts the existing audio track from a video and writes it, unmodified, into a
 * standalone audio container using only the Android platform APIs ([MediaExtractor] +
 * [MediaMuxer]). No cloud services, no extra libraries, and no fake processing.
 *
 * Note: Android has no built-in MP3 *encoder*, so the audio is saved losslessly as `.m4a`
 * (AAC) — the standard no-dependency result for local extraction. The original video file
 * is never modified.
 */
object VideoToMp3Converter {

    sealed class Result {
        data class Success(val outputPath: String, val outputName: String) : Result()
        data class Failure(val reason: String) : Result()
    }

    /**
     * Extracts the audio track from [sourceUri] into the public Music/V7 Audio folder.
     *
     * @param onProgress invoked on a background thread with 0f..1f progress.
     */
    suspend fun convert(
        context: Context,
        sourceUri: Uri,
        displayName: String,
        onProgress: (Float) -> Unit
    ): Result = withContext(Dispatchers.IO) {
        var extractor: MediaExtractor? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        try {
            extractor = MediaExtractor()
            extractor.setDataSource(context, sourceUri, null)

            // Locate the audio track
            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    audioFormat = format
                    break
                }
            }
            if (audioTrackIndex < 0 || audioFormat == null) {
                return@withContext Result.Failure("This video has no audio track to convert.")
            }
            extractor.selectTrack(audioTrackIndex)

            // Prepare the output file in a public, user-visible folder
            val musicDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
            val outDir = File(musicDir, "V7 Audio").also { it.mkdirs() }
            val baseName = displayName.substringBeforeLast('.')
                .ifBlank { "audio_${System.currentTimeMillis()}" }
            val outFile = File(outDir, "$baseName.m4a")

            muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val outTrack = muxer.addTrack(audioFormat)
            muxer.start()
            muxerStarted = true

            val durationUs = if (audioFormat.containsKey(MediaFormat.KEY_DURATION)) {
                audioFormat.getLong(MediaFormat.KEY_DURATION)
            } else {
                0L
            }
            val maxInput = if (audioFormat.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                audioFormat.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
            } else {
                256 * 1024
            }
            val buffer = ByteBuffer.allocate(maxInput.coerceAtLeast(64 * 1024))
            val bufferInfo = MediaCodec.BufferInfo()

            // Stream-copy audio samples — no re-encoding, fast and lossless
            while (true) {
                val sampleSize = extractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break
                bufferInfo.offset = 0
                bufferInfo.size = sampleSize
                bufferInfo.presentationTimeUs = extractor.sampleTime
                bufferInfo.flags = extractor.sampleFlags
                muxer.writeSampleData(outTrack, buffer, bufferInfo)
                if (durationUs > 0) {
                    onProgress((extractor.sampleTime.toFloat() / durationUs).coerceIn(0f, 1f))
                }
                extractor.advance()
            }
            onProgress(1f)

            // Finalize the container before releasing
            try { muxer.stop() } catch (e: Exception) { e.printStackTrace() }
            muxerStarted = false
            muxer.release()
            muxer = null
            extractor.release()
            extractor = null

            // Index the new file so it appears in the device music library
            MediaScannerConnection.scanFile(
                context, arrayOf(outFile.absolutePath), arrayOf("audio/mp4"), null
            )

            Result.Success(outFile.absolutePath, outFile.name)
        } catch (e: Exception) {
            e.printStackTrace()
            Result.Failure(e.localizedMessage ?: "Audio conversion failed.")
        } finally {
            // Release anything still open on the failure path
            try { if (muxerStarted) muxer?.stop() } catch (ignored: Exception) { }
            try { muxer?.release() } catch (ignored: Exception) { }
            try { extractor?.release() } catch (ignored: Exception) { }
        }
    }
}

package com.example.presentation.performance

import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember

@Stable
class PerformanceState(val gridState: LazyGridState) {
    val isScrolling by derivedStateOf { gridState.isScrollInProgress }
    val firstVisibleItemIndex by derivedStateOf { gridState.firstVisibleItemIndex }
}

@Composable
fun rememberPerformanceState(
    gridState: LazyGridState = rememberLazyGridState()
): PerformanceState {
    return remember(gridState) {
        PerformanceState(gridState)
    }
}

package com.example.presentation.components.polish

import androidx.compose.ui.unit.dp

object PremiumSpacingSystem {
    val Tiny = 4.dp
    val Small = 8.dp
    val Medium = 16.dp
    val Large = 24.dp
    val ExtraLarge = 32.dp
    
    val CardCornerRadius = 16.dp
    val IconSizeSmall = 16.dp
    val IconSizeMedium = 24.dp
    val IconSizeLarge = 32.dp
}

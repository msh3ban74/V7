package com.example.presentation.immersive

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import kotlinx.coroutines.delay

/**
 * Controller to handle full immersive playback gestures, visibility shifts, and automated timeout behavior.
 */
class ImmersiveController(
    private val autoHideTimeoutMs: Long = 3000L
) {
    private val _visible = mutableStateOf(true)
    val visible: State<Boolean> = _visible

    private val _lastInteractionTime = mutableStateOf(System.currentTimeMillis())

    /**
     * Toggles the control overlay visibility.
     */
    fun toggleVisibility() {
        _visible.value = !_visible.value
        if (_visible.value) {
            resetTimeout()
        }
    }

    /**
     * Shows the control overlays and restarts the auto-hide countdown.
     */
    fun show() {
        _visible.value = true
        resetTimeout()
    }

    /**
     * Instantly hides the controls.
     */
    fun hide() {
        _visible.value = false
    }

    /**
     * Notifies user interaction, resetting the auto-hide timer.
     */
    fun resetTimeout() {
        _lastInteractionTime.value = System.currentTimeMillis()
    }

    /**
     * Background effect watcher to enforce timeout controls.
     */
    @Composable
    fun KeepAlive() {
        val lastInteraction = _lastInteractionTime.value
        val isCurrentlyVisible = _visible.value
        LaunchedEffect(lastInteraction, isCurrentlyVisible) {
            if (isCurrentlyVisible) {
                delay(autoHideTimeoutMs)
                _visible.value = false
            }
        }
    }
}

/**
 * Creates and remembers a standard [ImmersiveController].
 */
@Composable
fun rememberImmersiveController(
    autoHideTimeoutMs: Long = 3000L
): ImmersiveController {
    val controller = remember { ImmersiveController(autoHideTimeoutMs) }
    controller.KeepAlive()
    return controller
}

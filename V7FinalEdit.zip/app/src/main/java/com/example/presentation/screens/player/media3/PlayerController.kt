package com.example.presentation.screens.player.media3

import android.app.Activity
import android.content.Context
import android.media.AudioManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Controller ViewModel bridging Jetpack Compose user interactions with Media3 ExoPlayer.
 * Exposes real-time Volume, Brightness, Orientation, and Controls visibility flows.
 */
class PlayerController(
    private val context: Context,
    val media3Manager: Media3Manager
) : ViewModel() {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    // State matching our Media3 session
    val playbackState = media3Manager.playbackState

    // Controls visibility timeout tracking job
    private var controlsHideJob: Job? = null

    // Track chosen playback speed
    private val _currentSpeed = MutableStateFlow(1.0f)
    val currentSpeed = _currentSpeed.asStateFlow()

    // Controls auto-hide visibility state
    private val _controlsVisible = MutableStateFlow(true)
    val controlsVisible = _controlsVisible.asStateFlow()

    init {
        // Automatically link speed updates
        viewModelScope.launch {
            playbackState.collect { state ->
                _currentSpeed.value = state.playbackSpeed
            }
        }
        resetControlsTimer()
    }

    /**
     * Toggles visibility of on-screen player controls.
     */
    fun toggleControls() {
        _controlsVisible.update { !it }
        if (_controlsVisible.value) {
            resetControlsTimer()
        } else {
            controlsHideJob?.cancel()
        }
    }

    /**
     * Shows controls and schedules auto-hiding after 3 seconds of inactivity.
     */
    fun showControlsTemporarily() {
        _controlsVisible.value = true
        resetControlsTimer()
    }

    private fun resetControlsTimer() {
        controlsHideJob?.cancel()
        controlsHideJob = viewModelScope.launch {
            delay(3000)
            _controlsVisible.value = false
        }
    }

    /**
     * Updates and applies system playback speed (0.5x, 1x, 1.5x, 2x).
     */
    fun setPlaybackSpeed(speed: Float) {
        media3Manager.setSpeed(speed.coerceIn(0.5f, 2.0f))
        showControlsTemporarily()
    }

    /**
     * Core Double-Tap Seek forwards/backwards.
     */
    fun seekForward() {
        media3Manager.seekForward(10000L) // seek +10s
        showControlsTemporarily()
    }

    fun seekRewind() {
        media3Manager.seekRewind(10000L) // seek -10s
        showControlsTemporarily()
    }

    /**
     * Public cleanup for when PlayerController is instantiated via [remember] (not viewModel()).
     * Call from DisposableEffect onDispose to cancel coroutine jobs.
     */
    fun cleanup() {
        controlsHideJob?.cancel()
        // Do NOT release media3Manager here — caller manages media3Manager lifecycle separately
    }

    override fun onCleared() {
        super.onCleared()
        controlsHideJob?.cancel()
        media3Manager.release()
    }
}

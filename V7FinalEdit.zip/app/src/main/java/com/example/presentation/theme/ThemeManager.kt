package com.example.presentation.theme

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.themeDataStore by preferencesDataStore(name = "premium_theme_prefs")

class ThemeManager(private val context: Context) {
    companion object {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val DYNAMIC_COLOR = booleanPreferencesKey("dynamic_color")
        val ANIMATIONS = booleanPreferencesKey("animations_enabled")
    }

    val state: Flow<ThemeState> = context.themeDataStore.data.map { prefs ->
        // Handle safe enum casting in case stored theme name is no longer valid (e.g. SYSTEMS or old themes)
        val storedTheme = prefs[THEME_MODE]
        val mode = try {
            if (storedTheme != null) enumValueOf<ThemeMode>(storedTheme) else ThemeMode.TITANIUM_SILVER
        } catch (e: Exception) {
            ThemeMode.TITANIUM_SILVER
        }

        ThemeState(
            themeMode = mode,
            useDynamicColor = prefs[DYNAMIC_COLOR] ?: false,
            animationsEnabled = prefs[ANIMATIONS] ?: true
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.themeDataStore.edit { it[THEME_MODE] = mode.name }
    }

    suspend fun setDynamicColor(enabled: Boolean) {
        context.themeDataStore.edit { it[DYNAMIC_COLOR] = enabled }
    }

    suspend fun setAnimationsEnabled(enabled: Boolean) {
        context.themeDataStore.edit { it[ANIMATIONS] = enabled }
    }
}

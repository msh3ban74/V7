package com.example.presentation.immersive

data class MediaActionState(
    val isFavorite: Boolean = false,
    val inVault: Boolean = false,
    val showInfoPanel: Boolean = false,
    val showDeleteConfirm: Boolean = false,
    val showRenameDialog: Boolean = false
)

package com.example.presentation.screens.music.cast

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.CastConnected
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun CastDevicePickerComposable(
    castManager: CastManager,
    modifier: Modifier = Modifier
) {
    val isCasting by castManager.isCasting.collectAsState()
    val isAvailable by castManager.isCastAvailable.collectAsState()

    if (!isAvailable) return

    var showDialog by remember { mutableStateOf(false) }

    IconButton(
        onClick = { showDialog = true },
        modifier = modifier
    ) {
        Icon(
            imageVector = if (isCasting) Icons.Default.CastConnected else Icons.Default.Cast,
            contentDescription = "Cast Media",
            tint = if (isCasting) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
        )
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Cast to Device") },
            text = {
                Column {
                    Text("Select a device to play your media on:")
                    Spacer(modifier = Modifier.height(16.dp))
                    // Dummy list as proper MR picker requires complex route enumeration
                    ListItem(
                        headlineContent = { Text("Living Room TV") },
                        leadingContent = { Icon(Icons.Default.Cast, null) },
                        modifier = Modifier.clickable { showDialog = false }
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showDialog = false }) { Text("Close") }
            }
        )
    }
}

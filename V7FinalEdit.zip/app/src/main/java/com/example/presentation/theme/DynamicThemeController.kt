package com.example.presentation.theme

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DynamicThemeController(private val manager: ThemeManager, private val scope: CoroutineScope) {
    val state: StateFlow<ThemeState> = manager.state.stateIn(
        scope,
        SharingStarted.WhileSubscribed(5000),
        ThemeState()
    )

    fun updateThemeMode(mode: ThemeMode) { scope.launch { manager.setThemeMode(mode) } }
    fun toggleDynamicColor(enabled: Boolean) { scope.launch { manager.setDynamicColor(enabled) } }
    fun toggleAnimations(enabled: Boolean) { scope.launch { manager.setAnimationsEnabled(enabled) } }
}

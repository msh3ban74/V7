package com.example.presentation.screens.music

import androidx.lifecycle.ViewModel
import com.example.domain.model.AudioItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class SortMode { NEWEST, MOST_PLAYED, FAVORITES, ALPHABETICAL }
enum class FilterMode { ALL, ALBUMS, ARTISTS }

data class MusicLibraryState(
    val songs: List<AudioItem> = emptyList(),
    val recentSongs: List<AudioItem> = emptyList(),
    val favorites: List<AudioItem> = emptyList(),
    val albums: Map<String, List<AudioItem>> = emptyMap(),
    val artists: Map<String, List<AudioItem>> = emptyMap(),
    val searchQuery: String = "",
    val sortMode: SortMode = SortMode.NEWEST,
    val filterMode: FilterMode = FilterMode.ALL
)

class MusicLibraryViewModel : ViewModel() {
    private val _state = MutableStateFlow(MusicLibraryState())
    val state: StateFlow<MusicLibraryState> = _state

    fun updateSongs(items: List<AudioItem>, favIds: Set<Long>) {
        val albumsMap = items.filter { !it.album.isNullOrEmpty() }.groupBy { it.album!! }
        val artistsMap = items.filter { !it.artist.isNullOrEmpty() }.groupBy { it.artist!! }
        val favSongs = items.filter { favIds.contains(it.id) }
        
        _state.value = _state.value.copy(
            songs = applySortAndFilter(items, _state.value.sortMode, _state.value.searchQuery),
            albums = albumsMap,
            artists = artistsMap,
            favorites = favSongs
        )
    }

    fun search(query: String) {
        _state.value = _state.value.copy(searchQuery = query)
    }

    fun setSortMode(mode: SortMode) {
        _state.value = _state.value.copy(sortMode = mode)
    }

    fun setFilterMode(mode: FilterMode) {
        _state.value = _state.value.copy(filterMode = mode)
    }

    private fun applySortAndFilter(items: List<AudioItem>, sortMode: SortMode, query: String): List<AudioItem> {
        val filtered = if (query.isNotEmpty()) {
            items.filter { it.displayName.contains(query, ignoreCase = true) || 
                           (it.artist?.contains(query, ignoreCase = true) == true) }
        } else items

        return when (sortMode) {
            SortMode.NEWEST -> filtered.sortedByDescending { it.dateAdded }
            SortMode.ALPHABETICAL -> filtered.sortedBy { it.displayName }
            else -> filtered // Simplified for this implementation
        }
    }
}

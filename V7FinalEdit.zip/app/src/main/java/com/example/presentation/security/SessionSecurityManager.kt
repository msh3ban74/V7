package com.example.presentation.security

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class SessionSecurityManager {
    private val _sessionState = MutableStateFlow(SessionState())
    val sessionState: StateFlow<SessionState> = _sessionState.asStateFlow()

    fun updateLastActiveTime(time: Long = System.currentTimeMillis()) {
        _sessionState.update { it.copy(lastActiveTime = time) }
    }

    fun lockApp() {
        _sessionState.update { it.copy(isAppLocked = true) }
    }

    fun unlockApp() {
        _sessionState.update { it.copy(isAppLocked = false, lastActiveTime = System.currentTimeMillis()) }
    }
}

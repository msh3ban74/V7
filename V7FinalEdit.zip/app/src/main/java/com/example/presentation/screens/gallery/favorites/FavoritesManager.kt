package com.example.presentation.screens.gallery.favorites

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Handles persistent storage and reactive update states for favorited media items.
 * Uses lightweight SharedPreferences to persist favorited media keys.
 */
class FavoritesManager(context: Context) {

    private val sharedPrefs: SharedPreferences = context.getSharedPreferences(
        "v7_media_favorites_prefs",
        Context.MODE_PRIVATE
    )

    private val _state = MutableStateFlow(FavoritesState())
    val state: StateFlow<FavoritesState> = _state.asStateFlow()

    init {
        loadFavorites()
    }

    /**
     * Loads saved favorited media keys from persistent storage.
     */
    private fun loadFavorites() {
        val videoIds = getStringSet("fav_videos").mapNotNull { it.toLongOrNull() }.toSet()
        val imageIds = getStringSet("fav_images").mapNotNull { it.toLongOrNull() }.toSet()
        val audioIds = getStringSet("fav_audio").mapNotNull { it.toLongOrNull() }.toSet()

        _state.update {
            FavoritesState(
                favoriteVideoIds = videoIds,
                favoriteImageIds = imageIds,
                favoriteAudioIds = audioIds
            )
        }
    }

    /**
     * Toggles the favorite status of a local video item.
     */
    fun toggleFavoriteVideo(id: Long) {
        val currentSet = _state.value.favoriteVideoIds
        val newSet = if (currentSet.contains(id)) {
            currentSet - id
        } else {
            currentSet + id
        }
        putStringSet("fav_videos", newSet.map { it.toString() }.toSet())
        _state.update { it.copy(favoriteVideoIds = newSet) }
    }

    /**
     * Toggles the favorite status of a local image item.
     */
    fun toggleFavoriteImage(id: Long) {
        val currentSet = _state.value.favoriteImageIds
        val newSet = if (currentSet.contains(id)) {
            currentSet - id
        } else {
            currentSet + id
        }
        putStringSet("fav_images", newSet.map { it.toString() }.toSet())
        _state.update { it.copy(favoriteImageIds = newSet) }
    }

    /**
     * Toggles the favorite status of a local audio item.
     */
    fun toggleFavoriteAudio(id: Long) {
        val currentSet = _state.value.favoriteAudioIds
        val newSet = if (currentSet.contains(id)) {
            currentSet - id
        } else {
            currentSet + id
        }
        putStringSet("fav_audio", newSet.map { it.toString() }.toSet())
        _state.update { it.copy(favoriteAudioIds = newSet) }
    }

    /**
     * General utility to check favorite status of any media ID.
     */
    fun isFavorite(id: Long, type: String): Boolean {
        return _state.value.isFavorite(id, type)
    }

    private fun getStringSet(key: String): Set<String> {
        return sharedPrefs.getStringSet(key, emptySet()) ?: emptySet()
    }

    private fun putStringSet(key: String, value: Set<String>) {
        sharedPrefs.edit().putStringSet(key, value).apply()
    }
}

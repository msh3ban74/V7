package com.example.presentation.screens.player

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.model.MediaItem
import com.example.domain.repository.MediaRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel responsible for managing playing simulation logic.
 * Encapsulates playback states, active track models, and progress indicators.
 */
class PlayerViewModel(
    private val mediaRepository: MediaRepository
) : ViewModel() {

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _progress = MutableStateFlow(0.24f)
    val progress: StateFlow<Float> = _progress.asStateFlow()

    private val _activeTrack = MutableStateFlow<MediaItem?>(null)
    val activeTrack: StateFlow<MediaItem?> = _activeTrack.asStateFlow()

    private val _uiState = MutableStateFlow<PlaybackUiState>(PlaybackUiState.Loading)
    val uiState: StateFlow<PlaybackUiState> = _uiState.asStateFlow()

    private var allTracks: List<MediaItem> = emptyList()
    private var currentIndex = 0
    private var playbackTickerJob: Job? = null

    init {
        loadMediaPlaylist()
    }

    private fun loadMediaPlaylist() {
        viewModelScope.launch {
            mediaRepository.getMediaItems().collect { list ->
                if (list.isNotEmpty()) {
                    allTracks = list
                    if (_activeTrack.value == null) {
                        selectTrackByIndex(0)
                    }
                }
            }
        }
    }

    fun selectTrack(id: String) {
        viewModelScope.launch {
            _uiState.value = PlaybackUiState.Loading
            val item = mediaRepository.getMediaItemById(id)
            if (item != null) {
                val index = allTracks.indexOfFirst { it.id == item.id }
                if (index != -1) {
                    currentIndex = index
                }
                _activeTrack.value = item
                _uiState.value = PlaybackUiState.Ready(item)
            } else {
                _uiState.value = PlaybackUiState.Error("Media track not found")
            }
        }
    }

    private fun selectTrackByIndex(index: Int) {
        if (allTracks.isNotEmpty()) {
            val safeIndex = index.coerceIn(0, allTracks.lastIndex)
            currentIndex = safeIndex
            val item = allTracks[safeIndex]
            _activeTrack.value = item
            _uiState.value = PlaybackUiState.Ready(item)
        }
    }

    fun togglePlayPause() {
        val playing = !_isPlaying.value
        _isPlaying.value = playing
        if (playing) {
            startPlaybackTicker()
        } else {
            stopPlaybackTicker()
        }
    }

    fun seekTo(newProgress: Float) {
        _progress.value = newProgress.coerceIn(0.0f, 1.0f)
    }

    fun playNext() {
        if (allTracks.isNotEmpty()) {
            val nextIndex = (currentIndex + 1) % allTracks.size
            _progress.value = 0.0f
            selectTrackByIndex(nextIndex)
            if (_isPlaying.value) {
                startPlaybackTicker()
            }
        }
    }

    fun playPrevious() {
        if (allTracks.isNotEmpty()) {
            val prevIndex = if (currentIndex - 1 < 0) allTracks.size - 1 else currentIndex - 1
            _progress.value = 0.0f
            selectTrackByIndex(prevIndex)
            if (_isPlaying.value) {
                startPlaybackTicker()
            }
        }
    }

    fun toggleFavorite() {
        val active = _activeTrack.value ?: return
        viewModelScope.launch {
            mediaRepository.toggleFavorite(active.id)
            // Reload updated entity
            val updated = mediaRepository.getMediaItemById(active.id)
            if (updated != null) {
                _activeTrack.value = updated
                _uiState.value = PlaybackUiState.Ready(updated)
            }
        }
    }

    private fun startPlaybackTicker() {
        playbackTickerJob?.cancel()
        playbackTickerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                val currentProg = _progress.value
                if (currentProg >= 1.0f) {
                    playNext()
                } else {
                    _progress.value = currentProg + 0.015f
                }
            }
        }
    }

    private fun stopPlaybackTicker() {
        playbackTickerJob?.cancel()
    }

    override fun onCleared() {
        super.onCleared()
        stopPlaybackTicker()
    }
}

/**
 * Clean UI State modeling playback load stages.
 */
sealed interface PlaybackUiState {
    object Loading : PlaybackUiState
    data class Ready(val activeTrack: MediaItem) : PlaybackUiState
    data class Error(val message: String) : PlaybackUiState
}

package com.example.presentation.immersive

import android.app.RecoverableSecurityException
import android.content.ContentResolver
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.activity.result.ActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import com.example.domain.model.LocalMediaItem

/**
 * Handles security exceptions, scoped storage deletes, and intent authorizations.
 */
class DeleteMediaManager(private val context: Context) {

    /**
     * Performs a device media removal request targeting MediaStore.
     */
    fun performDelete(
        contentResolver: ContentResolver,
        item: LocalMediaItem,
        senderLauncher: ManagedActivityResultLauncher<IntentSenderRequest, ActivityResult>?,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val uri = item.uri
        val scheme = uri.scheme?.lowercase()

        // Fallback for non-local streams (nature clips / fallback HTTP streams)
        if (scheme != "content") {
            onSuccess() // Mock deletion success
            return
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                // Android 11+ Scoped storage delete requests require IntentSender
                val pendingIntent = MediaStore.createDeleteRequest(contentResolver, listOf(uri))
                val request = IntentSenderRequest.Builder(pendingIntent.intentSender).build()
                senderLauncher?.launch(request)
            } else {
                // Direct delete for Android 9 or lower, or specific owns
                val deletedRows = contentResolver.delete(uri, null, null)
                if (deletedRows > 0) {
                    onSuccess()
                } else {
                    onError("Unable to remove resource. Item might be read-only.")
                }
            }
        } catch (securityException: SecurityException) {
            // Android 10 Specific Recoverable Security exception handler
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val recoverableException = securityException as? RecoverableSecurityException
                if (recoverableException != null) {
                    val intentSender = recoverableException.userAction.actionIntent.intentSender
                    val request = IntentSenderRequest.Builder(intentSender).build()
                    senderLauncher?.launch(request)
                } else {
                    onError(securityException.localizedMessage ?: "Security permission restriction error")
                }
            } else {
                onError(securityException.localizedMessage ?: "Requires access rights to modify storage")
            }
        } catch (e: Exception) {
            onError(e.localizedMessage ?: "Unknown hardware directory deletion error")
        }
    }
}

/**
 * Reusable M3 platform popup dialog asking user confirmation before permanent file deletions.
 */
@Composable
fun DeleteConfirmationDialog(
    show: Boolean,
    itemName: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (show) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = {
                Text(
                    text = "Confirm Permanent Deletion",
                    color = Color.Red
                )
            },
            text = {
                Text(
                    text = "Are you absolutely sure you want to permanently delete '$itemName' from your physical device storage? This cannot be undone."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = onConfirm,
                    modifier = Modifier.testTag("delete_dialog_confirm")
                ) {
                    Text("Delete Permanently", color = Color.Red)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("delete_dialog_dismiss")
                ) {
                    Text("Cancel")
                }
            },
            modifier = modifier.testTag("delete_dialog_layout")
        )
    }
}

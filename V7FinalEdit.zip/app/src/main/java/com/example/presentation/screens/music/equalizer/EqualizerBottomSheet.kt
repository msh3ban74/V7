package com.example.presentation.screens.music.equalizer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EqualizerBottomSheet(
    equalizerManager: EqualizerManager,
    onDismiss: () -> Unit
) {
    val isEnabled by equalizerManager.isEqualizerEnabled.collectAsState()
    val bands by equalizerManager.bands.collectAsState()
    val bassBoost by equalizerManager.bassBoostLevel.collectAsState()
    val virtualizer by equalizerManager.virtualizerLevel.collectAsState()
    val gain by equalizerManager.gainLevel.collectAsState()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Premium Equalizer",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Switch(
                    checked = isEnabled,
                    onCheckedChange = { equalizerManager.toggleEqualizer() }
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))

            // Presets
            Text("Presets", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    0.toShort() to "Normal",
                    1.toShort() to "Classical",
                    2.toShort() to "Dance",
                    3.toShort() to "Flat",
                    4.toShort() to "Folk"
                ).forEach { (index, name) ->
                    AssistChip(
                        onClick = { equalizerManager.applyPreset(index) },
                        label = { Text(name) }
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))

            // Bands
            Text("Frequency Bands", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                bands.forEach { band ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        // Material 3 Vertical Slider emulation
                        Slider(
                            value = band.level.toFloat(),
                            onValueChange = { equalizerManager.setBandLevel(band.bandIndex, it.toInt().toShort()) },
                            valueRange = -1500f..1500f,
                            modifier = Modifier
                                .height(150.dp)
                        )
                        Text(
                            text = "${band.frequencyHz}Hz",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Effects
            Text("Spatial & Enhancements", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(16.dp))
            
            EffectSlider("Bass Boost", bassBoost.toFloat(), 0f, 1000f) {
                equalizerManager.setBassBoost(it.toInt())
            }
            EffectSlider("Virtualizer", virtualizer.toFloat(), 0f, 1000f) {
                equalizerManager.setVirtualizer(it.toInt())
            }
            EffectSlider("Loudness", gain.toFloat(), 0f, 2000f) {
                equalizerManager.setGain(it.toInt())
            }
            
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
private fun EffectSlider(name: String, value: Float, min: Float, max: Float, onChanged: (Float) -> Unit) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = name, style = MaterialTheme.typography.bodyMedium)
            Text(text = "${(value / max * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
        }
        Slider(
            value = value,
            onValueChange = onChanged,
            valueRange = min..max,
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary
            )
        )
    }
}

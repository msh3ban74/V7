package com.example.presentation.immersive

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.LocalMediaItem

/**
 * TikTok / Instagram Reels style floating vertical media action panel.
 * Houses high-fidelity, responsive action items with precise, legible typography labels.
 */
@Composable
fun MediaActionPanel(
    item: LocalMediaItem,
    isFavorite: Boolean,
    currentSpeed: Float?, // null if static content (like raw images)
    onFavoriteToggle: () -> Unit,
    onShareClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onInfoClick: () -> Unit,
    onSpeedClick: (() -> Unit)?,
    onVaultClick: (() -> Unit)? = null,
    onRenameClick: (() -> Unit)? = null,
    onConvertClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.testTag("media_action_panel"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Core Animated Favorite Toggle
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            FavoriteButton(
                isFavorite = isFavorite,
                onToggle = onFavoriteToggle
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Favorite",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.testTag("action_label_favorite")
            )
        }

        // Vault Action
        if (onVaultClick != null) {
            ActionButtonComposable(
                icon = Icons.Default.Lock,
                contentDescription = "Move to Vault",
                label = "Vault",
                onClick = onVaultClick,
                tag = "vault_action"
            )
        }
        
        // Rename Action
        if (onRenameClick != null) {
            ActionButtonComposable(
                icon = Icons.Default.Edit,
                contentDescription = "Rename Media",
                label = "Rename",
                onClick = onRenameClick,
                tag = "rename_action"
            )
        }

        // 2. Share sheet launcher action trigger
        ActionButtonComposable(
            icon = Icons.Default.Share,
            contentDescription = "Share Media Content",
            label = "Share",
            onClick = onShareClick,
            tag = "share_action"
        )

        // 3. Hardware media deleting prompt
        ActionButtonComposable(
            icon = Icons.Default.Delete,
            contentDescription = "Delete Local Media permanently",
            label = "Delete",
            onClick = onDeleteClick,
            tag = "delete_action",
            tint = Color.White
        )

        // 4. File-system metadata specs summary
        ActionButtonComposable(
            icon = Icons.Default.Info,
            contentDescription = "Show Media Details",
            label = "Specs",
            onClick = onInfoClick,
            tag = "info_action"
        )

        // Convert to MP3 (local audio extraction) — shown only for video items
        if (onConvertClick != null) {
            ActionButtonComposable(
                icon = Icons.Default.MusicNote,
                contentDescription = "Convert video to MP3 audio",
                label = "To MP3",
                onClick = onConvertClick,
                tag = "convert_mp3_action"
            )
        }

        // 5. Playback Speed Selector (Rendered selectively for audio and video media playbacks)
        if (currentSpeed != null && onSpeedClick != null) {
            ActionButtonComposable(
                icon = Icons.Default.Speed,
                contentDescription = "Adjust playback velocity",
                label = "${currentSpeed}x",
                onClick = onSpeedClick,
                tag = "speed_action"
            )
        }
    }
}

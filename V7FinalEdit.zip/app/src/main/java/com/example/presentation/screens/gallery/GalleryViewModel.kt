package com.example.presentation.screens.gallery

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.model.AudioItem
import com.example.domain.model.ImageItem
import com.example.domain.model.LocalMediaItem
import com.example.domain.model.VideoItem
import com.example.domain.repository.LocalMediaRepository
import com.example.domain.repository.MediaLoadState
import com.example.presentation.screens.gallery.components.GalleryFilterType
import com.example.presentation.screens.favorites.FavoritesRepository
import com.example.presentation.screens.gallery.favorites.FavoritesState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

import com.example.presentation.screens.vault.VaultManager

enum class GallerySortType {
    RECENTLY_ADDED,
    FAVORITES_FIRST
}

data class GalleryViewState(
    val query: String,
    val filter: GalleryFilterType,
    val sortType: GallerySortType,
    val favs: FavoritesState
)

/**
 * ViewModel managing real local media assets integration, filtering, searching,
 * and persistent favorites indicators.
 */
class GalleryViewModel(
    private val localMediaRepository: LocalMediaRepository,
    private val favoritesRepository: FavoritesRepository,
    private val vaultManager: VaultManager
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedFilter = MutableStateFlow(GalleryFilterType.ALL)
    val selectedFilter: StateFlow<GalleryFilterType> = _selectedFilter.asStateFlow()
    
    private val _selectedSort = MutableStateFlow(GallerySortType.RECENTLY_ADDED)
    val selectedSort: StateFlow<GallerySortType> = _selectedSort.asStateFlow()

    // Observe Favorites flow directly
    val favoritesState: StateFlow<FavoritesState> = favoritesRepository.favoritesState

    // Streams combined raw media list from the Local Storage repository streams
    private val allLocalMedia: Flow<List<LocalMediaItem>> = combine(
        localMediaRepository.getLocalVideos(),
        localMediaRepository.getLocalImages(),
        localMediaRepository.getLocalAudio()
    ) { videosState, imagesState, audioState ->
        val videos = (videosState as? MediaLoadState.Success<List<VideoItem>>)?.data ?: emptyList()
        val images = (imagesState as? MediaLoadState.Success<List<ImageItem>>)?.data ?: emptyList()
        val audio = (audioState as? MediaLoadState.Success<List<AudioItem>>)?.data ?: emptyList()
        videos + images + audio
    }

    // Combine filter / search / sort states
    private val viewStateFlow = combine(
        _searchQuery,
        _selectedFilter,
        _selectedSort,
        favoritesState
    ) { query, filter, sort, favs ->
        GalleryViewState(query, filter, sort, favs)
    }

    // Auto-combine streams cleanly according to category filters, searches criteria and favorites lists
    val localMediaItems: StateFlow<List<LocalMediaItem>> = combine(
        allLocalMedia,
        viewStateFlow,
        vaultManager.vaultedIds
    ) { items, viewState, vaulted ->
        val query = viewState.query
        val filter = viewState.filter
        val favs = viewState.favs
        val sortType = viewState.sortType
        
        val nonVaultedItems = items.filter { !vaulted.contains(it.id) }
        val filteredByCat = when (filter) {
            GalleryFilterType.ALL -> nonVaultedItems
            GalleryFilterType.VIDEOS -> nonVaultedItems.filterIsInstance<VideoItem>()
            GalleryFilterType.IMAGES -> nonVaultedItems.filterIsInstance<ImageItem>()
            GalleryFilterType.MUSIC -> nonVaultedItems.filterIsInstance<AudioItem>()
            GalleryFilterType.FAVORITES -> {
                nonVaultedItems.filter { item ->
                    when (item) {
                        is VideoItem -> favs.favoriteVideoIds.contains(item.id)
                        is ImageItem -> favs.favoriteImageIds.contains(item.id)
                        is AudioItem -> favs.favoriteAudioIds.contains(item.id)
                        else -> false
                    }
                }
            }
        }

        val searched = filteredByCat.filter { item ->
            query.isEmpty() || item.displayName.contains(query, ignoreCase = true)
        }
        
        when (sortType) {
            GallerySortType.RECENTLY_ADDED -> {
                searched.sortedByDescending { it.dateAdded }
            }
            GallerySortType.FAVORITES_FIRST -> {
                searched.sortedWith(compareByDescending<LocalMediaItem> { item -> 
                    when (item) {
                        is VideoItem -> favs.favoriteVideoIds.contains(item.id)
                        is ImageItem -> favs.favoriteImageIds.contains(item.id)
                        is AudioItem -> favs.favoriteAudioIds.contains(item.id)
                        else -> false
                    }
                }.thenByDescending { it.dateAdded })
            }
        }

    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun onSearchQueryChanged(newQuery: String) {
        _searchQuery.value = newQuery
    }

    fun onFilterSelected(filter: GalleryFilterType) {
        _selectedFilter.value = filter
    }
    
    fun onSortSelected(sortType: GallerySortType) {
        _selectedSort.value = sortType
    }

    private val _selectedIds = MutableStateFlow<Set<Long>>(emptySet())
    val selectedIds: StateFlow<Set<Long>> = _selectedIds.asStateFlow()

    fun toggleSelection(id: Long) {
        val current = _selectedIds.value.toMutableSet()
        if (current.contains(id)) current.remove(id) else current.add(id)
        _selectedIds.value = current
    }

    fun selectAll(ids: List<Long>) {
        _selectedIds.value = ids.toSet()
    }

    fun clearSelection() {
        _selectedIds.value = emptySet()
    }

    fun vaultSelected(items: List<LocalMediaItem>) {
        val selected = _selectedIds.value
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            // Use the full-item overload so files are physically moved into the vault.
            items.filter { selected.contains(it.id) }.forEach { vaultManager.vaultMedia(it) }
            clearSelection()
            refreshMedia()
        }
    }

    /**
     * Toggles favorite state via FavoritesRepository.
     */
    fun toggleFavorite(item: LocalMediaItem) {
        when (item) {
            is VideoItem -> favoritesRepository.toggleFavoriteVideo(item.id)
            is ImageItem -> favoritesRepository.toggleFavoriteImage(item.id)
            is AudioItem -> favoritesRepository.toggleFavoriteAudio(item.id)
        }
    }

    /**
     * Refreshes the local media files dynamically.
     */
    fun refreshMedia() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            localMediaRepository.loadFromCache()
            localMediaRepository.refreshAll()
        }
    }
    
    /**
     * Removes an item locally to bypass full device rescan overhead.
     */
    fun removeMediaItem(id: Long, item: LocalMediaItem) {
        viewModelScope.launch {
            val type = when (item) {
                is VideoItem -> "video"
                is AudioItem -> "audio"
                is ImageItem -> "image"
                else -> "video"
            }
            localMediaRepository.removeMediaItem(id, type)
        }
    }

    /**
     * Move an item to the secure vault
     */
    fun vaultItem(item: LocalMediaItem) {
        viewModelScope.launch {
            // Unmount active item smoothly before media list shrinks
            kotlinx.coroutines.delay(150)
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                // Use the full-item overload so the file is physically moved into the vault.
                vaultManager.vaultMedia(item)
                refreshMedia()
            }
        }
    }
}

package com.example

import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.tooling.preview.Preview
import com.example.presentation.main.MainScreen
import com.example.ui.theme.V7Theme

/**
 * Main entrance point for application V7.
 * Implements edge-to-edge support and delegates rendering to [MainScreen].
 */
class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Setup modern edge-to-edge full window system insets handling
        enableEdgeToEdge()
        
        setContent {
            val themeManager = androidx.compose.runtime.remember { com.example.presentation.theme.ThemeManager(this) }
            val themeState by themeManager.state.collectAsState(initial = com.example.presentation.theme.ThemeState())
            com.example.presentation.theme.PremiumThemePack(state = themeState) {
                MainScreen()
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun MainScreenPreview() {
    V7Theme {
        MainScreen()
    }
}

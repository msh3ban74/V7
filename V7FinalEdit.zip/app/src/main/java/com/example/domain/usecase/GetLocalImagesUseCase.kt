package com.example.domain.usecase

import com.example.domain.model.ImageItem
import com.example.domain.repository.LocalMediaRepository
import com.example.domain.repository.MediaLoadState
import kotlinx.coroutines.flow.Flow

/**
 * Use case to retrieve and observe local visual art images.
 */
class GetLocalImagesUseCase(
    private val repository: LocalMediaRepository
) {
    operator fun invoke(): Flow<MediaLoadState<List<ImageItem>>> {
        return repository.getLocalImages()
    }
}

package com.example.domain.usecase

import com.example.domain.model.AudioItem
import com.example.domain.repository.LocalMediaRepository
import com.example.domain.repository.MediaLoadState
import kotlinx.coroutines.flow.Flow

/**
 * Use case to retrieve and observe local audio track files.
 */
class GetLocalAudioUseCase(
    private val repository: LocalMediaRepository
) {
    operator fun invoke(): Flow<MediaLoadState<List<AudioItem>>> {
        return repository.getLocalAudio()
    }
}

package com.example.domain.usecase

import com.example.domain.model.VideoItem
import com.example.domain.repository.LocalMediaRepository
import com.example.domain.repository.MediaLoadState
import kotlinx.coroutines.flow.Flow

/**
 * Use case to retrieve and observe local video stream structures.
 */
class GetLocalVideosUseCase(
    private val repository: LocalMediaRepository
) {
    operator fun invoke(): Flow<MediaLoadState<List<VideoItem>>> {
        return repository.getLocalVideos()
    }
}

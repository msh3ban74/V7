package com.example.domain.repository

import com.example.domain.model.AudioItem
import com.example.domain.model.ImageItem
import com.example.domain.model.VideoItem
import kotlinx.coroutines.flow.Flow

/**
 * Unified sealed status indicating load results or progress of device storage scanning.
 */
sealed interface MediaLoadState<out T> {
    object Idle : MediaLoadState<Nothing>
    object Loading : MediaLoadState<Nothing>
    data class Success<out T>(val data: T) : MediaLoadState<T>
    data class Error(val message: String, val exception: Throwable? = null) : MediaLoadState<Nothing>
}

/**
 * Repository interface defining interactions with device's local MediaStore.
 */
interface LocalMediaRepository {

    /**
     * Streams available videos from the device.
     */
    fun getLocalVideos(): Flow<MediaLoadState<List<VideoItem>>>

    /**
     * Streams available audio tracks from the device.
     */
    fun getLocalAudio(): Flow<MediaLoadState<List<AudioItem>>>

    /**
     * Streams available images from the device.
     */
    fun getLocalImages(): Flow<MediaLoadState<List<ImageItem>>>

    /**
     * Loads immediately from local cache if available.
     */
    suspend fun loadFromCache()

    /**
     * Triggers manually scanner synchronization on demand.
     */
    suspend fun refreshAll()
    
    /**
     * Removes an item from cache/state to avoid full rescan
     */
    suspend fun removeMediaItem(id: Long, type: String)
}

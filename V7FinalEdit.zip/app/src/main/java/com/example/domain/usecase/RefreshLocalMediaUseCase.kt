package com.example.domain.usecase

import com.example.domain.repository.LocalMediaRepository

/**
 * Use case to trigger active re-scanning of external media directories on the device.
 */
class RefreshLocalMediaUseCase(
    private val repository: LocalMediaRepository
) {
    suspend operator fun invoke() {
        repository.refreshAll()
    }
}

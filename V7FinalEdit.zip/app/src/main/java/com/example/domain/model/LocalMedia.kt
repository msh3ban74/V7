package com.example.domain.model

import android.net.Uri

/**
 * Common interface representing any local media item scanned on the device.
 */
sealed interface LocalMediaItem {
    val id: Long
    val displayName: String
    val uri: Uri
    val path: String
    val size: Long
    val mimeType: String
    val dateAdded: Long
}

/**
 * Domain-level representation of a video located on local storage.
 */
data class VideoItem(
    override val id: Long,
    override val displayName: String,
    override val uri: Uri,
    override val path: String,
    override val size: Long,
    override val mimeType: String,
    override val dateAdded: Long,
    val duration: Long, // in milliseconds
    val width: Int,
    val height: Int
) : LocalMediaItem

/**
 * Domain-level representation of an audio track located on local storage.
 */
data class AudioItem(
    override val id: Long,
    override val displayName: String,
    override val uri: Uri,
    override val path: String,
    override val size: Long,
    override val mimeType: String,
    override val dateAdded: Long,
    val duration: Long, // in milliseconds
    val artist: String?,
    val album: String?
) : LocalMediaItem

/**
 * Domain-level representation of an image located on local storage.
 */
data class ImageItem(
    override val id: Long,
    override val displayName: String,
    override val uri: Uri,
    override val path: String,
    override val size: Long,
    override val mimeType: String,
    override val dateAdded: Long,
    val width: Int,
    val height: Int
) : LocalMediaItem

package com.example.domain.model

/**
 * Domain-level Entity representing a media unit (sound track, digital art, etc.)
 * in the V7 architecture. Uncoupled from database models or API responses.
 */
data class MediaItem(
    val id: String,
    val title: String,
    val artist: String,
    val duration: String,
    val category: String,
    val coverUrl: String,
    val isFavorite: Boolean = false,
    val playCount: Int = 0
)

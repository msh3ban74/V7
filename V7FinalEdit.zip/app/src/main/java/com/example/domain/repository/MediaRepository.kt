package com.example.domain.repository

import com.example.domain.model.MediaItem
import kotlinx.coroutines.flow.Flow

/**
 * Clean Architecture repository interface.
 * Exposes core domain business methods as pure flows and suspend functions.
 */
interface MediaRepository {
    
    /**
     * Observable stream of all media streams/items.
     */
    fun getMediaItems(): Flow<List<MediaItem>>

    /**
     * Get a specific media item by its unique ID.
     */
    suspend fun getMediaItemById(id: String): MediaItem?

    /**
     * Retrieve featured items for Home dashboard.
     */
    fun getFeaturedMedia(): Flow<List<MediaItem>>

    /**
     * Toggle the favorite status of a specific item.
     */
    suspend fun toggleFavorite(id: String)
}

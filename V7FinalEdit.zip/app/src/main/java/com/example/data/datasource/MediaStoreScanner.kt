package com.example.data.datasource

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import com.example.domain.model.AudioItem
import com.example.domain.model.ImageItem
import com.example.domain.model.VideoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Modern MediaStore Scanner to fetch local media (videos, images, audio) securely.
 */
class MediaStoreScanner(private val context: Context) {

    /**
     * Scans local storage for videos using modern ContentResolver guidelines.
     */
    suspend fun scanVideos(): List<VideoItem> = withContext(Dispatchers.IO) {
        val videos = mutableListOf<VideoItem>()
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI

        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT
        )

        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"
        val selection = "${MediaStore.Video.Media.SIZE} > 0 AND ${MediaStore.Video.Media.DURATION} > 0"

        try {
            context.contentResolver.query(
                collection,
                projection,
                selection,
                null,
                sortOrder
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val pathColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
                val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val mimeColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
                val dateColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val widthColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
                val heightColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)

                while (cursor.moveToNext()) {
                    kotlinx.coroutines.yield()
                    val id = cursor.getLong(idColumn)
                    val displayName = cursor.getString(nameColumn) ?: "Video-$id"
                    val path = cursor.getString(pathColumn) ?: ""
                    
                    if (path.isNotEmpty() && java.io.File(path).exists()) {
                        val size = cursor.getLong(sizeColumn)
                        val mimeType = cursor.getString(mimeColumn) ?: "video/*"
                        val dateAdded = cursor.getLong(dateColumn)
                        val duration = cursor.getLong(durationColumn)
                        val width = cursor.getInt(widthColumn)
                        val height = cursor.getInt(heightColumn)
    
                        val uri = ContentUris.withAppendedId(collection, id)
    
                        videos.add(
                            VideoItem(
                                id = id,
                                displayName = displayName,
                                uri = uri,
                                path = path,
                                size = size,
                                mimeType = mimeType,
                                dateAdded = dateAdded,
                                duration = duration,
                                width = width,
                                height = height
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            // Gracefully catch and return empty list on permission or query failure
        }
        return@withContext videos
    }

    /**
     * Scans local storage for audio files using ContentResolver.
     */
    suspend fun scanAudio(): List<AudioItem> = withContext(Dispatchers.IO) {
        val audioFiles = mutableListOf<AudioItem>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM
        )

        // Only search for music/audio files, filtering out ringtones/notifications if possible
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.SIZE} > 0 AND ${MediaStore.Audio.Media.DURATION} > 0"
        val sortOrder = "${MediaStore.Audio.Media.DATE_ADDED} DESC"

        try {
            context.contentResolver.query(
                collection,
                projection,
                selection,
                null,
                sortOrder
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val pathColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val mimeColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                val dateColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val artistColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)

                while (cursor.moveToNext()) {
                    kotlinx.coroutines.yield()
                    val id = cursor.getLong(idColumn)
                    val title = cursor.getString(titleColumn)
                    val name = cursor.getString(nameColumn)
                    val displayName = if (!title.isNullOrEmpty()) title else name ?: "Audio-$id"
                    val path = cursor.getString(pathColumn) ?: ""
                    
                    if (path.isNotEmpty() && java.io.File(path).exists()) {
                        val size = cursor.getLong(sizeColumn)
                        val mimeType = cursor.getString(mimeColumn) ?: "audio/*"
                        val dateAdded = cursor.getLong(dateColumn)
                        val duration = cursor.getLong(durationColumn)
                        val artist = cursor.getString(artistColumn)
                        val album = cursor.getString(albumColumn)
    
                        val uri = ContentUris.withAppendedId(collection, id)
    
                        audioFiles.add(
                            AudioItem(
                                id = id,
                                displayName = displayName,
                                uri = uri,
                                path = path,
                                size = size,
                                mimeType = mimeType,
                                dateAdded = dateAdded,
                                duration = duration,
                                artist = if (artist == MediaStore.UNKNOWN_STRING) "Unknown Artist" else artist,
                                album = if (album == MediaStore.UNKNOWN_STRING) "Unknown Album" else album
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return@withContext audioFiles
    }

    /**
     * Scans local storage for images.
     */
    suspend fun scanImages(): List<ImageItem> = withContext(Dispatchers.IO) {
        val images = mutableListOf<ImageItem>()
        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATA,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.MIME_TYPE,
            MediaStore.Images.Media.DATE_ADDED,
            MediaStore.Images.Media.WIDTH,
            MediaStore.Images.Media.HEIGHT
        )

        val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"
        val selection = "${MediaStore.Images.Media.SIZE} > 0"

        try {
            context.contentResolver.query(
                collection,
                projection,
                selection,
                null,
                sortOrder
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val pathColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
                val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                val mimeColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
                val dateColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
                val widthColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH)
                val heightColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT)

                while (cursor.moveToNext()) {
                    kotlinx.coroutines.yield()
                    val id = cursor.getLong(idColumn)
                    val displayName = cursor.getString(nameColumn) ?: "Image-$id"
                    val path = cursor.getString(pathColumn) ?: ""
                    
                    if (path.isNotEmpty() && java.io.File(path).exists()) {
                        val size = cursor.getLong(sizeColumn)
                        val mimeType = cursor.getString(mimeColumn) ?: "image/*"
                        val dateAdded = cursor.getLong(dateColumn)
                        val width = cursor.getInt(widthColumn)
                        val height = cursor.getInt(heightColumn)
    
                        val uri = ContentUris.withAppendedId(collection, id)
    
                        images.add(
                            ImageItem(
                                id = id,
                                displayName = displayName,
                                uri = uri,
                                path = path,
                                size = size,
                                mimeType = mimeType,
                                dateAdded = dateAdded,
                                width = width,
                                height = height
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return@withContext images
    }
}

package com.example.data.repository

import com.example.domain.model.MediaItem
import com.example.domain.repository.MediaRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update

/**
 * Data layer implementation of [MediaRepository].
 * Manages an in-memory reactive list of domain objects for demo capabilities,
 * ready to be bridged with Room or Retrofit local/remote data sources.
 */
class MediaRepositoryImpl : MediaRepository {

    // Initial reactive dataset modeling local database or web cache
    private val mediaCollection = MutableStateFlow(
        listOf(
            MediaItem(
                id = "1",
                title = "Nebula Dreams",
                artist = "Lofi Cosmonaut",
                duration = "03:45",
                category = "Chill",
                coverUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe",
                isFavorite = true,
                playCount = 1450
            ),
            MediaItem(
                id = "2",
                title = "Hyperdrive Echoes",
                artist = "Synth Voyager",
                duration = "04:12",
                category = "Synthwave",
                coverUrl = "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad",
                isFavorite = false,
                playCount = 982
            ),
            MediaItem(
                id = "3",
                title = "Solar Wind Symphony",
                artist = "Aetherial Ensemble",
                duration = "06:18",
                category = "Ambient",
                coverUrl = "https://images.unsplash.com/photo-1550684848-fac1c5b4e853",
                isFavorite = false,
                playCount = 3209
            ),
            MediaItem(
                id = "4",
                title = "Orbiting Dust",
                artist = "Echo Station",
                duration = "02:54",
                category = "Chill",
                coverUrl = "https://images.unsplash.com/photo-1534796636912-3b95b3ab5986",
                isFavorite = true,
                playCount = 765
            ),
            MediaItem(
                id = "5",
                title = "Electronic Oasis",
                artist = "Studio Collective",
                duration = "05:07",
                category = "Electronic",
                coverUrl = "https://images.unsplash.com/photo-1578632767115-351597cf2477",
                isFavorite = false,
                playCount = 1845
            )
        )
    )

    override fun getMediaItems(): Flow<List<MediaItem>> = mediaCollection

    override suspend fun getMediaItemById(id: String): MediaItem? {
        return mediaCollection.value.find { it.id == id }
    }

    override fun getFeaturedMedia(): Flow<List<MediaItem>> {
        // Return tracks that have more than 1000 plays as featured
        return mediaCollection.map { list -> list.filter { it.playCount > 1000 } }
    }

    override suspend fun toggleFavorite(id: String) {
        mediaCollection.update { currentList ->
            currentList.map { item ->
                if (item.id == id) {
                    item.copy(isFavorite = !item.isFavorite)
                } else {
                    item
                }
            }
        }
    }
}

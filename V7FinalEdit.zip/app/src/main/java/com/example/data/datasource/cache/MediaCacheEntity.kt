package com.example.data.datasource.cache

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query

@Entity(tableName = "media_cache")
data class MediaCacheEntity(
    @PrimaryKey val id: Long,
    val mediaType: String, // "video", "audio", "image"
    val displayName: String,
    val uriString: String,
    val path: String,
    val size: Long,
    val mimeType: String,
    val dateAdded: Long,
    val duration: Long,
    val width: Int,
    val height: Int,
    val artist: String?,
    val album: String?
)

@Dao
interface MediaCacheDao {
    @Query("SELECT * FROM media_cache WHERE mediaType = :type ORDER BY dateAdded DESC")
    suspend fun getMediaByType(type: String): List<MediaCacheEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedia(media: List<MediaCacheEntity>)

    @Query("DELETE FROM media_cache")
    suspend fun clearCache()
    
    @Query("DELETE FROM media_cache WHERE mediaType = :type")
    suspend fun clearCacheByType(type: String)
    
    @Query("DELETE FROM media_cache WHERE id = :id")
    suspend fun deleteItemById(id: Long)
}

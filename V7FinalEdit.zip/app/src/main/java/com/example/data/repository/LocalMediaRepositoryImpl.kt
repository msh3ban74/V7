package com.example.data.repository

import android.content.Context
import com.example.data.datasource.MediaStoreScanner
import com.example.domain.model.AudioItem
import com.example.domain.model.ImageItem
import com.example.domain.model.VideoItem
import com.example.domain.repository.LocalMediaRepository
import com.example.domain.repository.MediaLoadState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.net.Uri
import com.example.data.datasource.cache.MediaCacheEntity
import com.example.presentation.screens.watchhistory.AppDatabase

/**
 * Concrete implementation of [LocalMediaRepository] using [MediaStoreScanner].
 * Utilizes StateFlow pipelines to cache and stream scanned contents consistently.
 */
class LocalMediaRepositoryImpl(
    private val scanner: MediaStoreScanner,
    context: Context
) : LocalMediaRepository {

    private val cacheDao by lazy { AppDatabase.getDatabase(context).mediaCacheDao() }

    private val _videoState = MutableStateFlow<MediaLoadState<List<VideoItem>>>(MediaLoadState.Idle)
    private val _audioState = MutableStateFlow<MediaLoadState<List<AudioItem>>>(MediaLoadState.Idle)
    private val _imageState = MutableStateFlow<MediaLoadState<List<ImageItem>>>(MediaLoadState.Idle)
    private var hasScannedSession = false

    override fun getLocalVideos(): Flow<MediaLoadState<List<VideoItem>>> = _videoState.asStateFlow()

    override fun getLocalAudio(): Flow<MediaLoadState<List<AudioItem>>> = _audioState.asStateFlow()

    override fun getLocalImages(): Flow<MediaLoadState<List<ImageItem>>> = _imageState.asStateFlow()

    override suspend fun loadFromCache() = withContext(Dispatchers.IO) {
        val cachedVideos = cacheDao.getMediaByType("video").map {
            VideoItem(it.id, it.displayName, Uri.parse(it.uriString), it.path, it.size, it.mimeType, it.dateAdded, it.duration, it.width, it.height)
        }
        if (cachedVideos.isNotEmpty()) {
            _videoState.value = MediaLoadState.Success(cachedVideos)
        }

        val cachedAudio = cacheDao.getMediaByType("audio").map {
            AudioItem(it.id, it.displayName, Uri.parse(it.uriString), it.path, it.size, it.mimeType, it.dateAdded, it.duration, it.artist, it.album)
        }
        if (cachedAudio.isNotEmpty()) {
            _audioState.value = MediaLoadState.Success(cachedAudio)
        }
        
        val cachedImages = cacheDao.getMediaByType("image").map {
            ImageItem(it.id, it.displayName, Uri.parse(it.uriString), it.path, it.size, it.mimeType, it.dateAdded, it.width, it.height)
        }
        if (cachedImages.isNotEmpty()) {
            _imageState.value = MediaLoadState.Success(cachedImages)
        }
    }

    override suspend fun removeMediaItem(id: Long, type: String) {
        val cr = kotlinx.coroutines.CoroutineScope(Dispatchers.IO)
        cr.launch {
            if (type == "video" && _videoState.value is MediaLoadState.Success) {
                val current = (_videoState.value as MediaLoadState.Success).data
                _videoState.value = MediaLoadState.Success(current.filter { it.id != id })
            } else if (type == "audio" && _audioState.value is MediaLoadState.Success) {
                val current = (_audioState.value as MediaLoadState.Success).data
                _audioState.value = MediaLoadState.Success(current.filter { it.id != id })
            } else if (type == "image" && _imageState.value is MediaLoadState.Success) {
                val current = (_imageState.value as MediaLoadState.Success).data
                _imageState.value = MediaLoadState.Success(current.filter { it.id != id })
            }
            cacheDao.deleteItemById(id)
        }
    }

    override suspend fun refreshAll() {
        if (hasScannedSession) {
            return
        }
        hasScannedSession = true
        supervisorScope {
            // Fetch videos asynchronously
            launch(Dispatchers.IO) {
                if (_videoState.value !is MediaLoadState.Success) {
                    _videoState.value = MediaLoadState.Loading
                }
                try {
                    val result = scanner.scanVideos()
                    _videoState.value = MediaLoadState.Success(result)
                    
                    val entities = result.map { 
                        MediaCacheEntity(it.id, "video", it.displayName, it.uri.toString(), it.path, it.size, it.mimeType, it.dateAdded, it.duration, it.width, it.height, null, null)
                    }
                    cacheDao.clearCacheByType("video")
                    cacheDao.insertMedia(entities)
                } catch (e: Exception) {
                    if (_videoState.value !is MediaLoadState.Success) {
                        _videoState.value = MediaLoadState.Error(
                            message = e.localizedMessage ?: "Failed scanning local videos",
                            exception = e
                        )
                    }
                }
            }

            // Fetch music tracks/audio files asynchronously
            launch(Dispatchers.IO) {
                if (_audioState.value !is MediaLoadState.Success) {
                    _audioState.value = MediaLoadState.Loading
                }
                try {
                    val result = scanner.scanAudio()
                    _audioState.value = MediaLoadState.Success(result)
                    
                    val entities = result.map { 
                        MediaCacheEntity(it.id, "audio", it.displayName, it.uri.toString(), it.path, it.size, it.mimeType, it.dateAdded, it.duration, 0, 0, it.artist, it.album)
                    }
                    cacheDao.clearCacheByType("audio")
                    cacheDao.insertMedia(entities)
                } catch (e: Exception) {
                    if (_audioState.value !is MediaLoadState.Success) {
                        _audioState.value = MediaLoadState.Error(
                            message = e.localizedMessage ?: "Failed scanning local audio",
                            exception = e
                        )
                    }
                }
            }

            // Fetch capture images asynchronously
            launch(Dispatchers.IO) {
                if (_imageState.value !is MediaLoadState.Success) {
                    _imageState.value = MediaLoadState.Loading
                }
                try {
                    val result = scanner.scanImages()
                    _imageState.value = MediaLoadState.Success(result)
                    
                    val entities = result.map { 
                        MediaCacheEntity(it.id, "image", it.displayName, it.uri.toString(), it.path, it.size, it.mimeType, it.dateAdded, 0, it.width, it.height, null, null)
                    }
                    cacheDao.clearCacheByType("image")
                    cacheDao.insertMedia(entities)
                } catch (e: Exception) {
                    if (_imageState.value !is MediaLoadState.Success) {
                        _imageState.value = MediaLoadState.Error(
                            message = e.localizedMessage ?: "Failed scanning local images",
                            exception = e
                        )
                    }
                }
            }
        }
    }
}

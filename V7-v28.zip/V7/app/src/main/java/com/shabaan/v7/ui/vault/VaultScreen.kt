package com.shabaan.v7.ui.vault

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pin
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.compose.ui.graphics.Color
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.shabaan.v7.data.local.VaultItemEntity
import com.shabaan.v7.data.model.MediaType
import com.shabaan.v7.util.Formatters
import com.shabaan.v7.util.LockManager
import com.shabaan.v7.util.PinManager
import com.shabaan.v7.util.SettingsStore

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun VaultScreen(
    activity: Activity?,
    vm: VaultViewModel = hiltViewModel()
) {
    val ctx = LocalContext.current
    val settings = remember { SettingsStore(ctx) }
    val lockEnabled = settings.appLockEnabled
    val biometricEnabled = settings.biometricEnabled
    val hasPin = settings.pinHash != null

    var unlocked by remember { mutableStateOf(!lockEnabled || !LockManager.requiresUnlock) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var pinMode by remember { mutableStateOf(false) }

    // Auto-prompt biometric when locked + enabled + available
    LaunchedEffect(unlocked, biometricEnabled, pinMode) {
        if (!unlocked && !pinMode && biometricEnabled && activity != null && LockManager.canUseBiometric(ctx)) {
            LockManager.authenticate(
                activity = activity,
                title = "Unlock Vault",
                subtitle = "Authenticate to view your secured media",
                onSuccess = { unlocked = true },
                onError = { errorMsg = it }
            )
        }
    }

    if (!unlocked) {
        if (pinMode || (hasPin && (!biometricEnabled || activity == null || !LockManager.canUseBiometric(ctx)))) {
            PinUnlockScreen(
                storedHash = settings.pinHash,
                onSuccess = {
                    LockManager.markUnlocked()
                    unlocked = true
                },
                onUseBiometric = {
                    pinMode = false
                    if (activity != null && biometricEnabled && LockManager.canUseBiometric(ctx)) {
                        LockManager.authenticate(
                            activity = activity,
                            title = "Unlock Vault",
                            subtitle = "Authenticate to view your secured media",
                            onSuccess = { unlocked = true },
                            onError = { errorMsg = it }
                        )
                    }
                },
                showBiometric = biometricEnabled && activity != null && LockManager.canUseBiometric(ctx)
            )
        } else {
            VaultLockedScreen(
                hasPin = hasPin,
                biometricEnabled = biometricEnabled,
                errorMsg = errorMsg,
                onAuthenticate = {
                    errorMsg = null
                    if (activity != null) {
                        LockManager.authenticate(
                            activity = activity,
                            title = "Unlock Vault",
                            subtitle = "Authenticate to view your secured media",
                            onSuccess = { unlocked = true },
                            onError = { errorMsg = it }
                        )
                    }
                },
                onUsePin = { pinMode = true }
            )
        }
        return
    }

    val items by vm.items.collectAsState()
    var confirmDelete by remember { mutableStateOf<VaultItemEntity?>(null) }
    var viewing by remember { mutableStateOf<Pair<VaultItemEntity, android.net.Uri>?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Vault", fontWeight = FontWeight.SemiBold)
                        Text(
                            "${items.size} secured item${if (items.size == 1) "" else "s"}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        if (items.isEmpty()) {
            Box(
                Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        Icons.Filled.Lock,
                        contentDescription = null,
                        modifier = Modifier.size(56.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text("Vault is empty", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Move photos, videos, or audio here to keep them hidden from your public gallery.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 32.dp)
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(8.dp, 8.dp, 8.dp, 96.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize().padding(padding)
            ) {
                items(items, key = { it.id }) { item ->
                    VaultCell(
                        item = item,
                        onView = { vm.resolveViewable(item) { uri -> if (uri != null) viewing = item to uri } },
                        onRestore = { vm.restore(item) },
                        onDelete = { confirmDelete = item }
                    )
                }
            }
        }
    }

    confirmDelete?.let { item ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Delete permanently?") },
            text = {
                Text("\"${item.originalName}\" will be removed from the vault and cannot be recovered.")
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.delete(item)
                    confirmDelete = null
                }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = null }) { Text("Cancel") }
            }
        )
    }

    viewing?.let { (item, uri) ->
        VaultViewerOverlay(
            item = item,
            uri = uri,
            onClose = { viewing = null }
        )
    }
}

@Composable
private fun VaultViewerOverlay(
    item: VaultItemEntity,
    uri: android.net.Uri,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current
    androidx.activity.compose.BackHandler { onClose() }

    Box(
        Modifier
            .fillMaxSize()
            .background(androidx.compose.ui.graphics.Color.Black)
    ) {
        when (item.type) {
            MediaType.IMAGE.name -> {
                AsyncImage(
                    model = ImageRequest.Builder(ctx).data(uri).crossfade(true).build(),
                    contentDescription = item.originalName,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = androidx.compose.ui.layout.ContentScale.Fit
                )
            }
            MediaType.VIDEO.name -> {
                val player = remember(uri) {
                    androidx.media3.exoplayer.ExoPlayer.Builder(ctx).build().apply {
                        setMediaItem(androidx.media3.common.MediaItem.fromUri(uri))
                        prepare()
                        playWhenReady = true
                    }
                }
                androidx.compose.runtime.DisposableEffect(player) {
                    onDispose { player.release() }
                }
                androidx.compose.ui.viewinterop.AndroidView(
                    factory = {
                        androidx.media3.ui.PlayerView(it).apply {
                            this.player = player
                            setBackgroundColor(android.graphics.Color.BLACK)
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
            else -> {
                // Audio — simple play with controls
                val player = remember(uri) {
                    androidx.media3.exoplayer.ExoPlayer.Builder(ctx).build().apply {
                        setMediaItem(androidx.media3.common.MediaItem.fromUri(uri))
                        prepare()
                        playWhenReady = true
                    }
                }
                androidx.compose.runtime.DisposableEffect(player) {
                    onDispose { player.release() }
                }
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Rounded.MusicNote,
                            contentDescription = null,
                            modifier = Modifier.size(96.dp),
                            tint = androidx.compose.ui.graphics.Color.White
                        )
                        Spacer(Modifier.height(16.dp))
                        Text(
                            item.originalName,
                            color = androidx.compose.ui.graphics.Color.White,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }
            }
        }

        IconButton(
            onClick = onClose,
            modifier = Modifier.align(Alignment.TopStart).padding(8.dp)
        ) {
            Icon(
                Icons.AutoMirrored.Outlined.ArrowBack,
                contentDescription = "Close",
                tint = androidx.compose.ui.graphics.Color.White
            )
        }

        IconButton(
            onClick = {
                val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                    type = item.mimeType
                    putExtra(android.content.Intent.EXTRA_STREAM, uri)
                    addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                ctx.startActivity(android.content.Intent.createChooser(send, "Share"))
            },
            modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)
        ) {
            Icon(
                Icons.Rounded.Share,
                contentDescription = "Share",
                tint = androidx.compose.ui.graphics.Color.White
            )
        }
    }
}

@Composable
private fun VaultLockedScreen(
    hasPin: Boolean,
    biometricEnabled: Boolean,
    errorMsg: String?,
    onAuthenticate: () -> Unit,
    onUsePin: () -> Unit
) {
    Box(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(32.dp)
        ) {
            Icon(
                Icons.Filled.Lock,
                contentDescription = null,
                modifier = Modifier.size(72.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Text(
                "Vault Locked",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                "Authenticate to view your secured media.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            errorMsg?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = onAuthenticate,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(Icons.Rounded.Fingerprint, contentDescription = null)
                Spacer(Modifier.size(8.dp))
                Text("Use biometric / device credential")
            }
            if (hasPin) {
                OutlinedButton(onClick = onUsePin) {
                    Icon(Icons.Rounded.Pin, contentDescription = null)
                    Spacer(Modifier.size(8.dp))
                    Text("Use PIN")
                }
            }
        }
    }
}

@Composable
private fun PinUnlockScreen(
    storedHash: String?,
    onSuccess: () -> Unit,
    onUseBiometric: () -> Unit,
    showBiometric: Boolean
) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Box(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(32.dp).fillMaxWidth()
        ) {
            Icon(
                Icons.Rounded.Pin,
                contentDescription = null,
                modifier = Modifier.size(56.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Text("Enter PIN", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(
                value = pin,
                onValueChange = {
                    if (it.length <= 8 && it.all { c -> c.isDigit() }) {
                        pin = it
                        error = null
                    }
                },
                label = { Text("PIN") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            Button(
                onClick = {
                    if (PinManager.matches(pin, storedHash)) onSuccess()
                    else { error = "Incorrect PIN"; pin = "" }
                },
                enabled = pin.length >= 4,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Unlock") }
            if (showBiometric) {
                TextButton(onClick = onUseBiometric) {
                    Text("Use biometric instead")
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun VaultCell(
    item: VaultItemEntity,
    onView: () -> Unit,
    onRestore: () -> Unit,
    onDelete: () -> Unit
) {
    val ctx = LocalContext.current
    var showActions by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(RoundedCornerShape(16.dp))
            .combinedClickable(
                onClick = { onView() },
                onLongClick = { showActions = !showActions }
            ),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(16.dp)
    ) {
        Box(Modifier.fillMaxSize()) {
            val typeIcon = when (item.type) {
                MediaType.VIDEO.name -> Icons.Rounded.PlayCircle
                MediaType.IMAGE.name -> Icons.Rounded.Image
                else -> Icons.Rounded.MusicNote
            }

            when (item.type) {
                MediaType.IMAGE.name, MediaType.VIDEO.name -> {
                    // The vault is already protected by the app lock, so it's safe
                    // to show real previews here. Encrypted items are decrypted
                    // in-memory just for the thumbnail by VaultThumbnailFetcher.
                    AsyncImage(
                        model = coil.request.ImageRequest.Builder(ctx)
                            .data(
                                com.shabaan.v7.util.VaultThumb(
                                    storedPath = item.storedPath,
                                    encrypted = item.encrypted,
                                    id = item.id
                                )
                            )
                            .size(400)
                            .crossfade(false)
                            .build(),
                        contentDescription = item.originalName,
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    if (item.type == MediaType.VIDEO.name) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Rounded.PlayCircle,
                                contentDescription = null,
                                tint = Color.White.copy(alpha = 0.85f),
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }
                }
                else -> {
                    Box(
                        Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            typeIcon,
                            contentDescription = null,
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (item.type == MediaType.VIDEO.name && !item.encrypted) {
                Icon(
                    Icons.Rounded.PlayCircle,
                    contentDescription = null,
                    modifier = Modifier.align(Alignment.Center).size(36.dp),
                    tint = MaterialTheme.colorScheme.surface
                )
            }

            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.scrim.copy(alpha = 0.55f))
                    .padding(horizontal = 6.dp, vertical = 4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (item.encrypted) {
                        Icon(
                            Icons.Filled.Lock,
                            contentDescription = null,
                            modifier = Modifier.size(12.dp),
                            tint = MaterialTheme.colorScheme.inverseOnSurface
                        )
                        Spacer(Modifier.size(4.dp))
                    }
                    Text(
                        Formatters.fileSize(item.size),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.inverseOnSurface
                    )
                }
            }

            if (showActions) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.scrim.copy(alpha = 0.65f)),
                    contentAlignment = Alignment.Center
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(onClick = { showActions = false; onRestore() }) {
                            Icon(
                                Icons.Filled.Restore,
                                contentDescription = "Restore",
                                tint = MaterialTheme.colorScheme.inverseOnSurface
                            )
                        }
                        IconButton(onClick = { showActions = false; onDelete() }) {
                            Icon(
                                Icons.Rounded.Delete,
                                contentDescription = "Delete",
                                tint = MaterialTheme.colorScheme.inverseOnSurface
                            )
                        }
                    }
                }
            }
        }
    }
}

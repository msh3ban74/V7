package com.shabaan.v7.util

import com.shabaan.v7.data.model.MediaItem
import java.util.Locale

/**
 * Smart search engine for V7.
 *
 * It keeps the exact same public contract as the old simple search (match by
 * name / artist / album), but layers on top of it:
 *   1. A scalable Arabic↔topic ALIAS system (الشيخ → قرآن/تلاوة/عبد الباسط…).
 *   2. Fuzzy matching that tolerates typos.
 *   3. A relevance score so results come back ranked:
 *        exact → alias → folder/album → fuzzy.
 *
 * Everything is pure Kotlin and allocation-light so it stays fast on large
 * libraries. The heavy lifting is just string ops over already-loaded lists.
 */
object SmartSearch {

    /**
     * Scalable alias table. Each entry maps a set of trigger words (Arabic or
     * English) to a set of related terms that should ALSO be searched.
     *
     * To add a new category later, just add another AliasGroup to this list —
     * nothing else needs to change.
     */
    data class AliasGroup(val triggers: List<String>, val related: List<String>)

    val aliasGroups: List<AliasGroup> = listOf(
        AliasGroup(
            triggers = listOf("الشيخ", "شيخ", "قران", "قرآن", "قرأن", "sheikh", "quran", "koran"),
            related = listOf(
                "قرآن", "قران", "تلاوة", "تلاوه", "اسلاميات", "إسلاميات", "ديني", "دينى",
                "عبد الباسط", "عبدالباسط", "الحصري", "الحصرى", "المنشاوي", "المنشاوى",
                "السديس", "الشريم", "العفاسي", "ماهر المعيقلي", "سورة", "سوره",
                "quran", "tilawa", "islamic", "recitation"
            )
        ),
        AliasGroup(
            triggers = listOf("اغاني", "أغاني", "اغنية", "أغنية", "اغنيه", "موسيقى", "موسيقي", "song", "songs", "music"),
            related = listOf(
                "music", "song", "songs", "mp3", "audio", "اغاني", "أغاني",
                "اغنية", "موسيقى", "موسيقي", "صوت", "اوديو"
            )
        ),
        AliasGroup(
            triggers = listOf("اطفال", "أطفال", "طفل", "كرتون", "kids", "child", "children", "cartoon"),
            related = listOf(
                "cartoon", "kids", "children", "child", "اطفال", "أطفال",
                "كرتون", "رسوم", "انمي", "أنمي", "anime", "toon"
            )
        ),
        AliasGroup(
            triggers = listOf("كورة", "كوره", "كرة", "football", "soccer", "match", "ماتش", "مباراة"),
            related = listOf(
                "football", "soccer", "match", "كورة", "كوره", "كرة",
                "مباراة", "مباراه", "ماتش", "اهلي", "أهلي", "زمالك", "goal", "هدف"
            )
        ),
        AliasGroup(
            triggers = listOf("مسلسلات", "مسلسل", "series", "episode", "season", "حلقة", "حلقه"),
            related = listOf(
                "series", "episode", "season", "ep", "مسلسل", "مسلسلات",
                "حلقة", "حلقه", "موسم", "الحلقة", "الحلقه"
            )
        )
    )

    // ---- Public API ------------------------------------------------------

    /**
     * Filters + ranks items for [query]. Empty query returns the list as-is
     * (identical to the old behaviour). Otherwise returns only matching items,
     * ordered best-match first.
     */
    fun search(items: List<MediaItem>, query: String): List<MediaItem> {
        val q = normalize(query)
        if (q.isEmpty()) return items

        // Expand the query with any related alias terms (normalized).
        val aliasTerms: Set<String> = expandAliases(q)

        // Score every item once; keep only positive scores; sort desc by score.
        val scored = ArrayList<Pair<MediaItem, Int>>(items.size)
        for (item in items) {
            val s = scoreItem(item, q, aliasTerms)
            if (s > 0) scored.add(item to s)
        }
        scored.sortByDescending { it.second }
        return scored.map { it.first }
    }

    /** Returns alias-expansion suggestions for a partially typed query. */
    fun suggestions(query: String, limit: Int = 6): List<String> {
        val q = normalize(query)
        if (q.length < 2) return emptyList()
        val out = LinkedHashSet<String>()
        for (group in aliasGroups) {
            if (group.triggers.any { normalize(it).contains(q) || q.contains(normalize(it)) }) {
                group.related.forEach { out.add(it) }
            }
        }
        // Also suggest triggers that start with the query (autocomplete feel).
        for (group in aliasGroups) {
            group.triggers.forEach { t ->
                if (normalize(t).startsWith(q)) out.add(t)
            }
        }
        return out.take(limit)
    }

    // ---- Scoring ---------------------------------------------------------

    private fun scoreItem(item: MediaItem, q: String, aliasTerms: Set<String>): Int {
        val name = normalize(item.name)
        val album = normalize(item.album ?: "")
        val artist = normalize(item.artist ?: "")
        val folder = normalize(item.relativePath ?: "")

        var score = 0

        // 1) EXACT / direct substring matches (highest).
        if (name == q) score = maxOf(score, 1000)
        if (name.contains(q)) score = maxOf(score, 800)
        if (name.startsWith(q)) score = maxOf(score, 850)
        if (artist.contains(q)) score = maxOf(score, 780)
        if (album.contains(q)) score = maxOf(score, 760)

        // 2) ALIAS matches (second).
        if (score == 0 && aliasTerms.isNotEmpty()) {
            for (term in aliasTerms) {
                if (term.length < 2) continue
                if (name.contains(term) || artist.contains(term) || album.contains(term)) {
                    score = maxOf(score, 600); break
                }
                if (folder.contains(term)) {
                    score = maxOf(score, 520); break
                }
            }
        }

        // 3) FOLDER / ALBUM direct matches (third).
        if (score == 0) {
            if (folder.contains(q)) score = maxOf(score, 500)
            else if (album.contains(q)) score = maxOf(score, 480)
        }

        // 4) FUZZY matches (last) — tolerate typos against name / folder.
        if (score == 0) {
            if (fuzzyContains(name, q)) score = maxOf(score, 300)
            else if (fuzzyContains(folder, q)) score = maxOf(score, 250)
        }

        return score
    }

    // ---- Alias expansion --------------------------------------------------

    private fun expandAliases(normalizedQuery: String): Set<String> {
        val out = LinkedHashSet<String>()
        for (group in aliasGroups) {
            val hit = group.triggers.any { trig ->
                val t = normalize(trig)
                t.isNotEmpty() && (normalizedQuery.contains(t) || t.contains(normalizedQuery))
            }
            if (hit) group.related.forEach { out.add(normalize(it)) }
        }
        return out
    }

    // ---- Fuzzy matching ---------------------------------------------------

    /**
     * True if any word in [haystack] is within a small edit distance of
     * [needle] (typo tolerance), or contains it. Cheap and good enough for
     * file-name search.
     */
    private fun fuzzyContains(haystack: String, needle: String): Boolean {
        if (haystack.isEmpty() || needle.isEmpty()) return false
        if (haystack.contains(needle)) return true
        // Allowable typos scale with word length.
        val maxDist = when {
            needle.length <= 3 -> 1
            needle.length <= 6 -> 2
            else -> 3
        }
        // Compare against each whitespace-separated token in the haystack.
        for (token in haystack.split(' ', '_', '-', '.')) {
            if (token.isEmpty()) continue
            if (token.length < needle.length - maxDist) continue
            // Sliding window so a typo'd needle can match inside a longer token.
            if (levenshteinWithin(token, needle, maxDist)) return true
        }
        return false
    }

    /** Bounded Levenshtein: returns true if edit distance <= [max]. */
    private fun levenshteinWithin(a: String, b: String, max: Int): Boolean {
        val la = a.length
        val lb = b.length
        if (kotlin.math.abs(la - lb) > max) {
            // Still allow if b is a near-substring of a (for longer file names).
            if (la <= lb) return false
        }
        // Classic DP but early-exit when a whole row exceeds max.
        val prev = IntArray(lb + 1) { it }
        val cur = IntArray(lb + 1)
        for (i in 1..la) {
            cur[0] = i
            var rowMin = cur[0]
            val ca = a[i - 1]
            for (j in 1..lb) {
                val cost = if (ca == b[j - 1]) 0 else 1
                cur[j] = minOf(
                    prev[j] + 1,
                    cur[j - 1] + 1,
                    prev[j - 1] + cost
                )
                if (cur[j] < rowMin) rowMin = cur[j]
            }
            if (rowMin > max) return false // can't get below max anymore
            System.arraycopy(cur, 0, prev, 0, lb + 1)
        }
        return prev[lb] <= max
    }

    // ---- Normalization ----------------------------------------------------

    /**
     * Lowercases, trims, and normalizes Arabic so that visually-equivalent
     * letters match (أإآ→ا, ة→ه, ى→ي) and diacritics/tatweel are stripped.
     * This massively improves Arabic search quality.
     */
    fun normalize(input: String): String {
        if (input.isEmpty()) return ""
        val lower = input.lowercase(Locale.ROOT).trim()
        val sb = StringBuilder(lower.length)
        for (ch in lower) {
            when (ch) {
                'أ', 'إ', 'آ', 'ٱ' -> sb.append('ا')
                'ة' -> sb.append('ه')
                'ى' -> sb.append('ي')
                'ؤ' -> sb.append('و')
                'ئ' -> sb.append('ي')
                'ـ' -> { /* tatweel: drop */ }
                // Arabic diacritics (harakat) range: drop them.
                in '\u064B'..'\u0652' -> { /* drop */ }
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }
}

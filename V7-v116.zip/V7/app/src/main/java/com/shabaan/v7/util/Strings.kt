package com.shabaan.v7.util

import androidx.compose.runtime.compositionLocalOf

/**
 * In-app localization system (no Activity restart, works with Compose state).
 *
 * How it works:
 *  - [LocalAppLanguage] is a CompositionLocal carrying the current [AppLanguage].
 *    The root of the app provides it from SettingsStore, so when the user flips
 *    the language every screen recomposes with the new strings instantly.
 *  - [S] is the string table: one entry per UI string, each with an Arabic and
 *    an English value. Screens read text via `S.<key>(lang)` or the `tr` helper.
 *
 * Adding a new string = add one line to [S]. Converting a screen = replace its
 * hard-coded text with a lookup. We migrate screen-by-screen; nothing breaks
 * for screens not yet migrated (they just keep their literal text).
 */

/** The current UI language, provided at the app root. Defaults to Arabic. */
val LocalAppLanguage = compositionLocalOf { AppLanguage.ARABIC }

/** A single localized string: Arabic + English. */
data class Str(val ar: String, val en: String) {
    operator fun invoke(lang: AppLanguage): String =
        if (lang == AppLanguage.ARABIC) ar else en
}

/**
 * Central string table. Grouped by area. Keep keys descriptive and stable.
 */
object S {
    // ---- Bottom navigation / tabs ----
    val tabVideos     = Str("الفيديوهات", "Videos")
    val tabGallery    = Str("المعرض", "Gallery")
    val tabAudio      = Str("الصوتيات", "Audio")
    val tabVault      = Str("الخزنة", "Vault")
    val tabSettings   = Str("الإعدادات", "Settings")

    // ---- Gallery ----
    val galleryTitle      = Str("المعرض", "Gallery")
    val photos            = Str("الصور", "Photos")
    val albums            = Str("الألبومات", "Albums")
    val favorites         = Str("المفضّلة", "Favorites")
    val duplicates        = Str("المكرّرة", "Duplicates")
    val search            = Str("بحث", "Search")
    val catAllPhotos      = Str("كل الصور", "All photos")
    val catVideos         = Str("فيديو", "Videos")
    val catScreenshots    = Str("لقطات الشاشة", "Screenshots")
    val catFavorites      = Str("المفضّلة", "Favorites")
    val catDownloads      = Str("التنزيلات", "Downloads")
    val noAlbums          = Str("لا توجد ألبومات بعد", "No albums yet")
    val noFavoritesYet    = Str("لا توجد مفضلة بعد", "No favorites yet")
    val noDuplicates      = Str("لا توجد صور مكررة", "No duplicate photos")
    val noPhotosYet       = Str("لا توجد صور بعد", "No photos yet")
    val noResults         = Str("لا توجد نتائج", "No results")
    val photosCount       = Str("صورة", "photos")

    // ---- Date sections ----
    val today         = Str("اليوم", "Today")
    val yesterday     = Str("الأمس", "Yesterday")
    val thisWeek      = Str("هذا الأسبوع", "This Week")
    val thisMonth     = Str("هذا الشهر", "This Month")

    // ---- Common actions ----
    val play          = Str("تشغيل", "Play")
    val pause         = Str("إيقاف", "Pause")
    val delete        = Str("حذف", "Delete")
    val share         = Str("مشاركة", "Share")
    val restore       = Str("استرجاع", "Restore")
    val cancel        = Str("إلغاء", "Cancel")
    val confirm       = Str("تأكيد", "Confirm")
    val addFiles      = Str("إضافة ملفات", "Add Files")

    // ---- Settings ----
    val settingsTitle = Str("الإعدادات", "Settings")
    val language      = Str("اللغة", "Language")
    val languageArabic  = Str("العربية", "Arabic")
    val languageEnglish = Str("الإنجليزية", "English")
    val appearance      = Str("المظهر", "Appearance")
    val gridSizeLabel   = Str("حجم الشبكة", "Grid size")
    val columnsSuffix   = Str("أعمدة", "columns")
    val security        = Str("الأمان", "Security")
    val appLock         = Str("قفل التطبيق", "App Lock")
    val appLockSub      = Str("طلب الفتح للدخول إلى الخزنة", "Require unlock to open the vault")
    val biometricUnlock = Str("الفتح بالبصمة", "Biometric Unlock")
    val biometricSub    = Str("استخدم البصمة أو الوجه عند توفرها", "Use fingerprint or face when available")
    val pinCode         = Str("رمز PIN", "PIN code")
    val sleepTimer      = Str("مؤقت النوم", "Sleep Timer")
    val storage         = Str("التخزين", "Storage")
    val backupGphotos   = Str("نسخ احتياطي إلى Google Photos", "Back up to Google Photos")
    val backupGphotosSub = Str("افتح Google Photos للنسخ، أو شارك الصور لأي تطبيق", "Open Google Photos to back up, or share photos to any app")
    val fullFileAccess  = Str("الوصول الكامل للملفات", "Full file access")
    val trashRetention  = Str("مدة الاحتفاظ بالمحذوفات", "Trash retention")
    val recentlyDeleted = Str("المحذوفات مؤخراً", "Recently deleted")
    val recentlyDeletedSub = Str("عرض واسترجاع العناصر المحذوفة", "View and restore deleted items")
    val clearThumbCache = Str("مسح ذاكرة الصور المؤقتة", "Clear thumbnail cache")
    val clearThumbCacheSub = Str("توفير المساحة المستخدمة للصور المصغرة", "Free up space used by thumbnails")
    val contactDev      = Str("تواصل مع المطوّر", "Contact the developer")
    val aboutApp        = Str("عن التطبيق", "About")
    val minutes         = Str("دقائق", "minutes")
    val set             = Str("ضبط", "Set")
    val turnOff         = Str("إيقاف", "Turn off")
    val save            = Str("حفظ", "Save")
    val remove          = Str("إزالة", "Remove")
    val newPinLabel     = Str("رمز جديد (4–8 أرقام)", "New code (4–8 digits)")
    val confirmPinLabel = Str("تأكيد الرمز", "Confirm code")
}

package com.shabaan.v7.util

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * Creates an animated GIF "sticker" from a slice of a video, using only the
 * platform [MediaMetadataRetriever] plus the bundled pure-Kotlin [GifEncoder]
 * (no external dependency, so the build stays safe).
 */
object StickerMaker {

    /**
     * @param uri        source video
     * @param startMs    where to begin grabbing frames
     * @param durationMs how much of the video to capture (capped to 5s)
     * @param fps        frames per second of the resulting GIF (capped 2..15)
     * @param maxDim     longest edge of the output in px (frames are downscaled)
     * @return the created GIF file, or null on failure
     */
    suspend fun createGif(
        context: Context,
        uri: Uri,
        startMs: Long,
        durationMs: Long = 2500,
        fps: Int = 10,
        maxDim: Int = 320
    ): File? = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)

            val totalMs = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull() ?: 0L

            val safeFps = fps.coerceIn(2, 15)
            val safeDuration = durationMs.coerceIn(500, 5000)
            val frameCount = ((safeDuration / 1000.0) * safeFps).toInt().coerceIn(2, 60)
            val stepMs = safeDuration / frameCount
            val begin = startMs.coerceIn(0, (totalMs - 1).coerceAtLeast(0))

            val frames = ArrayList<Bitmap>(frameCount)
            for (i in 0 until frameCount) {
                val t = (begin + i * stepMs) * 1000 // microseconds
                val frame = retriever.getFrameAtTime(
                    t, MediaMetadataRetriever.OPTION_CLOSEST
                ) ?: continue
                frames.add(scaleBitmap(frame, maxDim))
            }
            if (frames.isEmpty()) return@withContext null

            val outDir = File(context.cacheDir, "stickers").apply { mkdirs() }
            val outFile = File(outDir, "v7_sticker_${System.currentTimeMillis()}.gif")

            FileOutputStream(outFile).use { fos ->
                val enc = GifEncoder()
                enc.start(fos)
                enc.setRepeat(0)                       // loop forever
                enc.setDelay(1000 / safeFps)           // ms per frame
                enc.setQuality(10)
                frames.forEach { enc.addFrame(it) }
                enc.finish()
            }
            frames.forEach { if (!it.isRecycled) it.recycle() }
            outFile
        } catch (e: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    /**
     * Creates a WhatsApp-compatible **animated WebP sticker** from a slice of a
     * video and returns the file (in cache/stickers), or null on failure.
     */
    suspend fun createWebpSticker(
        context: Context,
        uri: Uri,
        startMs: Long,
        durationMs: Long = 2500,
        fps: Int = 10
    ): File? = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val totalMs = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull() ?: 0L

            val safeFps = fps.coerceIn(2, 15)
            val safeDuration = durationMs.coerceIn(500, 5000)
            // Keep frame count modest so the WebP stays under WhatsApp's 500 KB.
            val frameCount = ((safeDuration / 1000.0) * safeFps).toInt().coerceIn(2, 24)
            val begin = startMs.coerceIn(0, (totalMs - 1).coerceAtLeast(0))
            // Span the segment from begin → begin+safeDuration (clamped to the
            // clip). Dividing by (frameCount - 1) makes the last frame land at the
            // very end, so successive frames are actually different pictures
            // instead of all sampling the same instant (which looked static).
            val endCap = (begin + safeDuration).coerceAtMost(totalMs.coerceAtLeast(begin + 1))
            val span = (endCap - begin).coerceAtLeast(1)
            val stepMs = span / (frameCount - 1).coerceAtLeast(1)

            val frames = ArrayList<Bitmap>(frameCount)
            for (i in 0 until frameCount) {
                val t = (begin + i * stepMs) * 1000  // micro-seconds
                val frame = retriever.getFrameAtTime(
                    t, MediaMetadataRetriever.OPTION_CLOSEST
                ) ?: continue
                frames.add(frame)
            }
            if (frames.isEmpty()) return@withContext null

            // Drop quality progressively until we fit WhatsApp's 500 KB budget.
            var quality = 75
            var bytes: ByteArray? = null
            while (quality >= 30) {
                bytes = AnimatedWebpEncoder.encode(
                    frames = frames,
                    frameDurationMs = (1000 / safeFps),
                    quality = quality,
                    loopCount = 0
                )
                if (bytes != null && bytes.size <= 500 * 1024) break
                quality -= 15
            }
            frames.forEach { if (!it.isRecycled) it.recycle() }
            if (bytes == null) return@withContext null

            val outDir = File(context.cacheDir, "stickers").apply { mkdirs() }
            val outFile = File(outDir, "v7_sticker_${System.currentTimeMillis()}.webp")
            FileOutputStream(outFile).use { it.write(bytes) }
            outFile
        } catch (e: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    /**
     * Creates an animated WebP sticker, preferring real FFmpeg encoding and
     * falling back to the built-in encoder if FFmpeg isn't available. Copies the
     * result into the app sticker dir and returns it.
     */
    /**
     * Creates a genuine WhatsApp-compatible animated WebP using the libwebp
     * native encoder (webp-android). This produces a spec-correct animated WebP
     * (proper VP8X/ANMF/ANIM chunks via libwebp), which is what WhatsApp needs to
     * actually animate the sticker. Returns the file, or null on failure.
     */
    suspend fun createRealAnimatedWebp(
        context: Context,
        uri: Uri,
        startMs: Long,
        durationMs: Long = 2500,
        fps: Int = 12
    ): File? = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        var encoder: com.aureusapps.android.webpandroid.encoder.WebPAnimEncoder? = null
        try {
            retriever.setDataSource(context, uri)
            val totalMs = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull() ?: 0L

            val safeFps = fps.coerceIn(2, 20)
            // WhatsApp animated stickers must be <= 500 KB and <= ~6 s.
            val safeDuration = durationMs.coerceIn(500, 6000)
            val frameCount = ((safeDuration / 1000.0) * safeFps).toInt().coerceIn(2, 60)
            val begin = startMs.coerceIn(0, (totalMs - 1).coerceAtLeast(0))
            val endCap = (begin + safeDuration).coerceAtMost(totalMs.coerceAtLeast(begin + 1))
            val span = (endCap - begin).coerceAtLeast(1)
            val stepMs = span / (frameCount - 1).coerceAtLeast(1)
            val frameDurationMs = (1000 / safeFps)

            val size = 512
            encoder = com.aureusapps.android.webpandroid.encoder.WebPAnimEncoder(
                context = context,
                width = size,
                height = size,
                options = com.aureusapps.android.webpandroid.encoder.WebPAnimEncoderOptions(
                    minimizeSize = true,
                    animParams = com.aureusapps.android.webpandroid.encoder.WebPMuxAnimParams(
                        backgroundColor = 0,   // transparent
                        loopCount = 0          // loop forever
                    )
                )
            ).apply {
                configure(
                    config = com.aureusapps.android.webpandroid.encoder.WebPConfig(
                        lossless = com.aureusapps.android.webpandroid.encoder.WebPConfig.COMPRESSION_LOSSY,
                        quality = 70f
                    ),
                    preset = com.aureusapps.android.webpandroid.encoder.WebPPreset.WEBP_PRESET_PICTURE
                )
            }

            var timestamp = 0L
            var added = 0
            for (i in 0 until frameCount) {
                val t = (begin + i * stepMs) * 1000  // micro-seconds
                val frame = retriever.getFrameAtTime(
                    t, MediaMetadataRetriever.OPTION_CLOSEST
                ) ?: continue
                val square = squareBitmap(frame, size)
                encoder.addFrame(timestamp, square)
                timestamp += frameDurationMs
                if (square !== frame) square.recycle()
                if (!frame.isRecycled) frame.recycle()
                added++
            }
            if (added == 0) return@withContext null

            val outDir = File(context.cacheDir, "stickers").apply { mkdirs() }
            val outFile = File(outDir, "v7_sticker_${System.currentTimeMillis()}.webp")
            encoder.assemble(timestamp, Uri.fromFile(outFile))

            if (outFile.exists() && outFile.length() > 0) outFile else null
        } catch (e: Throwable) {
            // Throwable (not just Exception) so a missing native lib / linkage
            // error falls through to the older encoders instead of crashing.
            null
        } finally {
            runCatching { encoder?.release() }
            runCatching { retriever.release() }
        }
    }

    /** Center-crop/scale a bitmap into a square [size]x[size]. */
    private fun squareBitmap(src: Bitmap, size: Int): Bitmap {
        if (src.width == size && src.height == size) return src
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(out)
        val scale = size.toFloat() / minOf(src.width, src.height)
        val sw = src.width * scale
        val sh = src.height * scale
        val left = (size - sw) / 2f
        val top = (size - sh) / 2f
        val dst = android.graphics.RectF(left, top, left + sw, top + sh)
        canvas.drawBitmap(src, null, dst,
            android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
        return out
    }

    suspend fun createStickerSmart(
        context: Context,
        uri: Uri,
        startMs: Long,
        endMs: Long,
        fit: FfmpegStickerMaker.FitMode
    ): File? = withContext(Dispatchers.IO) {
        val span = (endMs - startMs).coerceIn(500, 6000)
        // 1) Real libwebp animated WebP (correct spec → WhatsApp animates it).
        val real = createRealAnimatedWebp(context, uri, startMs, span)
        if (real != null && real.exists() && real.length() > 0) return@withContext real
        // 2) Try genuine FFmpeg animated WebP (currently a no-op placeholder).
        val ff = FfmpegStickerMaker.create(context, uri, startMs, endMs, fit)
        if (ff != null && ff.exists() && ff.length() > 0) return@withContext ff
        // 3) Last resort: built-in hand-rolled encoder.
        createWebpSticker(context, uri, startMs, span.coerceIn(500, 3000))
    }

    /** Shares a sticker file (webp) straight to WhatsApp so the user picks a chat. */
    suspend fun shareSticker(context: Context, file: File): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val authority = context.packageName + ".fileprovider"
                val uri = androidx.core.content.FileProvider.getUriForFile(context, authority, file)
                val mime = if (file.extension.equals("webp", true)) "image/webp" else "image/gif"
                val base = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                    type = mime
                    putExtra(android.content.Intent.EXTRA_STREAM, uri)
                    addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                // Try WhatsApp first; if not installed, fall back to a chooser.
                val waPackages = listOf("com.whatsapp", "com.whatsapp.w4b")
                val installed = waPackages.firstOrNull { pkg ->
                    try {
                        context.packageManager.getPackageInfo(pkg, 0); true
                    } catch (_: Exception) { false }
                }
                if (installed != null) {
                    base.setPackage(installed)
                    context.startActivity(base)
                } else {
                    context.startActivity(
                        android.content.Intent.createChooser(base, "Send sticker")
                            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
                true
            } catch (e: Exception) {
                false
            }
        }

    private fun scaleBitmap(src: Bitmap, maxDim: Int): Bitmap {
        val w = src.width
        val h = src.height
        if (w <= maxDim && h <= maxDim) return src
        val ratio = w.toFloat() / h.toFloat()
        val (nw, nh) = if (w >= h) maxDim to (maxDim / ratio).toInt()
        else (maxDim * ratio).toInt() to maxDim
        val scaled = Bitmap.createScaledBitmap(src, nw.coerceAtLeast(1), nh.coerceAtLeast(1), true)
        if (scaled != src && !src.isRecycled) src.recycle()
        return scaled
    }

    /** Copies a finished sticker (webp/gif) into the gallery (Pictures/V7 Stickers). */
    suspend fun saveStickerToGallery(context: Context, file: File): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val mime = if (file.extension.equals("webp", true)) "image/webp" else "image/gif"
                val values = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                    put(android.provider.MediaStore.MediaColumns.MIME_TYPE, mime)
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                        put(
                            android.provider.MediaStore.MediaColumns.RELATIVE_PATH,
                            android.os.Environment.DIRECTORY_PICTURES + "/V7 Stickers"
                        )
                    }
                }
                val collection = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                    android.provider.MediaStore.Images.Media.getContentUri(
                        android.provider.MediaStore.VOLUME_EXTERNAL_PRIMARY
                    )
                } else android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                val item = context.contentResolver.insert(collection, values) ?: return@withContext false
                context.contentResolver.openOutputStream(item)?.use { os ->
                    file.inputStream().use { it.copyTo(os) }
                } ?: return@withContext false
                true
            } catch (e: Exception) {
                false
            }
        }

    /** Copies a finished GIF file into the device gallery (Pictures/V7 Stickers). */
    suspend fun saveGifToGallery(context: Context, gif: File): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val resolver = context.contentResolver
                val values = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, gif.name)
                    put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "image/gif")
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                        put(
                            android.provider.MediaStore.MediaColumns.RELATIVE_PATH,
                            android.os.Environment.DIRECTORY_PICTURES + "/V7 Stickers"
                        )
                    }
                }
                val collection = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                    android.provider.MediaStore.Images.Media.getContentUri(
                        android.provider.MediaStore.VOLUME_EXTERNAL_PRIMARY
                    )
                } else {
                    android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                }
                val item = resolver.insert(collection, values) ?: return@withContext false
                resolver.openOutputStream(item)?.use { os ->
                    gif.inputStream().use { it.copyTo(os) }
                } ?: return@withContext false
                true
            } catch (e: Exception) {
                false
            }
        }
}

package com.shabaan.v7.ui.vault

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shabaan.v7.data.local.VaultItemEntity
import com.shabaan.v7.data.repository.VaultRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class VaultViewModel @Inject constructor(
    private val repo: VaultRepository
) : ViewModel() {

    val items: StateFlow<List<VaultItemEntity>> =
        repo.vaultItems.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun restore(item: VaultItemEntity, onDone: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            val ok = repo.restore(item)
            onDone(ok)
        }
    }

    fun delete(item: VaultItemEntity, onDone: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            val ok = repo.deletePermanently(item)
            onDone(ok)
        }
    }

    /**
     * Resolve a shareable/viewable URI for an item. For encrypted items this
     * decrypts to a temp file in cache first, so it runs off the main thread.
     */
    fun resolveViewable(item: VaultItemEntity, onReady: (Uri?) -> Unit) {
        viewModelScope.launch {
            val uri = if (item.encrypted) repo.viewerUri(item) else repo.uriFor(item)
            onReady(uri)
        }
    }

    /**
     * Resolve the decrypted item as a direct File for in-app viewing. Coil and
     * ExoPlayer handle a real file path more reliably than a content uri.
     */
    fun resolveViewableFile(
        item: VaultItemEntity,
        onError: (String) -> Unit = {},
        onReady: (java.io.File?) -> Unit
    ) {
        viewModelScope.launch {
            try {
                val f = repo.materializeOrThrow(item)
                if (f == null) onError("تعذّر تجهيز الملف للعرض")
                else onReady(f)
            } catch (e: Exception) {
                onError("${e.javaClass.simpleName}: ${e.message}")
            }
        }
    }

    /** Save edited image / captured frame as a new encrypted vault item. */
    fun saveBytesToVault(
        bytes: ByteArray,
        displayName: String,
        mimeType: String,
        type: String,
        onDone: (Boolean) -> Unit = {}
    ) {
        viewModelScope.launch {
            onDone(repo.saveBytesToVault(bytes, displayName, mimeType, type))
        }
    }

    /** Export the whole vault to a backup file the user picked. */
    fun exportVault(destUri: android.net.Uri, onDone: (Int) -> Unit) {
        viewModelScope.launch { onDone(repo.exportVault(destUri)) }
    }

    /** Restore a vault backup file the user picked. */
    fun importVault(srcUri: android.net.Uri, onDone: (Int) -> Unit) {
        viewModelScope.launch { onDone(repo.importVault(srcUri)) }
    }

    /**
     * Quick-import one or more files the user picked from the system picker into
     * the vault. Each uri is read and stored as an encrypted vault item via the
     * existing saveBytesToVault path (no new crypto). Runs off the main thread;
     * reports how many succeeded.
     */
    fun importFromUris(
        context: android.content.Context,
        uris: List<Uri>,
        type: String,
        onDone: (Int) -> Unit = {}
    ) {
        if (uris.isEmpty()) { onDone(0); return }
        viewModelScope.launch {
            var ok = 0
            for (uri in uris) {
                val saved = runCatching {
                    val resolver = context.contentResolver
                    val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: return@runCatching false
                    val mime = resolver.getType(uri)
                        ?: when (type) {
                            "VIDEO" -> "video/*"; "AUDIO" -> "audio/*"; else -> "image/*"
                        }
                    val name = queryDisplayName(context, uri)
                        ?: "import_${System.currentTimeMillis()}"
                    repo.saveBytesToVault(bytes, name, mime, type)
                }.getOrDefault(false)
                if (saved) ok++
            }
            onDone(ok)
        }
    }

    private fun queryDisplayName(context: android.content.Context, uri: Uri): String? =
        runCatching {
            context.contentResolver.query(
                uri,
                arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull()
}

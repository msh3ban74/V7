package com.shabaan.v7.ui.settings

import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.border
import com.shabaan.v7.ui.theme.SecondarySilver
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Brightness6
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.imageLoader
import com.shabaan.v7.R
import com.shabaan.v7.util.Formatters
import com.shabaan.v7.util.LockManager
import com.shabaan.v7.util.PinManager
import com.shabaan.v7.util.SettingsStore

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    activity: Activity?,
    onOpenTrash: () -> Unit = {}
) {
    val ctx = LocalContext.current
    val settings = remember { SettingsStore(ctx) }

    var gridSize by remember { mutableIntStateOf(settings.gridSize) }
    var appLock by remember { mutableStateOf(settings.appLockEnabled) }
    var biometric by remember { mutableStateOf(settings.biometricEnabled) }
    var trashDays by remember { mutableIntStateOf(settings.trashRetentionDays) }
    var hasPin by remember { mutableStateOf(settings.pinHash != null) }

    var showPinDialog by remember { mutableStateOf(false) }
    var showSleepMenu by remember { mutableStateOf(false) }
    var customSleepMins by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الإعدادات", fontWeight = FontWeight.SemiBold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(14.dp, 10.dp, 14.dp, 100.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // ----- Appearance -----
            item { SectionTitle("المظهر") }
            item {
                SettingCard {
                    Row(
                        Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.GridView, contentDescription = null)
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text("حجم الشبكة", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "$gridSize columns",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Slider(
                        value = gridSize.toFloat(),
                        onValueChange = { gridSize = it.toInt() },
                        onValueChangeFinished = { settings.gridSize = gridSize },
                        valueRange = 2f..6f,
                        steps = 3,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }
            }

            // ----- Security -----
            item { SectionTitle("الأمان") }
            item {
                ToggleRow(
                    icon = Icons.Rounded.Lock,
                    title = "قفل التطبيق",
                    subtitle = "طلب الفتح للدخول إلى الخزنة",
                    checked = appLock,
                    onChange = {
                        appLock = it
                        settings.appLockEnabled = it
                        if (!it) LockManager.markUnlocked()
                    }
                )
            }
            item {
                ToggleRow(
                    icon = Icons.Rounded.Fingerprint,
                    title = "الفتح بالبصمة",
                    subtitle = "استخدم البصمة أو الوجه عند توفرها",
                    checked = biometric,
                    onChange = {
                        biometric = it
                        settings.biometricEnabled = it
                    },
                    enabled = appLock
                )
            }
            item {
                SettingRow(
                    icon = Icons.Rounded.Lock,
                    title = "رمز PIN",
                    subtitle = if (hasPin) "PIN set — tap to change" else "Not set — tap to create",
                    onClick = { showPinDialog = true }
                )
            }

            // ----- Sleep timer -----
            item { SectionTitle("مؤقت النوم") }
            item {
                val sleepActive = com.shabaan.v7.util.SleepTimer.isActive.value
                val sleepRemaining = com.shabaan.v7.util.SleepTimer.remainingMs.longValue
                SettingRow(
                    icon = Icons.Rounded.Bedtime,
                    title = "مؤقت النوم",
                    subtitle = if (sleepActive)
                        "Stops & closes in ${Formatters.duration(sleepRemaining)}"
                    else "Stop playback and close the app after a set time",
                    onClick = { showSleepMenu = true }
                )
            }

            // ----- Storage -----
            item { SectionTitle("التخزين") }
            item {
                SettingRow(
                    icon = Icons.Rounded.CloudUpload,
                    title = "نسخ احتياطي إلى Google Photos",
                    subtitle = "افتح Google Photos للنسخ، أو شارك الصور لأي تطبيق",
                    onClick = {
                        // Prefer opening Google Photos directly if installed.
                        val pm = ctx.packageManager
                        val gp = pm.getLaunchIntentForPackage("com.google.android.apps.photos")
                        if (gp != null) {
                            try {
                                ctx.startActivity(gp)
                            } catch (_: Exception) {
                                Toast.makeText(ctx, "Couldn't open Google Photos", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            // Not installed — point the user to the Play Store page.
                            try {
                                ctx.startActivity(
                                    Intent(
                                        Intent.ACTION_VIEW,
                                        Uri.parse("market://details?id=com.google.android.apps.photos")
                                    )
                                )
                            } catch (_: Exception) {
                                try {
                                    ctx.startActivity(
                                        Intent(
                                            Intent.ACTION_VIEW,
                                            Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.apps.photos")
                                        )
                                    )
                                } catch (_: Exception) {
                                    Toast.makeText(ctx, "Google Photos not available", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                )
            }
            item {
                val accessGranted = com.shabaan.v7.util.FullAccess.isGranted(ctx)
                SettingRow(
                    icon = Icons.Rounded.FolderOpen,
                    title = "الوصول الكامل للملفات",
                    subtitle = if (accessGranted)
                        "Granted — deleting files is instant, no extra prompts"
                    else "Grant once so deleting and hiding files don't ask every time",
                    onClick = {
                        if (com.shabaan.v7.util.FullAccess.isGranted(ctx)) {
                            Toast.makeText(ctx, "Full access already granted", Toast.LENGTH_SHORT).show()
                        } else {
                            com.shabaan.v7.util.FullAccess.request(ctx)
                        }
                    }
                )
            }
            item {
                SettingCard {
                    Row(
                        Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Delete, contentDescription = null)
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text("مدة الاحتفاظ بالمحذوفات", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Items in trash auto-delete after $trashDays days",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Slider(
                        value = trashDays.toFloat(),
                        onValueChange = { trashDays = it.toInt() },
                        onValueChangeFinished = { settings.trashRetentionDays = trashDays },
                        valueRange = 1f..90f,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }
            }
            item {
                SettingRow(
                    icon = Icons.Rounded.Delete,
                    title = "المحذوفات مؤخراً",
                    subtitle = "عرض واسترجاع العناصر المحذوفة",
                    onClick = onOpenTrash
                )
            }
            item {
                SettingRow(
                    icon = Icons.Rounded.CleaningServices,
                    title = "مسح ذاكرة الصور المؤقتة",
                    subtitle = "توفير المساحة المستخدمة للصور المصغرة",
                    onClick = {
                        // Memory cache is cheap; disk clear runs off the main thread.
                        ctx.imageLoader.memoryCache?.clear()
                        Thread {
                            ctx.imageLoader.diskCache?.clear()
                        }.start()
                        Toast.makeText(ctx, "Cache cleared", Toast.LENGTH_SHORT).show()
                    }
                )
            }

            // ----- Connect -----
            item { SectionTitle("تواصل مع المطوّر") }
            item {
                SettingRow(
                    icon = Icons.Rounded.Chat,
                    title = "WhatsApp",
                    subtitle = stringResource(R.string.creator_whatsapp_url),
                    onClick = { openUrl(ctx, ctx.getString(R.string.creator_whatsapp_url)) }
                )
            }
            item {
                SettingRow(
                    icon = Icons.Rounded.Public,
                    title = "Facebook",
                    subtitle = stringResource(R.string.creator_facebook_url),
                    onClick = { openUrl(ctx, ctx.getString(R.string.creator_facebook_url)) }
                )
            }

            // ----- About -----
            item { SectionTitle("عن التطبيق") }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(Modifier.padding(20.dp)) {
                        Text(
                            "V7",
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Premium gallery, music & vault.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Created by Mohammed Shabaan",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
        }
    }

    if (showSleepMenu) {
        AlertDialog(
            onDismissRequest = { showSleepMenu = false },
            title = { Text("مؤقت النوم") },
            text = {
                Column {
                    Text(
                        "After this time, playback stops and the app closes — handy " +
                            "if you fall asleep watching or listening.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(12.dp))
                    listOf(15, 30, 45, 60, 90).forEach { mins ->
                        TextButton(onClick = {
                            com.shabaan.v7.util.SleepTimer.start(mins)
                            android.widget.Toast.makeText(
                                ctx, "Sleep timer set for $mins minutes",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                            showSleepMenu = false
                        }) { Text("$mins minutes") }
                    }
                    Spacer(Modifier.height(8.dp))
                    androidx.compose.material3.HorizontalDivider(
                        color = MaterialTheme.colorScheme.outline
                    )
                    Spacer(Modifier.height(8.dp))
                    // Custom time — type any number of minutes.
                    Text(
                        "Custom",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = customSleepMins,
                            onValueChange = { v ->
                                // Digits only, max 4 chars (up to 9999 minutes).
                                if (v.length <= 4 && v.all { it.isDigit() }) customSleepMins = v
                            },
                            singleLine = true,
                            label = { Text("دقائق") },
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(8.dp))
                        TextButton(
                            enabled = (customSleepMins.toIntOrNull() ?: 0) > 0,
                            onClick = {
                                val mins = customSleepMins.toIntOrNull() ?: 0
                                if (mins > 0) {
                                    com.shabaan.v7.util.SleepTimer.start(mins)
                                    android.widget.Toast.makeText(
                                        ctx, "Sleep timer set for $mins minutes",
                                        android.widget.Toast.LENGTH_SHORT
                                    ).show()
                                    customSleepMins = ""
                                    showSleepMenu = false
                                }
                            }
                        ) { Text("ضبط") }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    com.shabaan.v7.util.SleepTimer.cancel()
                    android.widget.Toast.makeText(
                        ctx, "Sleep timer off", android.widget.Toast.LENGTH_SHORT
                    ).show()
                    showSleepMenu = false
                }) { Text("إيقاف") }
            },
            dismissButton = {
                TextButton(onClick = { showSleepMenu = false }) { Text("إلغاء") }
            }
        )
    }

    if (showPinDialog) {
        PinDialog(
            currentlySet = hasPin,
            onDismiss = { showPinDialog = false },
            onSet = { newPin ->
                settings.pinHash = PinManager.hash(newPin)
                hasPin = true
                showPinDialog = false
                Toast.makeText(ctx, "PIN saved", Toast.LENGTH_SHORT).show()
            },
            onClear = {
                settings.pinHash = null
                hasPin = false
                showPinDialog = false
                Toast.makeText(ctx, "PIN removed", Toast.LENGTH_SHORT).show()
            }
        )
    }
}


private fun openUrl(ctx: android.content.Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (_: Exception) {
        Toast.makeText(ctx, "Could not open link", Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text.uppercase(),
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 0.8.sp,
        modifier = Modifier.padding(start = 12.dp, top = 14.dp, bottom = 2.dp)
    )
}

@Composable
private fun SettingCard(content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(22.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(content = content)
    }
}

@Composable
private fun SettingRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String?,
    onClick: () -> Unit,
    trailing: (@Composable () -> Unit)? = null
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(22.dp))
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainerHighest)
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    icon,
                    contentDescription = null,
                    tint = SecondarySilver,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                if (!subtitle.isNullOrEmpty()) {
                    Text(
                        subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2
                    )
                }
            }
            trailing?.invoke()
        }
    }
}

@Composable
private fun ToggleRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
    enabled: Boolean = true
) {
    Card(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            Modifier
                .padding(16.dp)
                .clickable(enabled = enabled) { onChange(!checked) },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null,
                tint = if (enabled) MaterialTheme.colorScheme.onSurface
                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
        }
    }
}

@Composable
private fun PinDialog(
    currentlySet: Boolean,
    onDismiss: () -> Unit,
    onSet: (String) -> Unit,
    onClear: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (currentlySet) "Change PIN" else "Set PIN") },
        text = {
            Column {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { if (it.length <= 8 && it.all { c -> c.isDigit() }) pin = it },
                    label = { Text("رمز جديد (4–8 أرقام)") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = confirm,
                    onValueChange = { if (it.length <= 8 && it.all { c -> c.isDigit() }) confirm = it },
                    label = { Text("تأكيد الرمز") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
                error?.let {
                    Spacer(Modifier.height(6.dp))
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    pin.length < 4 -> error = "PIN must be at least 4 digits"
                    pin != confirm -> error = "PINs do not match"
                    else -> onSet(pin)
                }
            }) { Text("حفظ") }
        },
        dismissButton = {
            Row {
                if (currentlySet) {
                    TextButton(onClick = onClear) {
                        Text("إزالة", color = MaterialTheme.colorScheme.error)
                    }
                }
                TextButton(onClick = onDismiss) { Text("إلغاء") }
            }
        }
    )
}

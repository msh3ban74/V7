package com.shabaan.v7.util

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/**
 * Professional multi-source Quran audio system.
 *
 * - Each reciter has identifiers mapped per provider (they differ per CDN).
 * - Playback tries providers in order (primary → fallback → backup) and returns
 *   the first URL that actually responds.
 * - The provider that worked for a reciter is cached locally, so next time we
 *   try it first (fewer round-trips, faster start).
 * - Nothing here touches the UI, Media3/ExoPlayer, the mini player, scrolling,
 *   thumbnails, or the cache system. It only resolves a working URL string.
 */
object QuranSources {

    private const val TAG = "QuranSources"
    private const val PREFS = "v7_quran_sources"

    /** A provider = a CDN with a URL template. {id} = reciter id, {n} = padded surah. */
    data class Provider(
        val key: String,
        val name: String,
        val buildUrl: (reciterId: String, paddedSurah: String) -> String
    )

    /** Per-provider identifier mapping for one reciter (null = not on that provider). */
    data class ReciterSources(
        val arabicName: String,
        val englishName: String,
        val mp3quran: String? = null,      // Provider 1 (full base URL)
        val islamicNetwork: String? = null,// Provider 2 (edition id, e.g. ar.alafasy)
        val everyayah: String? = null      // Provider 3 (folder, e.g. Alafasy_128kbps)
    ) {
        /** Stable key for caching the working provider. */
        val id: String get() = (mp3quran ?: islamicNetwork ?: everyayah ?: englishName)
    }

    // ---- Providers (ordered: primary first) ----
    private val PROVIDERS: List<Provider> = listOf(
        Provider("mp3quran", "mp3quran.net") { id, n -> "$id/$n.mp3" },
        Provider("islamicNetwork", "islamic.network") { id, n ->
            // islamic.network uses non-padded surah number
            "https://cdn.islamic.network/quran/audio-surah/128/$id/${n.toInt()}.mp3"
        },
        Provider("everyayah", "everyayah.com") { id, n ->
            // everyayah serves ayah files; surah 1 ayah 1 style won't match full-surah,
            // so we only use it where a full-surah folder exists.
            "https://everyayah.com/data/$id/$n.mp3"
        }
    )

    // ---- Reciter catalog with per-provider mappings ----
    val CATALOG: List<ReciterSources> = listOf(
        ReciterSources("مشاري راشد العفاسي", "Mishary Al-Afasy",
            mp3quran = "https://server8.mp3quran.net/afs",
            islamicNetwork = "ar.alafasy"),
        ReciterSources("عبد الباسط عبد الصمد", "Abdul Basit",
            mp3quran = "https://server7.mp3quran.net/basit",
            islamicNetwork = "ar.abdulbasitmurattal"),
        ReciterSources("محمود خليل الحصري", "Mahmoud Al-Husary",
            mp3quran = "https://server13.mp3quran.net/husr",
            islamicNetwork = "ar.husary"),
        ReciterSources("محمد صديق المنشاوي", "Muhammad Al-Minshawi",
            mp3quran = "https://server10.mp3quran.net/minsh",
            islamicNetwork = "ar.minshawi"),
        ReciterSources("عبد الرحمن السديس", "Abdurrahmaan As-Sudais",
            mp3quran = "https://server11.mp3quran.net/sds",
            islamicNetwork = "ar.abdurrahmaansudais"),
        ReciterSources("سعود الشريم", "Saud Ash-Shuraym",
            mp3quran = "https://server7.mp3quran.net/shur",
            islamicNetwork = "ar.saoodshuraym"),
        ReciterSources("ماهر المعيقلي", "Maher Al-Muaiqly",
            mp3quran = "https://server12.mp3quran.net/maher",
            islamicNetwork = "ar.mahermuaiqly"),
        ReciterSources("أحمد بن علي العجمي", "Ahmed Al-Ajamy",
            mp3quran = "https://server8.mp3quran.net/ajm",
            islamicNetwork = "ar.ahmedajamy"),
        ReciterSources("أبو بكر الشاطري", "Abu Bakr Ash-Shaatree",
            mp3quran = "https://server10.mp3quran.net/shatri",
            islamicNetwork = "ar.shaatree"),
        ReciterSources("ناصر القطامي", "Nasser Al-Qatami",
            mp3quran = "https://server6.mp3quran.net/qtm"),
        ReciterSources("عبد الله الجهني", "Abdullah Al-Juhani",
            mp3quran = "https://server13.mp3quran.net/jhn"),
        ReciterSources("بندر بليلة", "Bandar Baleela",
            mp3quran = "https://server6.mp3quran.net/bna"),
        ReciterSources("ياسر الدوسري", "Yasser Al-Dossari",
            mp3quran = "https://server11.mp3quran.net/yasser"),
        ReciterSources("فارس عباد", "Fares Abbad",
            mp3quran = "https://server8.mp3quran.net/frs_a"),
        ReciterSources("إدريس أبكر", "Idrees Abkar",
            mp3quran = "https://server6.mp3quran.net/akdr"),
        ReciterSources("محمد جبريل", "Muhammad Jibreel",
            mp3quran = "https://server8.mp3quran.net/jbrl"),
        ReciterSources("محمد أيوب", "Muhammad Ayyoub",
            mp3quran = "https://server10.mp3quran.net/ayyub",
            islamicNetwork = "ar.muhammadayyoub"),
        ReciterSources("سعد الغامدي", "Saad Al-Ghamdi",
            mp3quran = "https://server7.mp3quran.net/s_gmd"),
        ReciterSources("علي جابر", "Ali Jaber",
            mp3quran = "https://server11.mp3quran.net/a_jbr"),
        ReciterSources("عبد الله بصفر", "Abdullah Basfar",
            mp3quran = "https://server13.mp3quran.net/bsfr",
            islamicNetwork = "ar.abdullahbasfar"),
        ReciterSources("عبد الباسط (مجوّد)", "Abdul Basit (Mujawwad)",
            islamicNetwork = "ar.abdulsamad"),
        ReciterSources("علي الحذيفي", "Ali Al-Hudhaify",
            mp3quran = "https://server10.mp3quran.net/hthfi",
            islamicNetwork = "ar.hudhaify"),
        ReciterSources("هاني الرفاعي", "Hani Ar-Rifai",
            mp3quran = "https://server13.mp3quran.net/rifai",
            islamicNetwork = "ar.hanirifai"),
        ReciterSources("محمد الطبلاوي", "Mohammad Al-Tablawi",
            mp3quran = "https://server6.mp3quran.net/tblawi"),
        ReciterSources("عبد الله المطرود", "Abdullah Al-Matroud",
            mp3quran = "https://server12.mp3quran.net/mtrod"),
        ReciterSources("صلاح بوخاطر", "Salah Bukhatir",
            mp3quran = "https://server11.mp3quran.net/sahl"),
        ReciterSources("عبد الباري الثبيتي", "Abdul Bari Ath-Thubaity",
            mp3quran = "https://server7.mp3quran.net/thubti"),
        ReciterSources("عبد الرشيد صوفي", "Abdul Rashid Sufi",
            mp3quran = "https://server6.mp3quran.net/soufi"),
        ReciterSources("خليفة الطنيجي", "Khalifa Al-Tunaiji",
            mp3quran = "https://server11.mp3quran.net/h_khashi"),
        ReciterSources("أحمد العجمي (مصحف مرتل)", "Ahmad Al-Ajamy 2",
            islamicNetwork = "ar.ahmedajamy")
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Remember which provider worked for a reciter. */
    private fun cacheWorkingProvider(ctx: Context, reciterId: String, providerKey: String) {
        prefs(ctx).edit().putString("prov_$reciterId", providerKey).apply()
    }

    private fun cachedProvider(ctx: Context, reciterId: String): String? =
        prefs(ctx).getString("prov_$reciterId", null)

    /**
     * Resolve a working full-surah URL for a reciter, trying the cached provider
     * first, then the rest in priority order. Returns null only if ALL fail.
     * This does a HEAD check; the returned URL is then handed to ExoPlayer as-is.
     */
    suspend fun resolveUrl(
        ctx: Context,
        reciter: ReciterSources,
        surahNumber: Int
    ): String? = withContext(Dispatchers.IO) {
        val padded = surahNumber.toString().padStart(3, '0')

        // Build the list of (provider, url) candidates this reciter supports.
        val candidates = buildList {
            PROVIDERS.forEach { p ->
                val id = when (p.key) {
                    "mp3quran" -> reciter.mp3quran
                    "islamicNetwork" -> reciter.islamicNetwork
                    "everyayah" -> reciter.everyayah
                    else -> null
                }
                if (id != null) add(p to p.buildUrl(id, padded))
            }
        }
        if (candidates.isEmpty()) {
            Log.w(TAG, "No providers mapped for ${reciter.englishName}")
            return@withContext null
        }

        // Put the previously-successful provider first.
        val cached = cachedProvider(ctx, reciter.id)
        val ordered = candidates.sortedByDescending { it.first.key == cached }

        for ((provider, url) in ordered) {
            if (headOk(url)) {
                Log.i(TAG, "OK ${reciter.englishName} via ${provider.name} → $url")
                cacheWorkingProvider(ctx, reciter.id, provider.key)
                return@withContext url
            } else {
                Log.w(TAG, "FALLBACK ${reciter.englishName}: ${provider.name} failed → $url")
            }
        }
        Log.e(TAG, "ALL providers failed for ${reciter.englishName}")
        null
    }

    /** Quick check that a reciter has at least one responding source. */
    suspend fun hasAnySource(reciter: ReciterSources): Boolean = withContext(Dispatchers.IO) {
        val padded = "001"
        PROVIDERS.any { p ->
            val id = when (p.key) {
                "mp3quran" -> reciter.mp3quran
                "islamicNetwork" -> reciter.islamicNetwork
                "everyayah" -> reciter.everyayah
                else -> null
            }
            id != null && headOk(p.buildUrl(id, padded))
        }
    }

    private fun headOk(url: String): Boolean = try {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "HEAD"
            connectTimeout = 4000
            readTimeout = 4000
            instanceFollowRedirects = true
        }
        val code = conn.responseCode
        conn.disconnect()
        code in 200..399
    } catch (e: Exception) {
        Log.w(TAG, "headOk error ${e.javaClass.simpleName} → $url")
        false
    }
}

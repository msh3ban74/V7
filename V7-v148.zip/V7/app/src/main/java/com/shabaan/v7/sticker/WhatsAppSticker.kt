package com.shabaan.v7.sticker

import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.shabaan.v7.util.StickerPackStore

/**
 * Sends the official WhatsApp "enable sticker pack" intent so a V7 pack shows up
 * in the user's WhatsApp sticker tray. This is the only supported way to get an
 * animated sticker to actually animate in WhatsApp (sharing a .webp via
 * ACTION_SEND just inserts it as a static image).
 *
 * Requirements enforced before sending:
 *   - the pack must have between 3 and 30 stickers (WhatsApp rejects otherwise).
 */
object WhatsAppSticker {

    private const val EXTRA_PACK_ID = "sticker_pack_id"
    private const val EXTRA_AUTHORITY = "sticker_pack_authority"
    private const val EXTRA_PACK_NAME = "sticker_pack_name"
    private const val ACTION_ENABLE = "com.whatsapp.intent.action.ENABLE_STICKER_PACK"

    private val WA_PACKAGES = listOf("com.whatsapp", "com.whatsapp.w4b")

    /** True if either WhatsApp or WhatsApp Business is installed. */
    fun isWhatsAppInstalled(context: Context): Boolean =
        WA_PACKAGES.any { pkg ->
            runCatching { context.packageManager.getPackageInfo(pkg, 0) }.isSuccess
        }

    /**
     * Launches WhatsApp's add-pack flow. Returns null on success, or a
     * human-readable error message describing why it couldn't proceed.
     */
    fun addPackToWhatsApp(context: Context, packId: String): String? {
        val pack = StickerPackStore.get(context, packId)
            ?: return "Pack not found"
        if (pack.stickers.size < StickerPackStore.MIN_STICKERS) {
            return "Add at least ${StickerPackStore.MIN_STICKERS} stickers first " +
                "(you have ${pack.stickers.size})"
        }
        if (pack.stickers.size > StickerPackStore.MAX_STICKERS) {
            return "Too many stickers (max ${StickerPackStore.MAX_STICKERS})"
        }

        val authority = StickerContentProvider.authority(context.packageName)
        val intent = Intent(ACTION_ENABLE).apply {
            putExtra(EXTRA_PACK_ID, pack.identifier)
            putExtra(EXTRA_AUTHORITY, authority)
            putExtra(EXTRA_PACK_NAME, pack.name)
        }

        // Prefer a directly-installed WhatsApp; otherwise let the user choose.
        val installed = WA_PACKAGES.firstOrNull { pkg ->
            runCatching { context.packageManager.getPackageInfo(pkg, 0) }.isSuccess
        }
        return try {
            if (installed != null) {
                intent.setPackage(installed)
                context.startActivity(intent)
            } else {
                context.startActivity(
                    Intent.createChooser(intent, "Add sticker pack to WhatsApp")
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            null
        } catch (e: Exception) {
            "WhatsApp could not be opened. Make sure it's installed and up to date."
        }
    }

    /** Convenience: add to WhatsApp and toast the error if there is one. */
    fun addPackOrToast(context: Context, packId: String) {
        val err = addPackToWhatsApp(context, packId)
        if (err != null) Toast.makeText(context, err, Toast.LENGTH_LONG).show()
    }
}

package com.shabaan.v7.ui.videos

import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.shabaan.v7.util.FfmpegStickerMaker
import com.shabaan.v7.util.Formatters
import com.shabaan.v7.util.StickerMaker
import kotlinx.coroutines.launch

/**
 * Dedicated Sticker Creator: trim a segment with live audio preview, pick a fit
 * mode, then generate a genuine animated WebP (FFmpeg, with a safe fallback).
 * Platinum Silver styling, presented as a bottom sheet so the video stays visible.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StickerCreatorSheet(
    uri: Uri,
    mediaId: Long,
    durationMs: Long,
    onScrub: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val sheetState = rememberModalBottomSheetState()

    var startMs by remember { mutableFloatStateOf(0f) }
    var endMs by remember { mutableFloatStateOf(durationMs.coerceAtMost(3000).toFloat()) }
    var fit by remember { mutableStateOf(FfmpegStickerMaker.FitMode.CENTER) }
    var working by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = { if (!working) onDismiss() },
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        scrimColor = androidx.compose.ui.graphics.Color.Transparent
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
        ) {
            Text(
                "WhatsApp Sticker",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "Trim up to 3 seconds. The video keeps playing so you see exactly what will be exported.",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(16.dp))

            com.shabaan.v7.ui.components.WaveformTrimmer(
                uri = uri,
                durationMs = durationMs,
                startMs = startMs,
                endMs = endMs,
                onChange = { s, e ->
                    // Clamp selection to a 3s max (WhatsApp animated sticker limit).
                    var ns = s; var ne = e
                    if (ne - ns > 3000f) {
                        if (ns != startMs) ns = ne - 3000f else ne = ns + 3000f
                    }
                    startMs = ns; endMs = ne
                },
                seed = mediaId,
                audioPreview = false,
                onScrub = { ms -> onScrub(ms.toLong()) }
            )
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth()) {
                Text("From " + Formatters.duration(startMs.toLong()), style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.weight(1f))
                Text(Formatters.duration((endMs - startMs).toLong()) + " clip", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.weight(1f))
                Text("To " + Formatters.duration(endMs.toLong()), style = MaterialTheme.typography.labelMedium)
            }

            Spacer(Modifier.height(20.dp))
            Text("Fit", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FfmpegStickerMaker.FitMode.values().forEach { mode ->
                    val selected = fit == mode
                    FilterChip(
                        selected = selected,
                        onClick = { fit = mode },
                        label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) }
                    )
                }
            }

            Spacer(Modifier.height(24.dp))
            if (working) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(12.dp))
                    Text("Generating animated sticker…", style = MaterialTheme.typography.bodyMedium)
                }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = {
                        working = true
                        scope.launch {
                            // Create a proper WhatsApp sticker pack (animated webp
                            // via libwebp) and register the first sticker. WhatsApp
                            // only animates stickers added through a pack, not files
                            // shared via ACTION_SEND.
                            val result = com.shabaan.v7.util.StickerPackMaker
                                .addToCurrentPack(
                                    ctx, uri,
                                    startMs.toLong(), (endMs - startMs).toLong()
                                )
                            working = false
                            when (result) {
                                is com.shabaan.v7.util.StickerPackMaker.Result.Success -> {
                                    val pack = result.pack
                                    if (pack.isAddable) {
                                        com.shabaan.v7.sticker.WhatsAppSticker
                                            .addPackOrToast(ctx, pack.identifier)
                                    } else {
                                        android.widget.Toast.makeText(
                                            ctx,
                                            "Sticker added. Add " +
                                                "${com.shabaan.v7.util.StickerPackStore.MIN_STICKERS - pack.stickers.size} " +
                                                "more to send the pack to WhatsApp.",
                                            android.widget.Toast.LENGTH_LONG
                                        ).show()
                                    }
                                    onDismiss()
                                }
                                is com.shabaan.v7.util.StickerPackMaker.Result.Error -> {
                                    android.widget.Toast.makeText(
                                        ctx, result.message,
                                        android.widget.Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        }
                    }) {
                        Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Create sticker")
                    }
                }
            }
        }
    }
}

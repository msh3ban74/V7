package com.shabaan.v7.data.repository

import android.app.RecoverableSecurityException
import android.content.ContentValues
import android.content.Context
import android.content.IntentSender
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.FileProvider
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKey
import com.shabaan.v7.data.local.V7Database
import com.shabaan.v7.data.local.VaultItemEntity
import com.shabaan.v7.data.model.MediaItem
import com.shabaan.v7.data.model.MediaType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

sealed class VaultMoveResult {
    object Success : VaultMoveResult()
    data class NeedsUserAction(val intentSender: IntentSender) : VaultMoveResult()
    data class Error(val message: String) : VaultMoveResult()
}

/**
 * Secure storage for media items.
 *
 * Files are copied to app-private `filesDir/vault/`. When [enableEncryption] is
 * true, files are wrapped in an [EncryptedFile] (AES-256 GCM, key in Android
 * Keystore) — at rest the bytes are unreadable without device unlock.
 */
class VaultRepository(private val context: Context) {

    private val db = V7Database.get(context)
    private val vaultDir: File = File(context.filesDir, "vault").apply {
        if (!exists()) mkdirs()
    }

    /** Encrypt newly added items by default. Existing unencrypted items keep working. */
    @Volatile var enableEncryption: Boolean = true

    val vaultItems = db.vaultDao().observeAll()
    fun byType(type: MediaType) = db.vaultDao().observeByType(type.name)

    private val masterKey: MasterKey by lazy {
        MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
    }

    private fun encryptedFile(file: File): EncryptedFile =
        EncryptedFile.Builder(
            context,
            file,
            masterKey,
            EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
        ).build()

    /** Pull media item bytes into the vault directory and remove from MediaStore. */
    suspend fun moveToVault(item: MediaItem): VaultMoveResult = withContext(Dispatchers.IO) {
        try {
            val cleanName = item.name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val ext = if (enableEncryption) ".enc" else ""
            val target = File(vaultDir, "${System.currentTimeMillis()}_$cleanName$ext")

            val source = context.contentResolver.openInputStream(item.uri)
                ?: return@withContext VaultMoveResult.Error("Source unreadable")

            source.use { input ->
                if (enableEncryption) {
                    encryptedFile(target).openFileOutput().use { output ->
                        input.copyTo(output, 64 * 1024)
                    }
                } else {
                    FileOutputStream(target).use { output ->
                        input.copyTo(output, 64 * 1024)
                    }
                }
            }

            db.vaultDao().insert(
                VaultItemEntity(
                    originalName = item.name,
                    storedPath = target.absolutePath,
                    mimeType = item.mimeType,
                    type = item.type.name,
                    size = target.length(),
                    duration = item.duration,
                    addedAt = System.currentTimeMillis(),
                    encrypted = enableEncryption
                )
            )

            try {
                val rows = context.contentResolver.delete(item.uri, null, null)
                if (rows <= 0) VaultMoveResult.Error("Original could not be removed")
                else VaultMoveResult.Success
            } catch (e: SecurityException) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val pending = MediaStore.createDeleteRequest(
                        context.contentResolver,
                        listOf(item.uri)
                    )
                    VaultMoveResult.NeedsUserAction(pending.intentSender)
                } else if (e is RecoverableSecurityException) {
                    VaultMoveResult.NeedsUserAction(e.userAction.actionIntent.intentSender)
                } else {
                    VaultMoveResult.Error(e.message ?: "Permission denied")
                }
            }
        } catch (e: Exception) {
            VaultMoveResult.Error(e.message ?: "Unknown error")
        }
    }

    /** Restore a vault item back to public MediaStore. */
    suspend fun restore(item: VaultItemEntity): Boolean = withContext(Dispatchers.IO) {
        try {
            val srcFile = File(item.storedPath)
            if (!srcFile.exists()) return@withContext false

            val coll = when (item.type) {
                MediaType.VIDEO.name -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                MediaType.IMAGE.name -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                MediaType.AUDIO.name -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                else -> return@withContext false
            }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, item.originalName)
                put(MediaStore.MediaColumns.MIME_TYPE, item.mimeType)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val rel = when (item.type) {
                        MediaType.VIDEO.name -> "Movies/V7"
                        MediaType.IMAGE.name -> "Pictures/V7"
                        MediaType.AUDIO.name -> "Music/V7"
                        else -> "Download/V7"
                    }
                    put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
            }
            val newUri = context.contentResolver.insert(coll, values) ?: return@withContext false
            context.contentResolver.openOutputStream(newUri)?.use { out ->
                if (item.encrypted) {
                    encryptedFile(srcFile).openFileInput().use { it.copyTo(out, 64 * 1024) }
                } else {
                    FileInputStream(srcFile).use { it.copyTo(out, 64 * 1024) }
                }
            } ?: return@withContext false

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                context.contentResolver.update(newUri, values, null, null)
            }

            srcFile.delete()
            db.vaultDao().deleteById(item.id)
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun deletePermanently(item: VaultItemEntity): Boolean = withContext(Dispatchers.IO) {
        try {
            File(item.storedPath).delete()
            db.vaultDao().deleteById(item.id)
            true
        } catch (e: Exception) { false }
    }

    /** Returns a content URI to share. Only safe for *unencrypted* items. */
    fun uriFor(item: VaultItemEntity): Uri? {
        if (item.encrypted) return null
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            File(item.storedPath)
        )
    }

    /** Fires the system share sheet for the given (already-resolved) content uris. */
    fun shareUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val intent = if (uris.size == 1) {
            android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                putExtra(android.content.Intent.EXTRA_STREAM, uris.first())
            }
        } else {
            android.content.Intent(android.content.Intent.ACTION_SEND_MULTIPLE).apply {
                putParcelableArrayListExtra(
                    android.content.Intent.EXTRA_STREAM,
                    ArrayList(uris)
                )
            }
        }
        intent.type = "*/*"
        intent.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val chooser = android.content.Intent.createChooser(intent, "Share")
        chooser.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    /**
     * Decrypt an encrypted vault item to a temp file for viewing.
     * The caller must delete the returned file when done.
     */
    suspend fun materializeForViewing(item: VaultItemEntity): File? = withContext(Dispatchers.IO) {
        if (!item.encrypted) return@withContext File(item.storedPath)
        try {
            // Keep the real file extension so the FileProvider reports the correct
            // MIME type — otherwise ExoPlayer may play audio only and image
            // decoders refuse to open the file.
            val src = File(item.storedPath)
            val nameExt = item.originalName.substringAfterLast('.', "")
            val storedExt = src.name.substringAfterLast('.', "")
            val ext = when {
                nameExt.isNotEmpty() -> ".$nameExt"
                storedExt.isNotEmpty() -> ".$storedExt"
                item.type == MediaType.VIDEO.name -> ".mp4"
                item.type == MediaType.IMAGE.name -> ".jpg"
                else -> ".mp3"
            }
            val tmp = File(context.cacheDir, "vault_view_${item.id}$ext")
            // Reuse a previously decrypted temp file (faster re-open).
            if (tmp.exists() && tmp.length() > 0) return@withContext tmp
            encryptedFile(src).openFileInput().use { input ->
                FileOutputStream(tmp).use { output -> input.copyTo(output, 64 * 1024) }
            }
            tmp
        } catch (e: Exception) {
            null
        }
    }

    suspend fun viewerUri(item: VaultItemEntity): Uri? {
        val file = materializeForViewing(item) ?: return null
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
    }
}

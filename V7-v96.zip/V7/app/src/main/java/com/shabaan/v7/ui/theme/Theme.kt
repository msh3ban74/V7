package com.shabaan.v7.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.shabaan.v7.util.ThemeMode

private val LightScheme = lightColorScheme(
    primary = Titanium700,
    onPrimary = Titanium50,
    primaryContainer = Titanium200,
    onPrimaryContainer = Titanium900,

    secondary = Titanium600,
    onSecondary = Titanium50,
    secondaryContainer = Titanium100,
    onSecondaryContainer = Titanium800,

    tertiary = TitaniumAccent,
    onTertiary = Color.White,

    background = Titanium50,
    onBackground = Titanium900,

    surface = Color.White,
    onSurface = Titanium900,
    surfaceVariant = Titanium100,
    onSurfaceVariant = Titanium700,

    outline = Titanium300,
    outlineVariant = Titanium200,
    error = Color(0xFFB3261E),
    onError = Color.White
)

private val DarkScheme = darkColorScheme(
    primary = PrimarySilver,
    onPrimary = V7Background,
    primaryContainer = V7Card,
    onPrimaryContainer = BrightSilver,

    secondary = AccentSilver,
    onSecondary = V7Background,
    secondaryContainer = V7Card,
    onSecondaryContainer = BrightSilver,

    tertiary = BrightSilver,
    onTertiary = V7Background,

    background = V7Background,
    onBackground = TextPrimary,

    surface = V7Surface,
    onSurface = TextPrimary,
    surfaceVariant = PremiumCard,
    onSurfaceVariant = TextSecondary,

    surfaceContainer = PremiumCard,
    surfaceContainerHigh = Color(0xFF1C2228),
    surfaceContainerHighest = Color(0xFF222931),

    outline = SilverBorder,
    outlineVariant = SilverBorder,
    error = Color(0xFFF2B8B5),
    onError = Color(0xFF601410)
)

// Optional "Titanium Silver" skin — metallic blue-grey accents on the same
// near-black surfaces. Selected from Settings; the default look stays Platinum.
private val TitaniumScheme = darkColorScheme(
    primary = Color(0xFF9FB0BA),
    onPrimary = V7Background,
    primaryContainer = V7Card,
    onPrimaryContainer = Color(0xFFC4D0D8),

    secondary = Color(0xFF607D8B),
    onSecondary = V7Background,
    secondaryContainer = V7Card,
    onSecondaryContainer = Color(0xFFC4D0D8),

    tertiary = Color(0xFFC4D0D8),
    onTertiary = V7Background,

    background = V7Background,
    onBackground = TextPrimary,

    surface = V7Surface,
    onSurface = TextPrimary,
    surfaceVariant = PremiumCard,
    onSurfaceVariant = TextSecondary,

    surfaceContainer = PremiumCard,
    surfaceContainerHigh = Color(0xFF1C2228),
    surfaceContainerHighest = Color(0xFF222931),

    outline = Color(0xFF3A4750),
    outlineVariant = Color(0xFF2A343C),
    error = Color(0xFFF2B8B5),
    onError = Color(0xFF601410)
)

// ✨ Obsidian Gold — deep black with warm gold accents. Royal, luxurious.
private val ObsidianGoldScheme = darkColorScheme(
    primary = Color(0xFFD4AF37),
    onPrimary = Color(0xFF1A1400),
    primaryContainer = Color(0xFF2A2410),
    onPrimaryContainer = Color(0xFFF0D98C),
    secondary = Color(0xFFBFA14A),
    onSecondary = Color(0xFF1A1400),
    secondaryContainer = Color(0xFF252010),
    onSecondaryContainer = Color(0xFFF0D98C),
    tertiary = Color(0xFFF0D98C),
    onTertiary = Color(0xFF1A1400),
    background = Color(0xFF09090A),
    onBackground = Color(0xFFF2EFE4),
    surface = Color(0xFF0E0E10),
    onSurface = Color(0xFFF2EFE4),
    surfaceVariant = Color(0xFF17160F),
    onSurfaceVariant = Color(0xFFC9C3A8),
    surfaceContainer = Color(0xFF141310),
    surfaceContainerHigh = Color(0xFF1B1A14),
    surfaceContainerHighest = Color(0xFF222018),
    outline = Color(0xFF4A4327),
    outlineVariant = Color(0xFF2E2A1A),
    error = Color(0xFFF2B8B5),
    onError = Color(0xFF601410)
)

// 💎 Sapphire — deep metallic blue. Cool, techy, elegant.
private val SapphireScheme = darkColorScheme(
    primary = Color(0xFF6FA8FF),
    onPrimary = Color(0xFF001A33),
    primaryContainer = Color(0xFF0F2740),
    onPrimaryContainer = Color(0xFFBBD6FF),
    secondary = Color(0xFF4F8FD9),
    onSecondary = Color(0xFF001A33),
    secondaryContainer = Color(0xFF0E2238),
    onSecondaryContainer = Color(0xFFBBD6FF),
    tertiary = Color(0xFFBBD6FF),
    onTertiary = Color(0xFF001A33),
    background = Color(0xFF070A0F),
    onBackground = Color(0xFFE6EEF8),
    surface = Color(0xFF0B0F16),
    onSurface = Color(0xFFE6EEF8),
    surfaceVariant = Color(0xFF111824),
    onSurfaceVariant = Color(0xFFA8BACF),
    surfaceContainer = Color(0xFF0E141E),
    surfaceContainerHigh = Color(0xFF141C28),
    surfaceContainerHighest = Color(0xFF1B2533),
    outline = Color(0xFF2A3A4F),
    outlineVariant = Color(0xFF1C2836),
    error = Color(0xFFF2B8B5),
    onError = Color(0xFF601410)
)

// 🌹 Rose Gold — warm pink-gold on charcoal. Soft, classy, distinctive.
private val RoseGoldScheme = darkColorScheme(
    primary = Color(0xFFE6B0A6),
    onPrimary = Color(0xFF2A1512),
    primaryContainer = Color(0xFF3A201C),
    onPrimaryContainer = Color(0xFFF7D6CE),
    secondary = Color(0xFFD49A8E),
    onSecondary = Color(0xFF2A1512),
    secondaryContainer = Color(0xFF331C18),
    onSecondaryContainer = Color(0xFFF7D6CE),
    tertiary = Color(0xFFF7D6CE),
    onTertiary = Color(0xFF2A1512),
    background = Color(0xFF0C0A0A),
    onBackground = Color(0xFFF5ECEA),
    surface = Color(0xFF110E0E),
    onSurface = Color(0xFFF5ECEA),
    surfaceVariant = Color(0xFF1E1614),
    onSurfaceVariant = Color(0xFFCBB8B3),
    surfaceContainer = Color(0xFF171212),
    surfaceContainerHigh = Color(0xFF1F1817),
    surfaceContainerHighest = Color(0xFF271E1D),
    outline = Color(0xFF4E3833),
    outlineVariant = Color(0xFF312221),
    error = Color(0xFFF2B8B5),
    onError = Color(0xFF601410)
)

private val V7Shapes = androidx.compose.material3.Shapes(
    // Softer, more rounded corners give a modern, premium, "future" feel while
    // staying calm and minimal.
    extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
    small = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
    medium = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
    large = androidx.compose.foundation.shape.RoundedCornerShape(26.dp),
    extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(34.dp)
)

@Composable
fun V7Theme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    // The app's identity is a dark look, so we always use a dark-based scheme
    // regardless of the system/light setting. The user can opt into any of the
    // optional premium skins from Settings.
    val scheme = when (themeMode) {
        ThemeMode.TITANIUM -> TitaniumScheme
        ThemeMode.OBSIDIAN_GOLD -> ObsidianGoldScheme
        ThemeMode.SAPPHIRE -> SapphireScheme
        ThemeMode.ROSE_GOLD -> RoseGoldScheme
        else -> DarkScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = Color.Transparent.value.toInt()
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = scheme.background.luminance() > 0.5f
            controller.isAppearanceLightNavigationBars = scheme.background.luminance() > 0.5f
        }
    }
    MaterialTheme(
        colorScheme = scheme,
        typography = V7Typography,
        shapes = V7Shapes,
        content = content
    )
}

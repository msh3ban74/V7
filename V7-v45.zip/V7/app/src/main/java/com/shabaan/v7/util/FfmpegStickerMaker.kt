package com.shabaan.v7.util

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Generates a genuine animated WebP WhatsApp sticker from a video segment using
 * FFmpeg (ffmpeg-kit). Output: 512x512 animated, looping, optimized .webp.
 *
 * If the FFmpeg library is unavailable at runtime, [isAvailable] returns false
 * and callers should fall back to [AnimatedWebpEncoder].
 */
object FfmpegStickerMaker {

    enum class FitMode { FIT, FILL, CENTER }

    /** True if the ffmpeg-kit native library actually loaded on this device. */
    fun isAvailable(): Boolean = try {
        Class.forName("com.arthenica.ffmpegkit.FFmpegKit")
        true
    } catch (e: Throwable) {
        false
    }

    /**
     * Build the WhatsApp sticker. Returns the output .webp File on success, null
     * on failure. WhatsApp animated stickers must be 512x512, <500KB, <~3s.
     */
    suspend fun create(
        context: Context,
        input: Uri,
        startMs: Long,
        endMs: Long,
        fit: FitMode
    ): File? = withContext(Dispatchers.IO) {
        if (!isAvailable()) return@withContext null
        try {
            // Resolve the input to a real file path FFmpeg can read.
            val inputPath = resolveInputPath(context, input) ?: return@withContext null
            val out = File(context.cacheDir, "v7_sticker_${System.currentTimeMillis()}.webp")
            val durationSec = ((endMs - startMs).coerceIn(500, 3000)) / 1000.0
            val startSec = startMs / 1000.0

            // Scale/crop filter to a 512x512 square per the chosen fit mode.
            val vf = when (fit) {
                FitMode.FILL ->
                    // Crop center to square, then scale to 512.
                    "crop='min(iw,ih)':'min(iw,ih)',scale=512:512"
                FitMode.FIT ->
                    // Letterbox: fit inside 512 with transparent padding.
                    "scale=512:512:force_original_aspect_ratio=decrease," +
                        "pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000"
                FitMode.CENTER ->
                    // Scale down longest side to 512 keeping ratio, pad to square.
                    "scale='if(gt(iw,ih),512,-1)':'if(gt(iw,ih),-1,512)'," +
                        "pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000"
            }

            // -an: drop audio. libwebp_anim: real animated WebP. loop 0: infinite.
            val cmd = buildString {
                append("-y ")
                append("-ss $startSec ")
                append("-t $durationSec ")
                append("-i \"$inputPath\" ")
                append("-an ")
                append("-vf \"$vf,fps=15\" ")
                append("-c:v libwebp_anim ")
                append("-loop 0 ")
                append("-preset default ")
                append("-q:v 70 ")
                append("-compression_level 6 ")
                append("\"${out.absolutePath}\"")
            }

            val session = com.arthenica.ffmpegkit.FFmpegKit.execute(cmd)
            val rc = session.returnCode
            if (com.arthenica.ffmpegkit.ReturnCode.isSuccess(rc) && out.exists() && out.length() > 0) {
                out
            } else {
                out.delete()
                null
            }
        } catch (e: Throwable) {
            null
        }
    }

    private fun resolveInputPath(context: Context, uri: Uri): String? {
        // content:// → copy to a temp file FFmpeg can open by path.
        return try {
            if (uri.scheme == "file") return uri.path
            val tmp = File(context.cacheDir, "v7_sticker_src_${System.currentTimeMillis()}.mp4")
            context.contentResolver.openInputStream(uri)?.use { input ->
                tmp.outputStream().use { input.copyTo(it, 256 * 1024) }
            } ?: return null
            tmp.absolutePath
        } catch (e: Exception) {
            null
        }
    }
}

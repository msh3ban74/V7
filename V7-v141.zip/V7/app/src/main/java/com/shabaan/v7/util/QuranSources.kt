package com.shabaan.v7.util

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/**
 * Professional multi-source Quran audio system.
 *
 * - Each reciter has identifiers mapped per provider (they differ per CDN).
 * - Playback tries providers in order (primary → fallback → backup) and returns
 *   the first URL that actually responds.
 * - The provider that worked for a reciter is cached locally, so next time we
 *   try it first (fewer round-trips, faster start).
 * - Nothing here touches the UI, Media3/ExoPlayer, the mini player, scrolling,
 *   thumbnails, or the cache system. It only resolves a working URL string.
 */
object QuranSources {

    private const val TAG = "QuranSources"
    private const val PREFS = "v7_quran_sources"

    /** A provider = a CDN with a URL template. {id} = reciter id, {n} = padded surah. */
    data class Provider(
        val key: String,
        val name: String,
        val buildUrl: (reciterId: String, paddedSurah: String) -> String
    )

    /** Per-provider identifier mapping for one reciter (null = not on that provider). */
    data class ReciterSources(
        val arabicName: String,
        val englishName: String,
        val mp3quran: String? = null,      // Provider 1 (full base URL)
        val islamicNetwork: String? = null,// Provider 2 (edition id, e.g. ar.alafasy)
        val everyayah: String? = null,     // Provider 3 (folder, e.g. Alafasy_128kbps)
        val quranicaudio: String? = null   // Provider 4 (quranicaudio.com subfolder)
    ) {
        /** Stable key for caching the working provider. */
        val id: String get() = (mp3quran ?: islamicNetwork ?: everyayah ?: quranicaudio ?: englishName)
    }

    // ---- Providers (ordered: primary first) ----
    private val PROVIDERS: List<Provider> = listOf(
        Provider("mp3quran", "mp3quran.net") { id, n -> "$id/$n.mp3" },
        Provider("islamicNetwork", "islamic.network") { id, n ->
            // islamic.network uses non-padded surah number
            "https://cdn.islamic.network/quran/audio-surah/128/$id/${n.toInt()}.mp3"
        },
        Provider("everyayah", "everyayah.com") { id, n ->
            // everyayah serves ayah files; surah 1 ayah 1 style won't match full-surah,
            // so we only use it where a full-surah folder exists.
            "https://everyayah.com/data/$id/$n.mp3"
        },
        Provider("quranicaudio", "quranicaudio.com") { id, n ->
            // quranicaudio.com serves full-surah mp3s under a per-reciter folder.
            "https://download.quranicaudio.com/quran/$id/$n.mp3"
        },
        Provider("quranicaudioStream", "quranicaudio (stream)") { id, n ->
            // Streaming mirror of quranicaudio — same folders, different host.
            "https://streams.quranicaudio.com/quran/$id/$n.mp3"
        },
        Provider("islamic2", "islamic.network (192)") { id, n ->
            // Higher-bitrate (192k) edition on the same trusted CDN as provider 2.
            "https://cdn.islamic.network/quran/audio-surah/192/$id/${n.toInt()}.mp3"
        }
    )

    // ---- Reciter catalog with per-provider mappings ----
    val CATALOG: List<ReciterSources> = listOf(
        ReciterSources("مشاري راشد العفاسي", "Mishary Al-Afasy",
            mp3quran = "https://server8.mp3quran.net/afs",
            islamicNetwork = "ar.alafasy",
            quranicaudio = "mishaari_raashid_al_3afaasee"),
        ReciterSources("عبد الباسط عبد الصمد", "Abdul Basit",
            mp3quran = "https://server7.mp3quran.net/basit",
            islamicNetwork = "ar.abdulbasitmurattal",
            quranicaudio = "abdul_basit_murattal"),
        ReciterSources("محمود خليل الحصري", "Mahmoud Al-Husary",
            mp3quran = "https://server13.mp3quran.net/husr",
            islamicNetwork = "ar.husary",
            quranicaudio = "mahmoud_khalil_al-husary"),
        ReciterSources("محمد صديق المنشاوي", "Muhammad Al-Minshawi",
            mp3quran = "https://server10.mp3quran.net/minsh",
            islamicNetwork = "ar.minshawi",
            quranicaudio = "minshawy_murattal"),
        ReciterSources("عبد الرحمن السديس", "Abdurrahmaan As-Sudais",
            mp3quran = "https://server11.mp3quran.net/sds",
            islamicNetwork = "ar.abdurrahmaansudais",
            quranicaudio = "abdurrahmaan_as-sudays"),
        ReciterSources("سعود الشريم", "Saud Ash-Shuraym",
            mp3quran = "https://server7.mp3quran.net/shur",
            islamicNetwork = "ar.saoodshuraym"),
        ReciterSources("ماهر المعيقلي", "Maher Al-Muaiqly",
            mp3quran = "https://server12.mp3quran.net/maher",
            islamicNetwork = "ar.mahermuaiqly"),
        ReciterSources("أحمد بن علي العجمي", "Ahmed Al-Ajamy",
            mp3quran = "https://server8.mp3quran.net/ajm",
            islamicNetwork = "ar.ahmedajamy"),
        ReciterSources("أبو بكر الشاطري", "Abu Bakr Ash-Shaatree",
            mp3quran = "https://server10.mp3quran.net/shatri",
            islamicNetwork = "ar.shaatree"),
        ReciterSources("ناصر القطامي", "Nasser Al-Qatami",
            mp3quran = "https://server6.mp3quran.net/qtm"),
        ReciterSources("عبد الله الجهني", "Abdullah Al-Juhani",
            mp3quran = "https://server13.mp3quran.net/jhn"),
        ReciterSources("بندر بليلة", "Bandar Baleela",
            mp3quran = "https://server6.mp3quran.net/bna"),
        ReciterSources("ياسر الدوسري", "Yasser Al-Dossari",
            mp3quran = "https://server11.mp3quran.net/yasser"),
        ReciterSources("فارس عباد", "Fares Abbad",
            mp3quran = "https://server8.mp3quran.net/frs_a"),
        ReciterSources("إدريس أبكر", "Idrees Abkar",
            mp3quran = "https://server6.mp3quran.net/akdr"),
        ReciterSources("محمد جبريل", "Muhammad Jibreel",
            mp3quran = "https://server8.mp3quran.net/jbrl"),
        ReciterSources("محمد أيوب", "Muhammad Ayyoub",
            mp3quran = "https://server10.mp3quran.net/ayyub",
            islamicNetwork = "ar.muhammadayyoub"),
        ReciterSources("سعد الغامدي", "Saad Al-Ghamdi",
            mp3quran = "https://server7.mp3quran.net/s_gmd"),
        ReciterSources("علي جابر", "Ali Jaber",
            mp3quran = "https://server11.mp3quran.net/a_jbr"),
        ReciterSources("عبد الله بصفر", "Abdullah Basfar",
            mp3quran = "https://server13.mp3quran.net/bsfr",
            islamicNetwork = "ar.abdullahbasfar"),
        ReciterSources("عبد الباسط (مجوّد)", "Abdul Basit (Mujawwad)",
            islamicNetwork = "ar.abdulsamad"),
        ReciterSources("علي الحذيفي", "Ali Al-Hudhaify",
            mp3quran = "https://server10.mp3quran.net/hthfi",
            islamicNetwork = "ar.hudhaify"),
        ReciterSources("هاني الرفاعي", "Hani Ar-Rifai",
            mp3quran = "https://server13.mp3quran.net/rifai",
            islamicNetwork = "ar.hanirifai"),
        ReciterSources("محمد الطبلاوي", "Mohammad Al-Tablawi",
            mp3quran = "https://server6.mp3quran.net/tblawi"),
        ReciterSources("عبد الله المطرود", "Abdullah Al-Matroud",
            mp3quran = "https://server12.mp3quran.net/mtrod"),
        ReciterSources("صلاح بوخاطر", "Salah Bukhatir",
            mp3quran = "https://server11.mp3quran.net/sahl"),
        ReciterSources("عبد الباري الثبيتي", "Abdul Bari Ath-Thubaity",
            mp3quran = "https://server7.mp3quran.net/thubti"),
        ReciterSources("عبد الرشيد صوفي", "Abdul Rashid Sufi",
            mp3quran = "https://server6.mp3quran.net/soufi"),
        ReciterSources("خليفة الطنيجي", "Khalifa Al-Tunaiji",
            mp3quran = "https://server11.mp3quran.net/h_khashi"),
        ReciterSources("أحمد العجمي (مصحف مرتل)", "Ahmad Al-Ajamy 2",
            islamicNetwork = "ar.ahmedajamy"),

        // ---- Extended catalog (more reciters via mp3quran.net) ----
        ReciterSources("ناصر القطامي (مصحف مكة)", "Nasser Al-Qatami 2",
            mp3quran = "https://server6.mp3quran.net/qtm"),
        ReciterSources("خالد الجليل", "Khalid Al-Jaleel",
            mp3quran = "https://server10.mp3quran.net/Khaleel"),
        ReciterSources("ياسر سلامة", "Yasser Salamah",
            mp3quran = "https://server8.mp3quran.net/yasser_salama"),
        ReciterSources("توفيق الصايغ", "Tawfeeq As-Sayegh",
            mp3quran = "https://server12.mp3quran.net/tawfeeq"),
        ReciterSources("ناصر المنيع", "Nasser Al-Munaya",
            mp3quran = "https://server14.mp3quran.net/nasser_almanea"),
        ReciterSources("أحمد النفيس", "Ahmad An-Nufais",
            mp3quran = "https://server16.mp3quran.net/nufais"),
        ReciterSources("ماجد الزامل", "Majid Az-Zamil",
            mp3quran = "https://server14.mp3quran.net/zamil"),
        ReciterSources("عبد الله الموسى", "Abdullah Al-Mousa",
            mp3quran = "https://server11.mp3quran.net/a_mousa"),
        ReciterSources("ناصر بن علي القطامي", "Nasser bin Ali",
            mp3quran = "https://server6.mp3quran.net/qtm"),
        ReciterSources("وديع اليمني", "Wadee Al-Yamani",
            mp3quran = "https://server16.mp3quran.net/wadee3"),
        ReciterSources("رعد الكردي", "Raad Al-Kurdi",
            mp3quran = "https://server16.mp3quran.net/kurdi"),
        ReciterSources("إسلام صبحي", "Islam Sobhi",
            mp3quran = "https://server10.mp3quran.net/islam"),
        ReciterSources("منصور السالمي", "Mansour As-Salimi",
            mp3quran = "https://server14.mp3quran.net/mansor"),
        ReciterSources("عبد الرحمن العوسي", "Abdurrahman Al-Ossi",
            mp3quran = "https://server8.mp3quran.net/aleausi"),
        ReciterSources("هزاع البلوشي", "Hazza Al-Balushi",
            mp3quran = "https://server16.mp3quran.net/hazza"),
        ReciterSources("عمر القزابري", "Omar Al-Qazabri",
            mp3quran = "https://server16.mp3quran.net/qzbri"),
        ReciterSources("ياسر الفيلكاوي", "Yasser Al-Failakawi",
            mp3quran = "https://server14.mp3quran.net/failakawi"),
        ReciterSources("صابر عبد الحكم", "Saber Abdul-Hakam",
            mp3quran = "https://server14.mp3quran.net/saber"),
        ReciterSources("أنس العمادي", "Anas Al-Emadi",
            mp3quran = "https://server16.mp3quran.net/emadi"),
        ReciterSources("عبد المحسن القاسم", "Abdul-Mohsen Al-Qasim",
            mp3quran = "https://server6.mp3quran.net/qasm"),
        ReciterSources("علي بن عبد الرحمن الحذيفي", "Ali Al-Hudhaify 2",
            mp3quran = "https://server9.mp3quran.net/hozaifi"),
        ReciterSources("محمد المحيسني", "Muhammad Al-Muhaisany",
            mp3quran = "https://server10.mp3quran.net/mhsny"),
        ReciterSources("سعد المقرن", "Saad Al-Muqarin",
            mp3quran = "https://server8.mp3quran.net/maqren"),
        ReciterSources("أكرم العلاقمي", "Akram Al-Alaqimi",
            mp3quran = "https://server14.mp3quran.net/alaqmi"),
        ReciterSources("عادل ريان", "Adel Rayyan",
            mp3quran = "https://server8.mp3quran.net/3adel"),
        ReciterSources("محمد عبد الكريم", "Muhammad Abdul-Kareem",
            mp3quran = "https://server12.mp3quran.net/abdulkrem"),
        ReciterSources("ناصر الحربي", "Nasser Al-Harbi",
            mp3quran = "https://server14.mp3quran.net/harbi")
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Remember which provider worked for a reciter. */
    private fun cacheWorkingProvider(ctx: Context, reciterId: String, providerKey: String) {
        prefs(ctx).edit().putString("prov_$reciterId", providerKey).apply()
    }

    private fun cachedProvider(ctx: Context, reciterId: String): String? =
        prefs(ctx).getString("prov_$reciterId", null)

    // ---- Health tracking ----------------------------------------------------
    // Per-provider success/failure counters + last-success timestamp, persisted
    // so healthy providers are preferred across sessions. Tiny integer writes;
    // never on the UI thread (callers are already on Dispatchers.IO).

    data class ProviderHealth(
        val key: String,
        val successes: Int,
        val failures: Int,
        val lastSuccessAt: Long
    ) {
        /** Simple health score: more successes & recent success rank higher. */
        val score: Double
            get() {
                val total = successes + failures
                val rate = if (total == 0) 0.5 else successes.toDouble() / total
                val recency = if (lastSuccessAt > 0) 0.25 else 0.0
                return rate + recency
            }
    }

    fun health(ctx: Context, providerKey: String): ProviderHealth {
        val p = prefs(ctx)
        return ProviderHealth(
            key = providerKey,
            successes = p.getInt("ok_$providerKey", 0),
            failures = p.getInt("fail_$providerKey", 0),
            lastSuccessAt = p.getLong("last_$providerKey", 0L)
        )
    }

    private fun recordSuccess(ctx: Context, providerKey: String) {
        val p = prefs(ctx)
        p.edit()
            .putInt("ok_$providerKey", p.getInt("ok_$providerKey", 0) + 1)
            .putLong("last_$providerKey", System.currentTimeMillis())
            .apply()
    }

    private fun recordFailure(ctx: Context, providerKey: String) {
        val p = prefs(ctx)
        p.edit().putInt("fail_$providerKey", p.getInt("fail_$providerKey", 0) + 1).apply()
    }

    /** A resolved candidate the player can try, with its provider for reporting. */
    data class Candidate(
        val providerKey: String,
        val providerName: String,
        val url: String
    )

    /**
     * Build the ordered list of candidate URLs for a reciter+surah, WITHOUT doing
     * network checks. Order = cached working provider first, then by health
     * score, then catalog order. This lets the player try them in turn and fail
     * over instantly (no HEAD round-trip) when a stream errors mid-playback.
     */
    fun candidatesFor(
        ctx: Context,
        reciter: ReciterSources,
        surahNumber: Int
    ): List<Candidate> {
        val padded = surahNumber.toString().padStart(3, '0')
        val raw = buildList {
            PROVIDERS.forEach { p ->
                val id = reciterIdFor(reciter, p.key)
                if (id != null) add(Candidate(p.key, p.name, p.buildUrl(id, padded)))
            }
        }
        if (raw.isEmpty()) return emptyList()
        val cached = cachedProvider(ctx, reciter.id)
        return raw.sortedWith(
            compareByDescending<Candidate> { it.providerKey == cached }
                .thenByDescending { health(ctx, it.providerKey).score }
        )
    }

    /**
     * Maps a provider key to the identifier this reciter uses on that provider
     * (null if the reciter isn't on it). Central place so adding a provider only
     * needs one update here, not in every call site.
     */
    private fun reciterIdFor(reciter: ReciterSources, providerKey: String): String? =
        when (providerKey) {
            "mp3quran" -> reciter.mp3quran
            "islamicNetwork" -> reciter.islamicNetwork
            "everyayah" -> reciter.everyayah
            "quranicaudio" -> reciter.quranicaudio
            // Mirrors / alternate-bitrate hosts that reuse an existing id:
            "quranicaudioStream" -> reciter.quranicaudio   // same folders as quranicaudio
            "islamic2" -> reciter.islamicNetwork           // same edition id, 192k
            else -> null
        }

    /** Mark the outcome of a real playback attempt (called by the player layer). */
    fun reportPlaybackResult(ctx: Context, reciter: ReciterSources, providerKey: String, success: Boolean) {
        if (success) {
            recordSuccess(ctx, providerKey)
            cacheWorkingProvider(ctx, reciter.id, providerKey)
        } else {
            recordFailure(ctx, providerKey)
        }
    }

    /**
     * Resolve a working full-surah URL for a reciter. Strategy tuned for speed
     * with many sources: try the cached/highest-health provider FIRST (one quick
     * HEAD — this usually succeeds instantly). If it fails, fire HEAD checks at
     * ALL remaining providers in PARALLEL and take the first that responds OK.
     * This keeps resolution fast even with 10+ sources (no serial waiting on
     * dead providers). Returns null only if every source fails.
     */
    suspend fun resolveUrl(
        ctx: Context,
        reciter: ReciterSources,
        surahNumber: Int
    ): String? = withContext(Dispatchers.IO) {
        val padded = surahNumber.toString().padStart(3, '0')

        // Build the list of (provider, url) candidates this reciter supports.
        val candidates = buildList {
            PROVIDERS.forEach { p ->
                val id = reciterIdFor(reciter, p.key)
                if (id != null) add(p to p.buildUrl(id, padded))
            }
        }
        if (candidates.isEmpty()) {
            Log.w(TAG, "No providers mapped for ${reciter.englishName}")
            return@withContext null
        }

        // Put the previously-successful provider first, then by health score.
        val cached = cachedProvider(ctx, reciter.id)
        val ordered = candidates.sortedWith(
            compareByDescending<Pair<Provider, String>> { it.first.key == cached }
                .thenByDescending { health(ctx, it.first.key).score }
        )

        // 1) Fast path: try the top (cached / healthiest) provider on its own.
        val (topProvider, topUrl) = ordered.first()
        if (headOk(topUrl)) {
            Log.i(TAG, "OK(top) ${reciter.englishName} via ${topProvider.name}")
            cacheWorkingProvider(ctx, reciter.id, topProvider.key)
            recordSuccess(ctx, topProvider.key)
            return@withContext topUrl
        }
        recordFailure(ctx, topProvider.key)

        // 2) Parallel path: race all remaining providers; take the first OK.
        val rest = ordered.drop(1)
        if (rest.isEmpty()) {
            Log.e(TAG, "ALL providers failed for ${reciter.englishName}")
            return@withContext null
        }
        val winner = coroutineScope {
            val deferreds = rest.map { (provider, url) ->
                async {
                    if (headOk(url)) provider to url else null
                }
            }
            // Collect results; pick the first non-null in priority order so the
            // result is deterministic (respects the original ordering).
            val results = deferreds.awaitAll()
            results.firstOrNull { it != null }
        }
        if (winner != null) {
            val (provider, url) = winner
            Log.i(TAG, "OK(parallel) ${reciter.englishName} via ${provider.name}")
            cacheWorkingProvider(ctx, reciter.id, provider.key)
            recordSuccess(ctx, provider.key)
            return@withContext url
        }
        // Record failures for the ones we raced.
        rest.forEach { recordFailure(ctx, it.first.key) }
        Log.e(TAG, "ALL providers failed for ${reciter.englishName}")
        null
    }

    /**
     * Quick check that a reciter has at least one responding source. Fires all
     * provider HEAD checks in PARALLEL and returns true as soon as the results
     * include a success — fast even with many sources (used when validating the
     * whole catalog on Quran open).
     */
    suspend fun hasAnySource(reciter: ReciterSources): Boolean = withContext(Dispatchers.IO) {
        val padded = "001"
        val urls = PROVIDERS.mapNotNull { p ->
            reciterIdFor(reciter, p.key)?.let { id -> p.buildUrl(id, padded) }
        }
        if (urls.isEmpty()) return@withContext false
        coroutineScope {
            urls.map { url -> async { headOk(url) } }.awaitAll().any { it }
        }
    }

    private fun headOk(url: String): Boolean = try {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "HEAD"
            connectTimeout = 4000
            readTimeout = 4000
            instanceFollowRedirects = true
        }
        val code = conn.responseCode
        conn.disconnect()
        code in 200..399
    } catch (e: Exception) {
        Log.w(TAG, "headOk error ${e.javaClass.simpleName} → $url")
        false
    }
}

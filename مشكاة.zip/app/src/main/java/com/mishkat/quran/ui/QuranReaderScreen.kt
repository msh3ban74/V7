package com.mishkat.quran.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mishkat.quran.audio.PlayerStatus
import com.mishkat.quran.audio.QuranAudioPlayer
import com.mishkat.quran.data.*
import com.mishkat.quran.viewmodel.QuranViewModel
import com.mishkat.quran.ui.theme.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.util.*

// ==========================================
// 1. QURAN READER & KHATMA WORKFLOW SCREEN
// ==========================================
@Composable
fun QuranReaderScreen(
    viewModel: QuranViewModel,
    isDarkTheme: Boolean,
    fontSize: Float
) {
    val suraList = viewModel.getAllSuras()
    val activeSuraId by viewModel.selectedSuraId.collectAsStateWithLifecycle()
    val activeKhatmah by viewModel.activeKhatmah.collectAsStateWithLifecycle()

    var showSuraDialog by remember { mutableStateOf(false) }
    var readingModeIsWard by remember { mutableStateOf(false) } // Toggle Free Reading vs Khatmah Ward Reading

    val currentSura = viewModel.getSuraById(activeSuraId) ?: suraList[0]
    val verses = viewModel.getSuraVerses(activeSuraId)

    // Notes adding dialog state
    var noteTargetVerse by remember { mutableStateOf<Verse?>(null) }
    var noteText by remember { mutableStateOf("") }

    // Context Tafsir view state
    var selectedVerseForTafsir by remember { mutableStateOf<Verse?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Upper Controls: Sura Selector list, Mode Toggle (Free vs Ward)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(if (isDarkTheme) DarkSurface else Color(0xFFE6EFEA))
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Sura Select action
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(IslamicEmerald)
                    .clickable { showSuraDialog = true }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "سورة ${currentSura.name}",
                    color = IslamicSand,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Icon(
                    imageVector = Icons.Default.ArrowDropDown,
                    contentDescription = "قائمة السور",
                    tint = IslamicGold
                )
            }

            // Word Reading vs Free Reading Toggle
            if (activeKhatmah != null) {
                val khatmah = activeKhatmah!!
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (readingModeIsWard) IslamicGold else Color.Transparent)
                        .clickable { readingModeIsWard = !readingModeIsWard }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (readingModeIsWard) Icons.Default.Star else Icons.Outlined.StarBorder,
                        contentDescription = null,
                        tint = if (readingModeIsWard) IslamicEmerald else IslamicGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "الورد القرآني",
                        color = if (readingModeIsWard) IslamicEmerald else (if (isDarkTheme) IslamicSand else IslamicEmerald),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            } else {
                Text(
                    text = "تصفح حر (لا توجد ختمة نشطة)",
                    fontSize = 12.sp,
                    color = if (isDarkTheme) Color.LightGray else IslamicEmerald,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Adjustable Font Size Panel Slider
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            colors = CardDefaults.cardColors(containerColor = if (isDarkTheme) DarkSurface else Color(0xFFF0F5F2))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.FormatSize, contentDescription = null, tint = IslamicGold, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("حجم الخط", fontSize = 12.sp, color = if (isDarkTheme) IslamicSand else IslamicEmerald)
                }
                Slider(
                    value = fontSize,
                    onValueChange = { viewModel.setFontSize(it) },
                    valueRange = 16f..40f,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 16.dp)
                        .testTag("font_size_slider")
                )
                Text("${fontSize.toInt()}sp", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (isDarkTheme) IslamicSand else IslamicEmerald)
            }
        }

        // Content Area containing verses
        Box(modifier = Modifier.weight(1f)) {
            if (readingModeIsWard && activeKhatmah != null) {
                WardReadingView(
                    viewModel = viewModel,
                    khatmah = activeKhatmah!!,
                    isDarkTheme = isDarkTheme,
                    fontSize = fontSize,
                    onVerseLongClick = { noteTargetVerse = it },
                    onVerseClick = { selectedVerseForTafsir = it }
                )
            } else {
                // Free reading
                FreeReadingView(
                    viewModel = viewModel,
                    verses = verses,
                    isDarkTheme = isDarkTheme,
                    fontSize = fontSize,
                    onVerseLongClick = { noteTargetVerse = it },
                    onVerseClick = { selectedVerseForTafsir = it }
                )
            }
        }

        // Bottom Player Controller Integration
        AudioPlaybackControllerBar(viewModel = viewModel, activeSura = currentSura, isDarkTheme = isDarkTheme)
    }

    // --- DIALOGS ---

    // Suras Listing Selector Dialog
    if (showSuraDialog) {
        Dialog(onDismissRequest = { showSuraDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.85f),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = if (isDarkTheme) DarkSurface else IslamicSand)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "اختر السورة الكريمة",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = IslamicGold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    OutlinedTextField(
                        value = "",
                        onValueChange = {},
                        placeholder = { Text("ابحث في الفهرس...") },
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                        leadingIcon = { Icon(Icons.Default.Search, null) }
                    )
                    LazyColumn(modifier = Modifier.weight(1f)) {
                        items(suraList) { sura ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        viewModel.selectSura(sura.id)
                                        showSuraDialog = false
                                    }
                                    .padding(vertical = 12.dp, horizontal = 16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(IslamicEmerald),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(sura.id.toString(), color = IslamicGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = sura.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = if (isDarkTheme) IslamicSand else IslamicEmerald
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(sura.type, fontSize = 11.sp, color = IslamicGold)
                                    Text("${sura.totalVerses} آية", fontSize = 11.sp, color = if (isDarkTheme) GrayText else Color.Gray)
                                }
                            }
                            HorizontalDivider(color = if (isDarkTheme) Color(0xFF22312C) else Color(0xFFE0EAE5))
                        }
                    }
                }
            }
        }
    }

    // Interactive Personal Note Form Dialog
    noteTargetVerse?.let { verse ->
        Dialog(onDismissRequest = { noteTargetVerse = null }) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = if (isDarkTheme) DarkSurface else IslamicSand)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "إضافة ملاحظة شخصية وتدبر للآية",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = IslamicGold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    Text(
                        text = "« ${verse.text} »",
                        fontSize = 13.sp,
                        color = if (isDarkTheme) IslamicSand else IslamicEmerald,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                        modifier = Modifier
                            .background(if (isDarkTheme) Color(0xFF1E2F2A) else Color(0xFFEAF2EE), RoundedCornerShape(8.dp))
                            .padding(12.dp)
                            .fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = noteText,
                        onValueChange = { noteText = it },
                        label = { Text("أدخل تأملاتك أو ملاحظاتك الشخصية...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .testTag("personal_note_field"),
                        maxLines = 4
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { noteTargetVerse = null; noteText = "" }) {
                            Text("إلغاء", color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                viewModel.addPersonalNote(
                                    suraName = suraList.first { it.id == verse.suraId }.name,
                                    verseNumber = verse.verseNumber,
                                    text = noteText
                                )
                                noteTargetVerse = null
                                noteText = ""
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IslamicEmerald),
                            modifier = Modifier.testTag("save_note_button")
                        ) {
                            Text("حفظ الملاحظة", color = IslamicSand)
                        }
                    }
                }
            }
        }
    }

    // Verse Details, cause of descent, and offline/online Tafsir viewer Dialog
    selectedVerseForTafsir?.let { verse ->
        Dialog(onDismissRequest = { selectedVerseForTafsir = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.75f),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = if (isDarkTheme) DarkSurface else IslamicSand)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "تفسير الآية وأسباب النزول",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = IslamicGold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    
                    // The Sacred text
                    Text(
                        text = verse.text,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDarkTheme) IslamicSand else IslamicEmerald,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(if (isDarkTheme) Color(0xFF1E2F2A) else Color(0xFFEAF2EE), RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    LazyColumn(modifier = Modifier.weight(1f)) {
                        item {
                            Text("التفسير الميسر:", fontWeight = FontWeight.Bold, color = IslamicGold, fontSize = 13.sp)
                            Text(
                                text = verse.tafsir,
                                fontSize = 14.sp,
                                color = if (isDarkTheme) Color.LightGray else Color.DarkGray,
                                modifier = Modifier.padding(vertical = 4.dp, horizontal = 4.dp),
                                style = LocalTextStyle.current.copy(
                                    lineHeight = 22.sp,
                                    textDirection = TextDirection.Rtl
                                )
                            )
                        }

                        if (verse.causeOfRevelation.isNotBlank()) {
                            item {
                                Spacer(modifier = Modifier.height(12.dp))
                                Text("سبب نزول الآية:", fontWeight = FontWeight.Bold, color = IslamicGold, fontSize = 13.sp)
                                Text(
                                    text = verse.causeOfRevelation,
                                    fontSize = 14.sp,
                                    color = if (isDarkTheme) Color.LightGray else Color.DarkGray,
                                    modifier = Modifier.padding(vertical = 4.dp, horizontal = 4.dp)
                                )
                            }
                        }

                        item {
                            Spacer(modifier = Modifier.height(16.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(16.dp))
                            // Interactive AI Tafsir Request
                            Text(
                                text = "مستند التفسير المتقدم بالذكاء الاصطناعي",
                                fontWeight = FontWeight.Bold,
                                color = IslamicGold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                            Button(
                                onClick = {
                                    val suraName = suraList.first { it.id == verse.suraId }.name
                                    viewModel.loadAiTafsir("سورة $suraName الآية ${verse.verseNumber}: ${verse.text}")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = IslamicLightGreen),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("ai_tafsir_button")
                            ) {
                                Icon(Icons.Default.AutoAwesome, null, tint = IslamicGold, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("طلب تفسير وأسباب نزول تفصيلية بالـ AI", color = IslamicSand, fontSize = 12.sp)
                            }

                            // Render AI Response if requested
                            val aiTafsirLoading by viewModel.aiTafsirLoading.collectAsStateWithLifecycle()
                            val aiTafsirResult by viewModel.aiTafsirResult.collectAsStateWithLifecycle()

                            if (aiTafsirLoading) {
                                Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator(color = IslamicGold)
                                }
                            }

                            aiTafsirResult?.let { aiResult ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 12.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isDarkTheme) Color(0xFF14201D) else Color(0xFFF1F6F3))
                                        .border(1.dp, IslamicGold.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                        .padding(12.dp)
                                ) {
                                    Text(
                                        text = aiResult.tafsir,
                                        fontSize = 13.sp,
                                        color = if (isDarkTheme) IslamicSand else IslamicEmerald
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { selectedVerseForTafsir = null; viewModel.clearAiStates() },
                        colors = ButtonDefaults.buttonColors(containerColor = IslamicEmerald),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("إغلاق التفسير", color = IslamicSand)
                    }
                }
            }
        }
    }
}

// --- INTERACTIVE WORD FLOW TEXT FOR SPELLING CORRECTION ---
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ArabicWordFlowText(
    verseText: String,
    verseNumber: Int,
    fontSize: Float,
    isDarkTheme: Boolean,
    onWordClick: (String, Int) -> Unit
) {
    val words = remember(verseText) { verseText.split("\\s+".toRegex()).filter { it.isNotBlank() } }
    val scope = rememberCoroutineScope()
    
    FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End,
        verticalArrangement = Arrangement.Center
    ) {
        words.forEachIndexed { index, word ->
            var isHighlighted by remember { mutableStateOf(false) }
            Text(
                text = word,
                fontSize = fontSize.sp,
                fontWeight = FontWeight.Bold,
                color = if (isHighlighted) IslamicGold else (if (isDarkTheme) IslamicSand else IslamicEmerald),
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (isHighlighted) IslamicGold.copy(alpha = 0.2f) else Color.Transparent)
                    .clickable {
                        isHighlighted = true
                        onWordClick(word, index)
                        // Auto-reset highlight color after 1 second using standard coroutines
                        scope.launch {
                            kotlinx.coroutines.delay(1000)
                            isHighlighted = false
                        }
                    }
                    .padding(horizontal = 2.dp, vertical = 1.dp)
            )
            Spacer(modifier = Modifier.width(3.dp))
        }
        
        // Verse number badge
        Text(
            text = " ﴿$verseNumber﴾",
            fontSize = (fontSize - 2).sp,
            fontWeight = FontWeight.Bold,
            color = IslamicGold,
            modifier = Modifier.padding(start = 2.dp)
        )
    }
}

// --- FREE READING WRAPPED COMPOSABLE ---
@Composable
fun FreeReadingView(
    viewModel: QuranViewModel,
    verses: List<Verse>,
    isDarkTheme: Boolean,
    fontSize: Float,
    onVerseLongClick: (Verse) -> Unit,
    onVerseClick: (Verse) -> Unit
) {
    val context = LocalContext.current
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 16.dp, top = 8.dp)
    ) {
        items(verses, key = { it.verseNumber }) { verse ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .testTag("verse_card_${verse.verseNumber}"),
                colors = CardDefaults.cardColors(
                    containerColor = if (isDarkTheme) DarkSurface else Color.White
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    // Holy Arabic Script split word-by-word
                    ArabicWordFlowText(
                        verseText = verse.text,
                        verseNumber = verse.verseNumber,
                        fontSize = fontSize,
                        isDarkTheme = isDarkTheme,
                        onWordClick = { word, idx ->
                            viewModel.playWordSound(word, verse.suraId, verse.verseNumber, idx)
                        }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    // Translation
                    Text(
                        text = verse.translation,
                        fontSize = (fontSize - 5).coerceAtLeast(12F).sp,
                        color = if (isDarkTheme) GrayText else Color.Gray,
                        style = LocalTextStyle.current.copy(textDirection = TextDirection.Ltr),
                        textAlign = TextAlign.Left,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    // Action Buttons (Tafsir, Notes, Share)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AssistChip(
                            onClick = { onVerseClick(verse) },
                            label = { Text("المعاني والتفسير", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                            leadingIcon = { Icon(Icons.Default.MenuBook, null, modifier = Modifier.size(14.dp)) },
                            colors = AssistChipDefaults.assistChipColors(
                                labelColor = IslamicGold,
                                leadingIconContentColor = IslamicGold
                            )
                        )
                        AssistChip(
                            onClick = { onVerseLongClick(verse) },
                            label = { Text("إضافة تدبر", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                            leadingIcon = { Icon(Icons.Default.NoteAdd, null, modifier = Modifier.size(14.dp)) },
                            colors = AssistChipDefaults.assistChipColors(
                                labelColor = if (isDarkTheme) IslamicSand else IslamicEmerald,
                                leadingIconContentColor = IslamicGold
                            )
                        )
                        AssistChip(
                            onClick = {
                                val suraName = viewModel.getSuraById(verse.suraId)?.name ?: ""
                                val message = "قال الله تعالى في سورة $suraName [آية ${verse.verseNumber}]:\n« ${verse.text} »\n\nتفسير الآية:\n${verse.tafsir}\n\nتمت المشاركة من تطبيق #مشكاة 🌟"
                                val shareIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(android.content.Intent.EXTRA_TEXT, message)
                                }
                                context.startActivity(android.content.Intent.createChooser(shareIntent, "مشاركة الآية الكريمة"))
                            },
                            label = { Text("مشاركة", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                            leadingIcon = { Icon(Icons.Default.Share, null, modifier = Modifier.size(13.dp)) },
                            colors = AssistChipDefaults.assistChipColors(
                                labelColor = if (isDarkTheme) IslamicSand else IslamicEmerald,
                                leadingIconContentColor = IslamicGold
                            )
                        )
                    }
                }
            }
        }
    }
}

// --- ACTIVE KHATMAH PORTION PROGRESS READER ---
@Composable
fun WardReadingView(
    viewModel: QuranViewModel,
    khatmah: Khatmah,
    isDarkTheme: Boolean,
    fontSize: Float,
    onVerseLongClick: (Verse) -> Unit,
    onVerseClick: (Verse) -> Unit
) {
    val surasInPortion = remember(khatmah) {
        viewModel.getAllSuras().filter {
            it.startPage <= khatmah.currentWordPageEnd && it.endPage >= khatmah.currentWordPageStart
        }
    }

    val portionVerses = remember(surasInPortion) {
        surasInPortion.flatMap { meta ->
            viewModel.getSuraVerses(meta.id)
        }
    }

    val listState = rememberLazyListState()
    
    val isPortionCompletedRead by remember {
        derivedStateOf {
            val layoutInfo = listState.layoutInfo
            val totalItems = layoutInfo.totalItemsCount
            if (totalItems == 0) false
            else {
                val lastVisibleItem = layoutInfo.visibleItemsInfo.lastOrNull()
                lastVisibleItem != null && lastVisibleItem.index >= totalItems - 1
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(IslamicEmerald)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "الورد اليومي لختمة: ${khatmah.name}",
                        color = IslamicGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "من الصفحة ${khatmah.currentWordPageStart} إلى ${khatmah.currentWordPageEnd} (المستهدف: ${formatWardGoal(khatmah.pagesPerWard)})",
                        color = IslamicSand,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isPortionCompletedRead) Color(0xFF2E7D32) else Color(0xFFC62828))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = if (isPortionCompletedRead) "جاهز للختم" else "واصل القراءة لآخر الصفحة",
                        color = IslamicSand,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 16.dp, top = 8.dp)
        ) {
            if (portionVerses.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text("الورد لليوم غير متوفر محلياً بالكامل. يمكنك تحميل التلاوات والاستمتاع بالتفسير المباشر.", color = Color.Gray, fontSize = 13.sp)
                    }
                }
            } else {
                items(portionVerses) { verse ->
                    val context = LocalContext.current
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isDarkTheme) DarkSurface else Color.White
                        )
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            ArabicWordFlowText(
                                verseText = verse.text,
                                verseNumber = verse.verseNumber,
                                fontSize = fontSize,
                                isDarkTheme = isDarkTheme,
                                onWordClick = { word, idx ->
                                    viewModel.playWordSound(word, verse.suraId, verse.verseNumber, idx)
                                }
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(onClick = { onVerseClick(verse) }) {
                                    Text("المعاني والنزول", color = IslamicGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                TextButton(onClick = { onVerseLongClick(verse) }) {
                                    Text("تدبر +", color = if (isDarkTheme) IslamicSand else IslamicEmerald, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.weight(1f))
                                IconButton(
                                    onClick = {
                                        val suraName = viewModel.getSuraById(verse.suraId)?.name ?: ""
                                        val message = "قال الله تعالى في سورة $suraName [آية ${verse.verseNumber}]:\n« ${verse.text} »\n\nتفسير الآية:\n${verse.tafsir}\n\nتمت المشاركة من تطبيق #مشكاة 🌟"
                                        val shareIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                            type = "text/plain"
                                            putExtra(android.content.Intent.EXTRA_TEXT, message)
                                        }
                                        context.startActivity(android.content.Intent.createChooser(shareIntent, "مشاركة الآية الكريمة"))
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = "مشاركة",
                                        tint = IslamicGold,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Forced Flow Scroll Lock
            item {
                AnimatedVisibility(
                    visible = isPortionCompletedRead,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Button(
                        onClick = { viewModel.completeCurrentWard() },
                        colors = ButtonDefaults.buttonColors(containerColor = IslamicGold),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp)
                            .height(50.dp)
                            .testTag("complete_ward_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = IslamicEmerald)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "أتممت قراءة الورد اليومي بنجاح",
                            color = IslamicEmerald,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    }
}

// --- PLAYER AUDIO RECITER BOTTOM PANEL ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioPlaybackControllerBar(
    viewModel: QuranViewModel,
    activeSura: SuraMeta,
    isDarkTheme: Boolean
) {
    val reciters = QuranAudioPlayer.reciters
    val status by QuranAudioPlayer.status.collectAsStateWithLifecycle()
    val activeReciter by QuranAudioPlayer.currentReciter.collectAsStateWithLifecycle()
    val playPosition by QuranAudioPlayer.currentPosition.collectAsStateWithLifecycle()
    val playDuration by QuranAudioPlayer.duration.collectAsStateWithLifecycle()
    val audioSuraId by QuranAudioPlayer.currentSuraId.collectAsStateWithLifecycle()

    var showSheikhDropdown by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = if (isDarkTheme) DarkSurface else Color(0xFFE5EEE9)),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(IslamicEmerald)
                            .clickable { showSheikhDropdown = !showSheikhDropdown }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.RecordVoiceOver, null, tint = IslamicGold, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(activeReciter.name, color = IslamicSand, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Icon(Icons.Default.ArrowDropDown, null, tint = IslamicGold)
                    }

                    DropdownMenu(
                        expanded = showSheikhDropdown,
                        onDismissRequest = { showSheikhDropdown = false }
                    ) {
                        reciters.forEach { reciter ->
                            DropdownMenuItem(
                                text = { Text(reciter.name, fontSize = 13.sp) },
                                onClick = {
                                    QuranAudioPlayer.setReciter(reciter)
                                    showSheikhDropdown = false
                                }
                            )
                        }
                    }
                }

                val playingSuraName = if (audioSuraId != null) {
                    val suraMeta = viewModel.getSuraById(audioSuraId!!)
                    suraMeta?.name ?: activeSura.name
                } else activeSura.name

                Text(
                    text = "قارئ التلاوة: سورة $playingSuraName",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDarkTheme) IslamicGold else IslamicEmerald
                )
            }

            // Timeline slider
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = formatTime(playPosition),
                    fontSize = 11.sp,
                    color = if (isDarkTheme) GrayText else Color.DarkGray
                )
                Slider(
                    value = if (playDuration > 0) playPosition.toFloat() else 0f,
                    onValueChange = { QuranAudioPlayer.seekTo(it.toInt()) },
                    valueRange = 0f..(if (playDuration > 0) playDuration.toFloat() else 100f),
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp)
                )
                Text(
                    text = formatTime(playDuration),
                    fontSize = 11.sp,
                    color = if (isDarkTheme) GrayText else Color.DarkGray
                )
            }

            // Controls buttons row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        val current = audioSuraId ?: activeSura.id
                        if (current > 1) QuranAudioPlayer.playSura(current - 1)
                    }
                ) {
                    Icon(imageVector = Icons.Default.SkipPrevious, contentDescription = "السورة السابقة", tint = IslamicEmerald, modifier = Modifier.size(24.dp))
                }

                Spacer(modifier = Modifier.width(16.dp))

                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(IslamicEmerald)
                        .clickable {
                            val activeSuraPlaying = audioSuraId ?: activeSura.id
                            if (audioSuraId == null) {
                                QuranAudioPlayer.playSura(activeSuraPlaying)
                            } else {
                                QuranAudioPlayer.togglePlayPause()
                            }
                        }
                        .testTag("audio_play_pause_button"),
                    contentAlignment = Alignment.Center
                ) {
                    when (status) {
                        PlayerStatus.LOADING -> CircularProgressIndicator(color = IslamicGold, modifier = Modifier.size(24.dp))
                        PlayerStatus.PLAYING -> Icon(Icons.Default.Pause, contentDescription = "إيقاف مؤقت", tint = IslamicGold)
                        else -> Icon(Icons.Default.PlayArrow, contentDescription = "تشغيل التلاوة", tint = IslamicGold)
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                IconButton(
                    onClick = {
                        val current = audioSuraId ?: activeSura.id
                        if (current < 114) QuranAudioPlayer.playSura(current + 1)
                    }
                ) {
                    Icon(imageVector = Icons.Default.SkipNext, contentDescription = "السورة التالية", tint = IslamicEmerald, modifier = Modifier.size(24.dp))
                }

                Spacer(modifier = Modifier.width(16.dp))

                IconButton(
                    onClick = { QuranAudioPlayer.stopPlayer() }
                ) {
                    Icon(imageVector = Icons.Default.Stop, contentDescription = "إيقاف", tint = HighContrastRed, modifier = Modifier.size(24.dp))
                }
            }
        }
    }
}

fun formatTime(ms: Int): String {
    val totalSeconds = ms / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format("%02d:%02d", minutes, seconds)
}

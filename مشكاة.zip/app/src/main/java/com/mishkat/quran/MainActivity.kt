package com.mishkat.quran

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mishkat.quran.audio.QuranAudioPlayer
import com.mishkat.quran.ui.QuranAppUi
import com.mishkat.quran.ui.theme.MyApplicationTheme
import com.mishkat.quran.viewmodel.QuranViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    
    // Initialize standard singletons with Application Context safely
    QuranAudioPlayer.initialize(applicationContext)
    
    // Register player as lifecycle observer for robust audio lifecycle hardening
    lifecycle.addObserver(QuranAudioPlayer)

    setContent {
      MyApplicationTheme {
        val viewModel: QuranViewModel = viewModel()
        Surface(modifier = Modifier.fillMaxSize()) {
          QuranAppUi(viewModel = viewModel)
        }
      }
    }
  }

  override fun onDestroy() {
    super.onDestroy()
    if (isFinishing) {
      QuranAudioPlayer.releasePlayer()
    }
  }
}

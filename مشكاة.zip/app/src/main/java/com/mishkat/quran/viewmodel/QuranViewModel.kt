package com.mishkat.quran.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mishkat.quran.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class QuranViewModel : ViewModel() {

    private val _selectedSuraId = MutableStateFlow(1)
    val selectedSuraId: StateFlow<Int> = _selectedSuraId.asStateFlow()

    private val _fontSize = MutableStateFlow(24f)
    val fontSize: StateFlow<Float> = _fontSize.asStateFlow()

    private val _activeKhatmah = MutableStateFlow<Khatmah?>(Khatmah(1, "ختمة رمضان الكبرى", 1, 10, 5.0f))
    val activeKhatmah: StateFlow<Khatmah?> = _activeKhatmah.asStateFlow()

    private val _aiTafsirLoading = MutableStateFlow(false)
    val aiTafsirLoading: StateFlow<Boolean> = _aiTafsirLoading.asStateFlow()

    private val _aiTafsirResult = MutableStateFlow<AiTafsirResult?>(null)
    val aiTafsirResult: StateFlow<AiTafsirResult?> = _aiTafsirResult.asStateFlow()

    private val suras = ArrayList<SuraMeta>()

    init {
        val names = listOf(
            "الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام", "الأعراف", "الأنفال", "التوبة", "يونس",
            "هود", "يوسف", "الرعد", "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم", "طه",
            "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت", "الروم",
            "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس", "الصافات", "ص", "الزمر", "غافر",
            "فصلت", "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح", "الحجرات", "ق",
            "الذاريات", "الطور", "النجم", "القمر", "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة",
            "الصف", "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم", "الملك", "القلم", "الحاقة", "المعارج",
            "نوح", "الجن", "المزمل", "المدثر", "القيامة", "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس",
            "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر", "البلد",
            "الشمس", "الليل", "الضحى", "الشرح", "التين", "العلق", "القدر", "البينة", "الزلزلة", "العاديات",
            "القارعة", "التكاثر", "العصر", "الهمزة", "الفيل", "قريش", "الماعون", "الكوثر", "الكافرون", "النصر",
            "المسد", "الإخلاص", "الفلق", "الناس"
        )
        var currentPage = 1
        for (i in 0 until names.size) {
            val id = i + 1
            val name = names[i]
            val totalVerses = when (id) {
                1 -> 7
                2 -> 286
                3 -> 200
                4 -> 176
                5 -> 120
                else -> 10 + (id * 3) % 100
            }
            val startPage = currentPage
            val pages = when (id) {
                1 -> 1
                2 -> 48
                3 -> 26
                4 -> 29
                else -> (totalVerses / 6).coerceAtLeast(1)
            }
            val endPage = startPage + pages - 1
            currentPage = endPage + 1
            
            val type = if (id in listOf(2, 3, 4, 5, 8, 9, 24, 33, 47, 48, 49, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 110)) "مدنية" else "مكية"
            suras.add(SuraMeta(id, name, type, totalVerses, startPage, endPage))
        }
    }

    fun getAllSuras(): List<SuraMeta> = suras

    fun getSuraById(id: Int): SuraMeta? = suras.find { it.id == id }

    fun getSuraVerses(suraId: Int): List<Verse> {
        val sura = getSuraById(suraId) ?: return emptyList()
        val list = ArrayList<Verse>()
        
        if (suraId == 1) {
            val fatihahTexts = listOf(
                "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
                "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ",
                "الرَّحْمَٰنِ الرَّحِيمِ",
                "مَالِكِ يَوْمِ الدِّينِ",
                "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ",
                "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ",
                "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ"
            )
            val translations = listOf(
                "In the name of Allah, the Entirely Merciful, the Especially Merciful.",
                "[All] praise is [due] to Allah, Lord of the worlds -",
                "The Entirely Merciful, the Especially Merciful,",
                "Sovereign of the Day of Recompense.",
                "It is You we worship and You we ask for help.",
                "Guide us to the straight path -",
                "The path of those upon whom You have bestowed favor, not of those who have earned [Your] anger or of those who are astray."
            )
            for (i in fatihahTexts.indices) {
                list.add(
                    Verse(
                        suraId = 1,
                        verseNumber = i + 1,
                        text = fatihahTexts[i],
                        translation = translations[i],
                        tafsir = "هذه الآية الكريمة تبين أساس الحمد والثناء لله رب العالمين وطلب الهداية والاستعانة به سبحانه وتعالى.",
                        causeOfRevelation = if (i == 0) "نزلت بمكة لافتتاح كلام الله تبارك وتعالى" else ""
                    )
                )
            }
            return list
        }
        
        for (v in 1..sura.totalVerses) {
            val arabic = "ذَٰلِكَ الْكِتَابُ لَا رَيْبَ ۛ فِيهِ ۛ هُدًى لِّلْمُتَّقِينَ الآية رقم $v من سورة ${sura.name}"
            val translation = "This is the Book about which there is no doubt, a guidance for those conscious of Allah. Verse $v of Sura ${sura.name}"
            list.add(
                Verse(
                    suraId = suraId,
                    verseNumber = v,
                    text = arabic,
                    translation = translation,
                    tafsir = "تفسير إيماني مبارك للآية الكريمة رقم $v من سورة ${sura.name} يحث على تدبر كلام رب البرية والتقرب إليه بطاعته.",
                    causeOfRevelation = if (v == 1) "سبب نزول تاريخي مسند لحادثة قديمة جرت في المدينة المنورة" else ""
                )
            )
        }
        return list
    }

    fun setFontSize(size: Float) {
        _fontSize.value = size
    }

    fun selectSura(id: Int) {
        _selectedSuraId.value = id
    }

    fun addPersonalNote(suraName: String, verseNumber: Int, text: String) {
        Log.d("QuranViewModel", "Saving personal note: '$text' for Sura $suraName Verse $verseNumber")
    }

    fun loadAiTafsir(query: String) {
        viewModelScope.launch {
            _aiTafsirLoading.value = true
            _aiTafsirResult.value = null
            delay(1500) // Simulating fast, secure AI inference
            _aiTafsirResult.value = AiTafsirResult(
                tafsir = """
                    تدبر روحاني عميق للاستعلام الممرر:
                    "$query"
                    
                    ١. الدلالة التربوية: تحثنا هذه الآيات البينات على الاستقامة واللجوء لخالق الأكوان في كل حركة وسكنة.
                    ٢. السلوك العملي: ينبغي للعبد ترسيخ إخلاص الحمد والعبادة لله في قلبه، لثمراتها العظيمة في تيسير شؤون الحياة الإيمانية والمادية.
                    ٣. الأثر النفسي: مقتضى اليقين التام بإن الله سبحانه كافٍ عبده وناصرٌ دينه، مما يبعث على الطمأنينة الكاملة في النفوس.
                """.trimIndent()
            )
            _aiTafsirLoading.value = false
        }
    }

    fun clearAiStates() {
        _aiTafsirLoading.value = false
        _aiTafsirResult.value = null
    }

    fun completeCurrentWard() {
        val current = _activeKhatmah.value ?: return
        val nextStart = current.currentWordPageEnd + 1
        val nextEnd = nextStart + current.pagesPerWard.toInt() - 1
        _activeKhatmah.value = current.copy(
            currentWordPageStart = nextStart,
            currentWordPageEnd = nextEnd
        )
    }

    fun playWordSound(word: String, suraId: Int, verseNumber: Int, wordIndex: Int) {
        Log.d("QuranViewModel", "playWordSound: '$word' at Sura $suraId Verse $verseNumber WordIndex $wordIndex")
    }
}

package com.mishkat.quran.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mishkat.quran.ui.theme.DarkSurface
import com.mishkat.quran.ui.theme.IslamicSand
import com.mishkat.quran.viewmodel.QuranViewModel

@Composable
fun QuranAppUi(viewModel: QuranViewModel) {
    val fontSize by viewModel.fontSize.collectAsStateWithLifecycle()
    val isDarkTheme = true // Defaulting to the premium Islamic dark theme with gold and emerald accents

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = if (isDarkTheme) DarkSurface else IslamicSand
    ) {
        QuranReaderScreen(
            viewModel = viewModel,
            isDarkTheme = isDarkTheme,
            fontSize = fontSize
        )
    }
}

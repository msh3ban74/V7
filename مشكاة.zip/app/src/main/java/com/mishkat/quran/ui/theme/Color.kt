package com.mishkat.quran.ui.theme

import androidx.compose.ui.graphics.Color

val IslamicEmerald = Color(0xFF0C3D2B)
val IslamicGold = Color(0xFFC5A85C)
val IslamicSand = Color(0xFFF4EDE2)
val DarkSurface = Color(0xFF161D1A)
val GrayText = Color(0xFF7F8C8D)
val HighContrastRed = Color(0xFFC0392B)
val IslamicLightGreen = Color(0xFFD0ECDA)

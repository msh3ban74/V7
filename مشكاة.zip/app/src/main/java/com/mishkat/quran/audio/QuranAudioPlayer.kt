package com.mishkat.quran.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class Reciter(
    val id: String,
    val name: String,
    val serverPath: String // Base segment for mp3quran
)

enum class PlayerStatus {
    IDLE,
    LOADING,
    PLAYING,
    PAUSED,
    ERROR
}

object QuranAudioPlayer : DefaultLifecycleObserver, MediaPlayer.OnPreparedListener, MediaPlayer.OnErrorListener, MediaPlayer.OnCompletionListener {
    private const val TAG = "QuranAudioPlayer"

    val reciters = listOf(
        Reciter("basit", "الشيخ عبد الباسط عبد الصمد", "https://server7.mp3quran.net/basit"),
        Reciter("husr", "الشيخ محمود خليل الحصري (مرتل)", "https://server13.mp3quran.net/husr"),
        Reciter("minsh", "الشيخ محمد صديق المنشاوي (مرتل)", "https://server11.mp3quran.net/minsh"),
        Reciter("afs", "الشيخ مشاري راشد العفاسي", "https://server8.mp3quran.net/afs")
    )

    private var mediaPlayer: MediaPlayer? = null
    private var handler: Handler = Handler(Looper.getMainLooper())
    private var appContext: Context? = null

    private val _status = MutableStateFlow(PlayerStatus.IDLE)
    val status: StateFlow<PlayerStatus> = _status.asStateFlow()

    private val _currentReciter = MutableStateFlow(reciters[0])
    val currentReciter: StateFlow<Reciter> = _currentReciter.asStateFlow()

    private val _currentSuraId = MutableStateFlow<Int?>(null)
    val currentSuraId: StateFlow<Int?> = _currentSuraId.asStateFlow()

    private val _currentPosition = MutableStateFlow(0)
    val currentPosition: StateFlow<Int> = _currentPosition.asStateFlow()

    private val _duration = MutableStateFlow(0)
    val duration: StateFlow<Int> = _duration.asStateFlow()

    private val updateProgressAction = object : Runnable {
        override fun run() {
            mediaPlayer?.let { player ->
                try {
                    if (player.isPlaying) {
                        _currentPosition.value = player.currentPosition
                        _duration.value = player.duration
                        handler.postDelayed(this, 1000)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Exception during media player progress update", e)
                }
            }
        }
    }

    init {
        initPlayer()
    }

    fun initialize(context: Context) {
        appContext = context.applicationContext
    }

    override fun onDestroy(owner: LifecycleOwner) {
        super.onDestroy(owner)
        val isChangingConfig = (owner as? androidx.activity.ComponentActivity)?.isChangingConfigurations == true
        Log.d(TAG, "Lifecycle onDestroy - changingConfigurations=$isChangingConfig")
        if (!isChangingConfig) {
            releasePlayer()
        }
    }

    private fun getSuraFile(suraId: Int): java.io.File {
        val context = appContext
        val parentDir = context?.filesDir ?: java.io.File(System.getProperty("java.io.tmpdir") ?: ".")
        return java.io.File(parentDir, "sura_audios/sura_${_currentReciter.value.id}_${suraId}.mp3")
    }

    private fun initPlayer() {
        try {
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setOnPreparedListener(this@QuranAudioPlayer)
                setOnErrorListener(this@QuranAudioPlayer)
                setOnCompletionListener(this@QuranAudioPlayer)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing player", e)
            _status.value = PlayerStatus.ERROR
        }
    }

    fun setReciter(reciter: Reciter) {
        _currentReciter.value = reciter
        // If already playing, hot-reload the audio with new Sheikh
        val activeSura = _currentSuraId.value
        if (activeSura != null && (_status.value == PlayerStatus.PLAYING || _status.value == PlayerStatus.PAUSED)) {
            playSura(activeSura)
        }
    }

    fun playSura(suraId: Int) {
        _currentSuraId.value = suraId
        _status.value = PlayerStatus.LOADING
        _currentPosition.value = 0
        _duration.value = 0
        handler.removeCallbacks(updateProgressAction)

        try {
            if (mediaPlayer == null) {
                initPlayer()
            } else {
                mediaPlayer?.reset()
            }

            // Local download check
            val localFile = getSuraFile(suraId)
            
            if (localFile.exists() && localFile.length() > 200) {
                mediaPlayer?.setDataSource(localFile.absolutePath)
            } else {
                // Format suraId to 3 digits (e.g. 1 -> 001, 114 -> 114)
                val formattedSuraId = String.format("%03d", suraId)
                val streamUrl = "${_currentReciter.value.serverPath}/$formattedSuraId.mp3"
                mediaPlayer?.setDataSource(streamUrl)
            }
            mediaPlayer?.prepareAsync()
        } catch (e: Exception) {
            Log.e(TAG, "Error setting data source: $e")
            _status.value = PlayerStatus.ERROR
        }
    }

    fun togglePlayPause() {
        try {
            val player = mediaPlayer ?: return
            if (_status.value == PlayerStatus.PLAYING) {
                player.pause()
                _status.value = PlayerStatus.PAUSED
                handler.removeCallbacks(updateProgressAction)
            } else if (_status.value == PlayerStatus.PAUSED) {
                player.start()
                _status.value = PlayerStatus.PLAYING
                handler.post(updateProgressAction)
            } else {
                // If idle, start with Al-Fatihah
                _currentSuraId.value?.let { playSura(it) } ?: playSura(1)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in togglePlayPause: $e")
            _status.value = PlayerStatus.ERROR
        }
    }

    fun seekTo(msec: Int) {
        try {
            mediaPlayer?.let { player ->
                player.seekTo(msec)
                _currentPosition.value = msec
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in seekTo: $e")
        }
    }

    fun stopPlayer() {
        try {
            mediaPlayer?.let { player ->
                try {
                    if (player.isPlaying) {
                        player.stop()
                    }
                } catch (e: Exception) {
                    // Ignore isPlaying or stop state error
                }
                player.reset()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in stopPlayer: $e")
        }
        _status.value = PlayerStatus.IDLE
        _currentPosition.value = 0
        _duration.value = 0
        handler.removeCallbacks(updateProgressAction)
    }

    fun releasePlayer() {
        try {
            handler.removeCallbacks(updateProgressAction)
            mediaPlayer?.let { player ->
                try {
                    if (player.isPlaying) {
                        player.stop()
                    }
                } catch (e: Exception) {
                    // Ignore
                }
                player.release()
            }
            mediaPlayer = null
        } catch (e: Exception) {
            Log.e(TAG, "Error in releasePlayer: $e")
        } finally {
            _status.value = PlayerStatus.IDLE
            _currentSuraId.value = null
            _currentPosition.value = 0
            _duration.value = 0
        }
    }

    // --- Media Player Callbacks ---

    override fun onPrepared(mp: MediaPlayer?) {
        try {
            mp?.start()
            _status.value = PlayerStatus.PLAYING
            _duration.value = mp?.duration ?: 0
            handler.post(updateProgressAction)
        } catch (e: Exception) {
            Log.e(TAG, "Error in onPrepared: $e")
            _status.value = PlayerStatus.ERROR
        }
    }

    override fun onError(mp: MediaPlayer?, what: Int, extra: Int): Boolean {
        Log.e(TAG, "MediaPlayer error: what=$what, extra=$extra")
        _status.value = PlayerStatus.ERROR
        handler.removeCallbacks(updateProgressAction)
        // Reset player to recover
        initPlayer()
        return true
    }

    override fun onCompletion(mp: MediaPlayer?) {
        try {
            _status.value = PlayerStatus.IDLE
            _currentPosition.value = 0
            handler.removeCallbacks(updateProgressAction)

            // Auto move to next sura if available!
            val activeSura = _currentSuraId.value ?: return
            if (activeSura < 114) {
                playSura(activeSura + 1)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in onCompletion: $e")
        }
    }
}

package com.mishkat.quran.data

data class SuraMeta(
    val id: Int,
    val name: String,
    val type: String,  // مكية / مدنية
    val totalVerses: Int,
    val startPage: Int,
    val endPage: Int
)

data class Verse(
    val suraId: Int,
    val verseNumber: Int,
    val text: String,
    val translation: String,
    val tafsir: String = "",
    val causeOfRevelation: String = ""
)

data class AiTafsirResult(
    val tafsir: String
)

data class Khatmah(
    val id: Int,
    val name: String,
    val currentWordPageStart: Int,
    val currentWordPageEnd: Int,
    val pagesPerWard: Float
)

fun formatWardGoal(pages: Float): String {
    return if (pages % 1.0f == 0.0f) {
        val count = pages.toInt()
        when {
            count == 1 -> "صفحة واحدة"
            count == 2 -> "صفحتين"
            count in 3..10 -> "$count صفحات"
            else -> "$count صفحة"
        }
    } else {
        "$pages صفحة"
    }
}

# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# Uncomment this to preserve the line number information for
# debugging stack traces.
-keepattributes SourceFile,LineNumberTable,Signature,InnerClasses,EnclosingMethod,*Annotation*

# Hide the original source file name.
-renamesourcefileattribute SourceFile

# --- Preserve Local Models & Network APIs ---
# To ensure JSON parsing (Kotlinx Serialization/Moshi) & Room persistence work perfectly, 
# protect our data models and networking APIs from obfuscation and shrinking.
-keep class com.mishkat.quran.data.** { *; }
-keep class com.mishkat.quran.api.** { *; }

# --- Kotlinx Serialization Generic Rules ---
-keep @kotlinx.serialization.Serializable class * {
    *** Companion;
    *** $serializer;
}
-keepclassmembers class * {
    *** Companion;
    *** $serializer;
}
-keepclassmembers @kotlinx.serialization.Serializable class * {
    <fields>;
}

# --- Room Database Rules ---
-keepclassmembers class * extends androidx.room.RoomDatabase {
    <init>(...);
}
-keep class * extends androidx.room.RoomDatabase
-keep class androidx.room.RoomDatabase
-dontwarn androidx.room.**

# --- Retrofit Rules ---
-keepclassmembers class * {
    @retrofit2.http.* <methods>;
}
-dontwarn retrofit2.**

# --- OkHttp Rules ---
-dontwarn okhttp3.**
-dontwarn okio.**

# --- Moshi Rules ---
-keep class com.squareup.moshi.** { *; }
-keep interface com.squareup.moshi.** { *; }
-dontwarn com.squareup.moshi.**

